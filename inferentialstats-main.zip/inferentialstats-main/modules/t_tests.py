"""
modules/t_tests.py
==================
Analysis runners for the T-Test family.
Each function returns a complete results dict (R) containing:
  - Descriptive statistics
  - Normality test results
  - Parametric test results
  - Non-parametric test results
  - Effect sizes (parametric + non-parametric)
  - All values pre-computed to avoid re-computation in UI and export layers

SPSS-equivalent output for:
  - One-Sample T-Test + Wilcoxon Signed-Rank
  - Paired-Sample T-Test + Wilcoxon Signed-Rank
  - Independent-Sample T-Test + Mann-Whitney U
    (with Levene's test, equal-variance and Welch variants)

Beyond SPSS:
  - Cohen's d for all variants
  - Rank-biserial r with 95% bootstrap CI
  - Post-hoc statistical power analysis

References:
  Cohen (1988). Statistical Power Analysis for the Behavioral Sciences.
  Field (2018). Discovering Statistics Using IBM SPSS Statistics (5th ed.).
"""

import numpy as np
from scipy import stats as scipy_stats

from modules.normality    import test_normality
from modules.descriptive  import (describe_one_sample, describe_paired,
                                   describe_independent, paired_correlation,
                                   ci_mean)
from modules.nonparametric import wilcoxon_signed_rank, mann_whitney_u
from modules.effect_size   import (cohens_d_one_sample, cohens_d_paired,
                                    cohens_d_independent,
                                    rank_biserial_wilcoxon,
                                    rank_biserial_mannwhitney,
                                    bootstrap_ci)
from utils.formatters      import effect_label_d, effect_label_r


# ══════════════════════════════════════════════════════════════════════════════
# ONE-SAMPLE T-TEST
# ══════════════════════════════════════════════════════════════════════════════

def run_one_sample(data, mu0, var_name="Variable", alpha=0.05):
    """
    Run One-Sample T-Test analysis.

    Tests whether the population mean of a single variable differs
    significantly from a specified hypothesised value (μ₀).
    If normality is violated, the Wilcoxon Signed-Rank Test is recommended.

    Parameters
    ----------
    data     : array-like — observed values
    mu0      : float      — hypothesised population mean
    var_name : str        — variable name for display
    alpha    : float      — significance level

    Returns
    -------
    dict R with keys:
        desc          : pd.DataFrame — descriptive statistics
        normality     : list of dict — SW + KS results
        use_param     : bool
        total_n       : int
        parametric    : dict — t-test results
        nonparametric : dict — Wilcoxon results + effect sizes
    """
    R    = {}
    data = np.array(data, dtype=float)
    n    = len(data)

    # ── Descriptives ──────────────────────────────────────────────────────────
    R["desc"]    = describe_one_sample(data, var_name, alpha)
    R["total_n"] = n

    # ── Normality ─────────────────────────────────────────────────────────────
    norm = test_normality(data, var_name, total_n=n)
    R["normality"]  = [norm]
    R["use_param"]  = norm["pass"]

    # ── Parametric: One-Sample T-Test ─────────────────────────────────────────
    t_stat, p_two = scipy_stats.ttest_1samp(data, mu0)
    df   = n - 1
    m    = float(np.mean(data))
    sd   = float(np.std(data, ddof=1))
    tc   = scipy_stats.t.ppf(1 - alpha / 2, df)
    diff = m - mu0
    d    = cohens_d_one_sample(data, mu0)

    R["parametric"] = {
        "test":        "One-Sample T-Test",
        "var_name":    var_name,
        "mu0":         mu0,
        "t":           float(t_stat),
        "df":          df,
        "p_two":       float(p_two),
        "p_one_lower": float(scipy_stats.t.cdf(t_stat, df)),
        "p_one_upper": float(1 - scipy_stats.t.cdf(t_stat, df)),
        "mean_diff":   diff,
        "se_diff":     sd / np.sqrt(n),
        "ci_lower":    diff - tc * (sd / np.sqrt(n)),
        "ci_upper":    diff + tc * (sd / np.sqrt(n)),
        "cohens_d":    d["d"],
        "d_label":     d["label"],
    }

    # ── Non-parametric: Wilcoxon Signed-Rank ──────────────────────────────────
    diff_arr = data - mu0
    w_res    = wilcoxon_signed_rank(diff_arr)
    r_rb     = rank_biserial_wilcoxon(diff_arr)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_wilcoxon, [diff_arr], alpha=alpha)

    R["nonparametric"] = {
        **w_res,
        "test":           "Wilcoxon Signed-Rank Test",
        "var_name":       var_name,
        "mu0":            mu0,
        "rank_biserial_r": float(r_rb) if not np.isnan(r_rb) else np.nan,
        "rb_ci_lower":    float(ci_lo) if not np.isnan(ci_lo) else np.nan,
        "rb_ci_upper":    float(ci_hi) if not np.isnan(ci_hi) else np.nan,
        "rb_label":       effect_label_r(r_rb),
    }

    return R


# ══════════════════════════════════════════════════════════════════════════════
# PAIRED-SAMPLE T-TEST
# ══════════════════════════════════════════════════════════════════════════════

def run_paired(data1, data2, label1="Variable 1",
               label2="Variable 2", alpha=0.05):
    """
    Run Paired-Sample T-Test analysis.

    Tests whether the mean difference between two related variables
    equals zero. If normality of differences is violated,
    the Wilcoxon Signed-Rank Test is recommended.

    Parameters
    ----------
    data1, data2 : array-like
    label1       : str — label for Variable 1 (pre / Time 1)
    label2       : str — label for Variable 2 (post / Time 2)
    alpha        : float

    Returns
    -------
    dict R with keys:
        desc          : pd.DataFrame
        correlation   : pd.DataFrame — Paired Samples Correlations
        normality     : list of dict
        use_param     : bool
        total_n       : int
        parametric    : dict
        nonparametric : dict
    """
    R     = {}
    data1 = np.array(data1, dtype=float)
    data2 = np.array(data2, dtype=float)
    n     = len(data1)
    diff  = data1 - data2

    # ── Descriptives ──────────────────────────────────────────────────────────
    R["desc"]      = describe_paired(data1, data2, label1, label2, alpha)
    R["correlation"] = paired_correlation(data1, data2, label1, label2)
    R["total_n"]   = n

    # ── Normality of differences ───────────────────────────────────────────────
    norm = test_normality(diff, f"{label1} \u2212 {label2}", total_n=n)
    R["normality"] = [norm]
    R["use_param"] = norm["pass"]

    # ── Parametric: Paired T-Test ─────────────────────────────────────────────
    t_stat, p_two = scipy_stats.ttest_rel(data1, data2)
    df      = n - 1
    m_diff  = float(np.mean(diff))
    sd_diff = float(np.std(diff, ddof=1))
    se_diff = sd_diff / np.sqrt(n)
    tc      = scipy_stats.t.ppf(1 - alpha / 2, df)
    d       = cohens_d_paired(diff)

    R["parametric"] = {
        "test":        "Paired Samples T-Test",
        "label1":      label1,
        "label2":      label2,
        "mean_diff":   m_diff,
        "sd_diff":     sd_diff,
        "se_diff":     se_diff,
        "t":           float(t_stat),
        "df":          df,
        "p_two":       float(p_two),
        "p_one_lower": float(scipy_stats.t.cdf(t_stat, df)),
        "p_one_upper": float(1 - scipy_stats.t.cdf(t_stat, df)),
        "ci_lower":    m_diff - tc * se_diff,
        "ci_upper":    m_diff + tc * se_diff,
        "cohens_d":    d["d"],
        "d_label":     d["label"],
    }

    # ── Non-parametric: Wilcoxon Signed-Rank ──────────────────────────────────
    # SPSS convention: differences = Variable2 - Variable1 (POST - PRE)
    diff_spss = data2 - data1
    w_res    = wilcoxon_signed_rank(diff_spss)
    r_rb     = rank_biserial_wilcoxon(diff_spss)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_wilcoxon, [diff_spss], alpha=alpha)

    R["nonparametric"] = {
        **w_res,
        "test":           "Wilcoxon Signed-Rank Test",
        "label1":         label1,
        "label2":         label2,
        "rank_biserial_r": float(r_rb) if not np.isnan(r_rb) else np.nan,
        "rb_ci_lower":    float(ci_lo) if not np.isnan(ci_lo) else np.nan,
        "rb_ci_upper":    float(ci_hi) if not np.isnan(ci_hi) else np.nan,
        "rb_label":       effect_label_r(r_rb),
    }

    return R


# ══════════════════════════════════════════════════════════════════════════════
# INDEPENDENT-SAMPLE T-TEST
# ══════════════════════════════════════════════════════════════════════════════

def run_independent(g1, g2, label1="Group 1", label2="Group 2",
                    dep_var="Score", alpha=0.05):
    """
    Run Independent-Sample T-Test analysis.

    Tests whether the means of a continuous outcome differ between
    two independent groups. Levene's test (center='mean', SPSS default)
    determines whether to use the equal-variance or Welch t-test.
    If normality is violated in either group, Mann-Whitney U is recommended.

    All one-tailed p-values are pre-computed here to ensure consistent
    values across UI, HTML report, and CSV export.

    Parameters
    ----------
    g1, g2   : array-like
    label1   : str
    label2   : str
    dep_var  : str — dependent variable name
    alpha    : float

    Returns
    -------
    dict R with keys:
        desc          : pd.DataFrame
        normality     : list of dict (one per group)
        levene        : dict
        use_param     : bool
        total_n       : int
        parametric    : dict (equal-var + Welch variants)
        nonparametric : dict (Mann-Whitney U + effect sizes)
    """
    R  = {}
    g1 = np.array(g1, dtype=float)
    g2 = np.array(g2, dtype=float)
    n1, n2   = len(g1), len(g2)
    total_n  = n1 + n2
    m1, m2   = float(np.mean(g1)), float(np.mean(g2))
    sd1, sd2 = float(np.std(g1, ddof=1)), float(np.std(g2, ddof=1))

    # ── Descriptives ──────────────────────────────────────────────────────────
    R["desc"]    = describe_independent(g1, g2, label1, label2, alpha)
    R["total_n"] = total_n

    # ── Normality (per group, criterion based on total_n) ─────────────────────
    nr1 = test_normality(g1, label1, total_n=total_n)
    nr2 = test_normality(g2, label2, total_n=total_n)
    R["normality"] = [nr1, nr2]
    R["use_param"] = nr1["pass"] and nr2["pass"]

    # ── Levene's Test — all 4 variants (SPSS-equivalent) ─────────────────────
    def _lev4(a, b, alp):
        groups_ = [a, b]
        k_, N_  = 2, len(a) + len(b)
        ns_     = [len(a), len(b)]
        variants_ = {}
        for ctr in ["mean", "median", "trimmed"]:
            F_, p_ = scipy_stats.levene(a, b, center=ctr)
            variants_[ctr] = {"F": float(F_), "p": float(p_),
                               "df1": 1, "df2": N_ - 2}
        # Median with adjusted df
        meds_  = [float(np.median(g)) for g in groups_]
        zg_    = [np.abs(g - m) for g, m in zip(groups_, meds_)]
        zm_    = [float(np.mean(z)) for z in zg_]
        zgr_   = float(np.mean(np.concatenate(zg_)))
        ss_b_  = sum(n * (zm - zgr_) ** 2 for n, zm in zip(ns_, zm_))
        ss_w_  = sum(float(np.sum((z - zm) ** 2)) for z, zm in zip(zg_, zm_))
        ms_b_  = ss_b_ / 1
        ms_w_  = ss_w_ / (N_ - 2) if N_ > 2 else np.nan
        F_a_   = ms_b_ / ms_w_ if (ms_w_ and ms_w_ > 0) else np.nan
        vz_    = [float(np.var(z, ddof=1)) if len(z) > 1 else 0.0 for z in zg_]
        ci_    = [v / n for v, n in zip(vz_, ns_)]
        cs_    = sum(ci_)
        df2a_  = (cs_ ** 2 / sum(c ** 2 / (n - 1)
                  for c, n in zip(ci_, ns_) if n > 1)
                  if cs_ > 0 else float(N_ - 2))
        pa_    = float(scipy_stats.f.sf(F_a_, 1, df2a_)) \
                 if not np.isnan(F_a_) else np.nan
        variants_["median_adjusted"] = {"F": F_a_, "p": pa_,
                                         "df1": 1, "df2": float(df2a_)}
        eq_ = variants_["mean"]["p"] > alp
        return {"variants": variants_, "equal_var": eq_,
                "F": variants_["mean"]["F"], "Sig.": variants_["mean"]["p"],
                "df1": 1, "df2": N_ - 2, "equal_var": eq_}

    R["levene"] = _lev4(g1, g2, alpha)
    equal_var   = R["levene"]["equal_var"]

    # ── Parametric: Independent T-Test (equal-var + Welch) ────────────────────
    t_eq,    p_eq    = scipy_stats.ttest_ind(g1, g2, equal_var=True)
    t_welch, p_welch = scipy_stats.ttest_ind(g1, g2, equal_var=False)

    df_eq    = n1 + n2 - 2
    df_welch = float(
        (sd1 ** 2 / n1 + sd2 ** 2 / n2) ** 2
        / ((sd1 ** 2 / n1) ** 2 / (n1 - 1)
           + (sd2 ** 2 / n2) ** 2 / (n2 - 1))
    )
    mean_diff = m1 - m2
    se_eq     = float(np.sqrt(
        ((n1 - 1) * sd1 ** 2 + (n2 - 1) * sd2 ** 2) / df_eq
        * (1 / n1 + 1 / n2)
    ))
    se_welch  = float(np.sqrt(sd1 ** 2 / n1 + sd2 ** 2 / n2))
    tc_eq     = scipy_stats.t.ppf(1 - alpha / 2, df_eq)
    tc_welch  = scipy_stats.t.ppf(1 - alpha / 2, df_welch)
    d         = cohens_d_independent(g1, g2)

    # Pre-compute all one-tailed p-values to avoid calling scipy in export layers
    p_eq_lower    = float(scipy_stats.t.cdf(t_eq,    df_eq))
    p_eq_upper    = float(1 - scipy_stats.t.cdf(t_eq,    df_eq))
    p_welch_lower = float(scipy_stats.t.cdf(t_welch, df_welch))
    p_welch_upper = float(1 - scipy_stats.t.cdf(t_welch, df_welch))

    R["parametric"] = {
        "test":          "Independent Samples T-Test",
        "label1":        label1,
        "label2":        label2,
        "dep_var":       dep_var,
        "mean_diff":     mean_diff,
        # Equal-variance t-test
        "t_eq":          float(t_eq),
        "df_eq":         df_eq,
        "p_eq":          float(p_eq),
        "p_eq_lower":    p_eq_lower,
        "p_eq_upper":    p_eq_upper,
        "se_eq":         se_eq,
        "ci_eq_l":       mean_diff - tc_eq * se_eq,
        "ci_eq_u":       mean_diff + tc_eq * se_eq,
        # Welch t-test
        "t_welch":       float(t_welch),
        "df_welch":      df_welch,
        "p_welch":       float(p_welch),
        "p_welch_lower": p_welch_lower,
        "p_welch_upper": p_welch_upper,
        "se_welch":      se_welch,
        "ci_welch_l":    mean_diff - tc_welch * se_welch,
        "ci_welch_u":    mean_diff + tc_welch * se_welch,
        # Effect size
        "cohens_d":      d["d"],
        "d_label":       d["label"],
        "sd_pooled":     d["sd_pooled"],
    }

    # ── Non-parametric: Mann-Whitney U ─────────────────────────────────────────
    mw_res   = mann_whitney_u(g1, g2, label1, label2)
    r_rb     = rank_biserial_mannwhitney(g1, g2)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_mannwhitney, [g1, g2], alpha=alpha)

    R["nonparametric"] = {
        **mw_res,
        "test":           "Mann-Whitney U Test",
        "dep_var":        dep_var,
        "rank_biserial_r": float(r_rb) if not np.isnan(r_rb) else np.nan,
        "rb_ci_lower":    float(ci_lo) if not np.isnan(ci_lo) else np.nan,
        "rb_ci_upper":    float(ci_hi) if not np.isnan(ci_hi) else np.nan,
        "rb_label":       effect_label_r(r_rb),
    }

    return R


# ══════════════════════════════════════════════════════════════════════════════
# ACTIVE TEST SELECTOR
# ══════════════════════════════════════════════════════════════════════════════

def get_active_test(R):
    """
    Return the name of the recommended test based on normality results.

    Parameters
    ----------
    R : dict — output of run_*()

    Returns
    -------
    str — name of the recommended test
    """
    test_type = R["parametric"]["test"]
    use_param = R["use_param"]

    if use_param:
        return test_type
    else:
        np_test = R["nonparametric"]["test"]
        return np_test


def get_active_results(R):
    """
    Return the recommended results dict (parametric or non-parametric)
    based on normality.

    Parameters
    ----------
    R : dict — output of run_*()

    Returns
    -------
    dict — either R['parametric'] or R['nonparametric']
    """
    return R["parametric"] if R["use_param"] else R["nonparametric"]


def get_primary_p(R):
    """
    Return the primary p-value (2-tailed) from the recommended test.

    For Independent T-Test, returns p based on Levene's test result:
      - equal variances assumed  → p_eq
      - equal variances not assumed → p_welch

    Parameters
    ----------
    R : dict

    Returns
    -------
    float
    """
    if R["use_param"]:
        pr = R["parametric"]
        if "p_two" in pr:
            return pr["p_two"]
        elif "levene" in R:
            return pr["p_eq"] if R["levene"]["equal_var"] else pr["p_welch"]
        else:
            return pr.get("p_eq", np.nan)
    else:
        return R["nonparametric"].get("p", np.nan)
