"""
modules/effect_size.py
======================
Effect size calculations for all statistical tests.
Includes parametric and non-parametric measures,
with bootstrap confidence intervals where applicable.

All measures go beyond standard SPSS output.

References:
  Cohen, J. (1988). Statistical power analysis for the behavioral sciences
    (2nd ed.). Lawrence Erlbaum Associates.
  Kerby, D. S. (2014). The simple difference formula: An approach to teaching
    nonparametric correlation. Comprehensive Psychology, 3, 11.IT.3.1.
  Efron, B., & Tibshirani, R. J. (1993). An introduction to the bootstrap.
    Chapman & Hall.
  Field, A. (2018). Discovering statistics using IBM SPSS statistics
    (5th ed.). SAGE Publications.
  Fritz, C. O., Morris, P. E., & Richler, J. J. (2012). Effect size
    estimates: Current use, calculations, and interpretation.
    Journal of Experimental Psychology: General, 141(1), 2-18.
"""

import numpy as np
from scipy import stats as scipy_stats
from collections import Counter
from utils.formatters import effect_label_d, effect_label_r, effect_label_eta2


# ══════════════════════════════════════════════════════════════════════════════
# PARAMETRIC EFFECT SIZES
# ══════════════════════════════════════════════════════════════════════════════

def cohens_d_one_sample(data, mu0):
    """
    Cohen's d for One-Sample T-Test.
    d = (M - μ₀) / SD

    Interpretation (Cohen, 1988):
      |d| < .20  → negligible
      .20–.49    → small
      .50–.79    → medium
      ≥ .80      → large

    Parameters
    ----------
    data : array-like
    mu0  : float — hypothesised population mean

    Returns
    -------
    dict with keys: d, label, formula
    """
    data = np.array(data, dtype=float)
    sd   = np.std(data, ddof=1)
    d    = float((np.mean(data) - mu0) / sd) if sd > 0 else np.nan
    return {
        "d":       d,
        "label":   effect_label_d(d),
        "formula": "d = (M - \u03bc\u2080) / SD",
    }


def cohens_d_paired(diff):
    """
    Cohen's d for Paired-Sample T-Test.
    d = M_diff / SD_diff

    Parameters
    ----------
    diff : array-like — differences (data1 - data2)

    Returns
    -------
    dict with keys: d, label, formula
    """
    diff = np.array(diff, dtype=float)
    sd   = np.std(diff, ddof=1)
    d    = float(np.mean(diff) / sd) if sd > 0 else np.nan
    return {
        "d":       d,
        "label":   effect_label_d(d),
        "formula": "d = M\u1d48\u1d49\u1d3c\u1da0 / SD\u1d48\u1d49\u1d3c\u1da0",
    }


def cohens_d_independent(g1, g2):
    """
    Cohen's d for Independent-Sample T-Test.
    Uses pooled standard deviation (SPSS method).
    d = (M1 - M2) / SD_pooled

    Parameters
    ----------
    g1, g2 : array-like

    Returns
    -------
    dict with keys: d, label, formula, sd_pooled, mean_diff
    """
    g1   = np.array(g1, dtype=float)
    g2   = np.array(g2, dtype=float)
    n1, n2 = len(g1), len(g2)
    sp   = np.sqrt(
        ((n1 - 1) * np.var(g1, ddof=1) + (n2 - 1) * np.var(g2, ddof=1))
        / (n1 + n2 - 2)
    )
    d    = float((np.mean(g1) - np.mean(g2)) / sp) if sp > 0 else np.nan
    return {
        "d":         d,
        "label":     effect_label_d(d),
        "formula":   "d = (M\u2081 \u2212 M\u2082) / SD\u209a\u2092\u2092\u2097\u2091\u2093",
        "sd_pooled": float(sp),
        "mean_diff": float(np.mean(g1) - np.mean(g2)),
    }


def eta_squared_anova(ss_between, ss_total):
    """
    Eta-squared (η²) for One-Way ANOVA.
    η² = SS_between / SS_total

    Parameters
    ----------
    ss_between : float
    ss_total   : float

    Returns
    -------
    dict with keys: eta2, label, formula
    """
    eta2 = float(ss_between / ss_total) if ss_total > 0 else np.nan
    return {
        "eta2":    eta2,
        "label":   effect_label_eta2(eta2),
        "formula": "\u03b7\u00b2 = SS\u1d47\u1d49\u1d57\u1d42\u1d49\u1d49\u1d4f / SS\u1d40\u1d52\u1d57\u1d43\u1d38",
    }


def partial_eta_squared(ss_effect, ss_effect_plus_ss_error):
    """
    Partial eta-squared (η²p) for factorial designs and ANCOVA.
    η²p = SS_effect / (SS_effect + SS_error)

    Parameters
    ----------
    ss_effect              : float
    ss_effect_plus_ss_error : float

    Returns
    -------
    dict with keys: partial_eta2, label, formula
    """
    eta2p = (float(ss_effect / ss_effect_plus_ss_error)
             if ss_effect_plus_ss_error > 0 else np.nan)
    return {
        "partial_eta2": eta2p,
        "label":        effect_label_eta2(eta2p),
        "formula":      "\u03b7\u00b2\u209a = SS\u1d49\u1da0\u1da0\u1d49\u1d9c\u1d40 / (SS\u1d49\u1da0\u1da0\u1d49\u1d9c\u1d40 + SS\u1d49\u02b3\u02b3\u1d52\u02b3)",
    }


def omega_squared_anova(ss_between, df_between, ms_within, ss_total, n_total):
    """
    Omega-squared (ω²) for One-Way ANOVA.
    Less biased than η². Recommended for reporting (Field, 2018).
    ω² = (SS_between - df_between × MS_within) /
          (SS_total + MS_within)

    Parameters
    ----------
    ss_between : float
    df_between : int
    ms_within  : float
    ss_total   : float
    n_total    : int

    Returns
    -------
    dict with keys: omega2, label, formula
    """
    numerator   = ss_between - df_between * ms_within
    denominator = ss_total + ms_within
    omega2      = float(numerator / denominator) if denominator > 0 else np.nan
    # Clamp to [0, 1] — can be slightly negative for very small effects
    if not np.isnan(omega2):
        omega2 = max(0.0, min(1.0, omega2))
    return {
        "omega2":  omega2,
        "label":   effect_label_eta2(omega2),
        "formula": "\u03c9\u00b2 = (SS\u1d47 \u2212 df\u1d47 \u00d7 MS\u1d42) / (SS\u1d40 + MS\u1d42)",
    }


# ══════════════════════════════════════════════════════════════════════════════
# NON-PARAMETRIC EFFECT SIZES
# ══════════════════════════════════════════════════════════════════════════════

def rank_biserial_mannwhitney(g1, g2):
    """
    Rank-biserial correlation r for Mann-Whitney U Test.
    r = 1 - (2U) / (n1 × n2)

    Range: [-1, 1]
    Interpretation (Kerby, 2014):
      |r| < .10  → negligible
      .10–.29    → small
      .30–.49    → medium
      ≥ .50      → large

    Parameters
    ----------
    g1, g2 : array-like

    Returns
    -------
    float
    """
    g1 = np.array(g1, dtype=float)
    g2 = np.array(g2, dtype=float)
    n1, n2 = len(g1), len(g2)
    # Count concordant pairs (g1 > g2)
    U1 = sum(
        1 if x > y else 0.5 if x == y else 0
        for x in g1 for y in g2
    )
    r = 1 - (2 * U1) / (n1 * n2)
    return float(r)


def rank_biserial_wilcoxon(diff_arr):
    """
    Rank-biserial correlation r for Wilcoxon Signed-Rank Test.
    r = (T+ - T-) / (T+ + T-)

    Parameters
    ----------
    diff_arr : array-like — differences (data1 - data2 or data - μ₀)

    Returns
    -------
    float
    """
    diff_arr = np.array(diff_arr, dtype=float)
    diff_nz  = diff_arr[diff_arr != 0]
    if len(diff_nz) < 1:
        return np.nan
    abs_d  = np.abs(diff_nz)
    ranks  = scipy_stats.rankdata(abs_d)
    pos_rs = float(np.sum(ranks[diff_nz > 0]))
    neg_rs = float(np.sum(ranks[diff_nz < 0]))
    total  = pos_rs + neg_rs
    return float((pos_rs - neg_rs) / total) if total > 0 else np.nan


# ══════════════════════════════════════════════════════════════════════════════
# BOOTSTRAP CONFIDENCE INTERVALS
# ══════════════════════════════════════════════════════════════════════════════

def bootstrap_ci(effect_fn, data_args, n_boot=2000, alpha=0.05, seed=42):
    """
    Compute bootstrap percentile confidence interval for any effect size.

    Parameters
    ----------
    effect_fn  : callable — function that takes *data_args and returns float
    data_args  : list of array-like — data arrays to resample
    n_boot     : int   — number of bootstrap resamples (default 2000)
    alpha      : float — significance level (default .05 → 95% CI)
    seed       : int   — random seed for reproducibility

    Returns
    -------
    tuple of (lower, upper) : float, float
        Returns (np.nan, np.nan) if insufficient bootstrap samples.

    References
    ----------
    Efron & Tibshirani (1993). An introduction to the bootstrap.
    """
    rng         = np.random.default_rng(seed)
    boot_values = []

    for _ in range(n_boot):
        resampled = []
        for arr in data_args:
            arr = np.array(arr, dtype=float)
            resampled.append(rng.choice(arr, size=len(arr), replace=True))
        try:
            val = effect_fn(*resampled)
            if not np.isnan(val):
                boot_values.append(val)
        except Exception:
            pass

    if len(boot_values) < max(10, n_boot * 0.05):
        return np.nan, np.nan

    lo = float(np.percentile(boot_values, 100 * alpha / 2))
    hi = float(np.percentile(boot_values, 100 * (1 - alpha / 2)))
    return lo, hi


# ══════════════════════════════════════════════════════════════════════════════
# COMPLETE EFFECT SIZE BUNDLES
# ══════════════════════════════════════════════════════════════════════════════

def compute_es_one_sample(data, mu0, alpha=0.05):
    """
    Compute all effect sizes for One-Sample T-Test.

    Parameters
    ----------
    data  : array-like
    mu0   : float
    alpha : float

    Returns
    -------
    dict with keys:
        cohens_d      : dict
        rank_biserial : float
        rb_ci_lower   : float
        rb_ci_upper   : float
        rb_label      : str
    """
    data = np.array(data, dtype=float)
    diff = data - mu0

    d_res = cohens_d_one_sample(data, mu0)
    r_rb  = rank_biserial_wilcoxon(diff)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_wilcoxon, [diff], alpha=alpha)

    return {
        "cohens_d":      d_res,
        "rank_biserial": r_rb,
        "rb_ci_lower":   ci_lo,
        "rb_ci_upper":   ci_hi,
        "rb_label":      effect_label_r(r_rb),
    }


def compute_es_paired(data1, data2, alpha=0.05):
    """
    Compute all effect sizes for Paired-Sample T-Test.

    Parameters
    ----------
    data1, data2 : array-like
    alpha        : float

    Returns
    -------
    dict with keys:
        cohens_d      : dict
        rank_biserial : float
        rb_ci_lower   : float
        rb_ci_upper   : float
        rb_label      : str
    """
    data1 = np.array(data1, dtype=float)
    data2 = np.array(data2, dtype=float)
    diff  = data1 - data2

    d_res = cohens_d_paired(diff)
    r_rb  = rank_biserial_wilcoxon(diff)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_wilcoxon, [diff], alpha=alpha)

    return {
        "cohens_d":      d_res,
        "rank_biserial": r_rb,
        "rb_ci_lower":   ci_lo,
        "rb_ci_upper":   ci_hi,
        "rb_label":      effect_label_r(r_rb),
    }


def compute_es_independent(g1, g2, alpha=0.05):
    """
    Compute all effect sizes for Independent-Sample T-Test.

    Parameters
    ----------
    g1, g2 : array-like
    alpha  : float

    Returns
    -------
    dict with keys:
        cohens_d      : dict
        rank_biserial : float
        rb_ci_lower   : float
        rb_ci_upper   : float
        rb_label      : str
    """
    g1 = np.array(g1, dtype=float)
    g2 = np.array(g2, dtype=float)

    d_res = cohens_d_independent(g1, g2)
    r_rb  = rank_biserial_mannwhitney(g1, g2)
    ci_lo, ci_hi = bootstrap_ci(
        rank_biserial_mannwhitney, [g1, g2], alpha=alpha)

    return {
        "cohens_d":      d_res,
        "rank_biserial": r_rb,
        "rb_ci_lower":   ci_lo,
        "rb_ci_upper":   ci_hi,
        "rb_label":      effect_label_r(r_rb),
    }
