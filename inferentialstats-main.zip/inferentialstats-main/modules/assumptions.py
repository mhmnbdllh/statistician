"""
modules/assumptions.py
======================
Assumption testing functions for all statistical tests.

Includes:
  - Levene's Test for Equality of Variances (t-tests, ANOVA)
  - Mauchly's Test of Sphericity (Repeated Measures ANOVA)
  - Box's M Test (MANOVA — placeholder)
  - Homogeneity of Regression Slopes (ANCOVA)
  - Assumption summary builder for all tests

SPSS Notes:
  1. Levene's test uses center='mean' (SPSS default)
  2. Mauchly's test uses the chi-squared approximation (SPSS method)
  3. Greenhouse-Geisser and Huynh-Feldt corrections computed when
     sphericity is violated

References:
  Levene (1960). Robust tests for equality of variances. In I. Olkin (Ed.),
    Contributions to Probability and Statistics. Stanford University Press.
  Mauchly (1940). Significance test for sphericity.
    Annals of Mathematical Statistics, 11(2), 204-209.
  Greenhouse & Geisser (1959). On methods in the analysis of profile data.
    Psychometrika, 24(2), 95-112.
  Huynh & Feldt (1976). Estimation of the Box correction for degrees of
    freedom from sample data in the randomized block and split-plot designs.
    Journal of Educational Statistics, 1(1), 69-82.
  Field (2018). Discovering Statistics Using IBM SPSS Statistics (5th ed.).
"""

import numpy as np
from scipy import stats as scipy_stats


# ══════════════════════════════════════════════════════════════════════════════
# LEVENE'S TEST FOR EQUALITY OF VARIANCES
# ══════════════════════════════════════════════════════════════════════════════

def levene_test(*groups, alpha=0.05):
    """
    Levene's Test for Equality of Variances.
    Uses center='mean' (SPSS default).

    Parameters
    ----------
    *groups : array-like — two or more groups
    alpha   : float

    Returns
    -------
    dict with keys:
        F         : float
        df1       : int
        df2       : int
        Sig.      : float
        equal_var : bool — True if p > alpha (equal variances assumed)
        result    : str  — human-readable result
        note      : str  — which t-test row to use
    """
    groups   = [np.array(g, dtype=float) for g in groups]
    ns       = [len(g) for g in groups]
    N        = sum(ns)
    k        = len(groups)
    lev_f, lev_p = scipy_stats.levene(*groups, center="mean")
    equal_var    = float(lev_p) > alpha

    return {
        "F":         float(lev_f),
        "df1":       k - 1,
        "df2":       N - k,
        "Sig.":      float(lev_p),
        "equal_var": equal_var,
        "result":    ("Equal variances assumed"
                      if equal_var
                      else "Equal variances not assumed (Welch correction applied)"),
        "note":      ("p > .05 \u2192 use equal-variance row."
                      if equal_var
                      else "p \u2264 .05 \u2192 use Welch correction row."),
    }


# ══════════════════════════════════════════════════════════════════════════════
# MAUCHLY'S TEST OF SPHERICITY
# ══════════════════════════════════════════════════════════════════════════════

def mauchly_test(data_wide):
    """
    Mauchly's Test of Sphericity for Repeated Measures ANOVA.
    Uses the chi-squared approximation (SPSS method).

    Sphericity assumption: the variances of the differences between
    all pairs of repeated measures are equal.

    Parameters
    ----------
    data_wide : 2D array-like (n_subjects × n_timepoints)

    Returns
    -------
    dict with keys:
        W                    : float — Mauchly's W statistic
        chi2                 : float — approximated chi-squared
        df                   : int
        p                    : float
        sphericity_assumed   : bool  — True if p > .05
        epsilon_gg           : float — Greenhouse-Geisser epsilon
        epsilon_hf           : float — Huynh-Feldt epsilon
        epsilon_lb           : float — Lower-bound epsilon (1/(k-1))
        correction_recommended : str
    """
    data_wide = np.array(data_wide, dtype=float)
    n, k      = data_wide.shape

    if k < 3:
        return {
            "W": np.nan, "chi2": np.nan, "df": 0,
            "p": np.nan, "sphericity_assumed": True,
            "epsilon_gg": 1.0, "epsilon_hf": 1.0, "epsilon_lb": 1.0,
            "correction_recommended": "Not applicable (k < 3)",
        }

    # Centre the data (subtract row means)
    centered = data_wide - data_wide.mean(axis=1, keepdims=True)

    # Covariance matrix of centred data
    S = np.cov(centered.T)

    # Mauchly's W
    try:
        det_S      = np.linalg.det(S)
        trace_S    = np.trace(S)
        p_minus_1  = k - 1
        W          = det_S / (trace_S / p_minus_1) ** p_minus_1

        # Chi-squared approximation (Mauchly, 1940)
        f          = 1 - (2 * p_minus_1 ** 2 + p_minus_1 + 2) / (6 * p_minus_1 * (n - 1))
        df         = p_minus_1 * (p_minus_1 + 1) // 2 - 1
        chi2       = -np.log(W) * (n - 1) * f if W > 0 else np.nan
        p          = float(scipy_stats.chi2.sf(chi2, df)) if not np.isnan(chi2) else np.nan
    except Exception:
        W = chi2 = p = np.nan
        df = 0

    sphericity_assumed = (not np.isnan(p)) and (p > 0.05)

    # Greenhouse-Geisser epsilon
    epsilon_gg = _greenhouse_geisser(S, k)

    # Huynh-Feldt epsilon
    epsilon_hf = _huynh_feldt(epsilon_gg, n, k)

    # Lower bound epsilon
    epsilon_lb = 1.0 / (k - 1)

    # Correction recommendation
    if sphericity_assumed:
        correction = "None required (sphericity assumed)"
    elif epsilon_gg >= 0.75:
        correction = "Huynh-Feldt correction recommended (\u03b5 \u2265 .75)"
    else:
        correction = "Greenhouse-Geisser correction recommended (\u03b5 < .75)"

    return {
        "W":                       float(W) if not np.isnan(W) else np.nan,
        "chi2":                    float(chi2) if not np.isnan(chi2) else np.nan,
        "df":                      df,
        "p":                       p,
        "sphericity_assumed":      sphericity_assumed,
        "epsilon_gg":              float(epsilon_gg),
        "epsilon_hf":              float(epsilon_hf),
        "epsilon_lb":              float(epsilon_lb),
        "correction_recommended":  correction,
    }


def _greenhouse_geisser(S, k):
    """
    Compute Greenhouse-Geisser epsilon from the covariance matrix S.
    """
    try:
        p         = k - 1  # number of levels minus 1
        trace_S   = np.trace(S)
        trace_S2  = np.trace(S @ S)
        ones      = np.ones((k, k))
        trace_ones_S = np.trace(ones @ S)

        numerator   = (p * trace_S) ** 2
        denominator = (
            p * (trace_S2 - (2 / p) * (S @ ones).diagonal().sum()
                 + (1 / p ** 2) * trace_ones_S)
        )
        # Simplified formula (Greenhouse & Geisser, 1959)
        # More robust version:
        eigenvalues = np.linalg.eigvalsh(S)
        eigenvalues = eigenvalues[eigenvalues > 1e-10]
        if len(eigenvalues) == 0:
            return 1.0
        num = np.sum(eigenvalues) ** 2
        den = (len(eigenvalues) - 1) * np.sum(eigenvalues ** 2)
        eps = num / den if den > 0 else 1.0
        return float(np.clip(eps, 1.0 / (k - 1), 1.0))
    except Exception:
        return 1.0


def _huynh_feldt(epsilon_gg, n, k):
    """
    Compute Huynh-Feldt epsilon as a correction to Greenhouse-Geisser.
    """
    try:
        p   = k - 1
        num = n * p * epsilon_gg - 2
        den = p * (n - 1 - p * epsilon_gg)
        eps = num / den if den > 0 else 1.0
        return float(np.clip(eps, epsilon_gg, 1.0))
    except Exception:
        return 1.0


# ══════════════════════════════════════════════════════════════════════════════
# HOMOGENEITY OF REGRESSION SLOPES  (ANCOVA)
# ══════════════════════════════════════════════════════════════════════════════

def homogeneity_of_regression_slopes(groups_data, covariate_data,
                                      group_labels=None):
    """
    Test for homogeneity of regression slopes — a key ANCOVA assumption.
    A significant interaction (group × covariate) violates this assumption.

    Tests whether the slope of the covariate-outcome relationship
    is equal across all groups via an interaction F-test.

    Parameters
    ----------
    groups_data    : list of array-like — outcome per group
    covariate_data : list of array-like — covariate per group
    group_labels   : list of str or None

    Returns
    -------
    dict with keys:
        F             : float — interaction F-statistic
        df1           : int
        df2           : int
        p             : float
        assumption_met : bool — True if p > .05
        slopes        : list of float — regression slope per group
        note          : str
    """
    groups_data    = [np.array(g, dtype=float) for g in groups_data]
    covariate_data = [np.array(c, dtype=float) for c in covariate_data]
    k              = len(groups_data)

    if group_labels is None:
        group_labels = [f"Group {i+1}" for i in range(k)]

    # Compute regression slope per group
    slopes = []
    for y, x in zip(groups_data, covariate_data):
        if len(x) > 1:
            slope, _, _, _, _ = scipy_stats.linregress(x, y)
            slopes.append(float(slope))
        else:
            slopes.append(np.nan)

    # Full model: outcome ~ group + covariate + group×covariate
    # Reduced model: outcome ~ group + covariate
    # F-test for the interaction term
    try:
        all_y = np.concatenate(groups_data)
        all_x = np.concatenate(covariate_data)
        N     = len(all_y)

        # Group indicator variables (dummy coding)
        group_idx = np.concatenate([
            np.full(len(g), i) for i, g in enumerate(groups_data)
        ])
        dummies = np.eye(k)[group_idx][:, :-1]  # drop last for identifiability

        # Reduced model: y ~ intercept + group_dummies + covariate
        X_red = np.column_stack([np.ones(N), dummies, all_x])
        # Full model: y ~ intercept + group_dummies + covariate + interactions
        interactions = dummies * all_x[:, np.newaxis]
        X_full = np.column_stack([X_red, interactions])

        # OLS via normal equations
        def ols_rss(X, y):
            try:
                beta = np.linalg.lstsq(X, y, rcond=None)[0]
                return float(np.sum((y - X @ beta) ** 2))
            except Exception:
                return np.nan

        rss_red  = ols_rss(X_red, all_y)
        rss_full = ols_rss(X_full, all_y)
        df1      = k - 1          # number of interaction terms
        df2      = N - X_full.shape[1]

        if rss_full is None or np.isnan(rss_full) or df2 <= 0:
            raise ValueError("Insufficient degrees of freedom")

        F = ((rss_red - rss_full) / df1) / (rss_full / df2)
        p = float(scipy_stats.f.sf(F, df1, df2))

    except Exception:
        F = p = np.nan
        df1 = df2 = 0

    assumption_met = (not np.isnan(p)) and (p > 0.05)

    return {
        "F":              float(F) if not np.isnan(F) else np.nan,
        "df1":            df1,
        "df2":            df2,
        "p":              p,
        "assumption_met": assumption_met,
        "slopes":         slopes,
        "group_labels":   group_labels,
        "note":           (
            "p > .05: Homogeneity of regression slopes assumed. "
            "ANCOVA is appropriate."
            if assumption_met else
            "p \u2264 .05: Homogeneity of regression slopes violated. "
            "The relationship between covariate and outcome differs across groups. "
            "Consider Johnson-Neyman procedure or separate regressions."
        ),
    }


# ══════════════════════════════════════════════════════════════════════════════
# ASSUMPTION SUMMARY BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_assumption_summary(R, test_type):
    """
    Build a structured assumption summary for any test type.
    Returns a list of dicts for table display and export.

    Each dict has keys: assumption, test, statistic, sig, result, decision.

    Parameters
    ----------
    R         : dict — results dict from run_*()
    test_type : str

    Returns
    -------
    list of dict
    """
    rows = []

    # ── Normality ──────────────────────────────────────────────────────────────
    from utils.formatters import _f, _p
    for nm in R.get("normality", []):
        is_sw_pri = nm["primary_label"] == "Shapiro-Wilk"
        is_ks_pri = nm["primary_label"] == "Kolmogorov-Smirnov"

        rows.append({
            "assumption": f"Normality \u2014 {nm['label']}",
            "test":       f"Shapiro-Wilk{'*' if is_sw_pri else ''}",
            "statistic":  f"W = {_f(nm['sw_W'])}",
            "sig":        _p(nm["sw_p"]),
            "result":     "Normal" if nm["sw_pass"] else "Non-Normal",
            "role":       "Primary criterion" if is_sw_pri else "Supplementary",
            "decision":   "Parametric eligible" if nm["pass"]
                          else "Non-parametric required",
        })
        rows.append({
            "assumption": "",
            "test":       f"KS Lilliefors{'*' if is_ks_pri else ''}",
            "statistic":  f"D = {_f(nm['ks_D'])}",
            "sig":        _p(nm["ks_p"]),
            "result":     "Normal" if nm["ks_pass"] else "Non-Normal",
            "role":       "Primary criterion" if is_ks_pri else "Supplementary",
            "decision":   "Parametric eligible" if nm["pass"]
                          else "Non-parametric required",
        })

    # ── Levene's Test ──────────────────────────────────────────────────────────
    if "levene" in R:
        lev = R["levene"]
        rows.append({
            "assumption": "Homogeneity of Variance",
            "test":       "Levene's Test (center = mean)",
            "statistic":  f"F({lev['df1']}, {lev['df2']}) = {_f(lev['F'])}",
            "sig":        _p(lev["Sig."]),
            "result":     "Satisfied" if lev["equal_var"] else "Violated",
            "role":       "Required",
            "decision":   "Equal variances assumed" if lev["equal_var"]
                          else "Welch correction applied",
        })

    # ── Mauchly's Sphericity ───────────────────────────────────────────────────
    if "mauchly" in R:
        mau = R["mauchly"]
        rows.append({
            "assumption": "Sphericity",
            "test":       "Mauchly's Test",
            "statistic":  f"W = {_f(mau['W'])}",
            "sig":        _p(mau["p"]),
            "result":     "Satisfied" if mau["sphericity_assumed"]
                          else "Violated",
            "role":       "Required",
            "decision":   mau["correction_recommended"],
        })

    # ── Homogeneity of Regression Slopes ──────────────────────────────────────
    if "homogeneity_slopes" in R:
        hrs = R["homogeneity_slopes"]
        rows.append({
            "assumption": "Homogeneity of Regression Slopes",
            "test":       "Group \u00d7 Covariate Interaction F-test",
            "statistic":  (f"F({hrs['df1']}, {hrs['df2']}) = {_f(hrs['F'])}"
                           if not np.isnan(hrs.get("F", np.nan)) else "."),
            "sig":        _p(hrs.get("p", np.nan)),
            "result":     "Satisfied" if hrs["assumption_met"] else "Violated",
            "role":       "Required for ANCOVA",
            "decision":   hrs["note"],
        })

    # ── Overall Decision ───────────────────────────────────────────────────────
    use_p    = R.get("use_param", True)
    prim_lbl = R["normality"][0]["primary_label"] if R.get("normality") else "N/A"
    total_n  = R.get("total_n", 0)

    rows.append({
        "assumption": "Overall Decision",
        "test":       f"Primary criterion: {prim_lbl}",
        "statistic":  f"Total N = {total_n}",
        "sig":        "\u2014",
        "result":     "Parametric" if use_p else "Non-parametric",
        "role":       "Decision",
        "decision":   "T-Test applied" if use_p else "Wilcoxon / Mann-Whitney U",
    })

    return rows


# ══════════════════════════════════════════════════════════════════════════════
# VARIANCE INFLATION FACTOR  (Multicollinearity — for Regression)
# ══════════════════════════════════════════════════════════════════════════════

def compute_vif(X):
    """
    Compute Variance Inflation Factor (VIF) for each predictor.
    VIF > 10 indicates problematic multicollinearity.
    VIF > 5 warrants caution.

    Parameters
    ----------
    X : 2D array-like (n_obs × n_predictors) — predictor matrix (no intercept)

    Returns
    -------
    list of float — VIF for each column of X
    """
    X   = np.array(X, dtype=float)
    k   = X.shape[1]
    vif = []
    for i in range(k):
        y_i  = X[:, i]
        X_i  = np.delete(X, i, axis=1)
        X_i  = np.column_stack([np.ones(len(y_i)), X_i])
        try:
            beta = np.linalg.lstsq(X_i, y_i, rcond=None)[0]
            y_hat = X_i @ beta
            ss_res = np.sum((y_i - y_hat) ** 2)
            ss_tot = np.sum((y_i - np.mean(y_i)) ** 2)
            r2  = 1 - ss_res / ss_tot if ss_tot > 0 else 0
            vif.append(float(1 / (1 - r2)) if r2 < 1 else np.inf)
        except Exception:
            vif.append(np.nan)
    return vif


# ══════════════════════════════════════════════════════════════════════════════
# DURBIN-WATSON TEST  (Autocorrelation — for Regression)
# ══════════════════════════════════════════════════════════════════════════════

def durbin_watson(residuals):
    """
    Compute the Durbin-Watson statistic to detect autocorrelation in residuals.
    Values near 2 indicate no autocorrelation.
    < 1.5 or > 2.5 warrant concern.

    Parameters
    ----------
    residuals : array-like

    Returns
    -------
    dict with keys: dw, interpretation
    """
    residuals = np.array(residuals, dtype=float)
    diff      = np.diff(residuals)
    dw        = float(np.sum(diff ** 2) / np.sum(residuals ** 2))

    if dw < 1.5:
        interpretation = "Positive autocorrelation detected (DW < 1.5)"
    elif dw > 2.5:
        interpretation = "Negative autocorrelation detected (DW > 2.5)"
    else:
        interpretation = "No substantial autocorrelation (1.5 \u2264 DW \u2264 2.5)"

    return {"dw": dw, "interpretation": interpretation}
