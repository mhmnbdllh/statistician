"""
modules/normality.py
====================
Normality testing using Shapiro-Wilk and Kolmogorov-Smirnov
(Lilliefors significance correction).

Primary decision criterion is based on TOTAL N of the analysis:
  total_n <  50 : Shapiro-Wilk recommended
  total_n >= 50 : Kolmogorov-Smirnov (Lilliefors) recommended

References:
  Razali & Wah (2011). Power comparisons of Shapiro-Wilk,
    Kolmogorov-Smirnov, Lilliefors and Anderson-Darling tests.
    Journal of Statistical Modeling and Analytics, 2(1), 21-33.
  Shapiro & Wilk (1965). An analysis of variance test for normality.
    Biometrika, 52(3-4), 591-611.
  Lilliefors (1967). On the Kolmogorov-Smirnov test for normality
    with mean and variance unknown.
    Journal of the American Statistical Association, 62(318), 399-402.
  Field (2018). Discovering Statistics Using IBM SPSS Statistics (5th ed.).
"""

import numpy as np
from scipy import stats as scipy_stats
from statsmodels.stats.diagnostic import lilliefors


# ══════════════════════════════════════════════════════════════════════════════
# CORE TEST FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def test_normality(data, label="", total_n=None):
    """
    Run both Shapiro-Wilk and Kolmogorov-Smirnov (Lilliefors correction)
    normality tests on a data array.

    Primary decision criterion is based on TOTAL N of the analysis,
    not the per-group or per-variable n:
      total_n <  50  →  Shapiro-Wilk is recommended
      total_n >= 50  →  Kolmogorov-Smirnov (Lilliefors) is recommended

    For Independent-Sample T-Test, pass total_n = n1 + n2.
    For One-Sample and Paired tests, total_n = n of the variable/difference.
    If total_n is not provided, per-sample n is used as fallback.

    Parameters
    ----------
    data    : array-like  — numeric data to test
    label   : str         — label for this variable/group (for display)
    total_n : int or None — total N of the analysis (see note above)

    Returns
    -------
    dict with keys:
        label         : str
        n             : int  — sample size of this array
        total_n       : int  — total N used for criterion selection
        sw_W          : float
        sw_p          : float
        sw_pass       : bool  — True if SW p > .05
        ks_D          : float
        ks_p          : float
        ks_pass       : bool  — True if KS p >= .05
        primary       : str   — 'sw' or 'ks'
        primary_label : str   — 'Shapiro-Wilk' or 'Kolmogorov-Smirnov'
        pass          : bool  — decision based on primary criterion
    """
    data  = np.array(data, dtype=float)
    n     = len(data)
    n_ref = total_n if total_n is not None else n

    result = {"label": label, "n": n, "total_n": n_ref}

    # ── Minimum sample size check ───────────────────────────────────────────
    if n < 3:
        result.update({
            "sw_W": np.nan, "sw_p": np.nan, "sw_pass": False,
            "ks_D": np.nan, "ks_p": np.nan, "ks_pass": False,
            "pass": False, "primary": "sw",
            "primary_label": "Shapiro-Wilk"
        })
        return result

    # ── Shapiro-Wilk ────────────────────────────────────────────────────────
    sw_W, sw_p = scipy_stats.shapiro(data)
    result["sw_W"]    = float(sw_W)
    result["sw_p"]    = float(sw_p)
    result["sw_pass"] = float(sw_p) > 0.05

    # ── Kolmogorov-Smirnov (Lilliefors correction) ──────────────────────────
    # pvalmethod:
    #   'table'  → Lilliefors critical value table interpolation
    #              More accurate for small n (closer to SPSS output)
    #   'approx' → Asymptotic normal approximation
    #              More accurate for large n
    # Note: Minor p-value discrepancies with SPSS may occur due to
    # differences in interpolation implementations. The D statistic
    # is identical to SPSS.
    try:
        ks_method = "table" if n_ref < 50 else "approx"
        ks_D, ks_p = lilliefors(data, dist="norm", pvalmethod=ks_method)
        result["ks_D"]    = float(ks_D)
        result["ks_p"]    = float(ks_p)
        result["ks_pass"] = float(ks_p) >= 0.05
    except Exception:
        result["ks_D"]    = np.nan
        result["ks_p"]    = np.nan
        result["ks_pass"] = True

    # ── Primary criterion based on TOTAL N ───────────────────────────────────
    if n_ref < 50:
        result["primary"]       = "sw"
        result["primary_label"] = "Shapiro-Wilk"
        result["pass"]          = result["sw_pass"]
    else:
        result["primary"]       = "ks"
        result["primary_label"] = "Kolmogorov-Smirnov"
        result["pass"]          = result["ks_pass"]

    return result


# ══════════════════════════════════════════════════════════════════════════════
# RECOMMENDATION NOTES
# ══════════════════════════════════════════════════════════════════════════════

def recommendation_note(total_n):
    """
    Return an academic-English recommendation note (HTML) explaining
    which normality test is appropriate given the total sample size.

    Parameters
    ----------
    total_n : int — total N of the analysis

    Returns
    -------
    str : HTML string (uses <b> for bold)
    """
    if total_n < 50:
        return (
            f"<b>Normality Test Recommendation (Total N\u2009=\u2009{total_n}):</b> "
            "Given a total sample size of fewer than 50 observations, the "
            "<b>Shapiro-Wilk test</b> is recommended as the primary criterion "
            "for assessing normality. The Shapiro-Wilk test is widely regarded "
            "as the most powerful test for detecting departures from normality "
            "in small to moderate samples "
            "(Razali &amp; Wah, 2011; Shapiro &amp; Wilk, 1965). "
            "The Kolmogorov-Smirnov result is reported for informational purposes."
        )
    else:
        return (
            f"<b>Normality Test Recommendation (Total N\u2009=\u2009{total_n}):</b> "
            "Given a total sample size of 50 or more observations, the "
            "<b>Kolmogorov-Smirnov test with Lilliefors significance "
            "correction</b> is recommended as the primary criterion. "
            "For larger samples, the Shapiro-Wilk test may become overly "
            "sensitive, flagging trivial deviations from normality as "
            "statistically significant. The Lilliefors-corrected K-S test "
            "provides a more appropriate assessment in this context "
            "(Lilliefors, 1967; Field, 2018; Razali &amp; Wah, 2011). "
            "The Shapiro-Wilk result is reported for informational purposes."
        )


def recommendation_note_plain(total_n):
    """
    Plain-text version of recommendation_note() for CSV/Excel export.

    Parameters
    ----------
    total_n : int

    Returns
    -------
    str : plain text (no HTML tags)
    """
    if total_n < 50:
        return (
            f"Normality Test Recommendation (Total N = {total_n}): "
            "Given a total sample size of fewer than 50 observations, the "
            "Shapiro-Wilk test is recommended as the primary criterion. "
            "The Shapiro-Wilk test exhibits superior sensitivity to departures "
            "from normality in small to moderate samples "
            "(Razali & Wah, 2011; Shapiro & Wilk, 1965). "
            "The Kolmogorov-Smirnov result is reported for informational purposes."
        )
    else:
        return (
            f"Normality Test Recommendation (Total N = {total_n}): "
            "Given a total sample size of 50 or more observations, the "
            "Kolmogorov-Smirnov test with Lilliefors significance correction "
            "is recommended as the primary criterion. For larger samples, "
            "the Shapiro-Wilk test may be overly sensitive to trivial "
            "deviations from normality "
            "(Lilliefors, 1967; Field, 2018; Razali & Wah, 2011). "
            "The Shapiro-Wilk result is reported for informational purposes."
        )


KS_DISCLAIMER = (
    "Minor discrepancies in Kolmogorov\u2013Smirnov p-values may occur "
    "due to differences in interpolation and approximation algorithms "
    "across statistical software packages."
)


# ══════════════════════════════════════════════════════════════════════════════
# SUMMARY HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def normality_decision_text(norm_list, use_param):
    """
    Generate a one-sentence normality decision summary for interpretation.

    Parameters
    ----------
    norm_list : list of dict — output of test_normality()
    use_param : bool

    Returns
    -------
    str : academic-English sentence
    """
    if len(norm_list) == 1:
        nm   = norm_list[0]
        prim = nm["primary_label"]
        n    = nm["total_n"]
        size = "n\u2009<\u200950" if n < 50 else "n\u2009\u2265\u200950"
        if use_param:
            return (
                f"The {prim} test (primary criterion, Total N\u2009=\u2009{n}, "
                f"{size}) indicated that the normality assumption was satisfied "
                f"(p\u2009&gt;\u2009.05); parametric analysis was applied."
            )
        else:
            return (
                f"The {prim} test (primary criterion, Total N\u2009=\u2009{n}, "
                f"{size}) indicated that the normality assumption was violated "
                f"(p\u2009\u2264\u2009.05); non-parametric analysis was applied."
            )
    else:
        # Multiple groups (Independent T-Test)
        prim    = norm_list[0]["primary_label"]
        total_n = norm_list[0]["total_n"]
        size    = "n\u2009<\u200950" if total_n < 50 else "n\u2009\u2265\u200950"
        if use_param:
            return (
                f"The {prim} test (primary criterion, Total N\u2009=\u2009{total_n}, "
                f"{size}) indicated that the normality assumption was satisfied "
                f"in both groups (p\u2009&gt;\u2009.05); parametric analysis was applied."
            )
        else:
            violated = [nm["label"] for nm in norm_list if not nm["pass"]]
            vstr = " and ".join(violated)
            return (
                f"The {prim} test (primary criterion, Total N\u2009=\u2009{total_n}, "
                f"{size}) indicated that the normality assumption was violated "
                f"in {vstr} (p\u2009\u2264\u2009.05); "
                f"non-parametric analysis was applied."
            )


def all_normal(norm_list):
    """
    Return True if all groups/variables pass the normality criterion.

    Parameters
    ----------
    norm_list : list of dict

    Returns
    -------
    bool
    """
    return all(nm["pass"] for nm in norm_list)


def get_primary_label(norm_list):
    """
    Return the primary normality test label from the first result in norm_list.

    Parameters
    ----------
    norm_list : list of dict

    Returns
    -------
    str : 'Shapiro-Wilk' or 'Kolmogorov-Smirnov'
    """
    return norm_list[0]["primary_label"] if norm_list else "Shapiro-Wilk"


def get_total_n(norm_list):
    """
    Return total_n from the first result in norm_list.

    Parameters
    ----------
    norm_list : list of dict

    Returns
    -------
    int
    """
    return norm_list[0].get("total_n", norm_list[0]["n"]) if norm_list else 0
