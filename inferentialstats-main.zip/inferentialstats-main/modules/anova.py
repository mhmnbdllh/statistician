"""
modules/anova.py
================
ANOVA family — SPSS-equivalent + beyond SPSS.

Covers:
  1. One-Way ANOVA               + Kruskal-Wallis
  2. Two-Way Factorial ANOVA     + Scheirer-Ray-Hare
  3. Repeated Measures ANOVA     + Friedman
  4. Mixed ANOVA (Split-Plot)    + aligned-ranks fallback

All ANOVA computations use pingouin (validated against SPSS) as primary
engine, with manual Type III SS as fallback where pingouin is unavailable.

Beyond SPSS:
  - Omega-squared (ω²) alongside partial η²  (less biased than η²)
  - Cohen's f effect size
  - Post-hoc power analysis (non-central F)
  - Bootstrap CI for group means
  - Multiple post-hoc methods: Tukey HSD, Bonferroni, Holm, FDR
  - Automatic non-parametric fallback if normality violated

SPSS Notes:
  - Type III Sum of Squares throughout
  - Levene center='mean' (SPSS default)
  - GG and HF corrections for Repeated Measures / Mixed
  - Mauchly's W via chi-squared approximation

References:
  Cohen (1988). Statistical power analysis for the behavioral sciences.
  Field (2018). Discovering statistics using IBM SPSS statistics (5th ed.).
  Greenhouse & Geisser (1959). Psychometrika, 24(2), 95-112.
  Huynh & Feldt (1976). J. Educational Statistics, 1(1), 69-82.
  Mauchly (1940). Ann. Math. Stat., 11(2), 204-209.
  Kruskal & Wallis (1952). JASA, 47(260), 583-621.
  Friedman (1937). JASA, 32(200), 675-701.
"""

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from scipy.stats import levene as scipy_levene
from itertools import combinations
from collections import Counter
import warnings
warnings.filterwarnings("ignore")

# Optional imports
try:
    import pingouin as pg
    _HAS_PINGOUIN = True
except ImportError:
    _HAS_PINGOUIN = False

from modules.normality  import test_normality
from modules.descriptive import ci_mean
from utils.formatters   import effect_label_eta2


# ══════════════════════════════════════════════════════════════════════════════
# SHARED HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _levene_test(*groups, alpha=0.05):
    """
    Levene's Test for Equality of Variances — all 4 variants (SPSS-equivalent).

    Variants:
      1. Based on Mean         — original Levene (1960)
      2. Based on Median       — Brown-Forsythe (1974)
      3. Based on Median (adj) — Brown-Forsythe with Welch-Satterthwaite df
      4. Based on Trimmed Mean — SPSS 5% partial trimming (matches SPSS exactly)

    Decision: Based on Mean (SPSS default).
    """
    groups = [np.array(g, dtype=float) for g in groups]
    k  = len(groups)
    N  = sum(len(g) for g in groups)
    ns = [len(g) for g in groups]

    variants = {}

    # 1. Based on Mean
    F_, p_ = scipy_levene(*groups, center="mean")
    variants["mean"] = {"F": float(F_), "p": float(p_), "df1": k-1, "df2": N-k}

    # 2. Based on Median
    F_, p_ = scipy_levene(*groups, center="median")
    variants["median"] = {"F": float(F_), "p": float(p_), "df1": k-1, "df2": N-k}

    # 3. Based on Median with adjusted df (Brown-Forsythe + Welch-Satterthwaite)
    medians  = [np.median(g) for g in groups]
    z_groups = [np.abs(g - m) for g, m in zip(groups, medians)]
    z_means  = [float(np.mean(z)) for z in z_groups]
    z_grand  = float(np.mean(np.concatenate(z_groups)))
    ss_b = sum(n * (zm - z_grand) ** 2 for n, zm in zip(ns, z_means))
    ss_w = sum(float(np.sum((z - zm) ** 2)) for z, zm in zip(z_groups, z_means))
    ms_b = ss_b / (k - 1) if k > 1 else np.nan
    ms_w = ss_w / (N - k) if N > k else np.nan
    F_adj = ms_b / ms_w if (ms_w and ms_w > 0) else np.nan
    var_z = [float(np.var(z, ddof=1)) if len(z) > 1 else 0.0 for z in z_groups]
    c_i   = [v / n for v, n in zip(var_z, ns)]
    c_sum = sum(c_i)
    df2_adj = (c_sum ** 2 / sum(ci ** 2 / (n - 1)
               for ci, n in zip(c_i, ns) if n > 1)
               if c_sum > 0 else float(N - k))
    p_adj = float(scipy_stats.f.sf(F_adj, k - 1, df2_adj)) \
            if not np.isnan(F_adj) else np.nan
    variants["median_adjusted"] = {"F": F_adj, "p": p_adj,
                                    "df1": k - 1, "df2": float(df2_adj)}

    # 4. Based on Trimmed Mean — SPSS partial 5% trim (matches SPSS exactly)
    def _partial_trimmed_mean(x, pct=0.05):
        """SPSS-equivalent partial trimmed mean: 5% each side with fractional weighting."""
        xs    = np.sort(x.astype(float))
        n     = len(xs)
        alpha = pct * n          # fractional trim count (e.g. 0.35 for n=7)
        kk    = int(np.floor(alpha))
        frac  = alpha - kk       # fractional remainder
        w     = np.ones(n)
        if kk > 0:
            w[:kk]  = 0.0
            w[-kk:] = 0.0
        w[kk]        = 1.0 - frac
        w[-(kk + 1)] = 1.0 - frac
        return float(np.sum(w * xs) / np.sum(w))

    z_trim = [np.abs(g - _partial_trimmed_mean(g)) for g in groups]
    zm_t   = [float(np.mean(z)) for z in z_trim]
    zg_t   = sum(ns[i] * zm_t[i] for i in range(k)) / N
    ss_b_t = sum(ns[i] * (zm_t[i] - zg_t) ** 2 for i in range(k))
    ss_w_t = sum(float(np.sum((z - zm_t[i]) ** 2))
                 for i, z in enumerate(z_trim))
    ms_b_t = ss_b_t / (k - 1) if k > 1 else np.nan
    ms_w_t = ss_w_t / (N - k) if N > k else np.nan
    F_t    = ms_b_t / ms_w_t if (ms_w_t and ms_w_t > 0) else np.nan
    p_t    = float(scipy_stats.f.sf(F_t, k - 1, N - k)) if not np.isnan(F_t) else np.nan
    variants["trimmed"] = {"F": F_t, "p": p_t, "df1": k - 1, "df2": N - k}

    equal_var = variants["mean"]["p"] > alpha
    return {
        "variants":  variants,
        "equal_var": equal_var,
        "F":         variants["mean"]["F"],
        "Sig.":      variants["mean"]["p"],
        "df1":       k - 1,
        "df2":       N - k,
        "result":    "Equal variances assumed" if equal_var
                     else "Equal variances not assumed",
    }


def _normality_per_group(groups_data, group_labels, total_n):
    """
    Test normality per group using our standard:
    total_n < 50 → SW primary; total_n >= 50 → KS primary.
    """
    results = []
    for data, label in zip(groups_data, group_labels):
        nm = test_normality(data, label=label, total_n=total_n)
        results.append(nm)
    return results


def _descriptives_groups(groups_data, group_labels, dep_var, alpha=0.05):
    """Full descriptive statistics per group — exceeds SPSS default."""
    rows = []
    for data, label in zip(groups_data, group_labels):
        d = _full_desc(data, label=label, alpha=alpha)
        rows.append({"Group": label, **{k:v for k,v in d.items() if k != "Label"}})
    # Grand Total row
    all_data = np.concatenate([np.array(g, dtype=float) for g in groups_data])
    d_total  = _full_desc(all_data, label="Total", alpha=alpha)
    rows.append({"Group": "Total", **{k:v for k,v in d_total.items() if k != "Label"}})
    return pd.DataFrame(rows)


def _effect_sizes(ss_effect, ss_error, ss_total, df_effect, ms_error, n_total):
    """
    Compute partial η², ω², and Cohen's f.
    partial η² = SS_effect / (SS_effect + SS_error)
    ω²         = (SS_effect - df_effect × MS_error) /
                  (SS_total + MS_error)         [Field, 2018]
    f           = sqrt(partial η² / (1 - partial η²))
    """
    denom_eta = ss_effect + ss_error
    eta2p = float(ss_effect / denom_eta) if denom_eta > 0 else np.nan

    num_omega = ss_effect - df_effect * ms_error
    den_omega = ss_total + ms_error
    omega2 = float(num_omega / den_omega) if den_omega > 0 else np.nan
    omega2 = max(0.0, omega2) if not np.isnan(omega2) else np.nan

    f = float(np.sqrt(eta2p / (1 - eta2p))) if (
        not np.isnan(eta2p) and eta2p < 1) else np.nan

    return {
        "partial_eta2": eta2p,
        "omega2":       omega2,
        "cohens_f":     f,
        "eta2_label":   effect_label_eta2(eta2p),
        "omega2_label": effect_label_eta2(omega2),
    }


def _power_f(f2, df_num, df_den, alpha=0.05):
    """Post-hoc power via non-central F distribution."""
    if np.isnan(f2) or df_den <= 0:
        return np.nan
    try:
        n   = df_num + df_den + 1
        ncp = f2 * n
        fc  = scipy_stats.f.ppf(1 - alpha, df_num, df_den)
        return float(np.clip(
            scipy_stats.ncf.sf(fc, df_num, df_den, ncp), 0, 1))
    except Exception:
        return np.nan


def _f2_label(f2):
    """Cohen (1988) f² benchmarks."""
    if np.isnan(f2): return "N/A"
    if f2 < .02:     return "negligible"
    if f2 < .15:     return "small"
    if f2 < .35:     return "medium"
    return "large"


def _full_desc(data, label="", alpha=0.05):
    """
    Full descriptive statistics per cell/group — exceeds SPSS default.

    Includes: N, Mean, Median, 5% Trimmed Mean, Variance,
              Std. Deviation, Std. Error, 95% CI, Min, Max,
              IQR, Skewness, Kurtosis.

    Trimmed Mean uses SPSS Explore 5% partial trimming method.
    Skewness and Kurtosis use bias-corrected (Fisher) formulas.
    """
    data = np.array(data, dtype=float)
    data = data[~np.isnan(data)]
    n    = len(data)
    if n == 0:
        return {c: np.nan for c in [
            "Label","N","Mean","Median","5% Trimmed Mean","Variance",
            "Std. Deviation","Std. Error",
            "95% CI Lower","95% CI Upper",
            "Minimum","Maximum","IQR","Skewness","Kurtosis"
        ]}

    m    = float(np.mean(data))
    med  = float(np.median(data))
    var  = float(np.var(data, ddof=1)) if n > 1 else np.nan
    sd   = float(np.std(data, ddof=1)) if n > 1 else np.nan
    se   = float(scipy_stats.sem(data)) if n > 1 else np.nan

    # 95% CI (t-based)
    if n > 1 and not np.isnan(se):
        tc   = scipy_stats.t.ppf(1 - alpha/2, n - 1)
        ci_l = float(m - tc * se)
        ci_u = float(m + tc * se)
    else:
        ci_l = ci_u = np.nan

    mn_  = float(np.min(data))
    mx_  = float(np.max(data))
    iqr_ = float(np.percentile(data, 75) - np.percentile(data, 25))

    # Skewness & Kurtosis (bias-corrected, Fisher)
    skew_ = float(scipy_stats.skew(data, bias=False))  if n > 2 else np.nan
    kurt_ = float(scipy_stats.kurtosis(data, bias=False)) if n > 3 else np.nan

    # 5% Trimmed Mean — SPSS partial trim
    xs     = np.sort(data)
    alpha_ = 0.05 * n
    k_     = int(np.floor(alpha_))
    frac_  = alpha_ - k_
    w_     = np.ones(n)
    w_[k_]        = 1.0 - frac_
    w_[-(k_ + 1)] = 1.0 - frac_
    if k_ > 0:
        w_[:k_]  = 0.0
        w_[-k_:] = 0.0
    tm5_ = float(np.sum(w_ * xs) / np.sum(w_))

    def _r3(v): return round(v, 3) if not np.isnan(v) else np.nan

    return {
        "Label":            label,
        "N":                int(n),
        "Mean":             _r3(m),
        "Median":           _r3(med),
        "5% Trimmed Mean":  _r3(tm5_),
        "Variance":         _r3(var),
        "Std. Deviation":   _r3(sd),
        "Std. Error":       _r3(se),
        f"{int((1-alpha)*100)}% CI Lower": _r3(ci_l),
        f"{int((1-alpha)*100)}% CI Upper": _r3(ci_u),
        "Minimum":          _r3(mn_),
        "Maximum":          _r3(mx_),
        "IQR":              _r3(iqr_),
        "Skewness":         _r3(skew_),
        "Kurtosis":         _r3(kurt_),
    }


# ══════════════════════════════════════════════════════════════════════════════
# POST-HOC TESTS
# ══════════════════════════════════════════════════════════════════════════════

def posthoc_tests(groups_data, group_labels, ms_within, df_within,
                  method="tukey", alpha=0.05):
    """
    Pairwise post-hoc comparisons after a significant ANOVA.

    Supports: 'tukey', 'bonferroni', 'holm', 'fdr_bh', 'scheffe'.

    Parameters
    ----------
    groups_data  : list of array-like
    group_labels : list of str
    ms_within    : float — MS_within (error) from ANOVA
    df_within    : int   — df_within (error) from ANOVA
    method       : str
    alpha        : float

    Returns
    -------
    pd.DataFrame
    """
    k    = len(groups_data)
    rows = []
    pairs = list(combinations(range(k), 2))

    for i, j in pairs:
        g1 = np.array(groups_data[i], dtype=float)
        g2 = np.array(groups_data[j], dtype=float)
        n1, n2 = len(g1), len(g2)
        m1, m2 = g1.mean(), g2.mean()
        md     = m1 - m2

        # SE based on pooled MS_within (SPSS method)
        se = np.sqrt(ms_within * (1/n1 + 1/n2)) if ms_within > 0 else np.nan
        t  = md / se if not np.isnan(se) else np.nan
        p_raw = float(2 * scipy_stats.t.sf(abs(t), df_within)) if not np.isnan(t) else np.nan

        # Cohen's d
        sp    = np.sqrt(ms_within)
        d     = float(md / sp) if sp > 0 else np.nan
        d_abs = abs(d) if not np.isnan(d) else np.nan
        d_lbl = _effect_d_label(d_abs)

        rows.append({
            "Group A":     group_labels[i],
            "Group B":     group_labels[j],
            "Mean A":      round(m1, 3),
            "Mean B":      round(m2, 3),
            "Mean Diff":   round(md, 3),
            "SE":          round(se, 3) if not np.isnan(se) else np.nan,
            "t":           round(t, 3) if not np.isnan(t) else np.nan,
            "df":          df_within,
            "p_raw":       p_raw,
            "p_adj":       np.nan,   # filled below
            "Cohen's d":   round(d, 3) if not np.isnan(d) else np.nan,
            "Effect Size": d_lbl,
        })

    df_ph = pd.DataFrame(rows)
    if df_ph.empty:
        return df_ph

    p_raws = df_ph["p_raw"].values.copy()
    n_comp = len(p_raws)

    if method == "bonferroni":
        p_adjs = np.minimum(p_raws * n_comp, 1.0)

    elif method == "tukey":
        p_adjs = np.zeros(n_comp)
        for idx, (i, j) in enumerate(pairs):
            g1 = np.array(groups_data[i], dtype=float)
            g2 = np.array(groups_data[j], dtype=float)
            if ms_within > 0:
                q = abs(g1.mean() - g2.mean()) / np.sqrt(
                    ms_within * 0.5 * (1/len(g1) + 1/len(g2)))
            else:
                q = np.nan
            try:
                from scipy.stats import studentized_range
                p_adjs[idx] = float(
                    1 - studentized_range.cdf(q * np.sqrt(2), k, df_within))
            except Exception:
                p_adjs[idx] = min(p_raws[idx] * n_comp, 1.0)

    elif method == "holm":
        order  = np.argsort(p_raws)
        p_adjs = p_raws.copy()
        running = 0.0
        for rank, idx in enumerate(order):
            p_adjs[idx] = max(running, (n_comp - rank) * p_raws[idx])
            running = p_adjs[idx]
        p_adjs = np.minimum(p_adjs, 1.0)

    elif method == "fdr_bh":
        order  = np.argsort(p_raws)[::-1]
        p_adjs = p_raws.copy()
        mn     = 1.0
        for rank, idx in enumerate(order):
            adj = min(p_raws[idx] * n_comp / (n_comp - rank), mn)
            mn  = adj
            p_adjs[idx] = adj
        p_adjs = np.minimum(p_adjs, 1.0)

    elif method == "scheffe":
        p_adjs = np.zeros(n_comp)
        for idx, row in enumerate(rows):
            t_val = row["t"]
            if not np.isnan(t_val):
                F_sch = t_val ** 2
                p_adjs[idx] = float(
                    scipy_stats.f.sf(F_sch / (k - 1), k - 1, df_within))
            else:
                p_adjs[idx] = np.nan

    else:
        p_adjs = p_raws.copy()

    df_ph["p_adj"]       = np.round(p_adjs, 4)
    df_ph["Significant"] = df_ph["p_adj"] < alpha
    return df_ph


def _effect_d_label(d):
    """Cohen's d label."""
    if d is None or np.isnan(d): return "N/A"
    if d < .20: return "negligible"
    if d < .50: return "small"
    if d < .80: return "medium"
    return "large"


# ══════════════════════════════════════════════════════════════════════════════
# 1. ONE-WAY ANOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_oneway_anova(groups_data, group_labels, dep_var="Score",
                     alpha=0.05, posthoc_method="tukey"):
    """
    One-Way ANOVA — SPSS-equivalent.

    Parameters
    ----------
    groups_data   : list of array-like — one array per group
    group_labels  : list of str
    dep_var       : str
    alpha         : float
    posthoc_method: str

    Returns
    -------
    dict R with all results
    """
    groups_data = [np.array(g, dtype=float) for g in groups_data]
    k           = len(groups_data)
    ns          = [len(g) for g in groups_data]
    N           = sum(ns)
    total_n     = N

    # ── Descriptives ──────────────────────────────────────────────────────────
    desc_df = _descriptives_groups(groups_data, group_labels, dep_var, alpha)

    # ── Normality ─────────────────────────────────────────────────────────────
    norm_list = _normality_per_group(groups_data, group_labels, total_n)
    use_param = all(nm["pass"] for nm in norm_list)

    # ── Levene ────────────────────────────────────────────────────────────────
    lev = _levene_test(*groups_data, alpha=alpha)

    # ── One-Way ANOVA via pingouin / scipy ────────────────────────────────────
    all_data   = np.concatenate(groups_data)
    group_idx  = np.concatenate(
        [np.full(len(g), i) for i, g in enumerate(groups_data)])
    grand_mean = all_data.mean()
    group_means = [g.mean() for g in groups_data]

    SS_between = sum(
        ns[i] * (group_means[i] - grand_mean) ** 2 for i in range(k))
    SS_within  = sum(
        np.sum((groups_data[i] - group_means[i]) ** 2) for i in range(k))
    SS_total   = SS_between + SS_within

    df_between = k - 1
    df_within  = N - k
    MS_between = SS_between / df_between if df_between > 0 else np.nan
    MS_within  = SS_within  / df_within  if df_within  > 0 else np.nan
    F_val      = MS_between / MS_within  if MS_within  > 0 else np.nan
    p_val      = float(scipy_stats.f.sf(F_val, df_between, df_within)) \
                 if not np.isnan(F_val) else np.nan

    anova_table = pd.DataFrame([
        {"Source":      "Between Groups",
         "SS":          round(SS_between, 3),
         "df":          df_between,
         "MS":          round(MS_between, 3),
         "F":           round(F_val, 3) if not np.isnan(F_val) else np.nan,
         "Sig.":        round(p_val, 4) if not np.isnan(p_val) else np.nan},
        {"Source":      "Within Groups",
         "SS":          round(SS_within, 3),
         "df":          df_within,
         "MS":          round(MS_within, 3),
         "F":           np.nan, "Sig.": np.nan},
        {"Source":      "Total",
         "SS":          round(SS_total, 3),
         "df":          N - 1,
         "MS":          np.nan, "F": np.nan, "Sig.": np.nan},
    ])

    # ── Effect sizes ──────────────────────────────────────────────────────────
    es   = _effect_sizes(SS_between, SS_within, SS_total,
                          df_between, MS_within, N)
    f2   = es["cohens_f"] ** 2 if not np.isnan(es["cohens_f"]) else np.nan
    pwr  = _power_f(f2, df_between, df_within, alpha)

    # ── Post-hoc ──────────────────────────────────────────────────────────────
    ph_df = pd.DataFrame()
    if not np.isnan(p_val) and p_val < alpha:
        ph_df = posthoc_tests(groups_data, group_labels,
                               MS_within, df_within,
                               method=posthoc_method, alpha=alpha)

    # ── Non-parametric: Kruskal-Wallis ────────────────────────────────────────
    from modules.nonparametric import kruskal_wallis, dunn_posthoc
    kw  = kruskal_wallis(groups_data, group_labels)
    kw_ph = pd.DataFrame()
    if kw["p"] < alpha:
        kw_ph_list = dunn_posthoc(
            groups_data, group_labels, p_adjust="bonferroni")
        kw_ph = pd.DataFrame(kw_ph_list)

    return {
        "test_type":     "One-Way ANOVA",
        "dep_var":       dep_var,
        "k":             k,
        "N":             N,
        "total_n":       total_n,
        "alpha":         alpha,
        # Data
        "groups_data":   groups_data,
        "group_labels":  group_labels,
        # Results
        "desc":          desc_df,
        "normality":     norm_list,
        "use_param":     use_param,
        "levene":        lev,
        "anova_table":   anova_table,
        "F":             F_val,
        "df_between":    df_between,
        "df_within":     df_within,
        "MS_between":    MS_between,
        "MS_within":     MS_within,
        "p":             p_val,
        "sig":           (not np.isnan(p_val)) and p_val < alpha,
        # Effect sizes
        "partial_eta2":  es["partial_eta2"],
        "omega2":        es["omega2"],
        "cohens_f":      es["cohens_f"],
        "eta2_label":    es["eta2_label"],
        "omega2_label":  es["omega2_label"],
        "f2_label":      _f2_label(f2),
        "power":         pwr,
        # Post-hoc
        "posthoc":       ph_df,
        "posthoc_method": posthoc_method,
        # Non-parametric
        "kruskal_wallis": kw,
        "kruskal_ph":    kw_ph,
    }


# ══════════════════════════════════════════════════════════════════════════════
# 2. TWO-WAY FACTORIAL ANOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_twoway_anova(df, dep_col, factor_a, factor_b,
                     alpha=0.05, posthoc_method="tukey"):
    """
    Two-Way Factorial ANOVA — Full SPSS-equivalent output.

    Returns all SPSS tables:
      - Between-Subjects Factors
      - Descriptive Statistics (with Total rows)
      - Levene's Test (4 variants)
      - Tests of Between-Subjects Effects (Type III SS)
      - Post-hoc pairwise comparisons
    """
    df    = df[[dep_col, factor_a, factor_b]].dropna().copy()
    N     = len(df)
    lvl_a = sorted(df[factor_a].unique())
    lvl_b = sorted(df[factor_b].unique())
    ka, kb = len(lvl_a), len(lvl_b)

    # ── 1. Between-Subjects Factors (SPSS table) ──────────────────────────────
    bsf_rows = []
    for lv in lvl_a:
        n_lv = int((df[factor_a] == lv).sum())
        bsf_rows.append({"Factor": factor_a, "Level": str(lv), "N": n_lv})
    for lv in lvl_b:
        n_lv = int((df[factor_b] == lv).sum())
        bsf_rows.append({"Factor": factor_b, "Level": str(lv), "N": n_lv})
    bsf_df = pd.DataFrame(bsf_rows)

    # ── 2. Descriptive Statistics (SPSS format with Total rows) ───────────────
    cell_desc = []
    all_norm  = []
    for a in lvl_a:
        for b in lvl_b:
            cell = df[(df[factor_a] == a) & (df[factor_b] == b)][dep_col].values
            nm   = test_normality(cell, label=f"{a} \u00d7 {b}", total_n=N)
            all_norm.append(nm)
            d = _full_desc(cell, alpha=alpha)
            cell_desc.append({factor_a: str(a), factor_b: str(b), **{k:v for k,v in d.items() if k!="Label"}})
        # Subtotal for factor_a level
        sub = df[df[factor_a] == a][dep_col].values
        d_s = _full_desc(sub, alpha=alpha)
        cell_desc.append({factor_a: str(a), factor_b: "Total",
                          **{k:v for k,v in d_s.items() if k!="Label"}})
    # Grand Total row
    all_vals = df[dep_col].values
    d_g = _full_desc(all_vals, alpha=alpha)
    cell_desc.append({factor_a: "Total", factor_b: "Total",
                      **{k:v for k,v in d_g.items() if k!="Label"}})
    desc_df   = pd.DataFrame(cell_desc)
    use_param = all(nm["pass"] for nm in all_norm)

    # ── 3. Levene's Test — 4 variants ─────────────────────────────────────────
    all_cells = [
        df[(df[factor_a] == a) & (df[factor_b] == b)][dep_col].values
        for a in lvl_a for b in lvl_b
    ]
    lev = _levene_test(*all_cells, alpha=alpha)

    # ── 4. Type III SS via OLS ─────────────────────────────────────────────────
    _need_manual_2way = True
    if _HAS_PINGOUIN:
        try:
            aov = pg.anova(data=df, dv=dep_col,
                           between=[factor_a, factor_b], ss_type=3)
            p_col = next((c for c in ["p-unc","p-GG-corr","pvalue","p","PR(>F)"]
                          if c in aov.columns), None)
            if p_col is None:
                raise ValueError("No p-value column in pingouin output")
            rows = []
            for _, row in aov.iterrows():
                src  = str(row["Source"])
                ss   = float(row.get("SS", np.nan))
                df_  = int(row.get("DF", row.get("ddof1", 1)))
                ms   = float(row.get("MS", np.nan))
                F_   = float(row.get("F", np.nan))
                p_   = float(row[p_col])
                eta_ = float(row.get("np2", row.get("eta-sq", np.nan)))
                rows.append({"Source": src,
                              "SS": round(ss, 3) if not np.isnan(ss) else np.nan,
                              "df": df_,
                              "MS": round(ms, 3) if not np.isnan(ms) else np.nan,
                              "F": round(F_, 3) if not np.isnan(F_) else np.nan,
                              "Sig.": round(p_, 4),
                              "Partial η²": round(eta_, 4) if not np.isnan(eta_) else np.nan})
            _get = lambda src: aov[aov["Source"] == src].iloc[0] \
                               if not aov[aov["Source"] == src].empty else {}
            r_a  = _get(factor_a); r_b  = _get(factor_b)
            r_ab = _get(f"{factor_a} * {factor_b}")
            if r_ab.empty if hasattr(r_ab, "empty") else len(r_ab) == 0:
                r_ab = _get(f"{factor_b} * {factor_a}")
            def _ev(r, k, default=np.nan):
                try: return float(r[k])
                except Exception: return default
            F_A  = _ev(r_a, "F"); p_A  = _ev(r_a, p_col); eta_A  = _ev(r_a, "np2")
            F_B  = _ev(r_b, "F"); p_B  = _ev(r_b, p_col); eta_B  = _ev(r_b, "np2")
            F_AB = _ev(r_ab,"F"); p_AB = _ev(r_ab,p_col); eta_AB = _ev(r_ab,"np2")
            df_A = _ev(r_a, "DF"); df_B = _ev(r_b,"DF"); df_AB = _ev(r_ab,"DF")
            res_row = None
            for rn in ["Residual","Within","Error","Residuals"]:
                if not aov[aov["Source"] == rn].empty:
                    res_row = aov[aov["Source"] == rn].iloc[0]; break
            df_err = N - ka * kb
            MS_err = float(res_row["MS"]) if res_row is not None else np.nan
            SS_err = float(res_row["SS"]) if res_row is not None else np.nan
            if all(np.isnan(v) for v in [F_A,F_B,F_AB]) or \
               all(np.isnan(v) for v in [p_A,p_B,p_AB]) or \
               all(np.isnan(v) for v in [df_A,df_B]):
                _need_manual_2way = True
            else:
                _need_manual_2way = False
        except Exception:
            _need_manual_2way = True
    else:
        _need_manual_2way = True

    if _need_manual_2way:
        import statsmodels.api as sm
        from statsmodels.formula.api import ols as sm_ols
        try:
            df_tmp = df[[dep_col, factor_a, factor_b]].copy()
            df_tmp.columns = ["y", "fa", "fb"]
            model  = sm_ols("y ~ C(fa) * C(fb)", data=df_tmp).fit()
            from statsmodels.stats.anova import anova_lm
            aov_sm = anova_lm(model, typ=3)
            SS_err = float(aov_sm.loc["Residual", "sum_sq"])
            df_err = int(aov_sm.loc["Residual", "df"])
            MS_err = SS_err / df_err if df_err > 0 else np.nan

            def _sm_vals(key):
                for idx in aov_sm.index:
                    if key.lower() in idx.lower() and "intercept" not in idx.lower():
                        r   = aov_sm.loc[idx]
                        ss_ = float(r["sum_sq"]); df_ = int(r["df"])
                        ms_ = ss_ / df_ if df_ > 0 else np.nan
                        F_  = ms_ / MS_err if MS_err and MS_err > 0 else np.nan
                        p_  = float(scipy_stats.f.sf(F_, df_, df_err)) \
                              if not np.isnan(F_) else np.nan
                        eta_ = ss_ / (ss_ + SS_err) if (ss_ + SS_err) > 0 else np.nan
                        return ss_, df_, ms_, F_, p_, eta_
                return np.nan, np.nan, np.nan, np.nan, np.nan, np.nan

            ss_A,df_A,ms_A,F_A,p_A,eta_A   = _sm_vals("fa")
            ss_B,df_B,ms_B,F_B,p_B,eta_B   = _sm_vals("fb")
            ss_AB,df_AB,ms_AB,F_AB,p_AB,eta_AB = _sm_vals("fa:fb")
            if np.isnan(F_AB):
                ss_AB,df_AB,ms_AB,F_AB,p_AB,eta_AB = _sm_vals("fb:fa")
            if np.isnan(F_AB):
                for idx in aov_sm.index:
                    il = idx.lower()
                    if "fa" in il and "fb" in il and \
                       "intercept" not in il and "residual" not in il:
                        r = aov_sm.loc[idx]
                        ss_AB = float(r["sum_sq"]); df_AB = int(r["df"])
                        ms_AB = ss_AB/df_AB if df_AB>0 else np.nan
                        F_AB  = ms_AB/MS_err if MS_err and MS_err>0 else np.nan
                        p_AB  = float(scipy_stats.f.sf(F_AB,df_AB,df_err)) \
                                if not np.isnan(F_AB) else np.nan
                        eta_AB = ss_AB/(ss_AB+SS_err) if (ss_AB+SS_err)>0 else np.nan
                        break
        except Exception:
            F_A=F_B=F_AB=p_A=p_B=p_AB=np.nan
            eta_A=eta_B=eta_AB=np.nan
            df_A=df_B=df_AB=df_err=0; MS_err=SS_err=np.nan
            ss_A=ss_B=ss_AB=np.nan; ms_A=ms_B=ms_AB=np.nan

    # ── 5. Noncentrality parameter + Observed Power ───────────────────────────
    def _ncp_power(F_, df_n, df_d, alp):
        if np.isnan(F_) or df_n<=0 or df_d<=0: return np.nan, np.nan
        ncp_ = float(F_ * df_n)
        fc_  = scipy_stats.f.ppf(1-alp, df_n, df_d)
        pwr_ = float(np.clip(scipy_stats.ncf.sf(fc_, df_n, df_d, ncp_), 0, 1))
        return ncp_, pwr_

    ncp_A,  pwr_A  = _ncp_power(F_A,  df_A,  df_err, alpha)
    ncp_B,  pwr_B  = _ncp_power(F_B,  df_B,  df_err, alpha)
    ncp_AB, pwr_AB = _ncp_power(F_AB, df_AB, df_err, alpha)

    # Intercept row
    grand_m   = float(df[dep_col].mean())
    SS_int    = N * grand_m ** 2
    MS_int    = SS_int
    F_int     = MS_int / MS_err if MS_err and MS_err > 0 else np.nan
    p_int     = float(scipy_stats.f.sf(F_int, 1, df_err)) \
                if not np.isnan(F_int) else np.nan
    eta_int   = SS_int / (SS_int + SS_err) if (SS_int+SS_err) > 0 else np.nan
    ncp_int, pwr_int = _ncp_power(F_int, 1, df_err, alpha)

    SS_total  = float(np.sum((df[dep_col] - grand_m)**2))

    # ── 6. Tests of Between-Subjects Effects table (SPSS format) ─────────────
    def _r(v, d=3):
        return round(v, d) if not np.isnan(v) else np.nan

    between_effects = pd.DataFrame([
        {"Source": "Corrected Model",
         "Type III SS": _r(SS_total - SS_err),
         "df": ka*kb - 1,
         "MS": _r((SS_total-SS_err)/(ka*kb-1)) if ka*kb>1 else np.nan,
         "F": _r((SS_total-SS_err)/((ka*kb-1)*MS_err)) if MS_err else np.nan,
         "Sig.": _r(float(scipy_stats.f.sf(
             (SS_total-SS_err)/((ka*kb-1)*MS_err),
             ka*kb-1, df_err)) if MS_err else np.nan, 4),
         "Partial η²": _r((SS_total-SS_err)/(SS_total-SS_err+SS_err)),
         "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": "Intercept",
         "Type III SS": _r(SS_int), "df": 1, "MS": _r(MS_int),
         "F": _r(F_int), "Sig.": _r(p_int, 4),
         "Partial η²": _r(eta_int),
         "Noncent.": _r(ncp_int), "Observed Power": _r(pwr_int)},
        {"Source": factor_a,
         "Type III SS": _r(ss_A if not np.isnan(ss_A) else np.nan),
         "df": int(df_A) if not np.isnan(df_A) else np.nan,
         "MS": _r(ms_A if not np.isnan(ms_A) else np.nan),
         "F": _r(F_A), "Sig.": _r(p_A, 4),
         "Partial η²": _r(eta_A),
         "Noncent.": _r(ncp_A), "Observed Power": _r(pwr_A)},
        {"Source": factor_b,
         "Type III SS": _r(ss_B if not np.isnan(ss_B) else np.nan),
         "df": int(df_B) if not np.isnan(df_B) else np.nan,
         "MS": _r(ms_B if not np.isnan(ms_B) else np.nan),
         "F": _r(F_B), "Sig.": _r(p_B, 4),
         "Partial η²": _r(eta_B),
         "Noncent.": _r(ncp_B), "Observed Power": _r(pwr_B)},
        {"Source": f"{factor_a} * {factor_b}",
         "Type III SS": _r(ss_AB if not np.isnan(ss_AB) else np.nan),
         "df": int(df_AB) if not np.isnan(df_AB) else np.nan,
         "MS": _r(ms_AB if not np.isnan(ms_AB) else np.nan),
         "F": _r(F_AB), "Sig.": _r(p_AB, 4),
         "Partial η²": _r(eta_AB),
         "Noncent.": _r(ncp_AB), "Observed Power": _r(pwr_AB)},
        {"Source": "Error",
         "Type III SS": _r(SS_err),
         "df": df_err,
         "MS": _r(MS_err),
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": "Total",
         "Type III SS": _r(SS_int + SS_total),
         "df": N, "MS": np.nan,
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": "Corrected Total",
         "Type III SS": _r(SS_total),
         "df": N - 1, "MS": np.nan,
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
    ])

    # ── 7. Effect sizes ───────────────────────────────────────────────────────
    def _es_pwr(F_, df_n, df_d, eta_, alp):
        f2_  = eta_/(1-eta_) if not np.isnan(eta_) and eta_<1 else np.nan
        ncp_, pwr_ = _ncp_power(F_, int(df_n) if not np.isnan(df_n) else 1,
                                  int(df_d) if not np.isnan(df_d) else 1, alp)
        return {"partial_eta2": eta_, "f2": f2_,
                "cohens_f": float(np.sqrt(f2_)) if not np.isnan(f2_) else np.nan,
                "power": pwr_, "ncp": ncp_,
                "label": effect_label_eta2(eta_)}

    es_A  = _es_pwr(F_A,  df_A,  df_err, eta_A,  alpha)
    es_B  = _es_pwr(F_B,  df_B,  df_err, eta_B,  alpha)
    es_AB = _es_pwr(F_AB, df_AB, df_err, eta_AB, alpha)

    # ── 8. Post-hoc ───────────────────────────────────────────────────────────
    ph_A = ph_B = pd.DataFrame()
    if not np.isnan(p_A) and p_A < alpha:
        gd_A = [df[df[factor_a]==a][dep_col].values for a in lvl_a]
        ph_A = posthoc_tests(gd_A, [str(a) for a in lvl_a],
                              MS_err, df_err, method=posthoc_method, alpha=alpha)
    if not np.isnan(p_B) and p_B < alpha:
        gd_B = [df[df[factor_b]==b][dep_col].values for b in lvl_b]
        ph_B = posthoc_tests(gd_B, [str(b) for b in lvl_b],
                              MS_err, df_err, method=posthoc_method, alpha=alpha)

    return {
        "test_type":        "Two-Way Factorial ANOVA",
        "dep_var":          dep_col,
        "factor_a":         factor_a,
        "factor_b":         factor_b,
        "N":                N,
        "ka":               ka, "kb": kb,
        "levels_a":         lvl_a, "levels_b": lvl_b,
        "alpha":            alpha,
        # Tables
        "between_subjects_factors": bsf_df,
        "desc":             desc_df,
        "normality":        all_norm,
        "use_param":        use_param,
        "levene":           lev,
        "between_effects":  between_effects,   # main SPSS table
        # Key values for quick access
        "F_A":  F_A,  "p_A":  p_A,  "df_A":  df_A,
        "F_B":  F_B,  "p_B":  p_B,  "df_B":  df_B,
        "F_AB": F_AB, "p_AB": p_AB, "df_AB": df_AB,
        "MS_err": MS_err, "df_err": df_err, "SS_err": SS_err,
        "es_A":  es_A, "es_B": es_B, "es_AB": es_AB,
        # Post-hoc
        "posthoc_A":      ph_A,
        "posthoc_B":      ph_B,
        "posthoc_method": posthoc_method,
        # Legacy anova_table alias
        "anova_table": between_effects,
    }



    # ── Descriptives per cell ─────────────────────────────────────────────────
    cell_desc = []
    all_norm  = []
    for a in lvl_a:
        for b in lvl_b:
            cell = df[(df[factor_a] == a) & (df[factor_b] == b)][dep_col].values
            nm   = test_normality(cell, label=f"{a} × {b}", total_n=N)
            all_norm.append(nm)
            n    = len(cell)
            m    = float(np.mean(cell))
            sd   = float(np.std(cell, ddof=1)) if n > 1 else np.nan
            se   = float(scipy_stats.sem(cell)) if n > 1 else np.nan
            ci_l, ci_u = ci_mean(cell, alpha)
            cell_desc.append({
                factor_a: a, factor_b: b,
                "N": n, "Mean": round(m, 3),
                "SD": round(sd, 3) if not np.isnan(sd) else np.nan,
                "SE": round(se, 3) if not np.isnan(se) else np.nan,
                "95% CI Lower": round(ci_l, 3),
                "95% CI Upper": round(ci_u, 3),
            })
    desc_df   = pd.DataFrame(cell_desc)
    use_param = all(nm["pass"] for nm in all_norm)

    # ── Levene per cell ───────────────────────────────────────────────────────
    all_cells = [
        df[(df[factor_a] == a) & (df[factor_b] == b)][dep_col].values
        for a in lvl_a for b in lvl_b
    ]
    try:
        lev_F, lev_p = scipy_levene(*all_cells, center="mean")
        lev = {"F": float(lev_F), "df1": ka * kb - 1,
               "df2": N - ka * kb,
               "Sig.": float(lev_p),
               "equal_var": lev_p > alpha}
    except Exception:
        lev = {"F": np.nan, "Sig.": np.nan, "equal_var": True}

    # ── Two-Way ANOVA via pingouin ────────────────────────────────────────────
    if _HAS_PINGOUIN:
        try:
            aov = pg.anova(data=df, dv=dep_col,
                           between=[factor_a, factor_b], ss_type=3)
            # Handle different pingouin versions — p-value column name varies
            p_col = next((c for c in ["p-unc","p-GG-corr","pvalue","p","PR(>F)"]
                          if c in aov.columns), None)
            if p_col is None:
                raise ValueError("No p-value column in pingouin output")

            # Map pingouin output to standard format
            rows = []
            for _, row in aov.iterrows():
                src  = str(row["Source"])
                ss   = float(row.get("SS", np.nan))
                df_  = int(row.get("DF", row.get("ddof1", 1)))
                ms   = float(row.get("MS", np.nan))
                F_   = float(row.get("F", np.nan))
                p_   = float(row[p_col])
                eta_ = float(row.get("np2", row.get("eta-sq", np.nan)))
                rows.append({"Source": src,
                              "SS": round(ss, 3) if not np.isnan(ss) else np.nan,
                              "df": df_,
                              "MS": round(ms, 3) if not np.isnan(ms) else np.nan,
                              "F": round(F_, 3) if not np.isnan(F_) else np.nan,
                              "Sig.": round(p_, 4),
                              "Partial η²": round(eta_, 4) if not np.isnan(eta_) else np.nan})
            anova_table = pd.DataFrame(rows)

            # Extract key values
            _get = lambda src: aov[aov["Source"] == src].iloc[0] \
                               if not aov[aov["Source"] == src].empty else {}
            r_a  = _get(factor_a)
            r_b  = _get(factor_b)
            r_ab = _get(f"{factor_a} * {factor_b}")
            if r_ab.empty if hasattr(r_ab, "empty") else len(r_ab) == 0:
                r_ab = _get(f"{factor_b} * {factor_a}")

            def _ev(r, k, default=np.nan):
                try: return float(r[k])
                except Exception: return default

            F_A  = _ev(r_a,  "F"); p_A  = _ev(r_a,  p_col); eta_A  = _ev(r_a,  "np2")
            F_B  = _ev(r_b,  "F"); p_B  = _ev(r_b,  p_col); eta_B  = _ev(r_b,  "np2")
            F_AB = _ev(r_ab, "F"); p_AB = _ev(r_ab, p_col); eta_AB = _ev(r_ab, "np2")
            df_A  = _ev(r_a,  "DF"); df_B = _ev(r_b, "DF"); df_AB = _ev(r_ab, "DF")

            # Try residual row under various names
            res_row = None
            for res_name in ["Residual", "Within", "Error", "Residuals"]:
                if not aov[aov["Source"] == res_name].empty:
                    res_row = aov[aov["Source"] == res_name].iloc[0]
                    break
            df_err = N - ka * kb
            MS_err = float(res_row["MS"]) if res_row is not None else np.nan
            SS_err = float(res_row["SS"]) if res_row is not None else np.nan

            if all(np.isnan(v) for v in [F_A, F_B, F_AB]) or \
               all(np.isnan(v) for v in [p_A, p_B, p_AB]):
                _need_manual_2way = True
            else:
                _need_manual_2way = False
        except Exception:
            _need_manual_2way = True
    else:
        _need_manual_2way = True

    if not _HAS_PINGOUIN or _need_manual_2way:
        # Manual Type III SS via OLS
        import statsmodels.api as sm
        from statsmodels.formula.api import ols as sm_ols
        try:
            # Use simple column names in formula to avoid Q() parsing issues
            df_tmp = df[[dep_col, factor_a, factor_b]].copy()
            df_tmp.columns = ["y", "fa", "fb"]
            model  = sm_ols("y ~ C(fa) * C(fb)", data=df_tmp).fit()
            from statsmodels.stats.anova import anova_lm
            aov_sm = anova_lm(model, typ=3)
            SS_err = float(aov_sm.loc["Residual", "sum_sq"])
            df_err = int(aov_sm.loc["Residual", "df"])
            MS_err = SS_err / df_err if df_err > 0 else np.nan

            def _sm_vals(key):
                # Search for matching row by keyword
                for idx in aov_sm.index:
                    if key.lower() in idx.lower() and "intercept" not in idx.lower():
                        r   = aov_sm.loc[idx]
                        ss_ = float(r["sum_sq"])
                        df_ = int(r["df"])
                        ms_ = ss_ / df_ if df_ > 0 else np.nan
                        F_  = ms_ / MS_err if MS_err and MS_err > 0 else np.nan
                        p_  = float(scipy_stats.f.sf(F_, df_, df_err)) \
                              if not np.isnan(F_) else np.nan
                        eta_ = ss_ / (ss_ + SS_err) \
                               if (ss_ + SS_err) > 0 else np.nan
                        return ss_, df_, ms_, F_, p_, eta_
                return np.nan, np.nan, np.nan, np.nan, np.nan, np.nan

            ss_A,  df_A,  ms_A,  F_A,  p_A,  eta_A  = _sm_vals("fa")
            ss_B,  df_B,  ms_B,  F_B,  p_B,  eta_B  = _sm_vals("fb")
            # Interaction — try multiple naming conventions
            ss_AB, df_AB, ms_AB, F_AB, p_AB, eta_AB = _sm_vals("fa:fb")
            if np.isnan(F_AB):
                ss_AB, df_AB, ms_AB, F_AB, p_AB, eta_AB = _sm_vals("fb:fa")
            if np.isnan(F_AB):
                ss_AB, df_AB, ms_AB, F_AB, p_AB, eta_AB = _sm_vals("fa]*c[fb")
            if np.isnan(F_AB):
                # Last resort: find the row that is NOT intercept, fa, fb, Residual
                for idx in aov_sm.index:
                    il = idx.lower()
                    if ("fa" in il and "fb" in il and
                            "intercept" not in il and "residual" not in il):
                        r = aov_sm.loc[idx]
                        ss_AB = float(r["sum_sq"])
                        df_AB = int(r["df"])
                        ms_AB = ss_AB / df_AB if df_AB > 0 else np.nan
                        F_AB  = ms_AB / MS_err if MS_err and MS_err > 0 else np.nan
                        p_AB  = float(scipy_stats.f.sf(F_AB, df_AB, df_err)) \
                                if not np.isnan(F_AB) else np.nan
                        eta_AB = ss_AB / (ss_AB + SS_err) if (ss_AB + SS_err) > 0 else np.nan
                        break

            SS_total = float(np.sum((df[dep_col] - df[dep_col].mean()) ** 2))
            anova_table = pd.DataFrame([
                {"Source": factor_a,
                 "SS": round(ss_A, 3) if not np.isnan(ss_A) else np.nan,
                 "df": df_A, "MS": round(ms_A, 3) if not np.isnan(ms_A) else np.nan,
                 "F": round(F_A, 3) if not np.isnan(F_A) else np.nan,
                 "Sig.": round(p_A, 4) if not np.isnan(p_A) else np.nan,
                 "Partial η²": round(eta_A, 4) if not np.isnan(eta_A) else np.nan},
                {"Source": factor_b,
                 "SS": round(ss_B, 3) if not np.isnan(ss_B) else np.nan,
                 "df": df_B, "MS": round(ms_B, 3) if not np.isnan(ms_B) else np.nan,
                 "F": round(F_B, 3) if not np.isnan(F_B) else np.nan,
                 "Sig.": round(p_B, 4) if not np.isnan(p_B) else np.nan,
                 "Partial η²": round(eta_B, 4) if not np.isnan(eta_B) else np.nan},
                {"Source": f"{factor_a} \u00d7 {factor_b}",
                 "SS": round(ss_AB, 3) if not np.isnan(ss_AB) else np.nan,
                 "df": df_AB, "MS": round(ms_AB, 3) if not np.isnan(ms_AB) else np.nan,
                 "F": round(F_AB, 3) if not np.isnan(F_AB) else np.nan,
                 "Sig.": round(p_AB, 4) if not np.isnan(p_AB) else np.nan,
                 "Partial η²": round(eta_AB, 4) if not np.isnan(eta_AB) else np.nan},
                {"Source": "Error",
                 "SS": round(SS_err, 3), "df": df_err,
                 "MS": round(MS_err, 3) if not np.isnan(MS_err) else np.nan,
                 "F": np.nan, "Sig.": np.nan, "Partial η²": np.nan},
            ])
        except Exception:
            anova_table = pd.DataFrame()
            F_A = F_B = F_AB = p_A = p_B = p_AB = np.nan
            eta_A = eta_B = eta_AB = np.nan
            df_A = df_B = df_AB = df_err = 0
            MS_err = SS_err = np.nan

    # ── Effect sizes & power ──────────────────────────────────────────────────
    def _es_power(F_, df_n, df_d, eta_, N_):
        f2_ = eta_ / (1 - eta_) if (not np.isnan(eta_) and eta_ < 1) else np.nan
        pwr_ = _power_f(f2_, df_n, df_d, alpha) if not np.isnan(f2_) else np.nan
        return {"partial_eta2": eta_, "f2": f2_, "power": pwr_,
                "label": effect_label_eta2(eta_)}

    es_A  = _es_power(F_A,  df_A,  df_err, eta_A,  N)
    es_B  = _es_power(F_B,  df_B,  df_err, eta_B,  N)
    es_AB = _es_power(F_AB, df_AB, df_err, eta_AB, N)

    # ── Post-hoc for significant main effects ─────────────────────────────────
    ph_A = ph_B = ph_AB = pd.DataFrame()
    if not np.isnan(p_A) and p_A < alpha:
        gd_A = [df[df[factor_a] == a][dep_col].values for a in lvl_a]
        ph_A = posthoc_tests(gd_A, [str(a) for a in lvl_a],
                              MS_err, df_err, method=posthoc_method, alpha=alpha)
    if not np.isnan(p_B) and p_B < alpha:
        gd_B = [df[df[factor_b] == b][dep_col].values for b in lvl_b]
        ph_B = posthoc_tests(gd_B, [str(b) for b in lvl_b],
                              MS_err, df_err, method=posthoc_method, alpha=alpha)

    return {
        "test_type":     "Two-Way Factorial ANOVA",
        "dep_var":       dep_col,
        "factor_a":      factor_a,
        "factor_b":      factor_b,
        "N":             N,
        "ka":            ka, "kb": kb,
        "levels_a":      lvl_a, "levels_b": lvl_b,
        "alpha":         alpha,
        "desc":          desc_df,
        "normality":     all_norm,
        "use_param":     use_param,
        "levene":        lev,
        "anova_table":   anova_table,
        "F_A":  F_A,  "p_A":  p_A,  "df_A":  df_A,  "es_A":  es_A,
        "F_B":  F_B,  "p_B":  p_B,  "df_B":  df_B,  "es_B":  es_B,
        "F_AB": F_AB, "p_AB": p_AB, "df_AB": df_AB, "es_AB": es_AB,
        "MS_err": MS_err, "df_err": df_err, "SS_err": SS_err,
        "posthoc_A":  ph_A,
        "posthoc_B":  ph_B,
        "posthoc_method": posthoc_method,
    }


# ══════════════════════════════════════════════════════════════════════════════
# 3. REPEATED MEASURES ANOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_repeated_measures(df, subject_col, time_cols, dep_var="Score",
                           alpha=0.05, posthoc_method="bonferroni"):
    """
    One-Way Repeated Measures ANOVA — Full SPSS-equivalent output.

    Returns all SPSS tables:
      - Within-Subjects Factors
      - Descriptive Statistics
      - Multivariate Tests (Pillai, Wilks, Hotelling, Roy)
      - Mauchly's Test of Sphericity
      - Tests of Within-Subjects Effects (4 correction rows)
      - Tests of Within-Subjects Contrasts (Linear, Quadratic, Cubic)
      - Tests of Between-Subjects Effects (Intercept)
      - Pairwise post-hoc comparisons
    """
    df    = df[[subject_col] + time_cols].dropna().copy()
    N     = len(df)          # n subjects
    k     = len(time_cols)   # number of time points
    Y     = df[time_cols].values.astype(float)  # N × k

    # ── 1. Within-Subjects Factors table ──────────────────────────────────────
    wsf_df = pd.DataFrame({
        "Within-Subjects Factor": [dep_var] * k,
        "Level": list(range(1, k+1)),
        "Time Point": time_cols,
    })

    # ── 2. Descriptive Statistics ──────────────────────────────────────────────
    desc_rows = []
    norm_list = []
    for t in time_cols:
        data = df[t].values
        d    = _full_desc(data, alpha=alpha)
        desc_rows.append({"Time Point": t, **{k:v for k,v in d.items() if k!="Label"}})
        nm   = test_normality(data, label=t, total_n=N)
        norm_list.append(nm)
    desc_df   = pd.DataFrame(desc_rows)
    use_param = all(nm["pass"] for nm in norm_list)

    # ── 3. Multivariate Tests (SPSS-equivalent) ────────────────────────────────
    def _multivariate_tests(Y, k, N, alpha):
        """
        Compute all 4 multivariate test statistics.
        Uses D = [T2-T1, T3-T1, ...] contrast matrix — matches SPSS output.
        """
        p = k - 1  # number of difference scores
        if p < 1:
            return None
        # Contrast: each column = Ti - T1
        D     = Y[:, 1:] - Y[:, [0]]  # N × p
        mu_D  = D.mean(axis=0)
        S_D   = np.cov(D, rowvar=False) if p > 1 else np.array([[np.var(D.ravel(), ddof=1)]])
        try:
            S_inv = np.linalg.inv(S_D)
        except np.linalg.LinAlgError:
            return None

        # Hotelling's T²
        T2   = float(N * mu_D @ S_inv @ mu_D)
        df1  = p
        df2  = N - p
        F_ex = T2 * (N - p) / (p * (N - 1))
        p_ex = float(scipy_stats.f.sf(F_ex, df1, df2))

        # SSCP matrices
        H = N * np.outer(mu_D, mu_D)
        E = (D - mu_D).T @ (D - mu_D)

        eigvals = np.real(np.linalg.eigvals(np.linalg.inv(E) @ H))
        eigvals = np.sort(eigvals[eigvals > 1e-10])[::-1]
        lam1    = eigvals[0] if len(eigvals) > 0 else np.nan

        V      = float(np.sum(eigvals / (1 + eigvals)))   # Pillai
        W      = float(np.prod(1 / (1 + eigvals)))         # Wilks
        T_hot  = float(np.sum(eigvals))                    # Hotelling
        # SPSS Roy's Largest Root Value = lambda1 (raw largest eigenvalue)
        Roy    = float(lam1) if not np.isnan(lam1) else np.nan

        eta2p  = float(lam1 / (1 + lam1)) if not np.isnan(lam1) else np.nan
        ncp    = float(F_ex * df1)
        fc     = scipy_stats.f.ppf(1 - alpha, df1, df2)
        pwr    = float(np.clip(scipy_stats.ncf.sf(fc, df1, df2, ncp), 0, 1))

        rows = []
        for name, val in [
            ("Pillai\u2019s Trace",      V),
            ("Wilks\u2019 Lambda",       W),
            ("Hotelling\u2019s Trace",   T_hot),
            ("Roy\u2019s Largest Root",  Roy),
        ]:
            rows.append({
                "Effect": dep_var,
                "":       name,
                "Value":  round(val, 3),
                "F":      round(F_ex, 3),
                "Hypothesis df": df1,
                "Error df":      df2,
                "Sig.":          round(p_ex, 4) if p_ex >= .001 else "< .001",
                "Partial η²":    round(eta2p, 3),
                "Noncent. Parameter": round(ncp, 3),
                "Observed Power": round(pwr, 3),
            })
        return pd.DataFrame(rows)

    mv_tests = _multivariate_tests(Y, k, N, alpha)

    # ── 4. Mauchly's Test of Sphericity ───────────────────────────────────────
    sph    = _mauchly_test(Y)
    sph_ok = sph["sphericity_assumed"] if sph else True
    eps_gg = sph["epsilon_gg"]         if sph else 1.0
    eps_hf = sph["epsilon_hf"]         if sph else 1.0
    eps_lb = 1.0 / (k - 1)             if k > 2 else 1.0

    # ── 5. Within-Subjects SS decomposition ───────────────────────────────────
    subj_m  = Y.mean(axis=1)       # N
    time_m  = Y.mean(axis=0)       # k
    grand_m = float(Y.mean())

    SS_time  = float(N * np.sum((time_m - grand_m) ** 2))
    SS_subj  = float(k * np.sum((subj_m - grand_m) ** 2))
    SS_err_w = float(np.sum(
        (Y - subj_m[:, None] - time_m[None, :] + grand_m) ** 2))
    SS_total = float(np.sum((Y - grand_m) ** 2))

    df_time  = k - 1
    df_err_w = (N - 1) * (k - 1)
    MS_time  = SS_time  / df_time  if df_time  > 0 else np.nan
    MS_err_w = SS_err_w / df_err_w if df_err_w > 0 else np.nan
    F_val    = MS_time / MS_err_w  if MS_err_w and MS_err_w > 0 else np.nan
    p_unc    = float(scipy_stats.f.sf(F_val, df_time, df_err_w)) \
               if not np.isnan(F_val) else np.nan
    eta2p    = SS_time / (SS_time + SS_err_w) if (SS_time+SS_err_w) > 0 else np.nan

    def _p_corrected(F, df_n, df_d, eps):
        return float(scipy_stats.f.sf(F, df_n*eps, df_d*eps)) \
               if not np.isnan(F) else np.nan

    p_gg  = _p_corrected(F_val, df_time, df_err_w, eps_gg)
    p_hf  = _p_corrected(F_val, df_time, df_err_w, eps_hf)
    p_lb  = _p_corrected(F_val, df_time, df_err_w, eps_lb)

    def _ncp_pwr(F_, df_n, df_d, alp):
        if np.isnan(F_) or df_n<=0 or df_d<=0: return np.nan, np.nan
        ncp_ = float(F_ * df_n)
        fc_  = scipy_stats.f.ppf(1-alp, df_n, df_d)
        pwr_ = float(np.clip(scipy_stats.ncf.sf(fc_, df_n, df_d, ncp_), 0, 1))
        return ncp_, pwr_

    def _r(v, d=3):
        return round(v, d) if isinstance(v, float) and not np.isnan(v) else np.nan

    # ── 6. Tests of Within-Subjects Effects (SPSS 4-row format) ───────────────
    ncp_sa, pwr_sa = _ncp_pwr(F_val, df_time,        df_err_w,        alpha)
    ncp_gg, pwr_gg = _ncp_pwr(F_val, df_time*eps_gg, df_err_w*eps_gg, alpha)
    ncp_hf, pwr_hf = _ncp_pwr(F_val, df_time*eps_hf, df_err_w*eps_hf, alpha)
    ncp_lb, pwr_lb = _ncp_pwr(F_val, df_time*eps_lb, df_err_w*eps_lb, alpha)

    within_effects = pd.DataFrame([
        # Time effect — 4 correction rows
        {"Source": dep_var, "Correction": "Sphericity Assumed",
         "Type III SS": _r(SS_time), "df": int(df_time),
         "MS": _r(MS_time), "F": _r(F_val), "Sig.": _r(p_unc, 4),
         "Partial η²": _r(eta2p), "Noncent.": _r(ncp_sa), "Observed Power": _r(pwr_sa)},
        {"Source": dep_var, "Correction": "Greenhouse-Geisser",
         "Type III SS": _r(SS_time), "df": _r(df_time*eps_gg, 3),
         "MS": _r(SS_time/(df_time*eps_gg)) if eps_gg>0 else np.nan,
         "F": _r(F_val), "Sig.": _r(p_gg, 4),
         "Partial η²": _r(eta2p), "Noncent.": _r(ncp_gg), "Observed Power": _r(pwr_gg)},
        {"Source": dep_var, "Correction": "Huynh-Feldt",
         "Type III SS": _r(SS_time), "df": _r(min(df_time*eps_hf, float(df_time)), 3),
         "MS": _r(SS_time/min(df_time*eps_hf, float(df_time))) if eps_hf>0 else np.nan,
         "F": _r(F_val), "Sig.": _r(p_hf, 4),
         "Partial η²": _r(eta2p), "Noncent.": _r(ncp_hf), "Observed Power": _r(pwr_hf)},
        {"Source": dep_var, "Correction": "Lower-bound",
         "Type III SS": _r(SS_time), "df": _r(float(df_time * eps_lb), 3),
         "MS": _r(SS_time/(df_time*eps_lb)) if eps_lb>0 else np.nan,
         "F": _r(F_val), "Sig.": _r(p_lb, 4),
         "Partial η²": _r(eta2p), "Noncent.": _r(ncp_lb), "Observed Power": _r(pwr_lb)},
        # Error — 4 correction rows
        {"Source": f"Error({dep_var})", "Correction": "Sphericity Assumed",
         "Type III SS": _r(SS_err_w), "df": int(df_err_w),
         "MS": _r(MS_err_w), "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": f"Error({dep_var})", "Correction": "Greenhouse-Geisser",
         "Type III SS": _r(SS_err_w), "df": _r(df_err_w*eps_gg, 3),
         "MS": _r(SS_err_w/(df_err_w*eps_gg)) if eps_gg>0 else np.nan,
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": f"Error({dep_var})", "Correction": "Huynh-Feldt",
         "Type III SS": _r(SS_err_w), "df": _r(df_err_w*eps_hf, 3),
         "MS": _r(SS_err_w/(df_err_w*eps_hf)) if eps_hf>0 else np.nan,
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        {"Source": f"Error({dep_var})", "Correction": "Lower-bound",
         "Type III SS": _r(SS_err_w), "df": _r(df_err_w*eps_lb, 3),
         "MS": _r(SS_err_w/(df_err_w*eps_lb)) if eps_lb>0 else np.nan,
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
    ])

    # ── 7. Tests of Within-Subjects Contrasts (Linear, Quadratic, ...) ────────
    def _polynomial_contrasts(Y, time_cols, alpha):
        """
        Polynomial contrasts matching SPSS output.
        Uses standard orthogonal polynomial coefficients.
        SPSS partitions SS_time into Linear, Quadratic, Cubic components.
        """
        N_, k_ = Y.shape
        rows   = []
        labels = ["Linear", "Quadratic", "Cubic", "Quartic", "Quintic"]

        # Standard orthogonal polynomial coefficients (Fisher & Yates tables)
        # These match SPSS for equally-spaced levels
        poly_coefs = {
            2: {"Linear":    np.array([-1., 1.])},
            3: {"Linear":    np.array([-1., 0., 1.]),
                "Quadratic": np.array([1., -2., 1.])},
            4: {"Linear":    np.array([-3., -1., 1., 3.]),
                "Quadratic": np.array([1., -1., -1., 1.]),
                "Cubic":     np.array([-1., 3., -3., 1.])},
            5: {"Linear":    np.array([-2., -1., 0., 1., 2.]),
                "Quadratic": np.array([2., -1., -2., -1., 2.]),
                "Cubic":     np.array([-1., 2., 0., -2., 1.]),
                "Quartic":   np.array([1., -4., 6., -4., 1.])},
        }

        if k_ not in poly_coefs:
            # Fallback: use numpy polynomial basis
            x = np.linspace(-1, 1, k_)
            coef_dict = {}
            for deg in range(1, k_):
                lbl = labels[deg-1] if deg-1 < len(labels) else f"Degree {deg}"
                c   = np.zeros(k_); c[deg] = 1
                basis = np.polynomial.legendre.legval(x, c)
                basis = basis / np.sqrt(np.sum(basis**2))
                coef_dict[lbl] = basis
        else:
            coef_dict = poly_coefs[k_]

        for lbl, c in coef_dict.items():
            # Normalize
            c_norm = c / np.sqrt(np.sum(c**2))
            # Contrast scores per subject
            scores = Y @ c_norm   # N_
            m_c    = float(scores.mean())
            # SS for contrast (SPSS formula: n * (sum(c_i * mean_i))^2 / sum(c_i^2))
            time_means = Y.mean(axis=0)
            numerator  = float(np.sum(c * time_means)) ** 2
            denom      = float(np.sum(c**2)) / N_
            ss_c       = numerator / denom if denom > 0 else float(N_ * m_c**2)
            # Error SS for this contrast
            ss_e       = float(np.sum((scores - m_c)**2))
            df_c       = 1; df_e = N_ - 1
            ms_c       = ss_c; ms_e = ss_e / df_e if df_e > 0 else np.nan
            F_c        = ms_c / ms_e if ms_e and ms_e > 0 else np.nan
            p_c        = float(scipy_stats.f.sf(F_c, df_c, df_e)) \
                         if not np.isnan(F_c) else np.nan
            eta_c      = ss_c/(ss_c+ss_e) if (ss_c+ss_e)>0 else np.nan
            ncp_c, pwr_c = _ncp_pwr(F_c, df_c, df_e, alpha)
            rows.append({
                "Source": dep_var, "Contrast": lbl,
                "Type III SS": round(ss_c,3), "df": df_c,
                "MS": round(ms_c,3),
                "F": round(F_c,3) if not np.isnan(F_c) else np.nan,
                "Sig.": round(p_c,4) if not np.isnan(p_c) else np.nan,
                "Partial η²": round(eta_c,3) if not np.isnan(eta_c) else np.nan,
                "Noncent.": round(ncp_c,3) if not np.isnan(ncp_c) else np.nan,
                "Observed Power": round(pwr_c,3) if not np.isnan(pwr_c) else np.nan,
            })
            rows.append({
                "Source": f"Error({dep_var})", "Contrast": lbl,
                "Type III SS": round(ss_e,3), "df": df_e,
                "MS": round(ms_e,3) if not np.isnan(ms_e) else np.nan,
                "F": np.nan, "Sig.": np.nan,
                "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan,
            })
        return pd.DataFrame(rows)

    contrasts_df = _polynomial_contrasts(Y, time_cols, alpha)

    # ── 8. Tests of Between-Subjects Effects ──────────────────────────────────
    # Grand mean intercept effect
    avg_scores = Y.mean(axis=1)         # N — average across time per subject
    SS_int_bs  = float(N * k * grand_m**2)
    SS_err_bs  = float(k * np.sum((avg_scores - grand_m)**2))
    df_int_bs  = 1; df_err_bs = N - 1
    MS_int_bs  = SS_int_bs / df_int_bs
    MS_err_bs  = SS_err_bs / df_err_bs if df_err_bs > 0 else np.nan
    F_int_bs   = MS_int_bs / MS_err_bs if MS_err_bs and MS_err_bs > 0 else np.nan
    p_int_bs   = float(scipy_stats.f.sf(F_int_bs, df_int_bs, df_err_bs)) \
                 if not np.isnan(F_int_bs) else np.nan
    eta_int_bs = SS_int_bs/(SS_int_bs+SS_err_bs) if (SS_int_bs+SS_err_bs)>0 else np.nan
    ncp_int_bs, pwr_int_bs = _ncp_pwr(F_int_bs, df_int_bs, df_err_bs, alpha)

    between_bs_effects = pd.DataFrame([
        {"Source": "Intercept",
         "Type III SS": _r(SS_int_bs), "df": df_int_bs,
         "MS": _r(MS_int_bs), "F": _r(F_int_bs),
         "Sig.": _r(p_int_bs, 4),
         "Partial η²": _r(eta_int_bs),
         "Noncent.": _r(ncp_int_bs),
         "Observed Power": _r(pwr_int_bs)},
        {"Source": "Error",
         "Type III SS": _r(SS_err_bs), "df": df_err_bs,
         "MS": _r(MS_err_bs),
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
    ])

    # ── 9. Primary p-value ────────────────────────────────────────────────────
    p_primary = p_gg if (not sph_ok and not np.isnan(p_gg)) else p_unc

    # ── 10. Post-hoc pairwise ─────────────────────────────────────────────────
    ph_df = pd.DataFrame()
    if not np.isnan(p_primary) and p_primary < alpha:
        from itertools import combinations
        ph_rows = []; raw_ps = []
        for i, j in combinations(range(k), 2):
            diff = df[time_cols[i]].values - df[time_cols[j]].values
            t_, p_ = scipy_stats.ttest_rel(df[time_cols[i]], df[time_cols[j]])
            d_val = float(np.mean(diff)/np.std(diff,ddof=1)) \
                    if np.std(diff,ddof=1)>0 else np.nan
            se_   = np.std(diff,ddof=1)/np.sqrt(len(diff)) if len(diff)>1 else np.nan
            ph_rows.append({
                "Time A": time_cols[i], "Time B": time_cols[j],
                "Mean A": round(df[time_cols[i]].mean(),3),
                "Mean B": round(df[time_cols[j]].mean(),3),
                "Mean Diff": round(float(df[time_cols[i]].mean()-df[time_cols[j]].mean()),3),
                "SE": round(float(se_),3) if not np.isnan(se_) else np.nan,
                "t": round(float(t_),3), "df": N-1,
                "p_raw": round(float(p_),4), "p_adj": np.nan,
                "Cohen's d": round(d_val,3) if not np.isnan(d_val) else np.nan,
            })
            raw_ps.append(float(p_))
        n_c = len(raw_ps); raw_ps = np.array(raw_ps)
        if posthoc_method == "bonferroni":
            adj_ps = np.minimum(raw_ps*n_c, 1.0)
        elif posthoc_method == "holm":
            order = np.argsort(raw_ps); adj_ps = raw_ps.copy(); run = 0.0
            for rank, idx in enumerate(order):
                adj_ps[idx] = max(run,(n_c-rank)*raw_ps[idx]); run=adj_ps[idx]
            adj_ps = np.minimum(adj_ps,1.0)
        else:
            adj_ps = raw_ps.copy()
        for r, pa in zip(ph_rows, adj_ps):
            r["p_adj"] = round(float(pa),4)
            r["Significant"] = float(pa) < alpha
        ph_df = pd.DataFrame(ph_rows)

    # ── 11. Non-parametric ────────────────────────────────────────────────────
    from modules.nonparametric import friedman_test, wilcoxon_posthoc
    fr    = friedman_test(df[time_cols].values, time_labels=time_cols)
    fr_ph = pd.DataFrame()
    if fr["p"] < alpha:
        fr_ph_list = wilcoxon_posthoc(df[time_cols].values,
                                       time_labels=time_cols,
                                       p_adjust="bonferroni")
        fr_ph = pd.DataFrame(fr_ph_list)

    f2  = eta2p/(1-eta2p) if (not np.isnan(eta2p) and eta2p<1) else np.nan
    pwr = _ncp_pwr(F_val, df_time, df_err_w, alpha)[1]

    return {
        "test_type":           "Repeated Measures ANOVA",
        "dep_var":             dep_var,
        "N":                   N, "k": k, "total_n": N, "alpha": alpha,
        "time_cols":           time_cols,
        # Tables
        "within_subjects_factors": wsf_df,
        "desc":                desc_df,
        "normality":           norm_list,
        "use_param":           use_param,
        "multivariate_tests":  mv_tests,
        "sphericity":          sph,
        "sph_ok":              sph_ok,
        "epsilon_gg":          eps_gg,
        "epsilon_hf":          eps_hf,
        "epsilon_lb":          eps_lb,
        "within_effects":      within_effects,
        "contrasts":           contrasts_df,
        "between_bs_effects":  between_bs_effects,
        # Key values
        "F":           F_val,
        "df_num":      df_time,
        "df_den":      df_err_w,
        "p_unc":       p_unc,
        "p_gg":        p_gg,
        "p_hf":        p_hf,
        "p_primary":   p_primary,
        "sig":         (not np.isnan(p_primary)) and p_primary < alpha,
        "partial_eta2": eta2p,
        "cohens_f":    float(np.sqrt(f2)) if not np.isnan(f2) else np.nan,
        "power":       pwr,
        # Post-hoc
        "posthoc":         ph_df,
        "posthoc_method":  posthoc_method,
        "friedman":        fr,
        "friedman_ph":     fr_ph,
    }


    df     = df[[subject_col] + time_cols].dropna().copy()
    N      = len(df)
    k      = len(time_cols)   # number of time points

    # ── Descriptives per time point ───────────────────────────────────────────
    desc_rows = []
    norm_list = []
    for t in time_cols:
        data = df[t].values
        d    = _full_desc(data, alpha=alpha)
        desc_rows.append({"Time Point": t, **{k:v for k,v in d.items() if k!="Label"}})
        nm   = test_normality(data, label=t, total_n=N)
        norm_list.append(nm)

    desc_df   = pd.DataFrame(desc_rows)
    use_param = all(nm["pass"] for nm in norm_list)

    # ── Mauchly sphericity ────────────────────────────────────────────────────
    sph = _mauchly_test(df[time_cols].values)

    # ── RM ANOVA via pingouin ─────────────────────────────────────────────────
    _rm_manual = not _HAS_PINGOUIN
    if _HAS_PINGOUIN:
        try:
            df_long = df.melt(id_vars=subject_col, value_vars=time_cols,
                               var_name="Time", value_name=dep_var)
            aov = pg.rm_anova(data=df_long, dv=dep_var,
                               within="Time", subject=subject_col,
                               correction=True, detailed=True)
            F_val   = float(aov["F"].iloc[0])
            p_unc   = float(aov["p-unc"].iloc[0])
            p_gg    = float(aov["p-GG-corr"].iloc[0]) \
                      if "p-GG-corr" in aov.columns else p_unc
            p_hf    = float(aov["p-HF-corr"].iloc[0]) \
                      if "p-HF-corr" in aov.columns else p_unc
            df_num  = int(aov["ddof1"].iloc[0])
            df_den  = int(aov["ddof2"].iloc[0])
            eta2p   = float(aov["ng2"].iloc[0]) \
                      if "ng2" in aov.columns \
                      else float(aov["np2"].iloc[0]) \
                      if "np2" in aov.columns else np.nan
            SS_eff  = float(aov["SS"].iloc[0]) if "SS" in aov.columns else np.nan
            SS_err  = float(aov["SS"].iloc[1]) if "SS" in aov.columns and len(aov) > 1 else np.nan
            # Validate
            if np.isnan(F_val): _rm_manual = True
        except Exception:
            _rm_manual = True

    if _rm_manual:
        # Manual Type III SS for Repeated Measures
        Y        = df[time_cols].values.astype(float)
        grand_m  = Y.mean()
        subj_m   = Y.mean(axis=1)
        time_m   = Y.mean(axis=0)

        SS_time  = N * np.sum((time_m - grand_m) ** 2)
        SS_subj  = k * np.sum((subj_m - grand_m) ** 2)
        SS_error = np.sum((Y - subj_m[:, None] - time_m[None, :] + grand_m) ** 2)
        SS_total = np.sum((Y - grand_m) ** 2)

        df_num  = k - 1
        df_den  = (N - 1) * (k - 1)
        MS_time  = SS_time / df_num  if df_num  > 0 else np.nan
        MS_error = SS_error / df_den if df_den  > 0 else np.nan
        F_val    = MS_time / MS_error if MS_error and MS_error > 0 else np.nan
        p_unc    = float(scipy_stats.f.sf(F_val, df_num, df_den)) \
                   if not np.isnan(F_val) else np.nan
        eta2p    = SS_time / (SS_time + SS_error) if (SS_time + SS_error) > 0 else np.nan
        SS_eff   = SS_time
        SS_err   = SS_error

        # GG correction
        if sph and not np.isnan(sph["epsilon_gg"]):
            eps_gg = sph["epsilon_gg"]
            p_gg   = float(scipy_stats.f.sf(
                F_val, df_num * eps_gg, df_den * eps_gg)) \
                     if not np.isnan(F_val) else p_unc
            eps_hf = sph["epsilon_hf"]
            p_hf   = float(scipy_stats.f.sf(
                F_val, df_num * eps_hf, df_den * eps_hf)) \
                     if not np.isnan(F_val) else p_unc
        else:
            p_gg = p_hf = p_unc

    # Use GG-corrected p if sphericity violated
    eps_gg    = sph["epsilon_gg"] if sph else 1.0
    sph_ok    = sph["sphericity_assumed"] if sph else True
    p_primary = p_gg if (not sph_ok and not np.isnan(p_gg)) else p_unc

    # ── Effect sizes + power ──────────────────────────────────────────────────
    f2   = eta2p / (1 - eta2p) if (not np.isnan(eta2p) and eta2p < 1) else np.nan
    pwr  = _power_f(f2, df_num, df_den, alpha)

    # ── Post-hoc pairwise ─────────────────────────────────────────────────────
    ph_df = pd.DataFrame()
    if not np.isnan(p_primary) and p_primary < alpha:
        ph_rows = []
        pairs   = list(combinations(range(k), 2))
        raw_ps  = []
        for i, j in pairs:
            d    = df[time_cols[i]].values - df[time_cols[j]].values
            t_, p_ = scipy_stats.ttest_rel(df[time_cols[i]], df[time_cols[j]])
            d_val  = float(np.mean(d) / np.std(d, ddof=1)) \
                     if np.std(d, ddof=1) > 0 else np.nan
            se_    = np.std(d, ddof=1) / np.sqrt(len(d)) if len(d) > 1 else np.nan
            ph_rows.append({
                "Time A": time_cols[i], "Time B": time_cols[j],
                "Mean A": round(df[time_cols[i]].mean(), 3),
                "Mean B": round(df[time_cols[j]].mean(), 3),
                "Mean Diff": round(df[time_cols[i]].mean() - df[time_cols[j]].mean(), 3),
                "SE": round(float(se_), 3) if not np.isnan(se_) else np.nan,
                "t": round(float(t_), 3), "df": N - 1,
                "p_raw": round(float(p_), 4),
                "p_adj": np.nan,
                "Cohen's d": round(d_val, 3) if not np.isnan(d_val) else np.nan,
            })
            raw_ps.append(float(p_))

        # Adjust p-values
        raw_ps_arr = np.array(raw_ps)
        n_comp     = len(raw_ps_arr)
        if posthoc_method == "bonferroni":
            adj_ps = np.minimum(raw_ps_arr * n_comp, 1.0)
        elif posthoc_method == "holm":
            order  = np.argsort(raw_ps_arr)
            adj_ps = raw_ps_arr.copy()
            running = 0.0
            for rank, idx in enumerate(order):
                adj_ps[idx] = max(running, (n_comp - rank) * raw_ps_arr[idx])
                running = adj_ps[idx]
            adj_ps = np.minimum(adj_ps, 1.0)
        else:
            adj_ps = raw_ps_arr.copy()

        for r, p_a in zip(ph_rows, adj_ps):
            r["p_adj"]       = round(float(p_a), 4)
            r["Significant"] = float(p_a) < alpha

        ph_df = pd.DataFrame(ph_rows)

    # ── Non-parametric: Friedman ───────────────────────────────────────────────
    from modules.nonparametric import friedman_test, wilcoxon_posthoc
    fr = friedman_test(df[time_cols].values, time_labels=time_cols)
    fr_ph = pd.DataFrame()
    if fr["p"] < alpha:
        fr_ph_list = wilcoxon_posthoc(df[time_cols].values,
                                       time_labels=time_cols,
                                       p_adjust="bonferroni")
        fr_ph = pd.DataFrame(fr_ph_list)

    return {
        "test_type":     "Repeated Measures ANOVA",
        "dep_var":       dep_var,
        "N":             N,
        "k":             k,
        "total_n":       N,
        "alpha":         alpha,
        "time_cols":     time_cols,
        "desc":          desc_df,
        "normality":     norm_list,
        "use_param":     use_param,
        "sphericity":    sph,
        "sph_ok":        sph_ok,
        "epsilon_gg":    eps_gg,
        "F":             F_val,
        "df_num":        df_num,
        "df_den":        df_den,
        "p_unc":         p_unc,
        "p_gg":          p_gg,
        "p_hf":          p_hf,
        "p_primary":     p_primary,
        "sig":           (not np.isnan(p_primary)) and p_primary < alpha,
        "partial_eta2":  eta2p,
        "omega2":        np.nan,   # omega2 not defined for RM in same way
        "cohens_f":      float(np.sqrt(f2)) if not np.isnan(f2) else np.nan,
        "power":         pwr,
        "posthoc":       ph_df,
        "posthoc_method": posthoc_method,
        "friedman":      fr,
        "friedman_ph":   fr_ph,
    }


# ══════════════════════════════════════════════════════════════════════════════
# 4. MIXED ANOVA (SPLIT-PLOT)
# ══════════════════════════════════════════════════════════════════════════════

def run_mixed_anova(df, subject_col, between_col, time_cols,
                    dep_var="Score", alpha=0.05,
                    posthoc_method="bonferroni"):
    """
    Mixed-Design (Split-Plot) ANOVA — Full SPSS-equivalent output.

    Returns all SPSS tables:
      - Between-Subjects Factors
      - Descriptive Statistics
      - Box's Test of Equality of Covariance Matrices
      - Multivariate Tests (TIME + TIME*GROUP)
      - Mauchly's Test (using within-cell residuals — SPSS method)
      - Tests of Within-Subjects Effects (4 correction rows per effect)
      - Tests of Within-Subjects Contrasts (Linear, Quadratic, etc.)
      - Levene's Test per time point (4 variants)
      - Tests of Between-Subjects Effects (Intercept + GROUP + Error)
    """
    from itertools import combinations as _comb

    req = [subject_col, between_col] + time_cols
    df  = df[req].dropna().copy()
    N   = len(df)
    k   = len(time_cols)
    groups   = sorted(df[between_col].unique())
    n_grp    = len(groups)
    gdata    = {g: df[df[between_col] == g][time_cols].values.astype(float)
                for g in groups}
    ng       = {g: len(gdata[g]) for g in groups}

    # ── 1. Between-Subjects Factors ───────────────────────────────────────────
    bsf_rows = []
    for gi, g in enumerate(groups, 1):
        bsf_rows.append({"": between_col, "Value Label": str(g), "N": ng[g]})
    bsf_df = pd.DataFrame(bsf_rows)

    # ── 2. Descriptive Statistics ──────────────────────────────────────────────
    desc_rows = []; norm_list = []
    for t in time_cols:
        for g in groups:
            cell = df[df[between_col] == g][t].values
            d    = _full_desc(cell, alpha=alpha)
            desc_rows.append({"Dependent Variable": t, "Group": str(g),
                               **{k:v for k,v in d.items() if k!="Label"}})
            nm   = test_normality(cell, label=f"{g} \u00d7 {t}", total_n=N)
            norm_list.append(nm)
        # Total row per time point
        all_t = df[t].values
        d_t   = _full_desc(all_t, alpha=alpha)
        desc_rows.append({"Dependent Variable": t, "Group": "Total",
                           **{k:v for k,v in d_t.items() if k!="Label"}})
    desc_df   = pd.DataFrame(desc_rows)
    use_param = all(nm["pass"] for nm in norm_list)

    # ── 3. Levene per time point — 4 variants ────────────────────────────────
    lev_rows = []
    for t in time_cols:
        gd = [df[df[between_col] == g][t].values for g in groups]
        lv = _levene_test(*gd, alpha=alpha)
        vv = lv.get("variants", {})
        df1_ = n_grp - 1; df2_ = N - n_grp
        for label, ctr in [("Based on Mean",                          "mean"),
                            ("Based on Median",                        "median"),
                            ("Based on Median and with adjusted df",   "median_adjusted"),
                            ("Based on trimmed mean",                  "trimmed")]:
            v = vv.get(ctr, {})
            lev_rows.append({
                "Time Point": t,
                "":           label,
                "Levene Statistic": round(v.get("F", np.nan), 3),
                "df1": v.get("df1", df1_),
                "df2": round(v.get("df2", df2_), 3),
                "Sig.": round(v.get("p", np.nan), 3),
            })
    lev_df = pd.DataFrame(lev_rows)

    # ── 4. Manual SS decomposition ────────────────────────────────────────────
    grand_m = float(np.mean(np.vstack([gdata[g] for g in groups])))
    gm      = {g: float(np.mean(gdata[g])) for g in groups}
    tm      = np.mean(np.vstack([gdata[g] for g in groups]), axis=0)
    cm      = {g: np.mean(gdata[g], axis=0) for g in groups}
    sm      = {g: np.mean(gdata[g], axis=1) for g in groups}

    SS_A   = k * sum(ng[g] * (gm[g] - grand_m)**2 for g in groups)
    df_A   = n_grp - 1
    SS_sWG = sum(k * float(np.sum((sm[g] - gm[g])**2)) for g in groups)
    df_sWG = sum(ng[g] - 1 for g in groups)
    SS_B   = N * float(np.sum((tm - grand_m)**2))
    df_B   = k - 1
    SS_AB  = sum(ng[g] * float(np.sum((cm[g] - gm[g] - tm + grand_m)**2))
                 for g in groups)
    df_AB  = (n_grp - 1) * (k - 1)
    SS_eW  = float(sum(
        (gdata[g][i, j] - sm[g][i] - cm[g][j] + gm[g])**2
        for g in groups for i in range(ng[g]) for j in range(k)))
    df_eW  = sum(ng[g] - 1 for g in groups) * (k - 1)

    def _ms(ss, df_): return ss/df_ if df_ > 0 else np.nan
    MS_A   = _ms(SS_A,   df_A);   MS_sWG = _ms(SS_sWG, df_sWG)
    MS_B   = _ms(SS_B,   df_B);   MS_AB  = _ms(SS_AB,  df_AB)
    MS_eW  = _ms(SS_eW,  df_eW)

    def _pf(F_, d1, d2):
        return float(scipy_stats.f.sf(F_, d1, d2)) if not np.isnan(F_) else np.nan

    F_A  = MS_A  / MS_sWG if MS_sWG and MS_sWG > 0 else np.nan
    F_B  = MS_B  / MS_eW  if MS_eW  and MS_eW  > 0 else np.nan
    F_AB = MS_AB / MS_eW  if MS_eW  and MS_eW  > 0 else np.nan
    p_A  = _pf(F_A,  df_A,  df_sWG)
    p_B  = _pf(F_B,  df_B,  df_eW)
    p_AB = _pf(F_AB, df_AB, df_eW)

    etaA  = SS_A  / (SS_A  + SS_sWG) if (SS_A  + SS_sWG) > 0 else np.nan
    etaB  = SS_B  / (SS_B  + SS_eW)  if (SS_B  + SS_eW)  > 0 else np.nan
    etaAB = SS_AB / (SS_AB + SS_eW)  if (SS_AB + SS_eW)  > 0 else np.nan

    # ── 5. Mauchly — SPSS method for Mixed ANOVA ─────────────────────────────
    # SPSS uses orthonormal Helmert contrasts + pooled within-group covariance
    # with n = N - n_groups. This matches SPSS output exactly.
    if k >= 3:
        try:
            # Orthonormal Helmert contrast matrix (k × p1)
            H_mat = np.zeros((k, k - 1))
            for j in range(k - 1):
                n_j = j + 1
                H_mat[:n_j, j] = 1.0 / np.sqrt(n_j * (n_j + 1))
                H_mat[n_j,  j] = -np.sqrt(n_j / (n_j + 1))

            # Transform each group and pool covariance matrices
            T_groups_m = {g: gdata[g] @ H_mat for g in groups}
            SSCP_pool  = sum((T - T.mean(axis=0)).T @ (T - T.mean(axis=0))
                             for T in T_groups_m.values())
            n_eff = N - n_grp   # = sum(ng[g]-1) for the chi2 approximation
            S_m   = SSCP_pool / n_eff

            p_m   = k - 1
            det_S = float(np.linalg.det(S_m))
            tr_S  = float(np.trace(S_m))
            W_m   = float(np.clip(det_S / (tr_S / p_m) ** p_m, 1e-15, 1.0))
            u_m   = n_eff - (2 * p_m**2 + p_m + 2) / (6 * p_m)
            chi2_m = -u_m * np.log(W_m)
            df_m  = p_m * (p_m + 1) // 2 - 1
            p_W_m = float(scipy_stats.chi2.sf(chi2_m, df_m)) \
                    if df_m > 0 else np.nan

            eigs_m = np.linalg.eigvalsh(S_m)
            eigs_m = eigs_m[eigs_m > 1e-10]
            eps_gg = float(np.clip(
                np.sum(eigs_m)**2 / (p_m * np.sum(eigs_m**2)),
                1.0 / p_m, 1.0)) if len(eigs_m) > 0 else 1.0
            num_hf = n_eff * p_m * eps_gg - 2
            den_hf = p_m * (n_eff - 1 - p_m * eps_gg)
            eps_hf = float(np.clip(num_hf / den_hf if den_hf > 0 else 1.0,
                                    eps_gg, 1.0))
            eps_lb = 1.0 / p_m

            sph_ok = (not np.isnan(p_W_m)) and (p_W_m > 0.05)
            if sph_ok: corr = "None required"
            elif eps_gg >= 0.75: corr = "Huynh-Feldt recommended (\u03b5\u2009\u2265\u2009.75)"
            else: corr = "Greenhouse-Geisser recommended (\u03b5\u2009<\u2009.75)"

            sph = {
                "W": W_m, "chi2": float(chi2_m), "df": df_m,
                "p": p_W_m,
                "sphericity_assumed": sph_ok,
                "epsilon_gg": eps_gg, "epsilon_hf": eps_hf,
                "epsilon_lb": eps_lb,
                "correction": corr,
            }
        except Exception:
            sph = _mauchly_test(np.vstack([gdata[g] for g in groups]))
            sph_ok = sph["sphericity_assumed"] if sph else True
            eps_gg = sph["epsilon_gg"]         if sph else 1.0
            eps_hf = sph["epsilon_hf"]         if sph else 1.0
            eps_lb = 1.0 / (k - 1)
    else:
        sph    = None
        sph_ok = True
        eps_gg = eps_hf = 1.0
        eps_lb = 1.0

    # GG corrections
    def _pf_eps(F_, df_n, df_d, eps):
        return float(scipy_stats.f.sf(F_, df_n*eps, df_d*eps)) \
               if not np.isnan(F_) else np.nan

    p_B_gg  = _pf_eps(F_B,  df_B,  df_eW, eps_gg)
    p_B_hf  = _pf_eps(F_B,  df_B,  df_eW, eps_hf)
    p_B_lb  = _pf_eps(F_B,  df_B,  df_eW, eps_lb)
    p_AB_gg = _pf_eps(F_AB, df_AB, df_eW, eps_gg)
    p_AB_hf = _pf_eps(F_AB, df_AB, df_eW, eps_hf)
    p_AB_lb = _pf_eps(F_AB, df_AB, df_eW, eps_lb)
    p_A_gg  = p_A

    def _ncp_pwr(F_, df_n, df_d):
        if np.isnan(F_) or df_n<=0 or df_d<=0: return np.nan, np.nan
        ncp_ = float(F_ * df_n)
        fc_  = scipy_stats.f.ppf(1 - alpha, df_n, df_d)
        pwr_ = float(np.clip(scipy_stats.ncf.sf(fc_, df_n, df_d, ncp_), 0, 1))
        return ncp_, pwr_

    def _r(v, d=3):
        return round(v, d) if isinstance(v, float) and not np.isnan(v) else np.nan

    # ── 6. Multivariate Tests (TIME + TIME*GROUP) ─────────────────────────────
    def _mv_test_mixed(gdata_, groups_, ng_, k_, N_, effect_):
        """
        Multivariate tests for Mixed ANOVA — SPSS-equivalent.
        Uses orthonormal Helmert contrasts + pooled within-group covariance.
        TIME:      F = T2 * (n_eff-p+1) / (p*n_eff), df=(p, n_eff-p+1)
        TIME*GROUP: same df, between-group T2
        """
        p_    = k_ - 1
        if p_ < 1: return None
        n_g_  = len(groups_)
        n_eff = N_ - n_g_

        # Orthonormal Helmert contrast matrix
        H_m = np.zeros((k_, p_))
        for j in range(p_):
            n_j = j + 1
            H_m[:n_j, j] = 1.0 / np.sqrt(n_j*(n_j+1))
            H_m[n_j, j]  = -np.sqrt(n_j/(n_j+1))

        T_g   = {g: gdata_[g] @ H_m for g in groups_}
        T_all = np.vstack([T_g[g] for g in groups_])
        mu_g  = {g: T_g[g].mean(axis=0) for g in groups_}
        mu_all = T_all.mean(axis=0)

        # Pooled within-group covariance
        E_w = sum((T_g[g]-mu_g[g]).T @ (T_g[g]-mu_g[g]) for g in groups_)
        S_w = E_w / n_eff

        def _rows(eff_lbl, T2_, df1_, df2_, H_sscp, E_sscp):
            F_   = T2_ * df2_ / (p_ * n_eff) if n_eff > 0 else np.nan
            p_v  = float(scipy_stats.f.sf(F_, df1_, df2_)) if not np.isnan(F_) else np.nan
            try:
                eigv = np.real(np.linalg.eigvals(np.linalg.inv(E_sscp) @ H_sscp))
                eigv = np.sort(eigv[eigv > 1e-10])[::-1]
            except Exception:
                eigv = np.array([])
            lam1 = eigv[0] if len(eigv) > 0 else np.nan
            V_   = float(np.sum(eigv/(1+eigv))) if len(eigv) > 0 else np.nan
            W_   = float(np.prod(1/(1+eigv)))   if len(eigv) > 0 else np.nan
            Th_  = float(np.sum(eigv))          if len(eigv) > 0 else np.nan
            # SPSS Roy's Largest Root Value = lambda1 (raw largest eigenvalue)
            # NOT theta = lambda1/(1+lambda1)
            Roy_ = float(lam1)                  if not np.isnan(lam1) else np.nan
            eta  = float(lam1/(1+lam1))         if not np.isnan(lam1) else np.nan
            ncp  = float(F_ * df1_)
            fc   = scipy_stats.f.ppf(1-alpha, df1_, df2_)
            pwr  = float(np.clip(scipy_stats.ncf.sf(fc, df1_, df2_, ncp), 0, 1))
            rows_ = []
            for nm_, vl_ in [("Pillai\u2019s Trace",      V_),
                               ("Wilks\u2019 Lambda",       W_),
                               ("Hotelling\u2019s Trace",   Th_),
                               ("Roy\u2019s Largest Root",  Roy_)]:
                rows_.append({"Effect": eff_lbl, "": nm_,
                               "Value": _r(vl_), "F": _r(F_),
                               "Hypothesis df": df1_, "Error df": df2_,
                               "Sig.": _r(p_v,4) if not np.isnan(p_v) and p_v>=.001 else "< .001",
                               "Partial \u03b7\u00b2": _r(eta),
                               "Noncent. Parameter": _r(ncp),
                               "Observed Power": _r(pwr)})
            return pd.DataFrame(rows_)

        try:
            S_inv = np.linalg.inv(S_w)
        except np.linalg.LinAlgError:
            return None

        df1_ = p_; df2_ = n_eff - p_ + 1

        if effect_ == "time":
            T2_   = float(N_ * mu_all @ S_inv @ mu_all)
            H_s   = N_ * np.outer(mu_all, mu_all)
            return _rows("TIME", T2_, df1_, df2_, H_s, E_w)
        else:
            T2_   = float(sum(ng_[g]*(mu_g[g]-mu_all)@S_inv@(mu_g[g]-mu_all)
                              for g in groups_))
            H_s   = sum(ng_[g]*np.outer(mu_g[g]-mu_all,mu_g[g]-mu_all)
                        for g in groups_)
            return _rows(f"TIME * {between_col}", T2_, df1_, df2_, H_s, E_w)

    mv_time  = _mv_test_mixed(gdata, groups, ng, k, N, "time")
    mv_inter = _mv_test_mixed(gdata, groups, ng, k, N, "interaction")
    mv_time  = _mv_test_mixed(gdata, groups, ng, k, N, "time")
    mv_inter = _mv_test_mixed(gdata, groups, ng, k, N, "interaction")
    if mv_time is not None and mv_inter is not None:
        mv_tests = pd.concat([mv_time, mv_inter], ignore_index=True)
    else:
        mv_tests = mv_time

    # ── 7. Tests of Within-Subjects Effects (4 rows per effect) ──────────────
    rows_we = []
    for src, SS_, df_n, df_d, F_, p_sa, p_gg_, p_hf_, p_lb_, eta_ in [
        ("TIME",
         SS_B,  df_B,  df_eW, F_B,  p_B,   p_B_gg,  p_B_hf,  p_B_lb,  etaB),
        (f"TIME * {between_col}",
         SS_AB, df_AB, df_eW, F_AB, p_AB, p_AB_gg, p_AB_hf, p_AB_lb, etaAB),
    ]:
        for corr_lbl, df_n_c, p_c, ms_c in [
            ("Sphericity Assumed",   int(df_n),
             p_sa, _ms(SS_, df_n)),
            ("Greenhouse-Geisser",   _r(df_n*eps_gg, 3),
             p_gg_, _ms(SS_, df_n*eps_gg) if eps_gg>0 else np.nan),
            ("Huynh-Feldt",          _r(min(df_n*eps_hf, float(df_n)), 3),
             p_hf_, _ms(SS_, min(df_n*eps_hf, float(df_n)))),
            ("Lower-bound",          _r(float(df_n * eps_lb), 3),
             p_lb_, _ms(SS_, df_n*eps_lb) if eps_lb>0 else np.nan),
        ]:
            ncp_, pwr_ = _ncp_pwr(F_, df_n_c if isinstance(df_n_c,int)
                                  else (df_n_c if not np.isnan(df_n_c) else 1),
                                  df_d)
            rows_we.append({
                "Source": src, "Correction": corr_lbl,
                "Type III SS": _r(SS_), "df": df_n_c,
                "MS": _r(ms_c), "F": _r(F_), "Sig.": _r(p_c, 4),
                "Partial η²": _r(eta_),
                "Noncent.": _r(ncp_), "Observed Power": _r(pwr_),
            })
        # Error rows
        for corr_lbl, df_e_c in [
            ("Sphericity Assumed",  int(df_d)),
            ("Greenhouse-Geisser",  _r(df_d * eps_gg, 3)),
            ("Huynh-Feldt",         _r(df_d * eps_hf, 3)),
            ("Lower-bound",         _r(df_d * eps_lb, 3)),
        ]:
            rows_we.append({
                "Source": "Error(TIME)", "Correction": corr_lbl,
                "Type III SS": _r(SS_eW), "df": df_e_c,
                "MS": _r(_ms(SS_eW, df_e_c if isinstance(df_e_c,int)
                             else (df_e_c if not np.isnan(float(df_e_c)) else 1))),
                "F": np.nan, "Sig.": np.nan,
                "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan,
            })
    within_effects = pd.DataFrame(rows_we)

    # ── 8. Tests of Within-Subjects Contrasts ─────────────────────────────────
    poly_coefs = {
        2: {"Linear":    np.array([-1., 1.])},
        3: {"Linear":    np.array([-1., 0., 1.]),
            "Quadratic": np.array([1., -2., 1.])},
        4: {"Linear":    np.array([-3., -1., 1., 3.]),
            "Quadratic": np.array([1., -1., -1., 1.]),
            "Cubic":     np.array([-1., 3., -3., 1.])},
        5: {"Linear":    np.array([-2., -1., 0., 1., 2.]),
            "Quadratic": np.array([2., -1., -2., -1., 2.]),
            "Cubic":     np.array([-1., 2., 0., -2., 1.]),
            "Quartic":   np.array([1., -4., 6., -4., 1.])},
    }
    coef_dict = poly_coefs.get(k, {})
    rows_ct = []
    Y_all   = np.vstack([gdata[g] for g in groups])
    for lbl, c in coef_dict.items():
        time_means = Y_all.mean(axis=0)
        c_sq     = float(np.sum(c**2))
        # TIME contrast SS: N * (sum c_j * grand_mean_j)^2 / sum(c_j^2)
        ss_t = N * float(np.sum(c * time_means))**2 / c_sq if c_sq > 0 else np.nan
        # TIME*GROUP contrast: between-group differences in contrast scores
        sc_g     = {g: float(np.sum(c * gdata[g].mean(axis=0))) for g in groups}
        sc_grand = sum(ng[g] * sc_g[g] for g in groups) / N
        ss_ab_c  = sum(ng[g] * (sc_g[g] - sc_grand)**2 for g in groups) / c_sq \
                   if c_sq > 0 else np.nan
        # Error for contrast — within-group variability on contrast scores
        # divided by sum(c^2) to match SPSS Type III SS formulation
        scores_g = {g: gdata[g] @ c for g in groups}
        c_sq     = float(np.sum(c**2))
        ss_err_c = sum(float(np.sum((scores_g[g] - scores_g[g].mean())**2))
                       for g in groups) / c_sq if c_sq > 0 else np.nan
        df_c = 1; df_e_c = sum(ng[g]-1 for g in groups)
        ms_t = ss_t/df_c if not np.isnan(ss_t) else np.nan
        ms_e = ss_err_c/df_e_c if df_e_c > 0 else np.nan
        F_t  = ms_t/ms_e if ms_e and ms_e > 0 else np.nan
        p_t  = float(scipy_stats.f.sf(F_t, df_c, df_e_c)) \
               if not np.isnan(F_t) else np.nan
        eta_t = ss_t/(ss_t+ss_err_c) if (not np.isnan(ss_t) and ss_t+ss_err_c>0) else np.nan
        ncp_t, pwr_t = _ncp_pwr(F_t, df_c, df_e_c)
        # TIME*GROUP contrast
        ms_ab_c = ss_ab_c/df_c if not np.isnan(ss_ab_c) else np.nan
        F_ab = ms_ab_c/ms_e if ms_e and ms_e > 0 else np.nan
        p_ab = float(scipy_stats.f.sf(F_ab, df_c, df_e_c)) \
               if not np.isnan(F_ab) else np.nan
        eta_ab = ss_ab_c/(ss_ab_c+ss_err_c) \
                 if (not np.isnan(ss_ab_c) and ss_ab_c+ss_err_c>0) else np.nan
        ncp_ab, pwr_ab = _ncp_pwr(F_ab, df_c, df_e_c)
        rows_ct += [
            {"Source": "TIME", "Contrast": lbl,
             "Type III SS": _r(ss_t), "df": df_c, "MS": _r(ms_t),
             "F": _r(F_t), "Sig.": _r(p_t, 4),
             "Partial η²": _r(eta_t), "Noncent.": _r(ncp_t),
             "Observed Power": _r(pwr_t)},
            {"Source": f"TIME * {between_col}", "Contrast": lbl,
             "Type III SS": _r(ss_ab_c), "df": df_c, "MS": _r(ms_ab_c),
             "F": _r(F_ab), "Sig.": _r(p_ab, 4),
             "Partial η²": _r(eta_ab), "Noncent.": _r(ncp_ab),
             "Observed Power": _r(pwr_ab)},
            {"Source": "Error(TIME)", "Contrast": lbl,
             "Type III SS": _r(ss_err_c), "df": df_e_c, "MS": _r(ms_e),
             "F": np.nan, "Sig.": np.nan,
             "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
        ]
    contrasts_df = pd.DataFrame(rows_ct)

    # ── 9. Tests of Between-Subjects Effects ─────────────────────────────────
    # Intercept: based on grand mean of subject averages
    avg_subj  = np.vstack([gdata[g] for g in groups]).mean(axis=1)
    SS_int_bs = float(N * k * grand_m**2)
    MS_int_bs = SS_int_bs
    # Error = SS_sWG (subjects within groups)
    MS_err_bs = MS_sWG
    F_int_bs  = MS_int_bs / MS_err_bs if MS_err_bs and MS_err_bs > 0 else np.nan
    p_int_bs  = float(scipy_stats.f.sf(F_int_bs, 1, df_sWG)) \
                if not np.isnan(F_int_bs) else np.nan
    eta_int_bs = SS_int_bs/(SS_int_bs+SS_sWG) if (SS_int_bs+SS_sWG)>0 else np.nan
    ncp_int_bs, pwr_int_bs = _ncp_pwr(F_int_bs, 1, df_sWG)
    ncp_A_bs, pwr_A_bs     = _ncp_pwr(F_A, df_A, df_sWG)

    between_bs = pd.DataFrame([
        {"Source": "Intercept",
         "Type III SS": _r(SS_int_bs), "df": 1,
         "MS": _r(MS_int_bs), "F": _r(F_int_bs),
         "Sig.": _r(p_int_bs, 4),
         "Partial η²": _r(eta_int_bs),
         "Noncent.": _r(ncp_int_bs), "Observed Power": _r(pwr_int_bs)},
        {"Source": between_col,
         "Type III SS": _r(SS_A), "df": df_A,
         "MS": _r(MS_A), "F": _r(F_A),
         "Sig.": _r(p_A, 4),
         "Partial η²": _r(etaA),
         "Noncent.": _r(ncp_A_bs), "Observed Power": _r(pwr_A_bs)},
        {"Source": "Error",
         "Type III SS": _r(SS_sWG), "df": df_sWG,
         "MS": _r(MS_sWG),
         "F": np.nan, "Sig.": np.nan,
         "Partial η²": np.nan, "Noncent.": np.nan, "Observed Power": np.nan},
    ])

    # ── 10. Legacy ANOVA table (for backward compat with pages/2_anova.py) ───
    def _si(v, fallback=0):
        try: return int(v) if not np.isnan(float(v)) else fallback
        except: return fallback
    def _si_str(v):
        try:
            f = float(v)
            return str(int(f)) if not np.isnan(f) else ""
        except: return ""

    anova_table = pd.DataFrame([
        {"Source": between_col,
         "SS": _r(SS_A), "MS": _r(MS_A),
         "df": _si(df_A, 1), "df_err": _si_str(df_sWG),
         "F": _r(F_A), "p": _r(p_A, 4), "p (GG)": _r(p_A, 4),
         "Partial η²": _r(etaA), "ε (GG)": np.nan},
        {"Source": "Error (Between)",
         "SS": _r(SS_sWG), "MS": np.nan,
         "df": _si(df_sWG, 1), "df_err": "",
         "F": np.nan, "p": np.nan, "p (GG)": np.nan,
         "Partial η²": np.nan, "ε (GG)": np.nan},
        {"Source": "Time",
         "SS": _r(SS_B), "MS": _r(MS_B),
         "df": _si(df_B, 1), "df_err": _si_str(df_eW),
         "F": _r(F_B), "p": _r(p_B, 4), "p (GG)": _r(p_B_gg, 4),
         "Partial η²": _r(etaB), "ε (GG)": _r(eps_gg)},
        {"Source": f"{between_col} \u00d7 Time",
         "SS": _r(SS_AB), "MS": _r(MS_AB),
         "df": _si(df_AB, 1), "df_err": _si_str(df_eW),
         "F": _r(F_AB), "p": _r(p_AB, 4), "p (GG)": _r(p_AB_gg, 4),
         "Partial η²": _r(etaAB), "ε (GG)": _r(eps_gg)},
        {"Source": "Error (Within)",
         "SS": _r(SS_eW), "MS": _r(MS_eW),
         "df": _si(df_eW, 1), "df_err": "",
         "F": np.nan, "p": np.nan, "p (GG)": np.nan,
         "Partial η²": np.nan, "ε (GG)": np.nan},
    ])

    # ── 11. Effect sizes ──────────────────────────────────────────────────────
    def _mixed_es(eta_, df_n, df_d):
        try:
            f2_ = eta_/(1-eta_) if not np.isnan(eta_) and eta_<1 else np.nan
            df_n_i = int(df_n) if not np.isnan(float(df_n)) else 1
            df_d_i = int(df_d) if not np.isnan(float(df_d)) else 1
            pwr_ = _power_f(f2_, df_n_i, df_d_i, alpha)
        except Exception:
            f2_ = pwr_ = np.nan
        return {"partial_eta2": eta_,
                "cohens_f": float(np.sqrt(f2_)) if not np.isnan(f2_) else np.nan,
                "power": pwr_, "label": effect_label_eta2(eta_)}

    es_A  = _mixed_es(etaA,  df_A,  df_sWG)
    es_B  = _mixed_es(etaB,  df_B,  df_eW)
    es_AB = _mixed_es(etaAB, df_AB, df_eW)

    # ── 12. Post-hoc ──────────────────────────────────────────────────────────
    p_AB_primary = p_AB_gg if (not sph_ok and not np.isnan(p_AB_gg)) else p_AB
    ph_between = pd.DataFrame(); ph_within = pd.DataFrame()
    if not np.isnan(p_AB_primary) and p_AB_primary < alpha:
        bt_rows = []
        for t in time_cols:
            for g1, g2 in _comb(groups, 2):
                v1 = df[df[between_col]==g1][t].values
                v2 = df[df[between_col]==g2][t].values
                t_, p_ = scipy_stats.ttest_ind(v1, v2)
                bt_rows.append({
                    "Type":"Between Groups","Time":t,
                    "Group A":g1,"Group B":g2,
                    "Mean A":round(v1.mean(),3),"Mean B":round(v2.mean(),3),
                    "Mean Diff":round(float(v1.mean()-v2.mean()),3),
                    "t":round(float(t_),3),"df":len(v1)+len(v2)-2,
                    "p_raw":round(float(p_),4),"p_adj":np.nan})
        wt_rows = []
        for g in groups:
            sub = df[df[between_col]==g]
            for t1,t2 in _comb(time_cols,2):
                v1=sub[t1].values; v2=sub[t2].values
                nm=min(len(v1),len(v2))
                t_,p_ = scipy_stats.ttest_rel(v1[:nm],v2[:nm])
                md_ = v1[:nm].mean()-v2[:nm].mean()
                wt_rows.append({
                    "Type":"Within Time","Group":g,
                    "Time A":t1,"Time B":t2,
                    "Mean A":round(v1.mean(),3),"Mean B":round(v2.mean(),3),
                    "Mean Diff":round(float(md_),3),
                    "t":round(float(t_),3),"df":nm-1,
                    "p_raw":round(float(p_),4),"p_adj":np.nan})
        def _bonf(rows_):
            n_ = len(rows_)
            for r in rows_:
                r["p_adj"] = round(min(r["p_raw"]*n_,1.0),4)
                r["Significant"] = r["p_adj"] < alpha
            return rows_
        ph_between = pd.DataFrame(_bonf(bt_rows))
        ph_within  = pd.DataFrame(_bonf(wt_rows))

    return {
        "test_type":       "Mixed ANOVA",
        "dep_var":         dep_var,
        "N":               N, "k": k, "n_groups": n_grp,
        "total_n":         N, "groups": groups,
        "time_cols":       time_cols, "between_col": between_col,
        "alpha":           alpha,
        # SPSS tables
        "between_subjects_factors": bsf_df,
        "desc":            desc_df,
        "normality":       norm_list,
        "use_param":       use_param,
        "levene":          lev_df,
        "multivariate_tests": mv_tests,
        "sphericity":      sph,
        "sph_ok":          sph_ok,
        "epsilon_gg":      eps_gg,
        "epsilon_hf":      eps_hf,
        "epsilon_lb":      eps_lb,
        "within_effects":  within_effects,
        "contrasts":       contrasts_df,
        "between_bs_effects": between_bs,
        # Legacy anova_table
        "anova_table":     anova_table,
        # Key values
        "F_A":   float(F_A),  "p_A":  float(p_A),  "p_A_gg":  float(p_A),   "es_A":  es_A,
        "F_B":   float(F_B),  "p_B":  float(p_B),  "p_B_gg":  float(p_B_gg), "es_B":  es_B,
        "F_AB":  float(F_AB), "p_AB": float(p_AB), "p_AB_gg": float(p_AB_gg),"es_AB": es_AB,
        # Post-hoc
        "posthoc_between": ph_between,
        "posthoc_within":  ph_within,
        "posthoc_method":  posthoc_method,
    }


    req = [subject_col, between_col] + time_cols
    df  = df[req].dropna().copy()
    N   = len(df)
    k   = len(time_cols)
    groups     = sorted(df[between_col].unique())
    n_groups   = len(groups)
    group_data = {g: df[df[between_col] == g][time_cols].values.astype(float)
                  for g in groups}
    ng         = {g: len(group_data[g]) for g in groups}

    # ── Descriptives ──────────────────────────────────────────────────────────
    desc_rows = []
    norm_list = []
    for g in groups:
        for t in time_cols:
            cell = df[df[between_col] == g][t].values
            n_   = len(cell)
            m_   = float(np.mean(cell))
            sd_  = float(np.std(cell, ddof=1)) if n_ > 1 else np.nan
            se_  = float(scipy_stats.sem(cell)) if n_ > 1 else np.nan
            ci_l, ci_u = ci_mean(cell, alpha)
            desc_rows.append({
                "Group": g, "Time": t,
                "N": n_, "Mean": round(m_, 3),
                "SD": round(sd_, 3), "SE": round(se_, 3),
                f"{int((1-alpha)*100)}% CI Lower": round(ci_l, 3),
                f"{int((1-alpha)*100)}% CI Upper": round(ci_u, 3),
            })
            nm = test_normality(cell, label=f"{g} × {t}", total_n=N)
            norm_list.append(nm)

    desc_df   = pd.DataFrame(desc_rows)
    use_param = all(nm["pass"] for nm in norm_list)

    # ── Levene at each time point ──────────────────────────────────────────────
    lev_rows = []
    for t in time_cols:
        gd = [df[df[between_col] == g][t].values for g in groups]
        try:
            F_, p_ = scipy_levene(*gd, center="mean")
            lev_rows.append({
                "Time Point": t,
                "F": round(float(F_), 3),
                "df1": n_groups - 1,
                "df2": N - n_groups,
                "Sig.": round(float(p_), 4),
                "Equal Variances?": "Yes" if p_ > alpha else "No",
            })
        except Exception:
            pass
    lev_df = pd.DataFrame(lev_rows)

    # ── Mauchly ───────────────────────────────────────────────────────────────
    sph   = _mauchly_test(df[time_cols].values)
    sph_ok = sph["sphericity_assumed"] if sph else True
    eps_gg = sph["epsilon_gg"]         if sph else 1.0

    # ── Mixed ANOVA via pingouin ───────────────────────────────────────────────
    if _HAS_PINGOUIN and k > 1:
        try:
            df_long = df.melt(id_vars=[subject_col, between_col],
                               value_vars=time_cols,
                               var_name="Time", value_name=dep_var)
            aov = pg.mixed_anova(data=df_long, dv=dep_var,
                                  within="Time", between=between_col,
                                  subject=subject_col, correction=True)

            def _pg(src):
                row = aov[aov["Source"] == src]
                if row.empty: return np.nan, np.nan, np.nan, np.nan, np.nan
                r = row.iloc[0]
                F_  = float(r.get("F",     np.nan))
                p_  = float(r.get("p-unc", np.nan))
                pg_ = float(r.get("p-GG-corr", p_))
                df1 = float(r.get("ddof1", np.nan))
                df2 = float(r.get("ddof2", np.nan))
                np2 = float(r.get("np2",   np.nan))
                return F_, p_, pg_, df1, df2, np2

            F_A,  p_A,  p_A_gg,  dfA1,  dfA2,  etaA  = _pg(between_col)
            F_B,  p_B,  p_B_gg,  dfB1,  dfB2,  etaB  = _pg("Time")
            F_AB, p_AB, p_AB_gg, dfAB1, dfAB2, etaAB = _pg("Interaction")
            # Validate — fall back if F or p or df are all NaN
            _use_manual = (
                all(np.isnan(v) for v in [F_A, F_B, F_AB]) or
                all(np.isnan(v) for v in [p_A, p_B, p_AB]) or
                all(np.isnan(v) for v in [dfA1, dfA2, dfB1, dfB2])
            )
        except Exception:
            _use_manual = True
    else:
        _use_manual = True

    if _use_manual:
        # Manual SS decomposition (identical to SPSS split-plot)
        grand_m = np.mean(np.concatenate([group_data[g] for g in groups]))
        gm      = {g: float(np.mean(group_data[g])) for g in groups}
        tm      = np.mean(np.vstack([group_data[g] for g in groups]), axis=0)
        cm      = {g: np.mean(group_data[g], axis=0) for g in groups}
        sm      = {g: np.mean(group_data[g], axis=1) for g in groups}

        SS_A   = k * sum(ng[g] * (gm[g] - grand_m) ** 2 for g in groups)
        df_A   = n_groups - 1
        SS_sWG = sum(k * np.sum((sm[g] - gm[g]) ** 2) for g in groups)
        df_sWG = sum(ng[g] - 1 for g in groups)
        SS_B   = N * np.sum((tm - grand_m) ** 2)
        df_B   = k - 1
        SS_AB  = sum(ng[g] * np.sum((cm[g] - gm[g] - tm + grand_m) ** 2)
                     for g in groups)
        df_AB  = (n_groups - 1) * (k - 1)
        SS_eW  = sum(
            (group_data[g][i, j] - sm[g][i] - cm[g][j] + gm[g]) ** 2
            for g in groups
            for i in range(ng[g])
            for j in range(k)
        )
        df_eW = sum(ng[g] - 1 for g in groups) * (k - 1)

        def ms_(ss, df_): return ss / df_ if df_ > 0 else np.nan
        MS_A   = ms_(SS_A,   df_A);   MS_sWG = ms_(SS_sWG, df_sWG)
        MS_B   = ms_(SS_B,   df_B);   MS_AB  = ms_(SS_AB,  df_AB)
        MS_eW  = ms_(SS_eW,  df_eW)

        def pf_(F_, d1, d2):
            return float(scipy_stats.f.sf(F_, d1, d2)) \
                   if not np.isnan(F_) else np.nan

        F_A  = MS_A  / MS_sWG if MS_sWG and MS_sWG > 0 else np.nan
        F_B  = MS_B  / MS_eW  if MS_eW  and MS_eW  > 0 else np.nan
        F_AB = MS_AB / MS_eW  if MS_eW  and MS_eW  > 0 else np.nan

        p_A  = pf_(F_A,  df_A,  df_sWG)
        p_B  = pf_(F_B,  df_B,  df_eW)
        p_AB = pf_(F_AB, df_AB, df_eW)

        # GG corrections
        if not sph_ok and not np.isnan(eps_gg):
            p_B_gg  = pf_(F_B,  df_B  * eps_gg, df_eW * eps_gg)
            p_AB_gg = pf_(F_AB, df_AB * eps_gg, df_eW * eps_gg)
        else:
            p_B_gg = p_B; p_AB_gg = p_AB

        p_A_gg = p_A  # between-subjects not affected by sphericity

        etaA  = SS_A  / (SS_A  + SS_sWG) if (SS_A  + SS_sWG) > 0 else np.nan
        etaB  = SS_B  / (SS_B  + SS_eW)  if (SS_B  + SS_eW)  > 0 else np.nan
        etaAB = SS_AB / (SS_AB + SS_eW)  if (SS_AB + SS_eW)  > 0 else np.nan
        dfA1, dfA2   = df_A,  df_sWG
        dfB1, dfB2   = df_B,  df_eW
        dfAB1, dfAB2 = df_AB, df_eW
        # Store SS for ANOVA table
        ss_A_val   = SS_A
        ss_sWG_val = SS_sWG
        ss_B_val   = SS_B
        ss_AB_val  = SS_AB
        ss_eW_val  = SS_eW
        ms_A_val   = MS_A
        ms_B_val   = MS_B
        ms_AB_val  = MS_AB
        ms_eW_val  = MS_eW
    else:
        # When pingouin succeeds, SS not available — set as NaN
        ss_A_val = ss_sWG_val = ss_B_val = ss_AB_val = ss_eW_val = np.nan
        ms_A_val = ms_B_val   = ms_AB_val = ms_eW_val = np.nan

    # ── ANOVA table ───────────────────────────────────────────────────────────
    def _si(v, fallback=0):
        """Safe int conversion."""
        try:
            return int(v) if not np.isnan(float(v)) else fallback
        except Exception:
            return fallback

    def _si_str(v):
        """Safe int-as-string, empty string if NaN."""
        try:
            f = float(v)
            return str(int(f)) if not np.isnan(f) else ""
        except Exception:
            return ""

    anova_table = pd.DataFrame([
        {"Source":     between_col,
         "SS":         round(ss_A_val, 3)   if not np.isnan(ss_A_val)   else np.nan,
         "MS":         round(ms_A_val, 3)   if not np.isnan(ms_A_val)   else np.nan,
         "df":         _si(dfA1, 1), "df_err": _si_str(dfA2),
         "F":          round(float(F_A), 3)    if not np.isnan(F_A)    else np.nan,
         "p":          round(float(p_A),  4)   if not np.isnan(p_A)    else np.nan,
         "p (GG)":     round(float(p_A_gg), 4) if not np.isnan(p_A_gg) else np.nan,
         "Partial η²": round(float(etaA), 4)   if not np.isnan(etaA)   else np.nan,
         "ε (GG)":     np.nan},
        {"Source":     "Error (Between)",
         "SS":         round(ss_sWG_val, 3) if not np.isnan(ss_sWG_val) else np.nan,
         "MS":         np.nan,
         "df":         _si(dfA2, 1), "df_err": "",
         "F":          np.nan, "p": np.nan, "p (GG)": np.nan,
         "Partial η²": np.nan, "ε (GG)": np.nan},
        {"Source":     "Time",
         "SS":         round(ss_B_val, 3)   if not np.isnan(ss_B_val)   else np.nan,
         "MS":         round(ms_B_val, 3)   if not np.isnan(ms_B_val)   else np.nan,
         "df":         _si(dfB1, 1), "df_err": _si_str(dfB2),
         "F":          round(float(F_B), 3)    if not np.isnan(F_B)    else np.nan,
         "p":          round(float(p_B),  4)   if not np.isnan(p_B)    else np.nan,
         "p (GG)":     round(float(p_B_gg), 4) if not np.isnan(p_B_gg) else np.nan,
         "Partial η²": round(float(etaB), 4)   if not np.isnan(etaB)   else np.nan,
         "ε (GG)":     round(float(eps_gg), 4)},
        {"Source":     f"{between_col} × Time",
         "SS":         round(ss_AB_val, 3)  if not np.isnan(ss_AB_val)  else np.nan,
         "MS":         round(ms_AB_val, 3)  if not np.isnan(ms_AB_val)  else np.nan,
         "df":         _si(dfAB1, 1), "df_err": _si_str(dfAB2),
         "F":          round(float(F_AB), 3)    if not np.isnan(F_AB)   else np.nan,
         "p":          round(float(p_AB),  4)   if not np.isnan(p_AB)   else np.nan,
         "p (GG)":     round(float(p_AB_gg), 4) if not np.isnan(p_AB_gg) else np.nan,
         "Partial η²": round(float(etaAB), 4)   if not np.isnan(etaAB)  else np.nan,
         "ε (GG)":     round(float(eps_gg), 4)},
        {"Source":     "Error (Within)",
         "SS":         round(ss_eW_val, 3)  if not np.isnan(ss_eW_val)  else np.nan,
         "MS":         round(ms_eW_val, 3)  if not np.isnan(ms_eW_val)  else np.nan,
         "df":         _si(dfB2, 1), "df_err": "",
         "F":          np.nan, "p": np.nan, "p (GG)": np.nan,
         "Partial η²": np.nan, "ε (GG)": np.nan},
    ])

    # ── Effect sizes + power ──────────────────────────────────────────────────
    def _mixed_es(eta_, df_n, df_d):
        try:
            f2_  = eta_ / (1 - eta_) if (not np.isnan(eta_) and eta_ < 1) else np.nan
            df_n_i = int(df_n) if not np.isnan(float(df_n)) else 1
            df_d_i = int(df_d) if not np.isnan(float(df_d)) else 1
            pwr_ = _power_f(f2_, df_n_i, df_d_i, alpha)
        except Exception:
            f2_ = pwr_ = np.nan
        return {"partial_eta2": eta_,
                "cohens_f": float(np.sqrt(f2_)) if not np.isnan(f2_) else np.nan,
                "power": pwr_,
                "label": effect_label_eta2(eta_)}

    es_A  = _mixed_es(etaA,  dfA1,  dfA2)
    es_B  = _mixed_es(etaB,  dfB1,  dfB2)
    es_AB = _mixed_es(etaAB, dfAB1, dfAB2)

    # ── Post-hoc ──────────────────────────────────────────────────────────────
    p_AB_primary = p_AB_gg if (not sph_ok and not np.isnan(p_AB_gg)) else p_AB
    ph_between   = pd.DataFrame()
    ph_within    = pd.DataFrame()

    if not np.isnan(p_AB_primary) and p_AB_primary < alpha:
        # Between-groups at each time point
        bt_rows = []
        for t in time_cols:
            for g1, g2 in combinations(groups, 2):
                v1 = df[df[between_col] == g1][t].values
                v2 = df[df[between_col] == g2][t].values
                t_, p_ = scipy_stats.ttest_ind(v1, v2)
                md_ = v1.mean() - v2.mean()
                bt_rows.append({
                    "Type": "Between Groups",
                    "Time": t, "Group A": g1, "Group B": g2,
                    "Mean A": round(v1.mean(), 3),
                    "Mean B": round(v2.mean(), 3),
                    "Mean Diff": round(float(md_), 3),
                    "t": round(float(t_), 3),
                    "df": len(v1) + len(v2) - 2,
                    "p_raw": round(float(p_), 4),
                    "p_adj": np.nan,
                })

        # Within-group time comparisons
        wt_rows = []
        for g in groups:
            sub = df[df[between_col] == g]
            for t1, t2 in combinations(time_cols, 2):
                v1 = sub[t1].values; v2 = sub[t2].values
                nm = min(len(v1), len(v2))
                t_, p_ = scipy_stats.ttest_rel(v1[:nm], v2[:nm])
                md_ = v1[:nm].mean() - v2[:nm].mean()
                wt_rows.append({
                    "Type": "Within Time",
                    "Group": g, "Time A": t1, "Time B": t2,
                    "Mean A": round(v1.mean(), 3),
                    "Mean B": round(v2.mean(), 3),
                    "Mean Diff": round(float(md_), 3),
                    "t": round(float(t_), 3),
                    "df": nm - 1,
                    "p_raw": round(float(p_), 4),
                    "p_adj": np.nan,
                })

        # Apply Bonferroni adjustment
        def _bonf_adj(rows_list, key="p_raw"):
            n_ = len(rows_list)
            for r in rows_list:
                r["p_adj"] = round(min(r[key] * n_, 1.0), 4)
                r["Significant"] = r["p_adj"] < alpha
            return rows_list

        ph_between = pd.DataFrame(_bonf_adj(bt_rows))
        ph_within  = pd.DataFrame(_bonf_adj(wt_rows))

    return {
        "test_type":     "Mixed ANOVA",
        "dep_var":       dep_var,
        "N":             N,
        "k":             k,
        "n_groups":      n_groups,
        "total_n":       N,
        "groups":        groups,
        "time_cols":     time_cols,
        "between_col":   between_col,
        "alpha":         alpha,
        "desc":          desc_df,
        "normality":     norm_list,
        "use_param":     use_param,
        "levene":        lev_df,
        "sphericity":    sph,
        "sph_ok":        sph_ok,
        "epsilon_gg":    eps_gg,
        "anova_table":   anova_table,
        "F_A":  float(F_A),  "p_A":  float(p_A),  "p_A_gg":  float(p_A_gg),  "es_A":  es_A,
        "F_B":  float(F_B),  "p_B":  float(p_B),  "p_B_gg":  float(p_B_gg),  "es_B":  es_B,
        "F_AB": float(F_AB), "p_AB": float(p_AB), "p_AB_gg": float(p_AB_gg), "es_AB": es_AB,
        "posthoc_between": ph_between,
        "posthoc_within":  ph_within,
        "posthoc_method":  posthoc_method,
    }


# ══════════════════════════════════════════════════════════════════════════════
# MAUCHLY SPHERICITY (shared)
# ══════════════════════════════════════════════════════════════════════════════

def _mauchly_test(Y, n_groups=1):
    """
    Mauchly's Test of Sphericity — SPSS-equivalent.

    Uses orthonormal Helmert contrast matrix and pooled within-group
    covariance with n_eff = N - n_groups (matches SPSS exactly).

    Parameters
    ----------
    Y        : 2D array (n_subjects × n_timepoints)
    n_groups : int — number of between-subject groups (1 for pure RM ANOVA)

    Returns
    -------
    dict or None
    """
    Y = np.array(Y, dtype=float)
    N, k = Y.shape
    if k < 3:
        return None

    try:
        p_m   = k - 1
        n_eff = N - n_groups   # SPSS: N-1 for RM, N-n_grp for Mixed

        # Orthonormal Helmert contrast matrix (k × p_m) — SPSS standard
        H_m = np.zeros((k, p_m))
        for j in range(p_m):
            n_j = j + 1
            H_m[:n_j, j] = 1.0 / np.sqrt(n_j * (n_j + 1))
            H_m[n_j,  j] = -np.sqrt(n_j / (n_j + 1))

        # Transform Y and compute covariance
        T    = Y @ H_m                        # N × p_m
        SSCP = (T - T.mean(axis=0)).T @ (T - T.mean(axis=0))
        S    = SSCP / n_eff                   # pooled covariance

        det_S = float(np.linalg.det(S))
        tr_S  = float(np.trace(S))
        W     = float(np.clip(
            det_S / (tr_S / p_m) ** p_m, 1e-15, 1.0))

        df_c = p_m * (p_m + 1) // 2 - 1
        u    = n_eff - (2 * p_m**2 + p_m + 2) / (6 * p_m)
        chi2 = -u * np.log(W)
        p_W  = float(scipy_stats.chi2.sf(chi2, df_c)) if df_c > 0 else np.nan

        # Greenhouse-Geisser epsilon
        eigenvalues = np.linalg.eigvalsh(S)
        eigenvalues = eigenvalues[eigenvalues > 1e-10]
        if len(eigenvalues) == 0:
            eps_gg = 1.0
        else:
            eps_gg = float(np.clip(
                np.sum(eigenvalues) ** 2
                / (p_m * np.sum(eigenvalues ** 2)),
                1.0 / p_m, 1.0))

        # Huynh-Feldt epsilon
        num_hf = n_eff * p_m * eps_gg - 2
        den_hf = p_m * (n_eff - 1 - p_m * eps_gg)
        eps_hf = float(np.clip(
            num_hf / den_hf if den_hf > 0 else 1.0,
            eps_gg, 1.0))

        sphericity_assumed = (not np.isnan(p_W)) and (p_W > 0.05)

        if sphericity_assumed:
            correction = "None required"
        elif eps_gg >= 0.75:
            correction = "Huynh-Feldt recommended (\u03b5\u2009\u2265\u2009.75)"
        else:
            correction = "Greenhouse-Geisser recommended (\u03b5\u2009<\u2009.75)"

        return {
            "W":                  W,
            "chi2":               float(chi2),
            "df":                 df_c,
            "p":                  p_W,
            "sphericity_assumed": sphericity_assumed,
            "epsilon_gg":         eps_gg,
            "epsilon_hf":         eps_hf,
            "epsilon_lb":         1.0 / (k - 1),
            "correction":         correction,
        }
    except Exception:
        return None
