"""
modules/ancova.py
=================
ANCOVA family — SPSS General Linear Model equivalent.

Supported analyses:
  1. One-Way ANCOVA   — 1 factor + 1+ covariate
  2. Factorial ANCOVA — 2 factors + 1+ covariate
  3. Repeated Measures ANCOVA — within-subjects + covariate
  4. Mixed ANCOVA     — between × within + covariate
  5. MANCOVA          — multiple DVs + factor + covariate

All parametric tests use Type III Sum of Squares (SPSS GLM default).

Key references:
  Field, A. (2018). Discovering statistics using IBM SPSS (5th ed.).
  Tabachnick, B. G., & Fidell, L. S. (2013). Using multivariate statistics (6th ed.).
"""

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
from statsmodels.stats.anova import anova_lm
from statsmodels.stats.diagnostic import lilliefors
from itertools import combinations
import patsy
from patsy.contrasts import Sum
from modules.normality import test_normality
import pingouin as pg
import warnings
warnings.filterwarnings("ignore")


# ══════════════════════════════════════════════════════════════════════════════
# SHARED HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _partial_eta2(ss_effect, ss_error):
    d = ss_effect + ss_error
    return float(ss_effect / d) if d > 0 else np.nan

def _omega2(ss_effect, df_effect, ms_error, ss_total):
    num = ss_effect - df_effect * ms_error
    den = ss_total + ms_error
    return float(max(num / den, 0.0)) if den > 0 else np.nan

def _cohens_f(eta2):
    if np.isnan(eta2) or eta2 >= 1.0: return np.nan
    return float(np.sqrt(eta2 / (1.0 - eta2)))

def _power_f(f2, df_num, df_den, alpha=0.05):
    if any(np.isnan(v) or v <= 0 for v in [f2, df_num, df_den]): return np.nan
    try:
        n   = df_num + df_den + 1
        ncp = f2 * n
        fc  = scipy_stats.f.ppf(1 - alpha, df_num, df_den)
        return float(np.clip(scipy_stats.ncf.sf(fc, df_num, df_den, ncp), 0, 1))
    except Exception:
        return np.nan

def _normality_residuals(residuals):
    res = np.array(residuals, dtype=float)
    n   = len(res)
    if n < 3 or float(np.std(res)) < 1e-10:
        return {"pass": False, "sw_W": np.nan, "sw_p": np.nan,
                "ks_D": np.nan, "ks_p": np.nan, "n": n, "primary": "sw"}
    try:   sw_W, sw_p = scipy_stats.shapiro(res)
    except: sw_W, sw_p = np.nan, np.nan
    try:
        meth = "table" if n < 50 else "approx"
        ks_D, ks_p = lilliefors(res, dist="norm", pvalmethod=meth)
    except: ks_D, ks_p = np.nan, np.nan
    primary = "sw" if n < 50 else "ks"
    passed  = (float(sw_p) > 0.05 if primary == "sw" and not np.isnan(sw_p)
               else float(ks_p) >= 0.05 if not np.isnan(ks_p) else False)
    return {"pass": passed, "n": n, "primary": primary,
            "sw_W": round(float(sw_W), 3) if not np.isnan(sw_W) else np.nan,
            "sw_p": round(float(sw_p), 3) if not np.isnan(sw_p) else np.nan,
            "ks_D": round(float(ks_D), 3) if not np.isnan(ks_D) else np.nan,
            "ks_p": round(float(ks_p), 3) if not np.isnan(ks_p) else np.nan}

def _levene(*groups):
    try:
        F, p = scipy_stats.levene(*groups, center='mean')
        return {"F": round(float(F), 3), "p": round(float(p), 3),
                "passed": float(p) > 0.05}
    except Exception:
        return {"F": np.nan, "p": np.nan, "passed": False}

def _descriptives_group(data, label):
    a = np.array(data, dtype=float)
    n = len(a)
    m = float(np.mean(a))
    sd = float(np.std(a, ddof=1)) if n > 1 else np.nan
    se = float(scipy_stats.sem(a)) if n > 1 else np.nan
    med = float(np.median(a))
    iqr = float(np.percentile(a, 75) - np.percentile(a, 25))
    var = float(np.var(a, ddof=1)) if n > 1 else np.nan
    mn  = float(np.min(a)); mx = float(np.max(a))
    skw = float(scipy_stats.skew(a)) if n > 2 else np.nan
    kur = float(scipy_stats.kurtosis(a)) if n > 3 else np.nan
    tc  = scipy_stats.t.ppf(0.975, n-1) if n > 1 else np.nan
    ci_l = float(m - tc*se) if not np.isnan(tc) else np.nan
    ci_u = float(m + tc*se) if not np.isnan(tc) else np.nan
    return {"Group/Variable": label, "N": n,
            "Mean": round(m,3), "Median": round(med,3),
            "Std. Deviation": round(sd,3) if not np.isnan(sd) else np.nan,
            "Variance": round(var,3) if not np.isnan(var) else np.nan,
            "Std. Error": round(se,3) if not np.isnan(se) else np.nan,
            "95% CI Lower": round(ci_l,3) if not np.isnan(ci_l) else np.nan,
            "95% CI Upper": round(ci_u,3) if not np.isnan(ci_u) else np.nan,
            "Minimum": round(mn,3), "Maximum": round(mx,3),
            "IQR": round(iqr,3),
            "Skewness": round(skw,3) if not np.isnan(skw) else np.nan,
            "Kurtosis": round(kur,3) if not np.isnan(kur) else np.nan}


def _normality_residuals_per_group(residuals, factor):
    """
    Normality of residuals tested per group — SPSS method.
    SPSS saves unstandardized residuals then tests per group via Explore.
    Returns dict with per_group results and overall pass.
    """
    res = np.array(residuals, dtype=float)
    fac = np.array(factor)
    per_group = {}
    for lv in sorted(np.unique(fac)):
        group_res = res[fac == lv]
        per_group[str(lv)] = _normality_residuals(group_res)
    all_pass = all(r["pass"] for r in per_group.values())
    return {"per_group": per_group, "pass": all_pass}


def _descriptives_with_total(y, fac, y_name="Y"):
    """Descriptives per group + Total row — SPSS style."""
    rows = []
    for lv in sorted(np.unique(fac)):
        mask = fac == lv
        rows.append(_descriptives_group(y[mask], str(lv)))
    # Total row
    rows.append(_descriptives_group(y, "Total"))
    return pd.DataFrame(rows)


def _compute_emms(model, df, factor_name, cov_names, y_name, alpha=0.05):
    """Estimated Marginal Means at grand mean of covariate(s) — SPSS method."""
    levels    = sorted(df[factor_name].unique())
    grand_cov = {c: float(df[c].mean()) for c in cov_names}
    pct       = int((1 - alpha) * 100)
    rows      = []
    for level in levels:
        pred_dict = {factor_name: [level]}
        pred_dict.update({c: [grand_cov[c]] for c in cov_names})
        pred_df   = pd.DataFrame(pred_dict)
        try:
            pr  = model.get_prediction(pred_df)
            emm = round(float(pr.predicted_mean[0]), 3)
            se  = round(float(pr.se_mean[0]), 3)
            ci  = pr.conf_int(alpha=alpha)
            cl  = round(float(ci[0, 0]), 3)
            cu  = round(float(ci[0, 1]), 3)
        except Exception:
            emm = se = cl = cu = np.nan
        # Unadjusted mean — use y_name directly from df
        if y_name in df.columns:
            unadj = round(float(df.loc[df[factor_name]==level, y_name].mean()), 3)
        else:
            unadj = np.nan
        n_grp = int((df[factor_name] == level).sum())
        rows.append({"": str(level), "N": n_grp,
                     "Unadjusted Mean": unadj,
                     "Adjusted Mean": emm, "Std. Error": se,
                     f"{pct}% CI Lower": cl, f"{pct}% CI Upper": cu})
    return pd.DataFrame(rows)


def _compute_emms_2way(model, df, fa, fb, cov_names, alpha=0.05):
    """EMMs for each cell and each margin in Factorial ANCOVA.
    Marginal EMMs use the delta method (averaged design rows) for SE — matches SPSS.
    """
    grand_cov = {c: float(df[c].mean()) for c in cov_names}
    pct       = int((1 - alpha) * 100)
    di        = model.model.data.design_info
    vcov      = model.cov_params().values
    df_err    = float(model.df_resid)
    tc        = scipy_stats.t.ppf(1 - alpha / 2, df_err)

    def _design_row(fav, fbv):
        """Design row for (fav, fbv) at grand-mean covariates."""
        row = {fa: [fav], fb: [fbv],
               **{c: [grand_cov[c]] for c in cov_names}}
        try:
            return np.asarray(
                patsy.dmatrix(di, pd.DataFrame(row), return_type="matrix")[0])
        except Exception:
            return None

    def _emm_se_ci(L_row):
        """EMM, SE, CI from a (possibly averaged) design row L."""
        try:
            emm = float(L_row @ model.params.values)
            var = float(L_row @ vcov @ L_row.T)
            se  = float(np.sqrt(max(var, 0.0)))
            return round(emm,3), round(se,3), round(emm-tc*se,3), round(emm+tc*se,3)
        except Exception:
            return np.nan, np.nan, np.nan, np.nan

    lvls_a = sorted(df[fa].unique())
    lvls_b = sorted(df[fb].unique())

    # ── Cell EMMs ─────────────────────────────────────────────────────────
    cell_rows = []
    cell_design = {}   # cache: (la,lb) → design row
    for la in lvls_a:
        for lb in lvls_b:
            L = _design_row(la, lb)
            cell_design[(la, lb)] = L
            if L is not None:
                emm, se, cl, cu = _emm_se_ci(L)
            else:
                emm = se = cl = cu = np.nan
            n_cell = int(((df[fa]==la) & (df[fb]==lb)).sum())
            cell_rows.append({
                fa: str(la), fb: str(lb), "N": n_cell,
                "Adjusted Mean": emm, "Std. Error": se,
                f"{pct}% CI Lower": cl, f"{pct}% CI Upper": cu,
            })

    # ── Marginal A (average over B levels) ────────────────────────────────
    a_rows = []
    for la in lvls_a:
        rows_b = [cell_design[(la, lb)] for lb in lvls_b
                  if cell_design.get((la, lb)) is not None]
        if rows_b:
            L_marg = np.mean(rows_b, axis=0)
            emm, se, cl, cu = _emm_se_ci(L_marg)
        else:
            emm = se = cl = cu = np.nan
        a_rows.append({
            fa: str(la),
            "Adjusted Mean": emm, "Std. Error": se,
            f"{pct}% CI Lower": cl, f"{pct}% CI Upper": cu,
        })

    # ── Marginal B (average over A levels) ────────────────────────────────
    b_rows = []
    for lb in lvls_b:
        rows_a = [cell_design[(la, lb)] for la in lvls_a
                  if cell_design.get((la, lb)) is not None]
        if rows_a:
            L_marg = np.mean(rows_a, axis=0)
            emm, se, cl, cu = _emm_se_ci(L_marg)
        else:
            emm = se = cl = cu = np.nan
        b_rows.append({
            fb: str(lb),
            "Adjusted Mean": emm, "Std. Error": se,
            f"{pct}% CI Lower": cl, f"{pct}% CI Upper": cu,
        })

    return pd.DataFrame(cell_rows), pd.DataFrame(a_rows), pd.DataFrame(b_rows)


def _ph_adjust(p_raw, diff, se_d, df_e, n_comp, k_groups, alpha, method):
    """Return (p_adj, t_c, label) for a post-hoc method.
    Methods: lsd, bonferroni, sidak, scheffe."""
    method = (method or "bonferroni").lower()
    if method == "lsd":
        p_adj = p_raw
        t_c   = scipy_stats.t.ppf(1 - alpha/2, df_e)
        lbl   = "LSD"
    elif method == "sidak":
        p_adj = min(1.0, float(1 - (1 - p_raw) ** n_comp))
        t_c   = scipy_stats.t.ppf(1 - (1-(1-alpha)**(1/n_comp))/2, df_e)
        lbl   = "Sidak"
    elif method == "scheffe":
        F_s   = (diff / se_d) ** 2 / max(k_groups - 1, 1) if se_d > 0 else np.nan
        p_adj = float(scipy_stats.f.sf(F_s, max(k_groups-1,1), df_e)) if not np.isnan(F_s) else np.nan
        fc    = max(k_groups-1,1) * scipy_stats.f.ppf(1-alpha, max(k_groups-1,1), df_e)
        t_c   = np.sqrt(fc)
        lbl   = "Scheffe"
    else:  # bonferroni
        p_adj = min(1.0, p_raw * n_comp)
        t_c   = scipy_stats.t.ppf(1 - alpha/(2*n_comp), df_e)
        lbl   = "Bonferroni"
    return p_adj, t_c, lbl


def _pairwise_comparisons(model, df, factor_name, cov_names,
                           alpha=0.05, method="bonferroni"):
    """
    Pairwise comparisons of EMMs.
    Methods: 'lsd' (none), 'bonferroni', 'sidak', 'scheffe'.
    SE via delta method using patsy design matrix + model vcov.
    """
    levels  = sorted(df[factor_name].unique())
    pairs   = list(combinations(levels, 2))
    n_comp  = len(pairs)
    k_groups= len(levels)
    pct     = int((1 - alpha) * 100)
    grand_cov = {c: float(df[c].mean()) for c in cov_names}
    df_err    = float(model.df_resid)
    vcov      = model.cov_params().values
    di        = model.model.data.design_info
    meth_lbl  = {"lsd":"LSD","bonferroni":"Bonferroni",
                  "sidak":"Sidak","scheffe":"Scheffe"}.get(method,"Bonferroni")

    def _adjust(p_raw, diff, se_d, df_e):
        if method == "lsd":
            p_adj = p_raw
            t_c   = scipy_stats.t.ppf(1 - alpha / 2, df_e)
        elif method == "sidak":
            p_adj = float(1 - (1 - p_raw) ** n_comp)
            p_adj = min(1.0, p_adj)
            t_c   = scipy_stats.t.ppf(1 - (1-(1-alpha)**(1/n_comp))/2, df_e)
        elif method == "scheffe":
            F_s   = (diff / se_d) ** 2 / (k_groups - 1)
            p_adj = float(scipy_stats.f.sf(F_s, k_groups-1, df_e))
            fc    = (k_groups-1) * scipy_stats.f.ppf(1-alpha, k_groups-1, df_e)
            t_c   = np.sqrt(fc)
        else:  # bonferroni
            p_adj = min(1.0, p_raw * n_comp)
            t_c   = scipy_stats.t.ppf(1 - alpha / (2 * n_comp), df_e)
        return p_adj, t_c

    rows = []
    for (g1, g2) in pairs:
        d1 = pd.DataFrame({factor_name: [g1],
                           **{c: [grand_cov[c]] for c in cov_names}})
        d2 = pd.DataFrame({factor_name: [g2],
                           **{c: [grand_cov[c]] for c in cov_names}})
        try:
            dm1   = np.asarray(patsy.dmatrix(di, d1, return_type='matrix')[0])
            dm2   = np.asarray(patsy.dmatrix(di, d2, return_type='matrix')[0])
            x_d   = dm1 - dm2
            var_d = float(x_d @ vcov @ x_d.T)
            se_d  = float(np.sqrt(max(var_d, 0.0)))
            emm1  = float(model.predict(d1)[0])
            emm2  = float(model.predict(d2)[0])
            diff  = emm1 - emm2
            t_s   = diff / se_d if se_d > 0 else np.nan
            p_raw = float(2 * scipy_stats.t.sf(abs(t_s), df_err))
            p_adj, t_c = _adjust(p_raw, diff, se_d, df_err)
            cl    = diff - t_c * se_d
            cu    = diff + t_c * se_d
            sig   = "*" if p_adj < alpha else ""
            for (g_i, g_j, d) in [(g1, g2, diff), (g2, g1, -diff)]:
                rows.append({
                    "(I)": str(g_i), "(J)": str(g_j),
                    f"Mean Diff (I\u2212J)": f"{round(d,3)}{sig}",
                    "Std. Error":            round(se_d, 3),
                    f"Sig. ({meth_lbl})":    round(p_adj, 3),
                    f"{pct}% CI Lower":      round(cl if g_i==g1 else -cu, 3),
                    f"{pct}% CI Upper":      round(cu if g_i==g1 else -cl, 3),
                })
        except Exception:
            for (g_i, g_j) in [(g1, g2), (g2, g1)]:
                rows.append({"(I)": str(g_i), "(J)": str(g_j),
                             f"Mean Diff (I\u2212J)": np.nan,
                             "Std. Error": np.nan,
                             f"Sig. ({meth_lbl})": np.nan,
                             f"{pct}% CI Lower": np.nan,
                             f"{pct}% CI Upper": np.nan})
    return pd.DataFrame(rows)


def _pairwise_factorial(model, df, factor_name, other_factors, cov_names,
                        alpha=0.05, method="bonferroni"):
    """
    Pairwise comparisons for one factor in Factorial ANCOVA.
    Correctly marginalizes over all other categorical factors — matches SPSS EMM pairwise.
    """
    import itertools
    levels_a  = sorted(df[factor_name].unique())
    pairs     = list(combinations(levels_a, 2))
    n_comp    = len(pairs)
    k         = len(levels_a)
    grand_cov = {c: float(df[c].mean()) for c in cov_names}
    df_err    = float(model.df_resid)
    vcov      = model.cov_params().values
    di        = model.model.data.design_info
    pct       = int((1 - alpha) * 100)
    meth_lbl  = {"lsd": "LSD", "bonferroni": "Bonferroni",
                 "sidak": "Sidak", "scheffe": "Scheffe"}.get(method, "Bonferroni")

    # All combinations of other factors for marginalization
    other_levels = [sorted(df[of].unique()) for of in other_factors]
    all_combos   = list(itertools.product(*other_levels))

    def _design_row(lv_a, other_combo):
        """Design row for (lv_a, other_combo) at grand-mean covariate."""
        row = {factor_name: [lv_a], **{c: [grand_cov[c]] for c in cov_names}}
        for of, ov in zip(other_factors, other_combo):
            row[of] = [ov]
        return np.asarray(patsy.dmatrix(di, pd.DataFrame(row),
                                        return_type="matrix")[0])

    rows = []
    for (g1, g2) in pairs:
        try:
            # Marginal contrast: average design rows over all other-factor combos
            L1   = np.mean([_design_row(g1, c) for c in all_combos], axis=0)
            L2   = np.mean([_design_row(g2, c) for c in all_combos], axis=0)
            L    = L1 - L2

            emm1 = float(L1 @ model.params.values)
            emm2 = float(L2 @ model.params.values)
            diff = emm1 - emm2

            var_d = float(L @ vcov @ L.T)
            se_d  = float(np.sqrt(max(var_d, 0.0)))
            t_s   = diff / se_d if se_d > 0 else np.nan
            p_raw = float(2 * scipy_stats.t.sf(abs(t_s), df_err))

            if method == "lsd":
                p_adj = p_raw
                t_c   = scipy_stats.t.ppf(1 - alpha / 2, df_err)
            elif method == "sidak":
                p_adj = min(1.0, float(1 - (1 - p_raw) ** n_comp))
                t_c   = scipy_stats.t.ppf(
                    1 - (1 - (1-alpha)**(1/n_comp)) / 2, df_err)
            elif method == "scheffe":
                F_s   = (diff / se_d)**2 / (k - 1)
                p_adj = float(scipy_stats.f.sf(F_s, k-1, df_err))
                fc    = (k-1) * scipy_stats.f.ppf(1-alpha, k-1, df_err)
                t_c   = float(np.sqrt(fc))
            else:  # bonferroni
                p_adj = min(1.0, p_raw * n_comp)
                t_c   = scipy_stats.t.ppf(1 - alpha / (2 * n_comp), df_err)

            sig = "*" if p_adj < alpha else ""
            for (gi, gj, d) in [(g1, g2, diff), (g2, g1, -diff)]:
                # cl/cu recomputed per-d inside loop — use directly
                cl = d - t_c * se_d
                cu = d + t_c * se_d
                rows.append({
                    "(I)": str(gi), "(J)": str(gj),
                    f"Mean Diff (I\u2212J)": f"{round(d, 3)}{sig}",
                    "Std. Error":            round(se_d, 3),
                    f"Sig. ({meth_lbl})":    round(p_adj, 3),
                    f"{pct}% CI Lower":      round(cl, 3),
                    f"{pct}% CI Upper":      round(cu, 3),
                })
        except Exception:
            for (gi, gj) in [(g1, g2), (g2, g1)]:
                rows.append({
                    "(I)": str(gi), "(J)": str(gj),
                    f"Mean Diff (I\u2212J)": "\u2014",
                    "Std. Error": "\u2014",
                    f"Sig. ({meth_lbl})": "\u2014",
                    f"{pct}% CI Lower": "\u2014",
                    f"{pct}% CI Upper": "\u2014",
                })
    return pd.DataFrame(rows)


def _test_homogeneity_slopes(df, y_name, factor_name, cov_name):
    """Homogeneity of regression slopes — test factor × covariate interaction."""
    try:
        f_full = (f"Q('{y_name}') ~ C(Q('{factor_name}'), Sum) + Q('{cov_name}') + "
                  f"C(Q('{factor_name}'), Sum):Q('{cov_name}')")
        f_red  = (f"Q('{y_name}') ~ C(Q('{factor_name}'), Sum) + Q('{cov_name}')")
        m_f = smf.ols(f_full, data=df).fit()
        m_r = smf.ols(f_red,  data=df).fit()
        aov = anova_lm(m_r, m_f)
        F   = round(float(aov["F"].iloc[1]), 3)
        p   = round(float(aov["Pr(>F)"].iloc[1]), 3)
        passed = p > 0.05
    except Exception:
        F, p, passed = np.nan, np.nan, False
    return {
        "F": F, "p": p, "passed": passed,
        "note": ("Homogeneity of regression slopes satisfied — the "
                 "relationship between the covariate and outcome does not "
                 "significantly differ across groups (p\u2009>\u2009.05)."
                 if passed else
                 "Homogeneity of regression slopes VIOLATED — the "
                 "relationship between the covariate and outcome differs "
                 "significantly across groups (p\u2009\u2264\u2009.05). "
                 "Interpret ANCOVA results with caution and consider "
                 "group-specific regression models.")
    }


def _linearity_cov(df, y_name, cov_name, factor_name):
    """Pearson r between covariate and DV within each group."""
    rows = []
    for level, grp in df.groupby(factor_name):
        x = grp[cov_name].values; y = grp[y_name].values
        n = len(x)
        if n > 2:
            r, p = scipy_stats.pearsonr(x, y)
            rows.append({"Group": str(level), "N": n,
                         "r": round(float(r),3), "Sig.": round(float(p),3),
                         "passed": float(p) < 0.05})
        else:
            rows.append({"Group": str(level), "N": n,
                         "r": np.nan, "Sig.": np.nan, "passed": False})
    return pd.DataFrame(rows)


def _build_anova_table(aov3, model, y_name, cov_names, factor_names):
    """
    Build SPSS-style Between-Subjects Effects table from statsmodels anova_lm
    Type III output. Adds Partial η², Cohen's f, Power.
    """
    ss_error = float(aov3.loc["Residual", "sum_sq"])
    df_error = float(aov3.loc["Residual", "df"])
    ms_error = ss_error / df_error if df_error > 0 else np.nan
    n_total  = int(model.nobs)

    # Corrected Total
    y_vals   = model.model.endog
    ss_total = float(np.sum((y_vals - y_vals.mean()) ** 2))
    df_total = n_total - 1
    ss_model = ss_total - ss_error

    rows = []
    # Helper: noncentrality parameter
    def _noncent(F, df):
        try:
            v = float(F) * float(df)
            return round(v, 3) if not np.isnan(v) else ""
        except Exception:
            return ""

    # Corrected Model (all predictors combined)
    df_model = int(model.df_model)
    rows.append({
        "Source":              "Corrected Model",
        "Type III SS":         round(ss_model, 3),
        "df":                  df_model,
        "Mean Square":         round(ss_model/df_model, 3) if df_model > 0 else np.nan,
        "F":                   round(float(model.fvalue), 3)  if not np.isnan(model.fvalue)  else np.nan,
        "Sig.":                round(float(model.f_pvalue), 3) if not np.isnan(model.f_pvalue) else np.nan,
        "Partial η²":          round(_partial_eta2(ss_model, ss_error), 3),
        "Noncent. Parameter":  _noncent(model.fvalue, df_model),
    })

    # Intercept
    if "Intercept" in aov3.index:
        ss_i  = float(aov3.loc["Intercept","sum_sq"])
        df_i  = float(aov3.loc["Intercept","df"])
        F_i   = float(aov3.loc["Intercept","F"])
        p_i   = float(aov3.loc["Intercept","PR(>F)"])
        rows.append({
            "Source": "Intercept",
            "Type III SS": round(ss_i,3), "df": int(df_i),
            "Mean Square": round(ss_i/df_i,3) if df_i>0 else np.nan,
            "F": round(F_i,3) if not np.isnan(F_i) else np.nan,
            "Sig.": round(p_i,3) if not np.isnan(p_i) else np.nan,
            "Partial η²": round(_partial_eta2(ss_i, ss_error), 3),
            "Noncent. Parameter": _noncent(F_i, df_i),
        })

    # Covariates first, then factors — SPSS order
    skip = {"Intercept", "Residual"}
    # Separate covariates and factors
    cov_keys = [k for k in aov3.index
                if k not in skip and any(cn in k for cn in cov_names)]
    fac_keys = [k for k in aov3.index
                if k not in skip and k not in cov_keys]

    for src in cov_keys + fac_keys:
        ss   = float(aov3.loc[src,"sum_sq"])
        df_s = float(aov3.loc[src,"df"])
        F_s  = float(aov3.loc[src,"F"])
        p_s  = float(aov3.loc[src,"PR(>F)"])
        ms_s = ss/df_s if df_s > 0 else np.nan
        eta2 = _partial_eta2(ss, ss_error)
        f2   = (_cohens_f(eta2))**2 if not np.isnan(_cohens_f(eta2)) else np.nan
        pwr  = _power_f(f2, int(df_s), int(df_error)) if not np.isnan(f2) else np.nan

        # Clean source name
        src_clean = (src.replace("C(Q('","").replace("'), Sum)","")
                       .replace("'))", "").replace("Q('","").replace("')","")
                       .replace(":","×"))
        rows.append({
            "Source":             src_clean,
            "Type III SS":        round(ss,3),
            "df":                 int(df_s),
            "Mean Square":        round(ms_s,3) if not np.isnan(ms_s) else np.nan,
            "F":                  round(F_s,3)  if not np.isnan(F_s)  else np.nan,
            "Sig.":               round(p_s,3)  if not np.isnan(p_s)  else np.nan,
            "Partial η²":         round(eta2,3) if not np.isnan(eta2) else np.nan,
            "Noncent. Parameter": _noncent(F_s, df_s),
        })

    # Error
    rows.append({
        "Source": "Error",
        "Type III SS": round(ss_error,3), "df": int(df_error),
        "Mean Square": round(ms_error,3) if not np.isnan(ms_error) else np.nan,
        "F": "", "Sig.": "", "Partial η²": "", "Noncent. Parameter": "",
    })
    # Total (uncorrected)
    ss_unc = float(np.sum(y_vals**2))
    rows.append({
        "Source": "Total",
        "Type III SS": round(ss_unc,3), "df": n_total,
        "Mean Square": "", "F": "", "Sig.": "", "Partial η²": "",
        "Noncent. Parameter": "",
    })
    # Corrected Total
    rows.append({
        "Source": "Corrected Total",
        "Type III SS": round(ss_total,3), "df": df_total,
        "Mean Square": "", "F": "", "Sig.": "", "Partial η²": "",
        "Noncent. Parameter": "",
    })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# 1. ONE-WAY ANCOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_one_way_ancova(y, factor, covariate,
                       y_name="Score", factor_name="Group",
                       cov_name="Covariate", alpha=0.05,
                       posthoc_method="bonferroni"):
    """
    One-Way ANCOVA — SPSS GLM Univariate equivalent.
    Type III SS. EMMs at grand mean of covariate. Bonferroni pairwise.
    """
    y   = np.array(y, dtype=float)
    cov = np.array(covariate, dtype=float)
    fac = np.array(factor)
    n   = len(y)

    df = pd.DataFrame({y_name: y, factor_name: fac, cov_name: cov})

    # ── Fit model (Type III SS) ────────────────────────────────────────────
    formula = (f"Q('{y_name}') ~ Q('{cov_name}') + C(Q('{factor_name}'), Sum)")
    model   = smf.ols(formula, data=df).fit()
    aov3    = anova_lm(model, typ=3)

    # ── ANOVA table ───────────────────────────────────────────────────────
    anova_df = _build_anova_table(aov3, model, y_name, [cov_name], [factor_name])

    # ── Extract factor effect for effect size ─────────────────────────────
    ss_error  = float(aov3.loc["Residual","sum_sq"])
    df_error  = float(aov3.loc["Residual","df"])
    fac_key   = [k for k in aov3.index
                 if factor_name in k and "Intercept" not in k and "Residual" not in k]
    if fac_key:
        ss_fac  = float(aov3.loc[fac_key[0],"sum_sq"])
        df_fac  = float(aov3.loc[fac_key[0],"df"])
        F_fac   = float(aov3.loc[fac_key[0],"F"])
        p_fac   = float(aov3.loc[fac_key[0],"PR(>F)"])
    else:
        ss_fac = df_fac = F_fac = p_fac = np.nan

    eta2  = _partial_eta2(ss_fac, ss_error)
    f_val = _cohens_f(eta2)
    f2    = f_val**2 if not np.isnan(f_val) else np.nan
    power = _power_f(f2, int(df_fac) if not np.isnan(df_fac) else 1,
                     int(df_error), alpha)

    # ── EMMs ──────────────────────────────────────────────────────────────
    emm_df = _compute_emms(model, df, factor_name, [cov_name], y_name, alpha)

    # ── Pairwise comparisons ──────────────────────────────────────────────
    pw_df  = _pairwise_comparisons(model, df, factor_name, [cov_name],
                                    alpha, posthoc_method)

    # ── Assumption tests ──────────────────────────────────────────────────
    # Normality: overall model residuals, total_n=N (SPSS method)
    norm_res = test_normality(model.resid.values, label="Residuals", total_n=n)
    levene   = _levene(*[y[fac == lv] for lv in np.unique(fac)])
    slopes   = _test_homogeneity_slopes(df, y_name, factor_name, cov_name)
    lin_cov  = _linearity_cov(df, y_name, cov_name, factor_name)

    # ── Descriptives with Total row ───────────────────────────────────────
    desc_df = _descriptives_with_total(y, fac, y_name)

    # ── Overall summary ───────────────────────────────────────────────────
    all_ok = (norm_res["pass"] and levene["passed"] and
              slopes["passed"] and bool(lin_cov["passed"].any()))

    return {
        "type":          "One-Way ANCOVA",
        "y_name":        y_name,
        "factor_name":   factor_name,
        "cov_name":      cov_name,
        "n":             n,
        "alpha":         alpha,
        "model":         model,
        "anova_table":   anova_df,
        "emm":           emm_df,
        "pairwise":      pw_df,
        "ss_factor":     ss_fac,
        "F_factor":      round(F_fac, 3) if not np.isnan(F_fac) else np.nan,
        "p_factor":      round(p_fac, 3) if not np.isnan(p_fac) else np.nan,
        "partial_eta2":  round(eta2, 3) if not np.isnan(eta2) else np.nan,
        "cohens_f":      round(f_val, 3) if not np.isnan(f_val) else np.nan,
        "power":         round(power, 3) if not np.isnan(power) else np.nan,
        "normality":     norm_res,
        "levene":        levene,
        "slopes":        slopes,
        "linearity":     lin_cov,
        "descriptives":  desc_df,
        "all_ok":        all_ok,
        "grand_cov_mean":round(float(cov.mean()), 3),
        "posthoc_method":posthoc_method,
    }


# ══════════════════════════════════════════════════════════════════════════════
# 2. FACTORIAL ANCOVA (Two-Way)
# ══════════════════════════════════════════════════════════════════════════════

def run_factorial_ancova(y, factor_a, factor_b, covariate,
                          y_name="Score", fa_name="Factor A",
                          fb_name="Factor B", cov_name="Covariate",
                          alpha=0.05, posthoc_method="bonferroni"):
    """
    Two-Way (Factorial) ANCOVA — SPSS GLM Univariate.
    Type III SS. EMMs for A, B, and A×B. Bonferroni pairwise per factor.
    """
    y   = np.array(y, dtype=float)
    cov = np.array(covariate, dtype=float)
    fa  = np.array(factor_a); fb = np.array(factor_b)
    n   = len(y)

    df = pd.DataFrame({y_name: y, fa_name: fa, fb_name: fb, cov_name: cov})

    # ── Fit model ─────────────────────────────────────────────────────────
    formula = (f"Q('{y_name}') ~ Q('{cov_name}') + "
               f"C(Q('{fa_name}'), Sum) + C(Q('{fb_name}'), Sum) + "
               f"C(Q('{fa_name}'), Sum):C(Q('{fb_name}'), Sum)")
    model   = smf.ols(formula, data=df).fit()
    aov3    = anova_lm(model, typ=3)

    anova_df = _build_anova_table(aov3, model, y_name,
                                  [cov_name], [fa_name, fb_name])

    ss_error = float(aov3.loc["Residual","sum_sq"])
    df_error = float(aov3.loc["Residual","df"])

    def _extract(name):
        key = [k for k in aov3.index
               if name in k and "Intercept" not in k and "Residual" not in k]
        if not key: return np.nan, np.nan, np.nan, np.nan
        k = key[0]
        return (float(aov3.loc[k,"sum_sq"]), float(aov3.loc[k,"df"]),
                float(aov3.loc[k,"F"]),      float(aov3.loc[k,"PR(>F)"]))

    ss_a,  df_a,  F_a,  p_a  = _extract(fa_name)
    ss_b,  df_b,  F_b,  p_b  = _extract(fb_name)
    # Interaction key has both factor names
    ia_keys = [k for k in aov3.index if fa_name in k and fb_name in k]
    if ia_keys:
        k = ia_keys[0]
        ss_ab, df_ab, F_ab, p_ab = (float(aov3.loc[k,"sum_sq"]),
                                    float(aov3.loc[k,"df"]),
                                    float(aov3.loc[k,"F"]),
                                    float(aov3.loc[k,"PR(>F)"]))
    else:
        ss_ab = df_ab = F_ab = p_ab = np.nan

    eta2_a  = _partial_eta2(ss_a,  ss_error)
    eta2_b  = _partial_eta2(ss_b,  ss_error)
    eta2_ab = _partial_eta2(ss_ab, ss_error)

    # ── EMMs ──────────────────────────────────────────────────────────────
    emm_cell, emm_a, emm_b = _compute_emms_2way(model, df, fa_name, fb_name,
                                                  [cov_name], alpha)

    # ── Pairwise per factor — marginalizing over other factor (matches SPSS) ─
    pw_a = _pairwise_factorial(model, df, fa_name, [fb_name], [cov_name],
                                alpha, posthoc_method)
    pw_b = _pairwise_factorial(model, df, fb_name, [fa_name], [cov_name],
                                alpha, posthoc_method)

    # ── Assumption tests ──────────────────────────────────────────────────
    norm_res = test_normality(model.resid.values, label="Residuals", total_n=n)
    levene   = _levene(*[y[(fa == la) & (fb == lb)]
                        for la in np.unique(fa) for lb in np.unique(fb)
                        if len(y[(fa==la)&(fb==lb)]) > 0])
    slopes_a = _test_homogeneity_slopes(df, y_name, fa_name, cov_name)
    slopes_b = _test_homogeneity_slopes(df, y_name, fb_name, cov_name)
    lin_a    = _linearity_cov(df, y_name, cov_name, fa_name)
    lin_b    = _linearity_cov(df, y_name, cov_name, fb_name)

    # ── Descriptives per cell + Total ──────────────────────────────────────
    desc_rows = []
    for la in sorted(np.unique(fa)):
        for lb in sorted(np.unique(fb)):
            mask = (fa==la) & (fb==lb)
            if mask.sum() > 0:
                desc_rows.append(_descriptives_group(y[mask], f"{la} × {lb}"))
    desc_rows.append(_descriptives_group(y, "Total"))
    desc_df = pd.DataFrame(desc_rows)

    # ── Parameter Estimates (SPSS parameterization: reference = LAST level) ─
    param_rows = []
    try:
        dfp = pd.DataFrame({"y": y, "fa": pd.Series(fa).astype(str),
                            "fb": pd.Series(fb).astype(str), "cov": cov})
        _ml = sorted(dfp["fa"].unique()); _fl = sorted(dfp["fb"].unique())
        _refa, _reffb = _ml[-1], _fl[-1]
        mp = smf.ols(
            f'y ~ C(fa, Treatment(reference="{_refa}"))'
            f'*C(fb, Treatment(reference="{_reffb}")) + cov', data=dfp).fit()
        dfe = mp.df_resid
        ci  = mp.conf_int()
        # Friendly parameter labels
        def _lbl(nm):
            if nm == "Intercept": return "Intercept"
            if nm == "cov":       return cov_name
            out = nm
            out = out.replace(f'C(fa, Treatment(reference="{_refa}"))[T.', f'[{fa_name}=')
            out = out.replace(f'C(fb, Treatment(reference="{_reffb}"))[T.', f'[{fb_name}=')
            out = out.replace("]:", "] * ").replace("[T.", f"[")
            out = out.replace("]", "]")
            return out
        for nm in mp.params.index:
            B=float(mp.params[nm]); SE=float(mp.bse[nm]); t=float(mp.tvalues[nm]); p=float(mp.pvalues[nm])
            eta=t**2/(t**2+dfe)
            param_rows.append({"Parameter":_lbl(nm),"B":round(B,3),"Std. Error":round(SE,3),
                "t":round(t,3),"Sig.":round(p,3),"95% CI Lower":round(float(ci.loc[nm,0]),3),
                "95% CI Upper":round(float(ci.loc[nm,1]),3),"Partial \u03b7\u00b2":round(eta,3)})
    except Exception:
        pass
    param_estimates = pd.DataFrame(param_rows)

    # ── Univariate Tests (EMM-based contrast F per factor; SPSS EMMEANS) ──
    univ_rows = []
    try:
        _ssr = float(model.ssr); _dfr = float(model.df_resid)
        _mse = _ssr / _dfr if _dfr > 0 else np.nan
        for _ss, _dff, _fnm in [(ss_a, df_a, fa_name), (ss_b, df_b, fb_name)]:
            if _ss is None or (isinstance(_ss, float) and np.isnan(_ss)):
                continue
            _F = (_ss/_dff)/_mse if _mse and _mse > 0 else np.nan
            _p = float(scipy_stats.f.sf(_F, _dff, _dfr)) if not np.isnan(_F) else np.nan
            _eta = _ss/(_ss+_ssr) if (_ss+_ssr) > 0 else np.nan
            univ_rows.append({"Effect":_fnm,"Source":"Contrast",
                "Sum of Squares":round(_ss,3),"df":int(_dff),"Mean Square":round(_ss/_dff,3),
                "F":round(_F,3),"Sig.":round(_p,3),"Partial \u03b7\u00b2":round(_eta,3)})
            univ_rows.append({"Effect":_fnm,"Source":"Error",
                "Sum of Squares":round(_ssr,3),"df":int(_dfr),"Mean Square":round(_mse,3),
                "F":"","Sig.":"","Partial \u03b7\u00b2":""})
    except Exception:
        pass
    univariate_tests = pd.DataFrame(univ_rows)

    all_ok = (norm_res["pass"] and levene["passed"] and
              slopes_a["passed"] and slopes_b["passed"])

    return {
        "type":         "Factorial ANCOVA",
        "y_name":       y_name,
        "fa_name":      fa_name,
        "fb_name":      fb_name,
        "cov_name":     cov_name,
        "n":            n,
        "alpha":        alpha,
        "model":        model,
        "anova_table":  anova_df,
        "param_estimates": param_estimates,
        "univariate_tests": univariate_tests,
        "emm_cell":     emm_cell,
        "emm_a":        emm_a,
        "emm_b":        emm_b,
        "pairwise_a":   pw_a,
        "pairwise_b":   pw_b,
        # Factor A
        "F_a":          round(F_a,  3) if not np.isnan(F_a)  else np.nan,
        "p_a":          round(p_a,  3) if not np.isnan(p_a)  else np.nan,
        "eta2_a":       round(eta2_a,  3) if not np.isnan(eta2_a)  else np.nan,
        # Factor B
        "F_b":          round(F_b,  3) if not np.isnan(F_b)  else np.nan,
        "p_b":          round(p_b,  3) if not np.isnan(p_b)  else np.nan,
        "eta2_b":       round(eta2_b,  3) if not np.isnan(eta2_b)  else np.nan,
        # Interaction
        "F_ab":         round(F_ab, 3) if not np.isnan(F_ab) else np.nan,
        "p_ab":         round(p_ab, 3) if not np.isnan(p_ab) else np.nan,
        "eta2_ab":      round(eta2_ab, 3) if not np.isnan(eta2_ab) else np.nan,
        # Assumptions
        "normality":    norm_res,
        "levene":       levene,
        "slopes_a":     slopes_a,
        "slopes_b":     slopes_b,
        "linearity_a":  lin_a,
        "linearity_b":  lin_b,
        "descriptives": desc_df,
        "all_ok":       all_ok,
        "grand_cov_mean": round(float(cov.mean()), 3),
    }


# ══════════════════════════════════════════════════════════════════════════════
# 3. REPEATED MEASURES ANCOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_rm_ancova(data_wide, time_labels, covariate,
                  y_name="Score", time_name="Time",
                  subject_name="Subject", cov_name="Covariate",
                  alpha=0.05, posthoc_method="bonferroni"):
    """
    Repeated Measures ANCOVA — SPSS GLM Repeated Measures with covariate.

    Correct algorithm (matches SPSS):
    - Within-subjects effects via TYPE III SS from long-format OLS with
      subject fixed effects: y ~ C(subject) + C(time) + cov + C(time):cov
    - df_error_within = (T-1)(N-1-p) — SPSS formula
    - Between-subjects covariate via regression of subject means on cov
    - Mauchly's sphericity test + GG epsilon
    - Multivariate tests (Wilks, Pillai, Hotelling, Roy) via MANOVA
    """
    from statsmodels.multivariate.manova import MANOVA

    data_wide = np.array(data_wide, dtype=float)
    cov       = np.array(covariate, dtype=float)
    N, T      = data_wide.shape
    p         = 1            # number of covariates

    # ── Within-subjects: TYPE III SS via long-format OLS ─────────────────
    df_long = pd.DataFrame({
        "subject": np.repeat(np.arange(N), T).astype(str),
        "time":    np.tile(time_labels, N),
        "y":       data_wide.flatten(),
        "cov":     np.repeat(cov, T),
    })
    formula_w = "y ~ C(subject) + C(time) + cov + C(time):cov"
    model_w   = smf.ols(formula_w, data=df_long).fit()
    aov3_w    = anova_lm(model_w, typ=3)

    SS_resid  = float(aov3_w.loc["Residual", "sum_sq"])
    df_resid  = float(aov3_w.loc["Residual", "df"])   # = (T-1)(N-1-p)
    MS_resid  = SS_resid / df_resid if df_resid > 0 else np.nan

    # TIME main effect
    t_key = next((k for k in aov3_w.index
                  if "C(time)" in k and ":" not in k and "subject" not in k), None)
    SS_time   = float(aov3_w.loc[t_key, "sum_sq"]) if t_key else np.nan
    df_time   = T - 1
    MS_time   = SS_time / df_time
    F_time    = MS_time / MS_resid
    p_time    = float(scipy_stats.f.sf(F_time, df_time, df_resid))
    eta2_time = _partial_eta2(SS_time, SS_resid)

    # TIME × COV interaction (use theoretical df = T-1)
    tc_key = next((k for k in aov3_w.index
                   if "C(time)" in k and "cov" in k.lower()), None)
    SS_tc   = float(aov3_w.loc[tc_key, "sum_sq"]) if tc_key else np.nan
    df_tc   = T - 1                    # theoretical df
    MS_tc   = SS_tc / df_tc
    F_tc    = MS_tc / MS_resid
    p_tc    = float(scipy_stats.f.sf(F_tc, df_tc, df_resid))
    eta2_tc = _partial_eta2(SS_tc, SS_resid)

    # ── Between-subjects: covariate effect on subject means ──────────────
    subj_means = data_wide.mean(axis=1)
    cov_c      = cov - cov.mean()
    SS_cov_b   = T * float(np.sum(cov_c * subj_means) ** 2 / np.sum(cov_c ** 2))
    SS_subj    = T * float(np.sum((subj_means - subj_means.mean()) ** 2))
    SS_err_b   = SS_subj - SS_cov_b
    df_err_b   = N - 1 - p
    MS_err_b   = SS_err_b / df_err_b if df_err_b > 0 else np.nan
    F_cov      = SS_cov_b / MS_err_b if MS_err_b else np.nan
    p_cov      = float(scipy_stats.f.sf(F_cov, 1, df_err_b))
    eta2_cov   = _partial_eta2(SS_cov_b, SS_err_b)
    B_cov      = float(np.sum(cov_c * subj_means) / np.sum(cov_c ** 2))

    # ── Mauchly's sphericity test (SPSS method) ───────────────────────────
    # Uses ORTHONORMAL contrasts on the ANCOVA error SSCP (residuals after
    # covariate removed). W is only invariant under proper orthonormal contrasts.
    try:
        p_sz = T - 1
        # Build orthonormal Helmert contrast: (T-1) × T, rows mutually orthogonal
        C_mat = np.zeros((p_sz, T))
        for i in range(p_sz):
            C_mat[i, :i+1] = 1.0
            C_mat[i, i+1]  = -(i+1)
            C_mat[i]      /= np.linalg.norm(C_mat[i])
        # Transform to contrast space, regress out intercept + covariate
        Ystar  = data_wide @ C_mat.T                 # N × (T-1)
        Xdes   = np.column_stack([np.ones(N), cov])  # intercept + covariate
        beta_s = np.linalg.lstsq(Xdes, Ystar, rcond=None)[0]
        resid_s = Ystar - Xdes @ beta_s
        E_sscp  = resid_s.T @ resid_s                # error SSCP (T-1)×(T-1)
        df_e_s  = N - 1 - p                          # n − 1 − n_covariates

        W_raw  = float(np.linalg.det(E_sscp) /
                       (np.trace(E_sscp) / p_sz) ** p_sz)
        W      = float(np.clip(W_raw, 1e-10, 1.0))
        d_corr = 1.0 - (2*p_sz**2 + p_sz + 2) / (6 * p_sz * df_e_s)
        chi2_W = -df_e_s * d_corr * np.log(W)
        df_mauchly = p_sz * (p_sz + 1) // 2 - 1
        p_mauchly  = float(scipy_stats.chi2.sf(chi2_W, max(df_mauchly, 1)))
        # GG epsilon from eigenvalues of error covariance (E / df_e)
        eig    = np.linalg.eigvalsh(E_sscp / df_e_s)
        eig    = eig[eig > 1e-12]
        eps_gg = float(np.clip(eig.sum()**2 / (p_sz * (eig**2).sum()),
                               1.0/(T-1), 1.0))
    except Exception:
        W = chi2_W = p_mauchly = eps_gg = np.nan
        df_mauchly = 0

    # GG-corrected df and p
    df_time_gg  = round(df_time * eps_gg, 3) if not np.isnan(eps_gg) else np.nan
    df_resid_gg = round(df_resid * eps_gg, 3) if not np.isnan(eps_gg) else np.nan
    p_time_gg   = (float(scipy_stats.f.sf(F_time, df_time_gg, df_resid_gg))
                   if not np.isnan(df_time_gg) else np.nan)

    # ── Multivariate tests (MANOVA on contrast scores) ────────────────────
    # Must use RAW covariate (not centered) to match SPSS within-subjects tests.
    mv_time = mv_tc = None
    try:
        # Orthonormal Helmert contrast scores (same basis as Mauchly)
        _Cmv = np.zeros((T-1, T))
        for _i in range(T-1):
            _Cmv[_i, :_i+1] = 1.0
            _Cmv[_i, _i+1]  = -(_i+1)
            _Cmv[_i]       /= np.linalg.norm(_Cmv[_i])
        Z = data_wide @ _Cmv.T
        df_mv = pd.DataFrame(Z, columns=[f"z{j}" for j in range(T-1)])
        df_mv["cov"] = cov
        z_str = " + ".join([f"z{j}" for j in range(T-1)])
        maov  = MANOVA.from_formula(f"{z_str} ~ cov", data=df_mv)
        mv_res = maov.mv_test()

        def _mv(label):
            try:
                for k in mv_res.results:
                    if label.lower() in str(k).lower():
                        tbl = mv_res.results[k]["stat"]
                        V   = float(tbl.loc["Pillai's trace","Value"])
                        Lam = float(tbl.loc["Wilks' lambda","Value"])
                        T0  = float(tbl.loc["Hotelling-Lawley trace","Value"])
                        th  = float(tbl.loc["Roy's greatest root","Value"])
                        dfh = float(tbl.loc["Pillai's trace","Num DF"])
                        dfe = float(tbl.loc["Pillai's trace","Den DF"])
                        s   = min(T-1, 1)  # within-subj effects here have 1 between-df
                        eta = round(V / max(s,1), 3)
                        Fp  = float(tbl.loc["Pillai's trace","F Value"])
                        return {
                            "Wilks":round(Lam,3),"F_Wilks":round(float(tbl.loc["Wilks' lambda","F Value"]),3),
                            "p_Wilks":round(float(tbl.loc["Wilks' lambda","Pr > F"]),3),
                            "Pillai":round(V,3),"F_Pillai":round(Fp,3),
                            "p_Pillai":round(float(tbl.loc["Pillai's trace","Pr > F"]),3),
                            "Hotelling":round(T0,3),"F_HL":round(float(tbl.loc["Hotelling-Lawley trace","F Value"]),3),
                            "p_HL":round(float(tbl.loc["Hotelling-Lawley trace","Pr > F"]),3),
                            "Roy":round(th,3),"F_Roy":round(float(tbl.loc["Roy's greatest root","F Value"]),3),
                            "p_Roy":round(float(tbl.loc["Roy's greatest root","Pr > F"]),3),
                            "df_hyp":int(dfh),"df_err":int(dfe),"eta2":eta,
                            "noncent":round(Fp*dfh,3),
                        }
            except Exception:
                pass
            return None
        mv_time = _mv("intercept")
        mv_tc   = _mv("cov")
    except Exception:
        pass

    # ── EMMs at each time point ───────────────────────────────────────────
    grand_cov_m = float(cov.mean())
    pct = int((1 - alpha) * 100)
    emm_rows = []
    for t_i, t_lbl in enumerate(time_labels):
        col = data_wide[:, t_i]
        m   = float(col.mean())
        se  = float(scipy_stats.sem(col))
        tc  = scipy_stats.t.ppf(1 - alpha/2, N - 1 - p)
        emm_rows.append({
            time_name:       t_lbl,
            "N":             N,
            "Unadjusted Mean": round(m, 3),
            "Adjusted Mean":   round(m, 3),
            "Std. Error":      round(se, 3),
            f"{pct}% CI Lower": round(m - tc*se, 3),
            f"{pct}% CI Upper": round(m + tc*se, 3),
        })
    emm_df = pd.DataFrame(emm_rows)

    # ── Pairwise TIME comparisons (selected post-hoc method) ──────────────
    pairs  = list(combinations(range(T), 2))
    n_comp = len(pairs)
    pw_rows = []
    _ph_lbl = "Bonferroni"
    for (i, j) in pairs:
        di    = data_wide[:, i] - data_wide[:, j]
        diff  = float(di.mean())
        se_d  = float(di.std(ddof=1) / np.sqrt(N))
        t_s   = diff / se_d if se_d > 0 else np.nan
        p_raw = float(2 * scipy_stats.t.sf(abs(t_s), N-1))
        p_adj, tc, _ph_lbl = _ph_adjust(p_raw, diff, se_d, N-1,
                                        n_comp, T, alpha, posthoc_method)
        sig   = "*" if p_adj < alpha else ""
        for (gi, gj, d) in [(i, j, diff), (j, i, -diff)]:
            pw_rows.append({
                "(I) Time": time_labels[gi], "(J) Time": time_labels[gj],
                "Mean Diff (I\u2212J)": f"{round(d,3)}{sig}",
                "Std. Error":          round(se_d, 3),
                f"Sig. ({_ph_lbl})":   round(p_adj, 3),
                f"{pct}% CI Lower":    round(d - tc*se_d, 3),
                f"{pct}% CI Upper":    round(d + tc*se_d, 3),
            })
    pw_df = pd.DataFrame(pw_rows)

    # ── Normality: overall model residuals with total_n=N (SPSS method) ──
    norm_res = test_normality(model_w.resid.values, label="Residuals", total_n=N)
    levene   = _levene(*[data_wide[:, i] for i in range(T)])

    # ── Descriptives ─────────────────────────────────────────────────────
    desc_rows = [_descriptives_group(data_wide[:, i], t)
                 for i, t in enumerate(time_labels)]
    # Total = subject means (each subject contributes 1 row)
    desc_rows.append(_descriptives_group(subj_means, "Total (Subject Means)"))
    desc_df = pd.DataFrame(desc_rows)

    # ── Within-Subjects Contrasts (polynomial: Linear, Quadratic, ...) ────
    contrast_rows = []
    try:
        _raw = np.polynomial.polynomial.polyvander(np.arange(T), T-1)
        _Q, _ = np.linalg.qr(_raw)
        Ppoly = _Q[:, 1:].T
        cnames = ["Linear","Quadratic","Cubic","Quartic","Order 5","Order 6"]
        for ci in range(T-1):
            zc  = data_wide @ Ppoly[ci]
            dcf = pd.DataFrame({"z": zc, "cov": cov})
            ac  = anova_lm(smf.ols("z ~ cov", data=dcf).fit(), typ=3)
            cl  = cnames[ci] if ci < len(cnames) else f"Order {ci+1}"
            ss_i=float(ac.loc["Intercept","sum_sq"]); F_i=float(ac.loc["Intercept","F"]); p_i=float(ac.loc["Intercept","PR(>F)"])
            ss_c=float(ac.loc["cov","sum_sq"]); F_c=float(ac.loc["cov","F"]); p_c=float(ac.loc["cov","PR(>F)"])
            ss_e=float(ac.loc["Residual","sum_sq"]); df_e=int(ac.loc["Residual","df"])
            contrast_rows.append({"Source":"TIME","Contrast":cl,"Type III SS":round(ss_i,3),
                "df":1,"MS":round(ss_i,3),"F":round(F_i,3),"Sig.":round(p_i,3)})
            contrast_rows.append({"Source":f"TIME \u00d7 {cov_name}","Contrast":cl,"Type III SS":round(ss_c,3),
                "df":1,"MS":round(ss_c,3),"F":round(F_c,3),"Sig.":round(p_c,3)})
            contrast_rows.append({"Source":"Error(TIME)","Contrast":cl,"Type III SS":round(ss_e,3),
                "df":df_e,"MS":round(ss_e/df_e,3) if df_e>0 else np.nan,"F":"","Sig.":""})
    except Exception:
        pass
    contrasts_df = pd.DataFrame(contrast_rows)

    return {
        "type":           "Repeated Measures ANCOVA",
        "y_name":         y_name,
        "time_name":      time_name,
        "cov_name":       cov_name,
        "time_labels":    time_labels,
        "n":              N, "T": T, "alpha": alpha,
        # Within-subjects TIME
        "F_time":         round(F_time,  3), "p_time":  round(p_time,  3),
        "df_time":        df_time, "df_resid_within": int(df_resid),
        "SS_time":        round(SS_time, 3), "MS_time": round(MS_time, 3),
        "eta2_time":      round(eta2_time, 3),
        # GG correction
        "eps_gg":         round(eps_gg, 3) if not np.isnan(eps_gg) else np.nan,
        "p_time_gg":      round(p_time_gg, 3) if not np.isnan(p_time_gg) else np.nan,
        "df_time_gg":     df_time_gg,
        # TIME × COV
        "F_tc":           round(F_tc, 3), "p_tc": round(p_tc, 3),
        "SS_tc":          round(SS_tc, 3), "df_tc": df_tc,
        "eta2_tc":        round(eta2_tc, 3),
        # Mauchly
        "mauchly_W":      round(float(W), 3) if not np.isnan(W) else np.nan,
        "mauchly_chi2":   round(chi2_W, 3)   if not np.isnan(chi2_W) else np.nan,
        "mauchly_df":     df_mauchly, "mauchly_p": round(p_mauchly, 3)
                          if not np.isnan(p_mauchly) else np.nan,
        # Multivariate
        "mv_time":        mv_time, "mv_tc": mv_tc,
        # Between-subjects covariate
        "F_cov":          round(F_cov, 3),  "p_cov":  round(p_cov, 3),
        "SS_cov":         round(SS_cov_b,3),"df_err_between": df_err_b,
        "eta2_cov":       round(eta2_cov,3),"B_cov":  round(B_cov, 3),
        "grand_cov_mean": round(grand_cov_m, 3),
        # Tables
        "emm":            emm_df,
        "pairwise_time":  pw_df,
        "contrasts":      contrasts_df,
        "descriptives":   desc_df,
        "normality":      norm_res, "levene": levene,
        "all_ok":         norm_res["pass"] and levene["passed"],
    }


# ══════════════════════════════════════════════════════════════════════════════
# 4. MIXED ANCOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_mixed_ancova(data_wide, time_labels, between_factor, covariate,
                     y_name="Score", time_name="Time",
                     between_name="Group", subject_name="Subject",
                     cov_name="Covariate", alpha=0.05, posthoc_method="bonferroni"):
    """
    Mixed ANCOVA — Between × Within (Repeated) + Covariate.
    Correct algorithm matching SPSS GLM Repeated Measures:

    Within-subjects (TIME, TIME×GROUP, TIME×COV):
      Long-format OLS with subject FE: y ~ C(subject) + C(time)
        + C(time):C(group) + C(time):cov
      df_error_within = (T-1)(N-k-p) — SPSS formula

    Between-subjects (GROUP, COV):
      ANCOVA on subject means: m ~ C(group) + cov
      df_error_between = N-k-p
    """
    from statsmodels.multivariate.manova import MANOVA

    data_wide      = np.array(data_wide, dtype=float)
    between_factor = np.array(between_factor)
    cov            = np.array(covariate, dtype=float)
    N, T           = data_wide.shape
    k              = len(np.unique(between_factor))
    p              = 1

    # ── Within-subjects model ─────────────────────────────────────────────
    # SPSS GLM uses sum-to-zero (effect) coding for Type III + raw covariate.
    df_long = pd.DataFrame({
        "subject": np.repeat(np.arange(N), T).astype(str),
        "time":    np.tile(time_labels, N),
        "group":   np.repeat(between_factor, T).astype(str),
        "y":       data_wide.flatten(),
        "cov":     np.repeat(cov, T),
    })
    formula_w  = ("y ~ C(time, Sum)*C(group, Sum) + cov "
                  "+ C(time, Sum):cov + C(subject, Sum)")
    model_w    = smf.ols(formula_w, data=df_long).fit()
    aov3_w     = anova_lm(model_w, typ=3)

    SS_resid_w = float(aov3_w.loc["Residual", "sum_sq"])
    df_resid_w = float(aov3_w.loc["Residual", "df"])  # = (T-1)(N-k-p)
    MS_resid_w = SS_resid_w / df_resid_w if df_resid_w > 0 else np.nan
    # Theoretical df_error for within = (T-1)(N-k-p)
    df_within_correct = (T-1) * (N - k - p)

    def _extract_w(key_substr, df_effect):
        """Get TYPE III SS for a within-subjects effect and compute F.
        Exact key resolution to avoid TIME matching TIME×GROUP etc."""
        # Map logical effect to the exact statsmodels index label
        exact = {
            "time":       "C(time, Sum)",
            "time:group": "C(time, Sum):C(group, Sum)",
            "time:cov":   "C(time, Sum):cov",
        }.get(key_substr)
        key = None
        if exact is not None and exact in aov3_w.index:
            key = exact
        else:
            cand = [k2 for k2 in aov3_w.index
                    if key_substr in k2 and "subject" not in k2.lower()
                    and "Residual" not in k2]
            key = cand[0] if cand else None
        if key is None:
            return np.nan, np.nan, np.nan, np.nan
        SS  = float(aov3_w.loc[key, "sum_sq"])
        MS  = SS / df_effect if df_effect > 0 else np.nan
        F   = MS / MS_resid_w
        p_v = float(scipy_stats.f.sf(F, df_effect, df_within_correct))
        return round(SS,3), df_effect, round(F,3), round(p_v,4)

    SS_time, _, F_time, p_time   = _extract_w("time", T-1)
    # Interaction TIME×GROUP: theoretical df = (T-1)*(k-1)
    SS_tg, _, F_tg, p_tg         = _extract_w("time:group", (T-1)*(k-1))
    # Interaction TIME×COV: theoretical df = T-1
    SS_tc, _, F_tc, p_tc         = _extract_w("time:cov", T-1)

    eta2_time = _partial_eta2(SS_time if not np.isnan(SS_time) else 0, SS_resid_w)
    eta2_tg   = _partial_eta2(SS_tg   if not np.isnan(SS_tg)   else 0, SS_resid_w)
    eta2_tc   = _partial_eta2(SS_tc   if not np.isnan(SS_tc)   else 0, SS_resid_w)

    # ── Mauchly's sphericity + GG epsilon (SPSS method) ───────────────────
    # Orthonormal contrasts on error SSCP after removing between-factor + covariate
    try:
        p_sz  = T - 1
        # Orthonormal Helmert contrast (T-1) × T
        C_mat = np.zeros((p_sz, T))
        for i in range(p_sz):
            C_mat[i, :i+1] = 1.0
            C_mat[i, i+1]  = -(i+1)
            C_mat[i]      /= np.linalg.norm(C_mat[i])
        Ystar = data_wide @ C_mat.T                  # N × (T-1)
        # Design: intercept + between-factor (dummy) + covariate
        grp_codes = pd.get_dummies(between_factor, drop_first=True).values.astype(float)
        Xdes  = np.column_stack([np.ones(N), grp_codes, cov])
        beta_s = np.linalg.lstsq(Xdes, Ystar, rcond=None)[0]
        resid_s = Ystar - Xdes @ beta_s
        E_sscp  = resid_s.T @ resid_s
        df_e_s  = N - k - p                          # pooled within-group, covariate-adjusted

        W_raw = float(np.linalg.det(E_sscp) / (np.trace(E_sscp)/p_sz)**p_sz)
        W     = float(np.clip(W_raw, 1e-10, 1.0))
        d_corr= 1.0 - (2*p_sz**2 + p_sz + 2) / (6 * p_sz * df_e_s)
        chi2_W= -df_e_s * d_corr * np.log(W)
        df_m  = p_sz*(p_sz+1)//2 - 1
        p_m   = float(scipy_stats.chi2.sf(chi2_W, max(df_m,1)))
        eig   = np.linalg.eigvalsh(E_sscp / df_e_s)
        eig   = eig[eig > 1e-12]
        eps_gg= float(np.clip(eig.sum()**2 / (p_sz * (eig**2).sum()),
                              1.0/(T-1), 1.0))
    except Exception:
        W = chi2_W = p_m = eps_gg = np.nan; df_m = 0

    # ── Between-subjects: ANCOVA on subject means ─────────────────────────
    subj_means = data_wide.mean(axis=1)
    df_b = pd.DataFrame({"m": subj_means, "group": between_factor, "cov": cov})
    model_b  = smf.ols("m ~ C(group) + cov", data=df_b).fit()
    aov3_b   = anova_lm(model_b, typ=3)

    SS_resid_b = float(model_b.ssr)
    df_resid_b = N - k - p
    MS_resid_b = SS_resid_b / df_resid_b if df_resid_b > 0 else np.nan

    def _extract_b(key_substr):
        keys = [k2 for k2 in aov3_b.index
                if key_substr in k2 and "Residual" not in k2
                and "Intercept" not in k2]
        if not keys: return np.nan, np.nan, np.nan, np.nan
        SS  = float(aov3_b.loc[keys[0], "sum_sq"]) * T  # × T for original space
        df_e= float(aov3_b.loc[keys[0], "df"])
        F   = float(aov3_b.loc[keys[0], "F"])   # F from subject-means model = SPSS F
        p_v = float(aov3_b.loc[keys[0], "PR(>F)"])
        return round(SS,3), int(df_e), round(F,3), round(p_v,4)

    SS_grp, df_grp, F_grp, p_grp = _extract_b("C(group)")
    SS_cov, df_cov, F_cov, p_cov = _extract_b("cov")

    # Partial η² for between effects: SS_effect / (SS_effect + SS_error)
    # SS_grp/SS_cov are in ×T (original) space; SS_resid_b is means space → ×T
    _SS_err_orig = SS_resid_b * T
    eta2_grp = (round(SS_grp / (SS_grp + _SS_err_orig), 3)
                if not np.isnan(SS_grp) and (SS_grp + _SS_err_orig) > 0 else np.nan)
    eta2_cov_b = (round(SS_cov / (SS_cov + _SS_err_orig), 3)
                  if not np.isnan(SS_cov) and (SS_cov + _SS_err_orig) > 0 else np.nan)
    B_cov    = float(model_b.params.get("cov", np.nan))

    # ── Multivariate tests (MANOVA on contrast scores, SPSS within-subjects) ──
    # Sum-coded group + RAW covariate so intercept = TIME main effect (avg over groups)
    mv_time = mv_tg = mv_tc = None
    try:
        # Orthonormal Helmert contrast scores
        _Cmv = np.zeros((T-1, T))
        for _i in range(T-1):
            _Cmv[_i, :_i+1] = 1.0
            _Cmv[_i, _i+1]  = -(_i+1)
            _Cmv[_i]       /= np.linalg.norm(_Cmv[_i])
        Z = data_wide @ _Cmv.T
        glev = sorted(np.unique(between_factor))
        ge   = np.zeros((N, k-1))
        for gi, lv in enumerate(glev[:-1]):
            ge[between_factor == lv, gi] = 1.0
        ge[between_factor == glev[-1], :] = -1.0
        df_mv = pd.DataFrame(Z, columns=[f"z{j}" for j in range(T-1)])
        for gi in range(k-1):
            df_mv[f"g{gi}"] = ge[:, gi]
        df_mv["cov"] = cov
        z_str = " + ".join([f"z{j}" for j in range(T-1)])
        g_str = " + ".join([f"g{gi}" for gi in range(k-1)])
        maov  = MANOVA.from_formula(f"{z_str} ~ {g_str} + cov", data=df_mv)
        mv_res= maov.mv_test()

        def _mv(label):
            try:
                for kk in mv_res.results:
                    if label == "group" and str(kk).startswith("g") and str(kk)[1:].isdigit():
                        pass
                    elif label.lower() not in str(kk).lower():
                        continue
                    tbl = mv_res.results[kk]["stat"]
                    V   = float(tbl.loc["Pillai's trace","Value"])
                    dfh = float(tbl.loc["Pillai's trace","Num DF"])
                    dfe = float(tbl.loc["Pillai's trace","Den DF"])
                    Fp  = float(tbl.loc["Pillai's trace","F Value"])
                    s   = 1
                    return {
                        "Wilks":round(float(tbl.loc["Wilks' lambda","Value"]),3),
                        "F_Wilks":round(float(tbl.loc["Wilks' lambda","F Value"]),3),
                        "p_Wilks":round(float(tbl.loc["Wilks' lambda","Pr > F"]),3),
                        "Pillai":round(V,3),"F_Pillai":round(Fp,3),
                        "p_Pillai":round(float(tbl.loc["Pillai's trace","Pr > F"]),3),
                        "Hotelling":round(float(tbl.loc["Hotelling-Lawley trace","Value"]),3),
                        "F_HL":round(float(tbl.loc["Hotelling-Lawley trace","F Value"]),3),
                        "p_HL":round(float(tbl.loc["Hotelling-Lawley trace","Pr > F"]),3),
                        "Roy":round(float(tbl.loc["Roy's greatest root","Value"]),3),
                        "F_Roy":round(float(tbl.loc["Roy's greatest root","F Value"]),3),
                        "p_Roy":round(float(tbl.loc["Roy's greatest root","Pr > F"]),3),
                        "df_hyp":int(dfh),"df_err":int(dfe),
                        "eta2":round(V/max(s,1),3),"noncent":round(Fp*dfh,3),
                    }
            except Exception:
                pass
            return None
        mv_time = _mv("intercept")
        mv_tc   = _mv("cov")
        # TIME×GROUP: first g* effect (k=2 → single g0; for k>2 statsmodels pools)
        for kk in mv_res.results:
            if str(kk).startswith("g") and str(kk)[1:].isdigit():
                tbl = mv_res.results[kk]["stat"]
                V   = float(tbl.loc["Pillai's trace","Value"])
                dfh = float(tbl.loc["Pillai's trace","Num DF"])
                dfe = float(tbl.loc["Pillai's trace","Den DF"])
                Fp  = float(tbl.loc["Pillai's trace","F Value"])
                mv_tg = {
                    "Wilks":round(float(tbl.loc["Wilks' lambda","Value"]),3),
                    "F_Wilks":round(float(tbl.loc["Wilks' lambda","F Value"]),3),
                    "p_Wilks":round(float(tbl.loc["Wilks' lambda","Pr > F"]),3),
                    "Pillai":round(V,3),"F_Pillai":round(Fp,3),
                    "p_Pillai":round(float(tbl.loc["Pillai's trace","Pr > F"]),3),
                    "Hotelling":round(float(tbl.loc["Hotelling-Lawley trace","Value"]),3),
                    "F_HL":round(float(tbl.loc["Hotelling-Lawley trace","F Value"]),3),
                    "p_HL":round(float(tbl.loc["Hotelling-Lawley trace","Pr > F"]),3),
                    "Roy":round(float(tbl.loc["Roy's greatest root","Value"]),3),
                    "F_Roy":round(float(tbl.loc["Roy's greatest root","F Value"]),3),
                    "p_Roy":round(float(tbl.loc["Roy's greatest root","Pr > F"]),3),
                    "df_hyp":int(dfh),"df_err":int(dfe),
                    "eta2":round(V,3),"noncent":round(Fp*dfh,3),
                }
                break
    except Exception:
        pass

    # ── EMMs: per GROUP (avg over time) and per TIME (avg over groups) ────
    pct = int((1 - alpha) * 100)
    # Cell EMMs
    cell_rows = []
    for grp in sorted(np.unique(between_factor)):
        idx = between_factor == grp
        for t_i, t_lbl in enumerate(time_labels):
            col = data_wide[idx, t_i]
            m   = float(col.mean())
            se  = float(scipy_stats.sem(col)) if len(col) > 1 else np.nan
            tc  = scipy_stats.t.ppf(1-alpha/2, len(col)-1) if len(col)>1 else np.nan
            cell_rows.append({
                between_name: str(grp), time_name: t_lbl,
                "N": int(len(col)),
                "Unadjusted Mean": round(m, 3),
                "Adjusted Mean":   round(m, 3),
                "Std. Error":      round(se, 3) if not np.isnan(se) else np.nan,
                f"{pct}% CI Lower": round(m-tc*se,3) if not np.isnan(tc) else np.nan,
                f"{pct}% CI Upper": round(m+tc*se,3) if not np.isnan(tc) else np.nan,
            })
    emm_cell = pd.DataFrame(cell_rows)

    # GROUP marginal EMMs (avg over time)
    grp_rows = []
    for grp in sorted(np.unique(between_factor)):
        idx = between_factor == grp
        m   = float(data_wide[idx].mean())
        se  = float(scipy_stats.sem(data_wide[idx].flatten()))
        tc  = scipy_stats.t.ppf(1-alpha/2, idx.sum()-1)
        grp_rows.append({
            between_name: str(grp), "N": int(idx.sum()),
            "Adjusted Mean": round(m,3), "Std. Error": round(se,3),
            f"{pct}% CI Lower": round(m-tc*se,3),
            f"{pct}% CI Upper": round(m+tc*se,3),
        })
    emm_group = pd.DataFrame(grp_rows)

    # TIME marginal EMMs (avg over groups)
    time_rows = []
    for t_i, t_lbl in enumerate(time_labels):
        col = data_wide[:, t_i]
        m   = float(col.mean())
        se  = float(scipy_stats.sem(col))
        tc  = scipy_stats.t.ppf(1-alpha/2, N-1)
        time_rows.append({
            time_name: t_lbl, "N": N,
            "Adjusted Mean": round(m,3), "Std. Error": round(se,3),
            f"{pct}% CI Lower": round(m-tc*se,3),
            f"{pct}% CI Upper": round(m+tc*se,3),
        })
    emm_time = pd.DataFrame(time_rows)

    # ── Pairwise GROUP comparisons (selected post-hoc method) ─────────────
    groups_list = sorted(np.unique(between_factor))
    pairs_g  = list(combinations(groups_list, 2))
    n_comp_g = len(pairs_g)
    k_g      = len(groups_list)
    pw_g_rows = []
    _phg_lbl = "Bonferroni"
    for (g1, g2) in pairs_g:
        m1 = float(data_wide[between_factor==g1].mean())
        m2 = float(data_wide[between_factor==g2].mean())
        diff = m1 - m2
        n1   = int((between_factor==g1).sum())
        n2   = int((between_factor==g2).sum())
        se_d = float(np.sqrt(MS_resid_b/T * (1/n1 + 1/n2)))
        t_s  = diff / se_d if se_d > 0 else np.nan
        p_raw= float(2*scipy_stats.t.sf(abs(t_s), df_resid_b))
        p_adj, tc, _phg_lbl = _ph_adjust(p_raw, diff, se_d, df_resid_b,
                                         n_comp_g, k_g, alpha, posthoc_method)
        sig  = "*" if p_adj < alpha else ""
        for (gi, gj, d) in [(g1,g2,diff),(g2,g1,-diff)]:
            pw_g_rows.append({
                "(I)": str(gi), "(J)": str(gj),
                "Mean Diff (I\u2212J)": f"{round(d,3)}{sig}",
                "Std. Error": round(se_d,3),
                f"Sig. ({_phg_lbl})": round(p_adj,3),
                f"{pct}% CI Lower": round(d-tc*se_d,3),
                f"{pct}% CI Upper": round(d+tc*se_d,3),
            })
    pw_group = pd.DataFrame(pw_g_rows)

    # ── Pairwise TIME comparisons (within-subject, selected method) ───────
    pairs_t  = list(combinations(range(T), 2))
    n_comp_t = len(pairs_t)
    pw_t_rows = []
    _pht_lbl = "Bonferroni"
    for (i, j) in pairs_t:
        di    = data_wide[:, i] - data_wide[:, j]
        diff  = float(di.mean())
        se_d  = float(di.std(ddof=1) / np.sqrt(N))
        t_s   = diff / se_d if se_d > 0 else np.nan
        p_raw = float(2 * scipy_stats.t.sf(abs(t_s), N-1))
        p_adj, tc, _pht_lbl = _ph_adjust(p_raw, diff, se_d, N-1,
                                         n_comp_t, T, alpha, posthoc_method)
        sig   = "*" if p_adj < alpha else ""
        for (gi, gj, d) in [(i, j, diff), (j, i, -diff)]:
            pw_t_rows.append({
                "(I) Time": time_labels[gi], "(J) Time": time_labels[gj],
                "Mean Diff (I\u2212J)": f"{round(d,3)}{sig}",
                "Std. Error":          round(se_d, 3),
                f"Sig. ({_pht_lbl})":  round(p_adj, 3),
                f"{pct}% CI Lower":    round(d - tc*se_d, 3),
                f"{pct}% CI Upper":    round(d + tc*se_d, 3),
            })
    pw_time = pd.DataFrame(pw_t_rows)

    # ── Normality: overall model residuals with total_n=N (SPSS method) ──
    norm_res = test_normality(model_w.resid.values, label="Residuals", total_n=N)
    levene   = _levene(*[data_wide[between_factor==g].flatten()
                         for g in np.unique(between_factor)])

    # ── Descriptives ──────────────────────────────────────────────────────
    desc_rows = []
    for grp in sorted(np.unique(between_factor)):
        idx = between_factor == grp
        for t_i, t_lbl in enumerate(time_labels):
            desc_rows.append(_descriptives_group(data_wide[idx,t_i],
                                                  f"{grp} \u2013 {t_lbl}"))
    # Total per group
    for grp in sorted(np.unique(between_factor)):
        idx = between_factor == grp
        desc_rows.append(_descriptives_group(data_wide[idx].mean(axis=1),
                                              f"{grp} \u2013 Total"))
    desc_df = pd.DataFrame(desc_rows)

    # ── Within-Subjects Contrasts (polynomial) for Mixed ──────────────────
    contrast_rows = []
    try:
        _raw = np.polynomial.polynomial.polyvander(np.arange(T), T-1)
        _Q, _ = np.linalg.qr(_raw)
        Ppoly = _Q[:, 1:].T
        glev2 = sorted(np.unique(between_factor))
        ge2 = np.zeros((N, k-1))
        for _gi, _lv in enumerate(glev2[:-1]):
            ge2[between_factor == _lv, _gi] = 1.0
        ge2[between_factor == glev2[-1], :] = -1.0
        cnames = ["Linear","Quadratic","Cubic","Quartic","Order 5","Order 6"]
        for ci in range(T-1):
            zc  = data_wide @ Ppoly[ci]
            dcf = pd.DataFrame({"z": zc, "cov": cov})
            for _gi in range(k-1):
                dcf[f"g{_gi}"] = ge2[:, _gi]
            gstr = " + ".join([f"g{_gi}" for _gi in range(k-1)])
            ac   = anova_lm(smf.ols(f"z ~ {gstr} + cov", data=dcf).fit(), typ=3)
            cl   = cnames[ci] if ci < len(cnames) else f"Order {ci+1}"
            gkey = [x for x in ac.index if x.startswith("g")][0]
            ss_i=float(ac.loc["Intercept","sum_sq"]); F_i=float(ac.loc["Intercept","F"]); p_i=float(ac.loc["Intercept","PR(>F)"])
            ss_g=float(ac.loc[gkey,"sum_sq"]); F_g=float(ac.loc[gkey,"F"]); p_g=float(ac.loc[gkey,"PR(>F)"])
            ss_c=float(ac.loc["cov","sum_sq"]); F_c=float(ac.loc["cov","F"]); p_c=float(ac.loc["cov","PR(>F)"])
            ss_e=float(ac.loc["Residual","sum_sq"]); df_e=int(ac.loc["Residual","df"])
            contrast_rows.append({"Source":"TIME","Contrast":cl,"Type III SS":round(ss_i,3),
                "df":1,"MS":round(ss_i,3),"F":round(F_i,3),"Sig.":round(p_i,3)})
            contrast_rows.append({"Source":f"TIME \u00d7 {between_name}","Contrast":cl,"Type III SS":round(ss_g,3),
                "df":1,"MS":round(ss_g,3),"F":round(F_g,3),"Sig.":round(p_g,3)})
            contrast_rows.append({"Source":f"TIME \u00d7 {cov_name}","Contrast":cl,"Type III SS":round(ss_c,3),
                "df":1,"MS":round(ss_c,3),"F":round(F_c,3),"Sig.":round(p_c,3)})
            contrast_rows.append({"Source":"Error(TIME)","Contrast":cl,"Type III SS":round(ss_e,3),
                "df":df_e,"MS":round(ss_e/df_e,3) if df_e>0 else np.nan,"F":"","Sig.":""})
    except Exception:
        pass
    contrasts_df = pd.DataFrame(contrast_rows)

    # ── Box's M Test of Equality of Covariance Matrices ───────────────────
    # Tests homogeneity of the covariance matrices of the repeated measures
    # across the between-subjects groups (SPSS GLM "Homogeneity tests").
    boxes_m = None
    try:
        groups_b = sorted(np.unique(between_factor))
        kB = len(groups_b); pB = T
        Ss, ns = [], []
        for g in groups_b:
            Yg = data_wide[between_factor == g]
            ns.append(len(Yg))
            Ss.append(np.cov(Yg.T, ddof=1) if len(Yg) > 1 else np.eye(pB))
        v_i     = [ni - 1 for ni in ns]
        df_pool = N - kB
        S_pool  = sum(vi*Si for vi, Si in zip(v_i, Ss)) / df_pool
        det_pool = max(np.linalg.det(S_pool), 1e-300)
        Mbox = sum(vi * (np.log(det_pool) -
                         np.log(max(np.linalg.det(Si), 1e-300)))
                   for vi, Si in zip(v_i, Ss))
        c1 = ((sum(1/vi for vi in v_i) - 1/df_pool) *
              (2*pB**2 + 3*pB - 1) / (6*(pB+1)*(kB-1)))
        c2 = ((sum(1/vi**2 for vi in v_i) - 1/df_pool**2) *
              (pB-1)*(pB+2) / (6*(kB-1)))
        u   = (1 - c1) * Mbox
        df1B = int(pB*(pB+1)*(kB-1) / 2)
        c2_c1sq = c2 - c1**2
        if c2_c1sq > 1e-12:
            df2B = (df1B + 2) / c2_c1sq
        else:
            df2B = (df1B + 2) / max(c1**2, 1e-12)
        F_b = u / df1B
        p_b = float(scipy_stats.f.sf(F_b, df1B, df2B))
        boxes_m = {"M": round(Mbox, 3), "F": round(F_b, 3),
                   "df1": df1B, "df2": round(df2B, 3), "Sig.": round(p_b, 3)}
    except Exception:
        boxes_m = None

    return {
        "type":            "Mixed ANCOVA",
        "y_name":          y_name, "between_name": between_name,
        "time_name":       time_name, "cov_name": cov_name,
        "time_labels":     time_labels, "n": N, "T": T, "k": k, "alpha": alpha,
        # Within-subjects
        "F_time":          F_time,  "p_time":    p_time,
        "df_time":         T-1, "df_resid_within": int(df_resid_w),
        "SS_time":         SS_time, "eta2_time":  round(eta2_time,3),
        "F_interact":      F_tg,   "p_interact": p_tg,
        "SS_interact":     SS_tg,  "eta2_interact": round(eta2_tg,3),
        "F_tc":            F_tc,   "p_tc":       p_tc,
        "SS_tc":           SS_tc,  "eta2_tc":    round(eta2_tc,3),
        # Mauchly + GG
        "mauchly_W":       round(float(W),3)       if not np.isnan(W) else np.nan,
        "mauchly_chi2":    round(chi2_W,3)          if not np.isnan(chi2_W) else np.nan,
        "mauchly_df":      df_m, "mauchly_p": round(p_m,3) if not np.isnan(p_m) else np.nan,
        "eps_gg":          round(eps_gg,3)          if not np.isnan(eps_gg) else np.nan,
        # Between-subjects
        "F_between":       F_grp,  "p_between":  p_grp,
        "SS_between":      SS_grp, "df_between":  df_grp,
        "eta2_between":    round(eta2_grp,3),
        "F_cov":           F_cov,  "p_cov":      p_cov,
        "SS_cov":          SS_cov, "B_cov":       round(B_cov,3),
        "df_resid_between":df_resid_b,
        "eta2_cov":        round(_partial_eta2(float(SS_cov/T) if SS_cov else 0, SS_resid_b), 3),
        "grand_cov_mean":  round(float(cov.mean()),3),
        # Multivariate
        "mv_time": mv_time, "mv_tg": mv_tg, "mv_tc": mv_tc,
        # Tables
        "emm":             emm_cell, "emm_group": emm_group, "emm_time": emm_time,
        "pairwise_group":  pw_group,
        "pairwise_time":   pw_time,
        "contrasts":       contrasts_df,
        "boxes_m":         boxes_m,
        "descriptives":    desc_df,
        "normality":       norm_res, "levene": levene,
        "all_ok":          norm_res["pass"] and levene["passed"],
    }


# ══════════════════════════════════════════════════════════════════════════════
# 5. MANCOVA
# ══════════════════════════════════════════════════════════════════════════════

def run_mancova(y_matrix, factor, covariate,
                y_names=None, factor_name="Group",
                cov_name="Covariate", alpha=0.05,
                posthoc_method="bonferroni"):
    """
    MANCOVA — Multiple DVs + Factor + Covariate.
    SPSS GLM Multivariate equivalent:
    - Box's M test
    - Multivariate Tests (Wilks, Pillai, Hotelling, Roy) for Factor and Covariate
    - Levene's per DV
    - Univariate ANCOVA per DV (Type III SS)
    - EMMs per Group per DV
    - Pairwise per DV (Bonferroni / LSD / Sidak / Scheffe)
    - Normality of residuals per DV
    """
    from statsmodels.multivariate.manova import MANOVA

    Y   = np.array(y_matrix, dtype=float)
    fac = np.array(factor)
    cov = np.array(covariate, dtype=float)
    n, p = Y.shape

    if y_names is None:
        y_names = [f"DV{i+1}" for i in range(p)]

    df = pd.DataFrame(Y, columns=y_names)
    df[factor_name] = fac
    df[cov_name]    = cov
    groups          = sorted(np.unique(fac))
    k               = len(groups)
    grand_cov_m     = float(cov.mean())

    # ── Multivariate Tests (Wilks, Pillai, Hotelling, Roy) ────────────────
    dv_formula = " + ".join([f"Q('{v}')" for v in y_names])
    formula    = (f"{dv_formula} ~ Q('{cov_name}') + "
                  f"C(Q('{factor_name}'), Sum)")

    # Parameters for correct F approximation
    n_cov  = 1          # number of covariates
    n_e    = n - k      # raw error df
    n_e_c  = n - k - n_cov   # covariate-adjusted error df (SPSS uses this)
    s_mv   = min(p, k - 1)   # s = min(DVs, hypothesis df)

    def _hl_f(T0):
        """
        Hotelling-Lawley F — McKeon (1974) / Pillai-Samson (1959).
        n_e_c = N - k - n_cov;  df_err = s*(n_e_c + s - p - 2)
        F = T0 * df_err / (s * df_hyp)
        """
        df_hyp_hl = p * (k - 1)
        df_err_hl = s_mv * (n_e_c + s_mv - p - 2)
        if df_err_hl <= 0 or df_hyp_hl <= 0:
            return np.nan, np.nan, np.nan
        F   = float(T0 * df_err_hl / (s_mv * df_hyp_hl))
        p_v = float(scipy_stats.f.sf(F, df_hyp_hl, df_err_hl))
        return round(F, 3), round(p_v, 3), df_err_hl

    # Pre-compute df for each statistic (verified against SPSS)
    _df_hyp_main = p * (k - 1)
    _df_err_Pi   = s_mv * (n_e_c + s_mv - p)
    _df_err_Wi   = s_mv * (n_e_c + s_mv - p - 1)
    _df_err_HL   = s_mv * (n_e_c + s_mv - p - 2)
    _df_hyp_Roy  = s_mv
    _df_err_Roy  = n_e_c

    # For Intercept / covariate effects (1 df): s=1, all 4 stats give same F
    # F = T₀ × (n_e_c − p + 1) / p  [exact F distribution for s=1]
    _df_hyp_1 = p                   # = 2
    _df_err_1 = n_e_c - p + 1       # = 25

    def _eta2(V=None, Lambda=None, T0=None, theta=None):
        """Partial η² for each multivariate statistic (SPSS formulas)."""
        try:
            if V       is not None: return round(float(V / s_mv), 3)
            if Lambda  is not None: return round(float(1 - Lambda**(1/s_mv)), 3)
            if T0      is not None: return round(float(T0 / (T0 + s_mv)), 3)
            if theta   is not None: return round(float(theta / (1 + theta)), 3)
        except Exception: pass
        return np.nan

    def _get_mv_1df(mv_res, search):
        """Multivariate tests for 1-df effects (Intercept, covariate). s=1 exact."""
        try:
            for key in mv_res.results:
                if search.lower() in str(key).lower():
                    tbl = mv_res.results[key]["stat"]
                    V   = float(tbl.loc["Pillai's trace",        "Value"])
                    Lam = float(tbl.loc["Wilks' lambda",         "Value"])
                    T0  = float(tbl.loc["Hotelling-Lawley trace","Value"])
                    th  = float(tbl.loc["Roy's greatest root",   "Value"])
                    # s=1: all 4 stats same F = T0*(n_e_c-p+1)/p
                    F_1  = round(float(T0 * _df_err_1 / _df_hyp_1), 3) if _df_err_1>0 else np.nan
                    p_1  = round(float(scipy_stats.f.sf(F_1, _df_hyp_1, _df_err_1)), 3) if not np.isnan(F_1) else np.nan
                    eta_1 = round(float(th / (1 + th)), 3)   # θ/(1+θ), same for all s=1
                    nc_1  = round(float(F_1) * _df_hyp_1, 3) if not np.isnan(F_1) else ""
                    return {
                        "Pillai":        round(V,   3),
                        "Wilks":         round(Lam, 3),
                        "Hotelling":     round(T0,  3),
                        "Roy":           round(th,  3),
                        "F_Pillai":      F_1, "p_Pillai":      p_1,
                        "F_Wilks":       F_1, "p_Wilks":       p_1,
                        "F_HL":          F_1, "p_HL":          p_1,
                        "F_Roy":         F_1, "p_Roy":         p_1,
                        "df_hyp_Pillai": _df_hyp_1, "df_err_Pillai": _df_err_1,
                        "df_hyp_Wilks":  _df_hyp_1, "df_err_Wilks":  _df_err_1,
                        "df_hyp_HL":     _df_hyp_1, "df_err_HL":     _df_err_1,
                        "df_hyp_Roy":    _df_hyp_1, "df_err_Roy":    _df_err_1,
                        "eta2_Pillai":   eta_1, "eta2_Wilks": eta_1,
                        "eta2_HL":       eta_1, "eta2_Roy":   eta_1,
                        "noncent_Pillai": nc_1, "noncent_Wilks": nc_1,
                        "noncent_HL":    nc_1,  "noncent_Roy":  nc_1,
                    }
        except Exception:
            pass
        return None

    def _get_mv(mv_res, search):
        try:
            for key in mv_res.results:
                if search.lower() in str(key).lower():
                    tbl    = mv_res.results[key]["stat"]
                    V      = float(tbl.loc["Pillai's trace",       "Value"])
                    Lambda = float(tbl.loc["Wilks' lambda",        "Value"])
                    T0_hl  = float(tbl.loc["Hotelling-Lawley trace","Value"])
                    theta  = float(tbl.loc["Roy's greatest root",  "Value"])
                    F_hl, p_hl, _ = _hl_f(T0_hl)
                    # Roy F & p from statsmodels (exact for s=1, approx otherwise)
                    F_Roy  = round(float(tbl.loc["Roy's greatest root","F Value"]), 3)
                    p_Roy  = round(float(tbl.loc["Roy's greatest root","Pr > F"]),  3)
                    return {
                        # Pillai
                        "Pillai":        round(V, 3),
                        "F_Pillai":      round(float(tbl.loc["Pillai's trace","F Value"]), 3),
                        "p_Pillai":      round(float(tbl.loc["Pillai's trace","Pr > F"]),  3),
                        "df_hyp_Pillai": int(_df_hyp_main),
                        "df_err_Pillai": int(_df_err_Pi),
                        "eta2_Pillai":   _eta2(V=V),
                        "noncent_Pillai": round(float(tbl.loc["Pillai's trace","F Value"]) * _df_hyp_main, 3),
                        # Wilks
                        "Wilks":         round(Lambda, 3),
                        "F_Wilks":       round(float(tbl.loc["Wilks' lambda","F Value"]), 3),
                        "p_Wilks":       round(float(tbl.loc["Wilks' lambda","Pr > F"]),  3),
                        "df_hyp_Wilks":  int(_df_hyp_main),
                        "df_err_Wilks":  int(_df_err_Wi),
                        "eta2_Wilks":    _eta2(Lambda=Lambda),
                        "noncent_Wilks": round(float(tbl.loc["Wilks' lambda","F Value"]) * _df_hyp_main, 3),
                        # Hotelling-Lawley (McKeon 1974 correct F)
                        "Hotelling":     round(T0_hl, 3),
                        "F_HL":          F_hl,
                        "p_HL":          p_hl,
                        "df_hyp_HL":     int(_df_hyp_main),
                        "df_err_HL":     int(_df_err_HL),
                        "eta2_HL":       _eta2(T0=T0_hl),
                        "noncent_HL":    round(float(F_hl) * _df_hyp_main, 3) if not np.isnan(float(F_hl if F_hl else 0)) else "",
                        # Roy
                        "Roy":           round(theta, 3),
                        "F_Roy":         F_Roy,
                        "p_Roy":         p_Roy,
                        "df_hyp_Roy":    int(_df_hyp_Roy),
                        "df_err_Roy":    int(_df_err_Roy),
                        "eta2_Roy":      _eta2(theta=theta),
                        "noncent_Roy":   round(float(F_Roy) * _df_hyp_Roy, 3),
                    }
        except Exception:
            pass
        return None

    try:
        maov         = MANOVA.from_formula(formula, data=df)
        mv_res       = maov.mv_test()
        mv_intercept = _get_mv_1df(mv_res, "Intercept")
        mv_cov       = _get_mv_1df(mv_res, cov_name)
        mv_factor    = _get_mv(mv_res, factor_name)
    except Exception:
        mv_intercept = mv_cov = mv_factor = None

    # ── Box's M test ──────────────────────────────────────────────────────
    boxes_m = None
    try:
        Ss, ns = [], []
        for g in groups:
            Yg = Y[fac == g]
            ns.append(len(Yg))
            Ss.append(np.cov(Yg.T, ddof=1) if len(Yg) > 1 else np.eye(p))
        v_i     = [ni - 1 for ni in ns]           # df per group
        df_pool = n - k                             # pooled df = N - k
        S_pool  = sum(vi*Si for vi,Si in zip(v_i,Ss)) / df_pool
        det_pool = max(np.linalg.det(S_pool), 1e-300)
        M = sum(vi * (np.log(det_pool) -
                      np.log(max(np.linalg.det(Si), 1e-300)))
                for vi, Si in zip(v_i, Ss))

        # SPSS correction factors (Box, 1949)
        c1 = ((sum(1/vi for vi in v_i) - 1/df_pool) *
               (2*p**2 + 3*p - 1) / (6*(p+1)*(k-1)))
        c2 = ((sum(1/vi**2 for vi in v_i) - 1/df_pool**2) *
               (p-1)*(p+2) / (6*(k-1)))

        u   = (1 - c1) * M
        df1 = int(p*(p+1)*(k-1) / 2)
        c2_c1sq = c2 - c1**2

        # Case A: c2 > c1² — standard approximation (SPSS default)
        if c2_c1sq > 1e-12:
            df2 = (df1 + 2) / c2_c1sq
            F_b = u / df1
        else:
            # Case B: fallback
            df2 = (df1 + 2) / max(c1**2, 1e-12)
            F_b = u / df1

        p_b = float(scipy_stats.f.sf(F_b, df1, df2))
        boxes_m = {"M":    round(M, 3),
                   "F":    round(F_b, 3),
                   "df1":  df1,
                   "df2":  round(df2, 3),
                   "Sig.": round(p_b, 3)}
    except Exception:
        boxes_m = None

    # ── Per-DV univariate ANCOVA (SPSS Between-Subjects Effects) ─────────
    univ_rows = []
    univ_models = {}
    for dv in y_names:
        formula_u = (f"Q('{dv}') ~ Q('{cov_name}') + "
                     f"C(Q('{factor_name}'), Sum)")
        try:
            m_u   = smf.ols(formula_u, data=df).fit()
            aov_u = anova_lm(m_u, typ=3)
            ss_e  = float(aov_u.loc["Residual","sum_sq"])
            df_e  = float(aov_u.loc["Residual","df"])
            ms_e  = ss_e / df_e if df_e > 0 else np.nan

            # Factor row
            fk = [k2 for k2 in aov_u.index
                  if factor_name in k2 and "Residual" not in k2
                  and "Intercept" not in k2]
            ss_f = float(aov_u.loc[fk[0],"sum_sq"]) if fk else np.nan
            df_f = float(aov_u.loc[fk[0],"df"])     if fk else np.nan
            F_f  = float(aov_u.loc[fk[0],"F"])      if fk else np.nan
            p_f  = float(aov_u.loc[fk[0],"PR(>F)"]) if fk else np.nan

            # Covariate row
            ck = [k2 for k2 in aov_u.index
                  if cov_name in k2 and "Residual" not in k2
                  and "Intercept" not in k2]
            ss_c = float(aov_u.loc[ck[0],"sum_sq"]) if ck else np.nan
            F_c  = float(aov_u.loc[ck[0],"F"])      if ck else np.nan
            p_c  = float(aov_u.loc[ck[0],"PR(>F)"]) if ck else np.nan

            # Intercept row
            ss_int = float(aov_u.loc["Intercept","sum_sq"]) if "Intercept" in aov_u.index else np.nan
            F_int  = float(aov_u.loc["Intercept","F"])      if "Intercept" in aov_u.index else np.nan
            p_int  = float(aov_u.loc["Intercept","PR(>F)"]) if "Intercept" in aov_u.index else np.nan

            eta2_f   = _partial_eta2(ss_f if not np.isnan(ss_f) else 0, ss_e)
            eta2_c   = _partial_eta2(ss_c if not np.isnan(ss_c) else 0, ss_e)
            eta2_int = _partial_eta2(ss_int if not np.isnan(ss_int) else 0, ss_e)

            # Corrected Model — use model ESS (SPSS method)
            ss_model   = float(m_u.ess)
            df_model   = int(m_u.df_model)
            ms_model   = ss_model / df_model if df_model > 0 else np.nan
            F_model    = float(m_u.fvalue)   if not np.isnan(m_u.fvalue)   else np.nan
            p_model    = float(m_u.f_pvalue) if not np.isnan(m_u.f_pvalue) else np.nan
            eta2_model = _partial_eta2(ss_model, ss_e)

            univ_models[dv] = m_u

            def _row(src, ss, df_s, F_s, p_s, eta):
                nc = round(float(F_s)*float(df_s),3) if not (F_s is None or (isinstance(F_s,float) and np.isnan(F_s))) else ""
                return {
                    "Dependent Variable": dv, "Source": src,
                    "Type III SS": round(ss,3) if not np.isnan(ss) else "",
                    "df":          int(df_s)   if not np.isnan(df_s) else "",
                    "MS":          round(ss/df_s,3) if not np.isnan(ss) and df_s>0 else "",
                    "F":           round(F_s,3) if not (F_s is None or np.isnan(F_s)) else "",
                    "Sig.":        round(p_s,3) if not (p_s is None or np.isnan(p_s)) else "",
                    "Partial η²":  round(eta,3) if not np.isnan(eta) else "",
                    "Noncent. Parameter": nc,
                }

            # SPSS row order: Corrected Model, Intercept, Covariate, Factor, Error, Corrected Total
            univ_rows.append(_row("Corrected Model", ss_model, df_model, F_model, p_model, eta2_model))
            univ_rows.append(_row("Intercept",       ss_int,   1,        F_int,   p_int,   eta2_int))
            univ_rows.append(_row(cov_name,          ss_c,     1,        F_c,     p_c,     eta2_c))
            univ_rows.append(_row(factor_name,       ss_f,     df_f,     F_f,     p_f,     eta2_f))
            univ_rows.append({
                "Dependent Variable": dv, "Source": "Error",
                "Type III SS": round(ss_e,3), "df": int(df_e),
                "MS": round(ms_e,3) if not np.isnan(ms_e) else "",
                "F": "", "Sig.": "", "Partial η²": "", "Noncent. Parameter": "",
            })
        except Exception:
            univ_rows.append({"Dependent Variable": dv, "Source": "Error (computation failed)",
                              "Type III SS":"","df":"","MS":"","F":"","Sig.":"","Partial η²":"","Noncent. Parameter":""})
        except Exception:
            univ_rows.append({"Dependent Variable": dv, "Source": "Error",
                              "Type III SS": np.nan, "df": np.nan,
                              "MS": np.nan, "F": np.nan,
                              "Sig.": np.nan, "Partial η²": np.nan})
    univ_df = pd.DataFrame(univ_rows)

    # ── Levene per DV — on RESIDUALS from ANCOVA model (SPSS method) ─────
    # "Tests equality of error variance" = residuals after covariate removed
    # Placed here so univ_models is already populated
    levene_rows = []
    for dv in y_names:
        m_u = univ_models.get(dv)
        if m_u is not None:
            resid_ser = pd.Series(m_u.resid.values, index=df.index)
            grp_resid = [resid_ser[df[factor_name]==g].values for g in groups]
            lev = _levene(*grp_resid)   # center='mean' — SPSS Levene (1960)
        else:
            lev = {"F": np.nan, "p": np.nan, "passed": False}
        levene_rows.append({
            "Dependent Variable": dv,
            "F":    round(lev.get("F", np.nan), 3),
            "df1":  k - 1,
            "df2":  n - k,
            "Sig.": round(lev.get("p", np.nan), 3),
        })
    levene_df = pd.DataFrame(levene_rows)

    # ── EMMs per Group per DV ─────────────────────────────────────────────
    pct = int((1-alpha)*100)
    emm_rows = []
    for dv in y_names:
        m_u = univ_models.get(dv)
        if m_u is None: continue
        for g in groups:
            pred_df = pd.DataFrame({factor_name: [g], cov_name: [grand_cov_m]})
            try:
                m_adj = float(m_u.predict(pred_df)[0])
                # SE via get_prediction
                gp    = m_u.get_prediction(pred_df)
                se    = float(gp.se_mean[0])
                tc    = scipy_stats.t.ppf(1-alpha/2, m_u.df_resid)
            except Exception:
                m_adj = float(Y[fac==g, y_names.index(dv)].mean())
                se    = float(scipy_stats.sem(Y[fac==g, y_names.index(dv)]))
                tc    = scipy_stats.t.ppf(1-alpha/2, n-k-1)
            emm_rows.append({
                "Dependent Variable": dv,
                factor_name:          str(g),
                "Adjusted Mean":      round(m_adj, 3),
                "Std. Error":         round(se, 3),
                f"{pct}% CI Lower":   round(m_adj - tc*se, 3),
                f"{pct}% CI Upper":   round(m_adj + tc*se, 3),
            })
    emm_df = pd.DataFrame(emm_rows)

    # ── Pairwise per DV — supports bonferroni / lsd / sidak / scheffe ────
    meth_lbl  = {"lsd":"LSD","bonferroni":"Bonferroni",
                 "sidak":"Sidak","scheffe":"Scheff\u00e9"}.get(posthoc_method,"Bonferroni")
    pw_rows   = []
    pair_list = list(combinations(groups, 2))
    n_comp    = len(pair_list)
    k_g       = len(groups)

    for dv in y_names:
        m_u = univ_models.get(dv)
        if m_u is None: continue
        df_e = float(m_u.df_resid)
        vcov = m_u.cov_params().values
        di   = m_u.model.data.design_info
        for (g1, g2) in pair_list:
            try:
                d1 = pd.DataFrame({factor_name:[g1], cov_name:[grand_cov_m]})
                d2 = pd.DataFrame({factor_name:[g2], cov_name:[grand_cov_m]})
                dm1 = np.asarray(patsy.dmatrix(di, d1, return_type="matrix")[0])
                dm2 = np.asarray(patsy.dmatrix(di, d2, return_type="matrix")[0])
                L     = dm1 - dm2
                var_d = float(L @ vcov @ L.T)
                se_d  = float(np.sqrt(max(var_d, 0.0)))
                emm1  = float(m_u.predict(d1)[0])
                emm2  = float(m_u.predict(d2)[0])
                diff  = emm1 - emm2
                t_s   = diff / se_d if se_d > 0 else np.nan
                p_raw = float(2 * scipy_stats.t.sf(abs(t_s), df_e))
                # Adjustment
                if posthoc_method == "lsd":
                    p_adj = p_raw
                    tc    = scipy_stats.t.ppf(1 - alpha/2, df_e)
                elif posthoc_method == "sidak":
                    p_adj = float(min(1.0, 1-(1-p_raw)**n_comp))
                    tc    = scipy_stats.t.ppf(
                        1-(1-(1-alpha)**(1/n_comp))/2, df_e)
                elif posthoc_method == "scheffe":
                    F_s   = (diff/se_d)**2/(k_g-1) if se_d > 0 else np.nan
                    p_adj = float(scipy_stats.f.sf(F_s, k_g-1, df_e))
                    fc    = (k_g-1)*scipy_stats.f.ppf(1-alpha, k_g-1, df_e)
                    tc    = float(np.sqrt(fc))
                else:  # bonferroni
                    p_adj = min(1.0, p_raw * n_comp)
                    tc    = scipy_stats.t.ppf(1-alpha/(2*n_comp), df_e)
                sig = "*" if p_adj < alpha else ""
                for (gi, gj, d) in [(g1,g2,diff),(g2,g1,-diff)]:
                    cl = d - tc*se_d; cu = d + tc*se_d
                    pw_rows.append({
                        "Dependent Variable":    dv,
                        "(I)": str(gi), "(J)":   str(gj),
                        f"Mean Diff (I\u2212J)": f"{round(d,3)}{sig}",
                        "Std. Error":            round(se_d, 3),
                        f"Sig. ({meth_lbl})":    round(p_adj, 3),
                        f"{pct}% CI Lower":      round(cl, 3),
                        f"{pct}% CI Upper":      round(cu, 3),
                    })
            except Exception:
                for (gi, gj) in [(g1,g2),(g2,g1)]:
                    pw_rows.append({
                        "Dependent Variable":    dv,
                        "(I)": str(gi), "(J)":   str(gj),
                        f"Mean Diff (I\u2212J)": "\u2014",
                        "Std. Error":            "\u2014",
                        f"Sig. ({meth_lbl})":    "\u2014",
                        f"{pct}% CI Lower":      "\u2014",
                        f"{pct}% CI Upper":      "\u2014",
                    })
    pairwise_df = pd.DataFrame(pw_rows)

    # ── Descriptives per group per DV ──────────────────────────────────────
    desc_rows = []
    for g in groups:
        for dv in y_names:
            desc_rows.append(_descriptives_group(
                Y[fac==g, y_names.index(dv)], f"{g} \u2013 {dv}"))
    for dv in y_names:
        desc_rows.append(_descriptives_group(
            Y[:, y_names.index(dv)], f"Total \u2013 {dv}"))
    desc_df = pd.DataFrame(desc_rows)

    # ── Normality of residuals per DV ──────────────────────────────────────
    norm_res = {}
    for dv in y_names:
        m_u = univ_models.get(dv)
        if m_u is not None:
            norm_res[dv] = test_normality(m_u.resid.values,
                                          label=f"Residuals ({dv})", total_n=n)
        else:
            norm_res[dv] = {"pass": False, "label": dv}

    all_ok = all(nr.get("pass", False) for nr in norm_res.values())

    return {
        "type":           "MANCOVA",
        "y_names":        y_names,
        "factor_name":    factor_name,
        "cov_name":       cov_name,
        "n":              n,
        "p":              p,
        "alpha":          alpha,
        "mv_intercept":   mv_intercept,
        "mv_factor":      mv_factor,
        "mv_cov":         mv_cov,
        "boxes_m":        boxes_m,
        "levene_mancova": levene_df,
        "univariate":     univ_df,
        "emm":            emm_df,
        "pairwise":       pairwise_df,
        "descriptives":   desc_df,
        "normality":      norm_res,
        "all_ok":         all_ok,
        "grand_cov_mean": round(grand_cov_m, 3),
    }
