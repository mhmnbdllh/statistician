"""
modules/descriptive.py
======================
Descriptive statistics functions shared across all statistical tests.
Returns pandas DataFrames formatted for direct display and export.

All outputs are SPSS-equivalent:
  - Mean, SD, SE Mean, CI, Min, Max, Skewness, Kurtosis
  - Confidence intervals use the t-distribution (not z)
"""

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats


# ══════════════════════════════════════════════════════════════════════════════
# CONFIDENCE INTERVAL
# ══════════════════════════════════════════════════════════════════════════════

def ci_mean(data, alpha=0.05):
    """
    Compute two-sided confidence interval for the mean
    using the t-distribution (SPSS method).

    Parameters
    ----------
    data  : array-like
    alpha : float — significance level (default 0.05 → 95% CI)

    Returns
    -------
    tuple of (lower, upper) : float, float
    """
    data = np.array(data, dtype=float)
    n    = len(data)
    if n < 2:
        return np.nan, np.nan
    m  = np.mean(data)
    se = scipy_stats.sem(data)
    tc = scipy_stats.t.ppf(1 - alpha / 2, n - 1)
    return float(m - tc * se), float(m + tc * se)


# ══════════════════════════════════════════════════════════════════════════════
# SINGLE VARIABLE DESCRIPTIVES
# ══════════════════════════════════════════════════════════════════════════════

def describe_one(data, var_name="Variable", alpha=0.05):
    """
    Compute descriptive statistics for a single numeric variable.
    Equivalent to SPSS Descriptives or Explore output.

    Parameters
    ----------
    data     : array-like
    var_name : str
    alpha    : float

    Returns
    -------
    pd.DataFrame with one row
    """
    data    = np.array(data, dtype=float)
    n       = len(data)
    m       = float(np.mean(data))
    sd      = float(np.std(data, ddof=1))
    se      = float(scipy_stats.sem(data))
    ci_l, ci_u = ci_mean(data, alpha)
    pct     = int((1 - alpha) * 100)
    med     = float(np.median(data))
    skew    = float(scipy_stats.skew(data))
    kurt    = float(scipy_stats.kurtosis(data))
    se_skew = float(np.sqrt(6 * n * (n - 1) / ((n - 2) * (n + 1) * (n + 3))))
    se_kurt = float(2 * se_skew * np.sqrt((n * n - 1) / ((n - 3) * (n + 5))))

    return pd.DataFrame([{
        "N":                      n,
        "Mean":                   m,
        "Std. Deviation":         sd,
        "Std. Error Mean":        se,
        f"{pct}% CI Lower":       ci_l,
        f"{pct}% CI Upper":       ci_u,
        "Median":                 med,
        "Minimum":                float(np.min(data)),
        "Maximum":                float(np.max(data)),
        "Range":                  float(np.max(data) - np.min(data)),
        "Variance":               float(np.var(data, ddof=1)),
        "Skewness":               skew,
        "Std. Error of Skewness": se_skew,
        "Kurtosis":               kurt,
        "Std. Error of Kurtosis": se_kurt,
    }])


# ══════════════════════════════════════════════════════════════════════════════
# ONE-SAMPLE DESCRIPTIVES
# ══════════════════════════════════════════════════════════════════════════════

def describe_one_sample(data, var_name="Variable", alpha=0.05):
    """
    Descriptive statistics for One-Sample T-Test.
    Returns a single-row DataFrame with all SPSS-equivalent statistics.

    Parameters
    ----------
    data     : array-like
    var_name : str
    alpha    : float

    Returns
    -------
    pd.DataFrame
    """
    df       = describe_one(data, var_name, alpha)
    df.insert(0, "Variable", var_name)
    return df


# ══════════════════════════════════════════════════════════════════════════════
# PAIRED-SAMPLE DESCRIPTIVES
# ══════════════════════════════════════════════════════════════════════════════

def describe_paired(data1, data2, label1="Variable 1",
                    label2="Variable 2", alpha=0.05):
    """
    Descriptive statistics for Paired-Sample T-Test.
    Returns a two-row DataFrame (one row per variable) — SPSS Explore equivalent.
    """
    data1 = np.array(data1, dtype=float)
    data2 = np.array(data2, dtype=float)
    pct   = int((1 - alpha) * 100)
    rows  = []

    for data, label in [(data1, label1), (data2, label2)]:
        n        = len(data)
        m        = float(np.mean(data))
        sd       = float(np.std(data, ddof=1))
        se       = float(scipy_stats.sem(data))
        ci_l, ci_u = ci_mean(data, alpha)
        med      = float(np.median(data))
        var_     = float(np.var(data, ddof=1))
        iqr_     = float(np.percentile(data, 75) - np.percentile(data, 25))
        mn_      = float(np.min(data))
        mx_      = float(np.max(data))
        skew_    = float(scipy_stats.skew(data))
        kurt_    = float(scipy_stats.kurtosis(data))
        # 5% trimmed mean (SPSS partial trimming)
        xs       = np.sort(data)
        a_       = 0.05 * n
        k_       = int(np.floor(a_))
        frac_    = a_ - k_
        w_       = np.ones(n)
        w_[k_]         = 1.0 - frac_
        w_[-(k_ + 1)]  = 1.0 - frac_
        if k_ > 0:
            w_[:k_]  = 0.0
            w_[-k_:] = 0.0
        tm5_ = float(np.sum(w_ * xs) / np.sum(w_))

        rows.append({
            "Variable":               label,
            "N":                      n,
            "Mean":                   round(m, 3),
            "Median":                 round(med, 3),
            "5% Trimmed Mean":        round(tm5_, 3),
            "Std. Deviation":         round(sd, 3),
            "Variance":               round(var_, 3),
            "Std. Error Mean":        round(se, 3),
            f"{pct}% CI Lower":       round(ci_l, 3),
            f"{pct}% CI Upper":       round(ci_u, 3),
            "Minimum":                round(mn_, 3),
            "Maximum":                round(mx_, 3),
            "IQR":                    round(iqr_, 3),
            "Skewness":               round(skew_, 3),
            "Kurtosis":               round(kurt_, 3),
        })

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# INDEPENDENT-SAMPLE DESCRIPTIVES
# ══════════════════════════════════════════════════════════════════════════════

def describe_independent(g1, g2, label1="Group 1",
                          label2="Group 2", alpha=0.05):
    """
    Descriptive statistics for Independent-Sample T-Test — SPSS Explore equivalent.
    """
    pct  = int((1 - alpha) * 100)
    rows = []

    for data, label in [(g1, label1), (g2, label2)]:
        data    = np.array(data, dtype=float)
        n       = len(data)
        m       = float(np.mean(data))
        sd      = float(np.std(data, ddof=1))
        se      = float(scipy_stats.sem(data))
        ci_l, ci_u = ci_mean(data, alpha)
        med     = float(np.median(data))
        var_    = float(np.var(data, ddof=1))
        iqr_    = float(np.percentile(data, 75) - np.percentile(data, 25))
        mn_     = float(np.min(data))
        mx_     = float(np.max(data))
        skew_   = float(scipy_stats.skew(data))
        kurt_   = float(scipy_stats.kurtosis(data))
        # 5% trimmed mean (SPSS partial trimming)
        xs      = np.sort(data)
        a_      = 0.05 * n
        k_      = int(np.floor(a_))
        frac_   = a_ - k_
        w_      = np.ones(n)
        w_[k_]        = 1.0 - frac_
        w_[-(k_ + 1)] = 1.0 - frac_
        if k_ > 0:
            w_[:k_]  = 0.0
            w_[-k_:] = 0.0
        tm5_ = float(np.sum(w_ * xs) / np.sum(w_))

        rows.append({
            "Group":                  label,
            "N":                      n,
            "Mean":                   round(m, 3),
            "Median":                 round(med, 3),
            "5% Trimmed Mean":        round(tm5_, 3),
            "Std. Deviation":         round(sd, 3),
            "Variance":               round(var_, 3),
            "Std. Error Mean":        round(se, 3),
            f"{pct}% CI Lower":       round(ci_l, 3),
            f"{pct}% CI Upper":       round(ci_u, 3),
            "Minimum":                round(mn_, 3),
            "Maximum":                round(mx_, 3),
            "IQR":                    round(iqr_, 3),
            "Skewness":               round(skew_, 3),
            "Kurtosis":               round(kurt_, 3),
        })

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# MULTI-GROUP DESCRIPTIVES (ANOVA / ANCOVA)
# ══════════════════════════════════════════════════════════════════════════════

def describe_groups(groups_data, group_labels, dep_var="Score", alpha=0.05):
    """
    Descriptive statistics for multiple groups (One-Way ANOVA, etc.).
    Returns a DataFrame with one row per group plus a Total row.

    Parameters
    ----------
    groups_data  : list of array-like
    group_labels : list of str
    dep_var      : str
    alpha        : float

    Returns
    -------
    pd.DataFrame
    """
    pct  = int((1 - alpha) * 100)
    rows = []

    for data, label in zip(groups_data, group_labels):
        data    = np.array(data, dtype=float)
        n       = len(data)
        m       = float(np.mean(data))
        sd      = float(np.std(data, ddof=1))
        se      = float(scipy_stats.sem(data))
        ci_l, ci_u = ci_mean(data, alpha)
        rows.append({
            "Group":                  label,
            "N":                      n,
            "Mean":                   m,
            "Std. Deviation":         sd,
            "Std. Error Mean":        se,
            f"{pct}% CI Lower":       ci_l,
            f"{pct}% CI Upper":       ci_u,
            "Minimum":                float(np.min(data)),
            "Maximum":                float(np.max(data)),
            "Skewness":               float(scipy_stats.skew(data)),
            "Kurtosis":               float(scipy_stats.kurtosis(data)),
        })

    # Total row
    all_data = np.concatenate([np.array(g, dtype=float) for g in groups_data])
    n_tot    = len(all_data)
    ci_tl, ci_tu = ci_mean(all_data, alpha)
    rows.append({
        "Group":                  "Total",
        "N":                      n_tot,
        "Mean":                   float(np.mean(all_data)),
        "Std. Deviation":         float(np.std(all_data, ddof=1)),
        "Std. Error Mean":        float(scipy_stats.sem(all_data)),
        f"{pct}% CI Lower":       ci_tl,
        f"{pct}% CI Upper":       ci_tu,
        "Minimum":                float(np.min(all_data)),
        "Maximum":                float(np.max(all_data)),
        "Skewness":               float(scipy_stats.skew(all_data)),
        "Kurtosis":               float(scipy_stats.kurtosis(all_data)),
    })

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# REPEATED MEASURES DESCRIPTIVES
# ══════════════════════════════════════════════════════════════════════════════

def describe_repeated(data_wide, time_labels, alpha=0.05):
    """
    Descriptive statistics for Repeated Measures ANOVA.
    Returns a DataFrame with one row per time point.

    Parameters
    ----------
    data_wide   : 2D array-like (n_subjects × n_timepoints)
    time_labels : list of str
    alpha       : float

    Returns
    -------
    pd.DataFrame
    """
    data_wide = np.array(data_wide, dtype=float)
    pct       = int((1 - alpha) * 100)
    rows      = []

    for t, label in enumerate(time_labels):
        col     = data_wide[:, t]
        n       = len(col)
        m       = float(np.mean(col))
        sd      = float(np.std(col, ddof=1))
        se      = float(scipy_stats.sem(col))
        ci_l, ci_u = ci_mean(col, alpha)
        rows.append({
            "Time Point":             label,
            "N":                      n,
            "Mean":                   m,
            "Std. Deviation":         sd,
            "Std. Error Mean":        se,
            f"{pct}% CI Lower":       ci_l,
            f"{pct}% CI Upper":       ci_u,
            "Minimum":                float(np.min(col)),
            "Maximum":                float(np.max(col)),
        })

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# CORRELATION (PAIRED SAMPLES)
# ══════════════════════════════════════════════════════════════════════════════

def paired_correlation(data1, data2, label1="Variable 1",
                        label2="Variable 2"):
    """
    Pearson correlation between two paired variables.
    Equivalent to SPSS Paired Samples Correlations table.

    Parameters
    ----------
    data1, data2 : array-like
    label1       : str
    label2       : str

    Returns
    -------
    pd.DataFrame with one row
    """
    data1 = np.array(data1, dtype=float)
    data2 = np.array(data2, dtype=float)
    n     = len(data1)
    r, p  = scipy_stats.pearsonr(data1, data2)

    return pd.DataFrame([{
        "Pair":                f"{label1} & {label2}",
        "N":                   n,
        "Pearson Correlation": float(r),
        "Sig. (2-tailed)":     float(p),
    }])


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def format_desc(df):
    """
    Format all float columns in a descriptives DataFrame to 3 decimal places.
    Used before rendering as HTML table.

    Parameters
    ----------
    df : pd.DataFrame

    Returns
    -------
    pd.DataFrame — copy with floats formatted as strings
    """
    from utils.formatters import _f
    dd = df.copy()
    for c in dd.select_dtypes(include=[float, np.float64]).columns:
        dd[c] = dd[c].apply(_f)
    return dd


def cohen_d_1s(data, mu0):
    """
    Cohen's d for One-Sample T-Test.
    d = (M - μ₀) / SD

    Parameters
    ----------
    data : array-like
    mu0  : float

    Returns
    -------
    float
    """
    data = np.array(data, dtype=float)
    sd   = np.std(data, ddof=1)
    return float((np.mean(data) - mu0) / sd) if sd > 0 else np.nan


def cohen_d_paired(diff):
    """
    Cohen's d for Paired-Sample T-Test.
    d = M_diff / SD_diff

    Parameters
    ----------
    diff : array-like — differences (data1 - data2)

    Returns
    -------
    float
    """
    diff = np.array(diff, dtype=float)
    sd   = np.std(diff, ddof=1)
    return float(np.mean(diff) / sd) if sd > 0 else np.nan


def cohen_d_ind(g1, g2):
    """
    Cohen's d for Independent-Sample T-Test.
    Uses pooled standard deviation (SPSS method).
    d = (M1 - M2) / SD_pooled

    Parameters
    ----------
    g1, g2 : array-like

    Returns
    -------
    float
    """
    g1 = np.array(g1, dtype=float)
    g2 = np.array(g2, dtype=float)
    n1, n2 = len(g1), len(g2)
    sp = np.sqrt(
        ((n1 - 1) * np.var(g1, ddof=1) + (n2 - 1) * np.var(g2, ddof=1))
        / (n1 + n2 - 2)
    )
    return float((np.mean(g1) - np.mean(g2)) / sp) if sp > 0 else np.nan


def eta_squared(ss_between, ss_total):
    """
    Eta-squared (η²) effect size for ANOVA.
    η² = SS_between / SS_total

    Parameters
    ----------
    ss_between : float
    ss_total   : float

    Returns
    -------
    float
    """
    if ss_total == 0:
        return np.nan
    return float(ss_between / ss_total)


def omega_squared(ss_between, df_between, ms_within):
    """
    Omega-squared (ω²) effect size for ANOVA.
    More conservative and less biased than η².
    ω² = (SS_between - df_between × MS_within) /
          (SS_total + MS_within)

    Parameters
    ----------
    ss_between : float
    df_between : int
    ms_within  : float

    Returns
    -------
    float
    """
    numerator = ss_between - df_between * ms_within
    if ms_within == 0:
        return np.nan
    return float(numerator / (ss_between + (1 - df_between) * ms_within
                               + ms_within))
