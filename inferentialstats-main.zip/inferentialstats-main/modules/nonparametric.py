"""
modules/nonparametric.py
========================
Non-parametric statistical tests — SPSS-exact formulas.

Tests included:
  T-Test equivalents:
    - Wilcoxon Signed-Rank Test  (One-Sample & Paired)
    - Mann-Whitney U Test        (Independent-Sample)

  ANOVA equivalents (ready for future pages):
    - Kruskal-Wallis Test        (One-Way ANOVA equivalent)
    - Friedman Test              (Repeated Measures ANOVA equivalent)

SPSS Formula Notes:
  1. Wilcoxon Z: (W - E[W]) / sqrt(Var[W] - ties_correction)
  2. Mann-Whitney U: U = min(U1, U2); W = rank_sum(group_1)
  3. Z uses normal approximation with ties correction (SPSS method)
  4. Mann-Whitney U always reported with 3 decimal places
  5. Kruskal-Wallis H uses chi-squared approximation with ties correction
  6. Friedman uses chi-squared approximation

References:
  Mann & Whitney (1947). On a test of whether one of two random variables
    is stochastically larger than the other.
    Annals of Mathematical Statistics, 18(1), 50-60.
  Wilcoxon (1945). Individual comparisons by ranking methods.
    Biometrics Bulletin, 1(6), 80-83.
  Kruskal & Wallis (1952). Use of ranks in one-criterion variance analysis.
    Journal of the American Statistical Association, 47(260), 583-621.
  Friedman (1937). The use of ranks to avoid the assumption of normality.
    Journal of the American Statistical Association, 32(200), 675-701.
  Field (2018). Discovering Statistics Using IBM SPSS Statistics (5th ed.).
"""

import numpy as np
from scipy import stats as scipy_stats
from collections import Counter


# ══════════════════════════════════════════════════════════════════════════════
# WILCOXON SIGNED-RANK TEST  (SPSS-exact)
# ══════════════════════════════════════════════════════════════════════════════

def wilcoxon_signed_rank(diff_arr):
    """
    Wilcoxon Signed-Rank Test — SPSS-exact implementation.

    Uses ties-corrected variance for Z computation, identical to SPSS.
    Z = (W - E[W]) / sqrt(Var[W] - ties_correction)

    Parameters
    ----------
    diff_arr : array-like
        Differences (data1 - data2) for Paired test, or
        (data - μ₀) for One-Sample test.

    Returns
    -------
    dict with keys:
        W             : float — test statistic (minimum of T+, T-)
        Z             : float — standardised statistic
        p             : float — asymptotic 2-tailed p-value
        pos_rank_sum  : float — sum of positive ranks (T+)
        neg_rank_sum  : float — sum of negative ranks (T-)
        n_pos         : int   — number of positive differences
        n_neg         : int   — number of negative differences
        n_ties        : int   — number of zero differences (excluded)
        n_total       : int   — total number of observations
        mean_pos_rank : float
        mean_neg_rank : float
    """
    diff_arr = np.array(diff_arr, dtype=float)
    n_total  = len(diff_arr)
    diff_nz  = diff_arr[diff_arr != 0]
    n        = len(diff_nz)
    n_ties   = n_total - n

    if n < 1:
        return dict(
            W=np.nan, Z=np.nan, p=np.nan,
            pos_rank_sum=0.0, neg_rank_sum=0.0,
            n_pos=0, n_neg=0, n_ties=n_ties,
            n_total=n_total,
            mean_pos_rank=np.nan, mean_neg_rank=np.nan,
        )

    abs_d  = np.abs(diff_nz)
    ranks  = scipy_stats.rankdata(abs_d)
    pos_rs = float(np.sum(ranks[diff_nz > 0]))
    neg_rs = float(np.sum(ranks[diff_nz < 0]))
    n_pos  = int(np.sum(diff_nz > 0))
    n_neg  = int(np.sum(diff_nz < 0))
    W      = min(pos_rs, neg_rs)

    # Ties-corrected variance (SPSS method)
    tie_groups = Counter(abs_d)
    ties_corr  = sum(t ** 3 - t for t in tie_groups.values()) / 48.0
    Var_W      = n * (n + 1) * (2 * n + 1) / 24 - ties_corr
    E_W        = n * (n + 1) / 4

    Z = (W - E_W) / np.sqrt(Var_W) if Var_W > 0 else np.nan
    p = float(2 * scipy_stats.norm.sf(abs(Z))) if not np.isnan(Z) else np.nan

    return dict(
        W=W, Z=Z, p=p,
        pos_rank_sum=pos_rs,
        neg_rank_sum=neg_rs,
        n_pos=n_pos,
        n_neg=n_neg,
        n_ties=n_ties,
        n_total=n_total,
        mean_pos_rank=pos_rs / n_pos if n_pos > 0 else np.nan,
        mean_neg_rank=neg_rs / n_neg if n_neg > 0 else np.nan,
    )


# ══════════════════════════════════════════════════════════════════════════════
# MANN-WHITNEY U TEST  (SPSS-exact)
# ══════════════════════════════════════════════════════════════════════════════

def mann_whitney_u(g1, g2, label1="Group 1", label2="Group 2"):
    """
    Mann-Whitney U Test — SPSS-exact implementation.

    U  = min(U1, U2)
    W  = rank_sum(group_1)   [Wilcoxon W as reported by SPSS]
    Z uses normal approximation with ties correction (SPSS method).
    U always reported with 3 decimal places (SPSS format).

    Parameters
    ----------
    g1, g2   : array-like
    label1   : str
    label2   : str

    Returns
    -------
    dict with keys:
        U             : float — Mann-Whitney U statistic
        U1            : float — U for group 1
        U2            : float — U for group 2
        W_wilcoxon    : float — Wilcoxon W (rank sum of group 1)
        R1            : float — sum of ranks for group 1
        R2            : float — sum of ranks for group 2
        mean_rank1    : float
        mean_rank2    : float
        n1            : int
        n2            : int
        Z             : float
        p             : float — asymptotic 2-tailed p-value
        label1        : str
        label2        : str
    """
    g1 = np.array(g1, dtype=float)
    g2 = np.array(g2, dtype=float)
    n1, n2   = len(g1), len(g2)
    N        = n1 + n2
    all_data = np.concatenate([g1, g2])
    all_rnks = scipy_stats.rankdata(all_data)

    R1 = float(np.sum(all_rnks[:n1]))
    R2 = float(np.sum(all_rnks[n1:]))
    U1 = n1 * n2 + n1 * (n1 + 1) / 2 - R1
    U2 = n1 * n2 + n2 * (n2 + 1) / 2 - R2
    U  = min(U1, U2)
    W_wilcoxon = R1

    # Ties-corrected variance (SPSS method)
    tie_groups = Counter(all_rnks)
    ties_corr  = (
        sum(t ** 3 - t for t in tie_groups.values()) / (N * (N - 1))
        if N > 1 else 0
    )
    Var_U = n1 * n2 / 12 * (N + 1 - ties_corr)
    E_U   = n1 * n2 / 2

    Z = (U - E_U) / np.sqrt(Var_U) if Var_U > 0 else np.nan
    p = float(2 * scipy_stats.norm.sf(abs(Z))) if not np.isnan(Z) else np.nan

    # Exact significance (scipy method='exact', feasible for small N)
    try:
        if (n1 + n2) <= 500:
            exact_res = scipy_stats.mannwhitneyu(g1, g2, method='exact',
                                                  alternative='two-sided')
            p_exact = float(exact_res.pvalue)
        else:
            p_exact = np.nan
    except Exception:
        p_exact = np.nan

    return dict(
        U=U, U1=U1, U2=U2,
        W_wilcoxon=W_wilcoxon,
        R1=R1, R2=R2,
        mean_rank1=R1 / n1,
        mean_rank2=R2 / n2,
        n1=n1, n2=n2,
        Z=Z, p=p, p_exact=p_exact,
        label1=label1, label2=label2,
    )


# ══════════════════════════════════════════════════════════════════════════════
# KRUSKAL-WALLIS TEST  (One-Way ANOVA equivalent)
# ══════════════════════════════════════════════════════════════════════════════

def kruskal_wallis(groups_data, group_labels=None):
    """
    Kruskal-Wallis H Test — non-parametric equivalent of One-Way ANOVA.
    Uses ties-corrected H statistic.

    H = [12 / (N(N+1)) × Σ(Rj²/nj)] - 3(N+1)
    Ties correction: H_corrected = H / (1 - Σ(t³-t)/(N³-N))

    Parameters
    ----------
    groups_data  : list of array-like
    group_labels : list of str or None

    Returns
    -------
    dict with keys:
        H             : float — Kruskal-Wallis H statistic (ties-corrected)
        df            : int   — degrees of freedom (k - 1)
        p             : float — asymptotic p-value (chi-squared)
        n_groups      : int
        group_stats   : list of dict (n, mean_rank, sum_rank per group)
        N_total       : int
    """
    groups_data = [np.array(g, dtype=float) for g in groups_data]
    k           = len(groups_data)

    if group_labels is None:
        group_labels = [f"Group {i+1}" for i in range(k)]

    N        = sum(len(g) for g in groups_data)
    all_data = np.concatenate(groups_data)
    all_rnks = scipy_stats.rankdata(all_data)

    # Group rank sums
    idx    = 0
    g_stats = []
    rank_sums = []
    for i, g in enumerate(groups_data):
        ni   = len(g)
        rnks = all_rnks[idx: idx + ni]
        Rs   = float(np.sum(rnks))
        rank_sums.append(Rs)
        g_stats.append({
            "label":      group_labels[i],
            "n":          ni,
            "mean_rank":  float(Rs / ni),
            "sum_rank":   Rs,
        })
        idx += ni

    # H statistic
    H = (12 / (N * (N + 1))) * sum(
        Rs ** 2 / len(groups_data[i])
        for i, Rs in enumerate(rank_sums)
    ) - 3 * (N + 1)

    # Ties correction
    tie_groups = Counter(all_rnks)
    ties_sum   = sum(t ** 3 - t for t in tie_groups.values())
    C          = 1 - ties_sum / (N ** 3 - N) if (N ** 3 - N) > 0 else 1
    H_corrected = H / C if C > 0 else H

    df = k - 1
    p  = float(scipy_stats.chi2.sf(H_corrected, df))

    return dict(
        H=float(H_corrected),
        H_uncorrected=float(H),
        df=df,
        p=p,
        n_groups=k,
        N_total=N,
        group_stats=g_stats,
    )


# ══════════════════════════════════════════════════════════════════════════════
# FRIEDMAN TEST  (Repeated Measures ANOVA equivalent)
# ══════════════════════════════════════════════════════════════════════════════

def friedman_test(data_wide, time_labels=None):
    """
    Friedman Test — non-parametric equivalent of Repeated Measures ANOVA.

    χ²F = [12 / (N × k × (k+1))] × Σ Rj² - 3N(k+1)

    Parameters
    ----------
    data_wide   : 2D array-like (n_subjects × n_timepoints)
    time_labels : list of str or None

    Returns
    -------
    dict with keys:
        chi2          : float — Friedman chi-squared statistic
        df            : int   — degrees of freedom (k - 1)
        p             : float — asymptotic p-value
        N             : int   — number of subjects
        k             : int   — number of time points
        mean_ranks    : list of float — mean rank per time point
        sum_ranks     : list of float — rank sum per time point
        time_labels   : list of str
    """
    data_wide = np.array(data_wide, dtype=float)
    N, k      = data_wide.shape

    if time_labels is None:
        time_labels = [f"Time {i+1}" for i in range(k)]

    # Rank within each subject (row)
    row_ranks = np.apply_along_axis(scipy_stats.rankdata, 1, data_wide)

    # Column (time-point) rank sums and means
    col_rank_sums  = row_ranks.sum(axis=0)
    col_mean_ranks = (row_ranks.mean(axis=0)).tolist()

    # Friedman statistic
    chi2 = (
        12 / (N * k * (k + 1))
        * np.sum(col_rank_sums ** 2)
        - 3 * N * (k + 1)
    )
    df = k - 1
    p  = float(scipy_stats.chi2.sf(chi2, df))

    return dict(
        chi2=float(chi2),
        df=df,
        p=p,
        N=N,
        k=k,
        mean_ranks=col_mean_ranks,
        sum_ranks=col_rank_sums.tolist(),
        time_labels=time_labels,
    )


# ══════════════════════════════════════════════════════════════════════════════
# DUNN'S POST-HOC TEST  (after Kruskal-Wallis)
# ══════════════════════════════════════════════════════════════════════════════

def dunn_posthoc(groups_data, group_labels=None, p_adjust="bonferroni"):
    """
    Dunn's post-hoc pairwise comparisons after a significant Kruskal-Wallis.
    Uses z-scores derived from rank sums with optional p-value adjustment.

    Parameters
    ----------
    groups_data : list of array-like
    group_labels : list of str or None
    p_adjust    : str — 'bonferroni', 'holm', or 'none'

    Returns
    -------
    list of dict, each with keys:
        group1, group2, z, p_raw, p_adj, significant
    """
    groups_data = [np.array(g, dtype=float) for g in groups_data]
    k           = len(groups_data)

    if group_labels is None:
        group_labels = [f"Group {i+1}" for i in range(k)]

    N        = sum(len(g) for g in groups_data)
    all_data = np.concatenate(groups_data)
    all_rnks = scipy_stats.rankdata(all_data)

    # Mean ranks per group
    idx = 0
    mean_ranks = []
    ns         = []
    for g in groups_data:
        ni = len(g)
        mean_ranks.append(float(np.mean(all_rnks[idx: idx + ni])))
        ns.append(ni)
        idx += ni

    # Ties correction factor
    tie_groups = Counter(all_rnks)
    ties_sum   = sum(t ** 3 - t for t in tie_groups.values())
    C          = (N ** 3 - N - ties_sum) / (12 * (N - 1)) if N > 1 else 1

    comparisons = []
    pairs       = [(i, j) for i in range(k) for j in range(i + 1, k)]

    for i, j in pairs:
        se  = np.sqrt(C * (1 / ns[i] + 1 / ns[j]))
        z   = (mean_ranks[i] - mean_ranks[j]) / se if se > 0 else np.nan
        p_r = float(2 * scipy_stats.norm.sf(abs(z))) if not np.isnan(z) else np.nan
        comparisons.append({
            "group1": group_labels[i],
            "group2": group_labels[j],
            "z":      float(z),
            "p_raw":  p_r,
        })

    # P-value adjustment
    n_comp = len(comparisons)
    p_raws = [c["p_raw"] for c in comparisons]

    if p_adjust == "bonferroni":
        p_adjs = [min(p * n_comp, 1.0) if not np.isnan(p) else np.nan
                  for p in p_raws]
    elif p_adjust == "holm":
        ranked  = sorted(range(n_comp), key=lambda x: p_raws[x])
        p_adjs  = [np.nan] * n_comp
        running = 0.0
        for rank, idx in enumerate(ranked):
            if not np.isnan(p_raws[idx]):
                adj = max(running, (n_comp - rank) * p_raws[idx])
                running = adj
                p_adjs[idx] = min(adj, 1.0)
    else:
        p_adjs = p_raws

    for c, p_a in zip(comparisons, p_adjs):
        c["p_adj"]       = float(p_a) if not np.isnan(p_a) else np.nan
        c["significant"] = (p_a < 0.05) if not np.isnan(p_a) else False

    return comparisons


# ══════════════════════════════════════════════════════════════════════════════
# WILCOXON POST-HOC  (after Friedman)
# ══════════════════════════════════════════════════════════════════════════════

def wilcoxon_posthoc(data_wide, time_labels=None, p_adjust="bonferroni"):
    """
    Pairwise Wilcoxon Signed-Rank tests as post-hoc after Friedman.
    With optional Bonferroni or Holm p-value adjustment.

    Parameters
    ----------
    data_wide   : 2D array-like (n_subjects × n_timepoints)
    time_labels : list of str or None
    p_adjust    : str — 'bonferroni', 'holm', or 'none'

    Returns
    -------
    list of dict, each with keys:
        time1, time2, W, Z, p_raw, p_adj, significant
    """
    data_wide = np.array(data_wide, dtype=float)
    N, k      = data_wide.shape

    if time_labels is None:
        time_labels = [f"Time {i+1}" for i in range(k)]

    pairs       = [(i, j) for i in range(k) for j in range(i + 1, k)]
    comparisons = []

    for i, j in pairs:
        diff = data_wide[:, i] - data_wide[:, j]
        res  = wilcoxon_signed_rank(diff)
        comparisons.append({
            "time1": time_labels[i],
            "time2": time_labels[j],
            "W":     res["W"],
            "Z":     res["Z"],
            "p_raw": res["p"],
        })

    # P-value adjustment
    n_comp = len(comparisons)
    p_raws = [c["p_raw"] for c in comparisons]

    if p_adjust == "bonferroni":
        p_adjs = [min(p * n_comp, 1.0) if not np.isnan(p) else np.nan
                  for p in p_raws]
    elif p_adjust == "holm":
        ranked  = sorted(range(n_comp), key=lambda x: p_raws[x])
        p_adjs  = [np.nan] * n_comp
        running = 0.0
        for rank, idx_r in enumerate(ranked):
            if not np.isnan(p_raws[idx_r]):
                adj = max(running, (n_comp - rank) * p_raws[idx_r])
                running = adj
                p_adjs[idx_r] = min(adj, 1.0)
    else:
        p_adjs = p_raws

    for c, p_a in zip(comparisons, p_adjs):
        c["p_adj"]       = float(p_a) if not np.isnan(p_a) else np.nan
        c["significant"] = (p_a < 0.05) if not np.isnan(p_a) else False

    return comparisons
