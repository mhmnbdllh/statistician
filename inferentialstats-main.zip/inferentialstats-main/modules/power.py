"""
modules/power.py
================
Post-hoc statistical power analysis for all statistical tests.

Post-hoc power uses the observed effect size and sample size to estimate
the probability of correctly rejecting H₀ given that the effect is real.

Methods:
  - Parametric tests  : non-central t-distribution
  - ANOVA             : non-central F-distribution
  - Non-parametric    : normal approximation via observed Z statistic

All results include:
  - Achieved power (1 - β)
  - Power classification (Excellent / Adequate / Moderate / Low)
  - Minimum n required to achieve power = .80 (a priori recommendation)

References:
  Cohen, J. (1988). Statistical power analysis for the behavioral sciences
    (2nd ed.). Lawrence Erlbaum Associates.
  Field, A. (2018). Discovering statistics using IBM SPSS statistics
    (5th ed.). SAGE Publications.
  Faul, F., Erdfelder, E., Lang, A. G., & Buchner, A. (2007). G*Power 3:
    A flexible statistical power analysis program for the social, behavioral,
    and biomedical sciences. Behavior Research Methods, 39(2), 175-191.
"""

import numpy as np
from scipy import stats as scipy_stats
from utils.formatters import power_label


# ══════════════════════════════════════════════════════════════════════════════
# CORE POWER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def _power_t(d, n, df, alpha, tails=2):
    """
    Compute power for a t-test using the non-central t-distribution.

    Parameters
    ----------
    d     : float — Cohen's d (effect size)
    n     : float — effective sample size
    df    : float — degrees of freedom
    alpha : float — significance level
    tails : int   — 1 or 2

    Returns
    -------
    float — achieved power
    """
    if np.isnan(d) or np.isnan(n) or df <= 0:
        return np.nan
    ncp   = abs(d) * np.sqrt(n)     # non-centrality parameter
    tc    = scipy_stats.t.ppf(1 - alpha / tails, df)
    power = (1 - scipy_stats.nct.cdf(tc, df, ncp)
             + scipy_stats.nct.cdf(-tc, df, ncp))
    return float(np.clip(power, 0.0, 1.0))


def _power_f(f2, df_num, df_den, alpha):
    """
    Compute power for an F-test using the non-central F-distribution.

    Parameters
    ----------
    f2     : float — Cohen's f² (effect size for ANOVA)
    df_num : int   — numerator df
    df_den : int   — denominator df
    alpha  : float

    Returns
    -------
    float — achieved power
    """
    if np.isnan(f2) or df_num <= 0 or df_den <= 0:
        return np.nan
    N      = df_num + df_den + 1  # approximate total N
    ncp    = f2 * N
    fc     = scipy_stats.f.ppf(1 - alpha, df_num, df_den)
    power  = float(scipy_stats.ncf.sf(fc, df_num, df_den, ncp))
    return float(np.clip(power, 0.0, 1.0))


def _n_for_power(target_power, effect_fn, effect_args,
                 n_min=3, n_max=10000, alpha=0.05):
    """
    Binary search for the minimum n required to achieve target power.

    Parameters
    ----------
    target_power : float — e.g. 0.80
    effect_fn    : callable(n) → power estimate
    effect_args  : dict — additional fixed arguments for effect_fn
    n_min, n_max : int
    alpha        : float

    Returns
    -------
    int or None
    """
    lo, hi = n_min, n_max
    while lo < hi:
        mid = (lo + hi) // 2
        pwr = effect_fn(mid, **effect_args)
        if np.isnan(pwr):
            return None
        if pwr < target_power:
            lo = mid + 1
        else:
            hi = mid
    return lo if lo <= n_max else None


# ══════════════════════════════════════════════════════════════════════════════
# ONE-SAMPLE T-TEST POWER
# ══════════════════════════════════════════════════════════════════════════════

def power_one_sample(R, alpha=0.05):
    """
    Post-hoc power analysis for One-Sample T-Test.

    Parameters
    ----------
    R     : dict — output of run_one_sample()
    alpha : float

    Returns
    -------
    dict with power analysis results
    """
    pr  = R["parametric"]
    n   = int(R["desc"]["N"].iloc[0])
    d   = abs(pr.get("cohens_d", np.nan))
    df  = n - 1

    power = _power_t(d, n, df, alpha)

    # Minimum n for power = .80
    def _pwr_fn(n_test, d=d, alpha=alpha):
        return _power_t(d, n_test, n_test - 1, alpha)
    n_required = _n_for_power(0.80, _pwr_fn, {})

    return _build_result(
        test_type   = "One-Sample T-Test",
        effect_size = d,
        effect_type = "Cohen\u2019s d",
        power       = power,
        alpha       = alpha,
        n           = n,
        n_required  = n_required,
    )


# ══════════════════════════════════════════════════════════════════════════════
# PAIRED-SAMPLE T-TEST POWER
# ══════════════════════════════════════════════════════════════════════════════

def power_paired(R, alpha=0.05):
    """
    Post-hoc power analysis for Paired-Sample T-Test.

    Parameters
    ----------
    R     : dict — output of run_paired()
    alpha : float

    Returns
    -------
    dict
    """
    pr  = R["parametric"]
    n   = int(R["desc"]["N"].iloc[0])
    d   = abs(pr.get("cohens_d", np.nan))
    df  = n - 1

    power = _power_t(d, n, df, alpha)

    def _pwr_fn(n_test, d=d, alpha=alpha):
        return _power_t(d, n_test, n_test - 1, alpha)
    n_required = _n_for_power(0.80, _pwr_fn, {})

    return _build_result(
        test_type   = "Paired-Sample T-Test",
        effect_size = d,
        effect_type = "Cohen\u2019s d",
        power       = power,
        alpha       = alpha,
        n           = n,
        n_required  = n_required,
    )


# ══════════════════════════════════════════════════════════════════════════════
# INDEPENDENT-SAMPLE T-TEST POWER
# ══════════════════════════════════════════════════════════════════════════════

def power_independent(R, alpha=0.05):
    """
    Post-hoc power analysis for Independent-Sample T-Test.
    Uses harmonic mean of n1 and n2 as effective sample size.

    Parameters
    ----------
    R     : dict — output of run_independent()
    alpha : float

    Returns
    -------
    dict
    """
    pr   = R["parametric"]
    np_r = R["nonparametric"]
    lev  = R["levene"]
    n1, n2 = np_r["n1"], np_r["n2"]
    d      = abs(pr.get("cohens_d", np.nan))

    # Harmonic mean as effective n
    n_harm = float(2 / (1 / n1 + 1 / n2))
    df     = pr["df_eq"] if lev["equal_var"] else pr["df_welch"]

    power = _power_t(d, n_harm / 2, df, alpha)

    # Minimum n per group for power = .80
    def _pwr_fn(n_test, d=d, alpha=alpha):
        n_h   = float(n_test)
        df_t  = 2 * n_test - 2
        return _power_t(d, n_h, df_t, alpha)
    n_required = _n_for_power(0.80, _pwr_fn, {})

    result = _build_result(
        test_type   = "Independent-Sample T-Test",
        effect_size = d,
        effect_type = "Cohen\u2019s d",
        power       = power,
        alpha       = alpha,
        n           = None,
        n_required  = n_required,
    )
    result["n1"]          = n1
    result["n2"]          = n2
    result["n_total"]     = n1 + n2
    result["n_harm"]      = round(n_harm, 2)
    result["n_desc"]      = f"n\u2081\u2009=\u2009{n1}, n\u2082\u2009=\u2009{n2}"
    result["n_req_desc"]  = (f"{n_required} per group"
                              if n_required else "N/A")
    return result


# ══════════════════════════════════════════════════════════════════════════════
# ONE-WAY ANOVA POWER
# ══════════════════════════════════════════════════════════════════════════════

def power_oneway_anova(R, alpha=0.05):
    """
    Post-hoc power analysis for One-Way ANOVA.
    Converts η² to Cohen's f² for non-central F computation.

    Parameters
    ----------
    R     : dict — output of run_oneway_anova()
    alpha : float

    Returns
    -------
    dict
    """
    anova  = R.get("anova", {})
    eta2   = anova.get("eta2", np.nan)
    df_num = anova.get("df_between", 1)
    df_den = anova.get("df_within", 1)
    N      = anova.get("N_total", df_num + df_den + 1)

    # Cohen's f² from η²
    f2 = eta2 / (1 - eta2) if (not np.isnan(eta2) and eta2 < 1) else np.nan
    f  = np.sqrt(f2) if not np.isnan(f2) else np.nan

    power = _power_f(f2, df_num, df_den, alpha)

    return _build_result(
        test_type   = "One-Way ANOVA",
        effect_size = float(f) if not np.isnan(f) else np.nan,
        effect_type = "Cohen\u2019s f",
        power       = power,
        alpha       = alpha,
        n           = N,
        n_required  = None,
    )


# ══════════════════════════════════════════════════════════════════════════════
# NON-PARAMETRIC POWER (normal approximation)
# ══════════════════════════════════════════════════════════════════════════════

def power_nonparametric(R, alpha=0.05):
    """
    Approximate post-hoc power for non-parametric tests via
    the observed Z statistic and normal approximation.
    Min N computed from approximate d (d = Z/sqrt(N)).
    """
    np_r    = R.get("nonparametric", {})
    z       = abs(np_r.get("Z", np.nan))
    n       = R.get("total_n", np.nan)
    is_indp = "label1" in np_r and "label2" in np_r and "dep_var" in np_r

    if np.isnan(z):
        return _build_result(
            test_type   = np_r.get("test", "Non-parametric"),
            effect_size = np.nan,
            effect_type = "Z (approx.)",
            power       = np.nan,
            alpha       = alpha,
            n           = n,
            n_required  = None,
        )

    z_crit  = scipy_stats.norm.ppf(1 - alpha / 2)
    z_power = scipy_stats.norm.ppf(0.80)
    power   = float(np.clip(
        scipy_stats.norm.sf(z_crit - z) + scipy_stats.norm.cdf(-z_crit - z),
        0.0, 1.0))

    # Approximate effect size d from Z/sqrt(N)
    d_approx = z / np.sqrt(n) if (not np.isnan(n) and n > 0) else np.nan

    # Min N for power=0.80
    n_required = None
    if not np.isnan(d_approx) and d_approx > 0:
        if is_indp:
            # Independent: 2 groups, n per group
            n_pg = int(np.ceil(2 * ((z_crit + z_power) / d_approx) ** 2))
            n_required = n_pg  # per group
        else:
            # One-sample / paired
            n_required = int(np.ceil(((z_crit + z_power) / d_approx) ** 2))

    return _build_result(
        test_type   = np_r.get("test", "Non-parametric"),
        effect_size = float(d_approx) if not np.isnan(d_approx) else np.nan,
        effect_type = "Approx. d (from Z)",
        power       = power,
        alpha       = alpha,
        n           = int(n) if not np.isnan(n) else None,
        n_required  = n_required,
    )


# ══════════════════════════════════════════════════════════════════════════════
# MAIN DISPATCHER
# ══════════════════════════════════════════════════════════════════════════════

def compute_power(R, test_type, alpha=0.05):
    """
    Dispatch power analysis to the correct function based on test type
    and whether parametric or non-parametric analysis was applied.

    Parameters
    ----------
    R         : dict — output of any run_*() function
    test_type : str
    alpha     : float

    Returns
    -------
    dict with power analysis results
    """
    use_param = R.get("use_param", True)

    try:
        if not use_param:
            return power_nonparametric(R, alpha)

        if test_type == "One-Sample T-Test":
            return power_one_sample(R, alpha)
        elif test_type == "Paired-Sample T-Test":
            return power_paired(R, alpha)
        elif test_type == "Independent-Sample T-Test":
            return power_independent(R, alpha)
        elif test_type == "One-Way ANOVA":
            return power_oneway_anova(R, alpha)
        else:
            # Fallback for tests not yet implemented
            return power_nonparametric(R, alpha)

    except Exception:
        return _build_result(
            test_type   = test_type,
            effect_size = np.nan,
            effect_type = "N/A",
            power       = np.nan,
            alpha       = alpha,
            n           = None,
            n_required  = None,
        )


# ══════════════════════════════════════════════════════════════════════════════
# RESULT BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def _build_result(test_type, effect_size, effect_type,
                  power, alpha, n, n_required):
    """
    Build a standardised power result dict.

    Parameters
    ----------
    test_type   : str
    effect_size : float
    effect_type : str
    power       : float
    alpha       : float
    n           : int or None
    n_required  : int or None — min n for power = .80

    Returns
    -------
    dict
    """
    pwr_label = power_label(power) if not np.isnan(power) else "N/A"
    pwr_pct   = f"{power * 100:.1f}%" if not np.isnan(power) else "N/A"
    n_desc    = str(n) if n is not None else "N/A"

    n_req_desc = (str(n_required)
                  if n_required is not None and n_required <= 9999
                  else "> 10,000 (effect size too small)")

    return {
        "test_type":      test_type,
        "effect_size":    float(effect_size) if not np.isnan(effect_size) else np.nan,
        "effect_type":    effect_type,
        "alpha":          alpha,
        "power":          float(power) if not np.isnan(power) else np.nan,
        "power_pct":      pwr_pct,
        "power_label":    pwr_label,
        "n":              n,
        "n_desc":         n_desc,
        "n_required_80":  n_required,
        "n_req_desc":     n_req_desc,
        "reference":      "Cohen (1988)",
    }


# ══════════════════════════════════════════════════════════════════════════════
# POWER TABLE ROWS (for display)
# ══════════════════════════════════════════════════════════════════════════════

def power_table_rows(pw):
    """
    Convert a power result dict to table rows for display.

    Parameters
    ----------
    pw : dict — output of compute_power()

    Returns
    -------
    list of [parameter, value] pairs
    """
    from utils.formatters import _f

    n_desc = pw.get("n_desc", "N/A")
    if "n1" in pw:
        n_desc = pw.get("n_desc", f"n\u2081 = {pw['n1']}, n\u2082 = {pw['n2']}")

    return [
        ["Parameter",                   "Value"],
        ["Sample size",                  n_desc],
        ["Observed effect size",
         f"{_f(pw.get('effect_size', float('nan')))} ({pw.get('effect_type', '')})"],
        ["Significance level (\u03b1)",  str(pw.get("alpha", 0.05))],
        ["Achieved statistical power",   pw.get("power_pct", "N/A")],
        ["Power classification",         pw.get("power_label", "N/A")],
        ["Recommended minimum power",    "\u2265\u2009.80 (Cohen, 1988)"],
        ["Minimum n for power = .80",    pw.get("n_req_desc", "N/A")],
    ]
