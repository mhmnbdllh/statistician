"""
modules/regression.py
=====================
Linear Regression analysis — SPSS-equivalent + beyond SPSS.

SPSS-equivalent tables:
  - Descriptive Statistics (Mean, Median, SD, N per variable)
  - Correlations matrix (Pearson r + Sig. 1-tailed + N)
  - Variables Entered/Removed
  - Model Summary (R, R², Adj R², SE, R²-Change, F-Change, DW)
  - ANOVA table (Regression, Residual, Total)
  - Coefficients (B, SE, Beta, t, Sig., 95% CI, Zero-order/Partial/Part r,
                  Tolerance, VIF)
  - Collinearity Diagnostics (Eigenvalue, Condition Index, Variance Proportions)
  - Residuals Statistics (Predicted, Residual, Std. Predicted, Std. Residual)

Assumption Tests:
  1. Normality of residuals  (Shapiro-Wilk + KS Lilliefors, N criterion)
  2. Linearity               (ANOVA Deviation-from-Linearity, SPSS Means)
  3. Multicollinearity       (VIF + Tolerance)
  4. Heteroscedasticity      (Glejser test)
  5. Autocorrelation         (Durbin-Watson)
  6. Outliers                (Cook's Distance, threshold 4/n)

Beyond SPSS:
  - 95% Bootstrap CI for every B coefficient (2,000 resamples)
  - Partial and part (semi-partial) correlations
  - Effect size f² (Cohen, 1988)
  - Post-hoc statistical power (non-central F)
  - Minimum N for power = .80
  - Full descriptive statistics (N, Mean, Median, 5% Trimmed Mean,
    Variance, SD, SE, 95% CI, Min, Max, IQR, Skewness, Kurtosis)
  - APA 7th edition write-up
  - Academic interpretation per assumption + per coefficient

References:
  Cohen, J. (1988). Statistical power analysis for the behavioral sciences.
  Field, A. (2018). Discovering statistics using IBM SPSS (5th ed.).
  Faul et al. (2007). G*Power 3. Behavior Research Methods, 39, 175-191.
  Belsley et al. (1980). Regression Diagnostics.
"""

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from statsmodels.stats.diagnostic import lilliefors
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm
import warnings
warnings.filterwarnings("ignore")


# ══════════════════════════════════════════════════════════════════════════════
# DESCRIPTIVE STATISTICS
# ══════════════════════════════════════════════════════════════════════════════

def _desc_one(data, alpha=0.05):
    """Full descriptive statistics for one variable — SPSS Explore equivalent."""
    x   = np.array(data, dtype=float)
    x   = x[~np.isnan(x)]
    n   = len(x)
    if n == 0:
        return {k: np.nan for k in ["N","Mean","Median","5% Trimmed Mean",
            "Variance","Std. Deviation","Std. Error",
            "95% CI Lower","95% CI Upper",
            "Minimum","Maximum","IQR","Skewness","Kurtosis"]}
    m    = float(np.mean(x))
    med  = float(np.median(x))
    var  = float(np.var(x, ddof=1)) if n > 1 else np.nan
    sd   = float(np.std(x, ddof=1)) if n > 1 else np.nan
    se   = float(scipy_stats.sem(x)) if n > 1 else np.nan
    if n > 1 and not np.isnan(se):
        tc   = scipy_stats.t.ppf(1 - alpha / 2, n - 1)
        ci_l = float(m - tc * se)
        ci_u = float(m + tc * se)
    else:
        ci_l = ci_u = np.nan
    mn_  = float(np.min(x))
    mx_  = float(np.max(x))
    iqr_ = float(np.percentile(x, 75) - np.percentile(x, 25))
    skew = float(scipy_stats.skew(x, bias=False))  if n > 2 else np.nan
    kurt = float(scipy_stats.kurtosis(x, bias=False)) if n > 3 else np.nan
    # 5% partial trimmed mean (SPSS method)
    xs   = np.sort(x)
    a_   = 0.05 * n
    k_   = int(np.floor(a_))
    frac = a_ - k_
    w_   = np.ones(n)
    w_[k_]        = 1.0 - frac
    w_[-(k_ + 1)] = 1.0 - frac
    if k_ > 0:
        w_[:k_]  = 0.0
        w_[-k_:] = 0.0
    tm5 = float(np.sum(w_ * xs) / np.sum(w_))

    def _r3(v): return round(v, 3) if not np.isnan(v) else np.nan
    return {
        "N":               int(n),
        "Mean":            _r3(m),
        "Median":          _r3(med),
        "5% Trimmed Mean": _r3(tm5),
        "Variance":        _r3(var),
        "Std. Deviation":  _r3(sd),
        "Std. Error":      _r3(se),
        "95% CI Lower":    _r3(ci_l),
        "95% CI Upper":    _r3(ci_u),
        "Minimum":         _r3(mn_),
        "Maximum":         _r3(mx_),
        "IQR":             _r3(iqr_),
        "Skewness":        _r3(skew),
        "Kurtosis":        _r3(kurt),
    }


def compute_descriptives(y, X_df, y_name, alpha=0.05):
    """
    SPSS-style Descriptive Statistics table for all variables.
    Returns pd.DataFrame with columns: Variable, N, Mean, Std. Deviation.
    Also returns full_desc dict for Beyond-SPSS display.
    """
    all_vars = [y_name] + list(X_df.columns)
    all_data = [np.array(y, dtype=float)] + [X_df[c].values.astype(float)
                                              for c in X_df.columns]
    spss_rows  = []   # SPSS default: N, Mean, Std. Deviation
    full_rows  = []   # Beyond SPSS: all stats
    for name, data in zip(all_vars, all_data):
        d = _desc_one(data, alpha)
        spss_rows.append({
            "": name,
            "Mean":             d["Mean"],
            "Std. Deviation":   d["Std. Deviation"],
            "N":                d["N"],
        })
        full_rows.append({"Variable": name, **d})
    return pd.DataFrame(spss_rows), pd.DataFrame(full_rows)


# ══════════════════════════════════════════════════════════════════════════════
# CORRELATIONS MATRIX
# ══════════════════════════════════════════════════════════════════════════════

def compute_correlations(y, X_df, y_name):
    """
    SPSS-style Correlations table:
    Pearson r, Sig. (1-tailed), N for all variable pairs.
    Returns dict with keys: r_df, sig_df, n_df
    """
    all_vars = [y_name] + list(X_df.columns)
    data_mat = np.column_stack(
        [np.array(y, dtype=float)] +
        [X_df[c].values.astype(float) for c in X_df.columns]
    )
    n_vars = len(all_vars)
    r_mat  = np.full((n_vars, n_vars), np.nan)
    p_mat  = np.full((n_vars, n_vars), np.nan)
    n_mat  = np.full((n_vars, n_vars), np.nan)

    for i in range(n_vars):
        for j in range(n_vars):
            xi = data_mat[:, i]; xj = data_mat[:, j]
            mask = ~(np.isnan(xi) | np.isnan(xj))
            nm = int(np.sum(mask))
            if nm < 2:
                continue
            r, p2 = scipy_stats.pearsonr(xi[mask], xj[mask])
            r_mat[i, j] = round(float(r), 3)
            p_mat[i, j] = round(float(p2 / 2), 3)   # 1-tailed
            n_mat[i, j] = nm

    r_df = pd.DataFrame(r_mat, index=all_vars, columns=all_vars)
    p_df = pd.DataFrame(p_mat, index=all_vars, columns=all_vars)
    n_df = pd.DataFrame(n_mat, index=all_vars, columns=all_vars)
    return {"r_df": r_df, "p_df": p_df, "n_df": n_df, "vars": all_vars}


# ══════════════════════════════════════════════════════════════════════════════
# COLLINEARITY DIAGNOSTICS
# ══════════════════════════════════════════════════════════════════════════════

def compute_collinearity_diagnostics(X_df):
    """
    SPSS Collinearity Diagnostics:
    Eigenvalues, Condition Index, Variance Proportions.

    Method: SVD of column-norm-scaled [1 | X] matrix (SPSS method).
    CI = sqrt(max_eigenvalue / eigenvalue_i).
    Variance proportions = Vᵀ² normalised per predictor.

    Returns pd.DataFrame with columns:
    Dimension, Eigenvalue, Condition Index, (Constant), x1, x2, ...
    """
    X_c      = np.column_stack([np.ones(len(X_df)), X_df.values.astype(float)])
    col_names = ["(Constant)"] + list(X_df.columns)

    # Scale each column by its L2 norm (SPSS method)
    col_norms = np.sqrt((X_c ** 2).sum(axis=0))
    col_norms[col_norms == 0] = 1.0
    X_scaled  = X_c / col_norms

    _, s, Vt = np.linalg.svd(X_scaled, full_matrices=False)
    eigenvalues = s ** 2
    ci          = np.sqrt(eigenvalues[0] / np.where(eigenvalues > 0,
                                                     eigenvalues, np.nan))
    # Variance proportions: for each predictor j,
    # proportion explained by dimension i = Vt[i,j]² / sum_i(Vt[i,j]²)
    V    = Vt.T   # shape (p, ndims)
    phi  = (V ** 2)                          # (p, ndims)
    denom = phi.sum(axis=1, keepdims=True)   # sum over dims per predictor
    denom[denom == 0] = 1.0
    phi  = (phi / denom).T                   # (ndims, p)

    rows = []
    for i in range(len(eigenvalues)):
        row = {
            "Dimension":       i + 1,
            "Eigenvalue":      round(float(eigenvalues[i]), 3),
            "Condition Index": round(float(ci[i]), 3),
        }
        for j, cn in enumerate(col_names):
            row[cn] = round(float(phi[i, j]), 2)
        rows.append(row)
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# RESIDUALS STATISTICS
# ══════════════════════════════════════════════════════════════════════════════

def compute_residuals_statistics(fitted, residuals, y, se_est=None, alpha=0.05):
    """
    SPSS Residuals Statistics table.
    Std. Residual = residual / se_est  (SPSS: sqrt(MSE), not std of residuals)
    """
    fitted_    = np.array(fitted,    dtype=float)
    residuals_ = np.array(residuals, dtype=float)
    n = len(fitted_)

    # SPSS Std. Predicted Value: (fitted - mean_fitted) / std_fitted
    zpred = ((fitted_ - fitted_.mean()) / fitted_.std(ddof=1)
             if fitted_.std(ddof=1) > 0 else np.zeros(n))

    # SPSS Std. Residual = residual / sqrt(MSE) = residual / se_est
    if se_est is not None and se_est > 0:
        zresid = residuals_ / se_est
    else:
        se_resid = float(np.std(residuals_, ddof=1)) if n > 1 else np.nan
        zresid   = (residuals_ / se_resid if se_resid and se_resid > 0
                    else np.zeros(n))

    def _stats(arr):
        a = arr[~np.isnan(arr)]
        if len(a) == 0:
            return {"Minimum": np.nan, "Maximum": np.nan,
                    "Mean": np.nan, "Std. Deviation": np.nan, "N": 0}
        return {
            "Minimum":       round(float(np.min(a)), 5),
            "Maximum":       round(float(np.max(a)), 5),
            "Mean":          round(float(np.mean(a)), 5),
            "Std. Deviation":round(float(np.std(a, ddof=1)) if len(a)>1 else np.nan, 5),
            "N":             int(len(a)),
        }

    rows = []
    for label, arr in [
        ("Predicted Value",      fitted_),
        ("Residual",             residuals_),
        ("Std. Predicted Value", zpred),
        ("Std. Residual",        zresid),
    ]:
        s = _stats(arr)
        rows.append({"": label, **s})
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# NORMALITY OF RESIDUALS
# ══════════════════════════════════════════════════════════════════════════════

def test_normality_residuals(residuals):
    """
    Normality of regression residuals.
    Primary criterion: N < 50 → Shapiro-Wilk; N ≥ 50 → KS Lilliefors.
    Returns dict identical in structure to modules/normality.test_normality().
    """
    res = np.array(residuals, dtype=float)
    n   = len(res)

    # Guard: zero variance residuals (perfect fit) — tests not meaningful
    if n < 3 or float(np.std(res)) < 1e-10:
        return {
            "label": "Residuals", "n": n, "total_n": n,
            "sw_W": np.nan, "sw_p": np.nan, "sw_pass": False,
            "ks_D": np.nan, "ks_p": np.nan, "ks_pass": False,
            "primary": "sw", "primary_label": "Shapiro-Wilk",
            "pass": False,
        }

    try:
        sw_W, sw_p = scipy_stats.shapiro(res)
    except Exception:
        sw_W, sw_p = np.nan, np.nan

    try:
        ks_method  = "table" if n < 50 else "approx"
        ks_D, ks_p = lilliefors(res, dist="norm", pvalmethod=ks_method)
    except Exception:
        ks_D, ks_p = np.nan, np.nan

    if n < 50:
        primary       = "sw"
        primary_label = "Shapiro-Wilk"
        passed        = (not np.isnan(sw_p)) and float(sw_p) > 0.05
    else:
        primary       = "ks"
        primary_label = "Kolmogorov-Smirnov"
        passed        = (not np.isnan(ks_p)) and float(ks_p) >= 0.05

    return {
        "label":         "Residuals",
        "n":             n, "total_n": n,
        "sw_W":          float(sw_W)  if not np.isnan(sw_W)  else np.nan,
        "sw_p":          float(sw_p)  if not np.isnan(sw_p)  else np.nan,
        "sw_pass":       (not np.isnan(sw_p)) and float(sw_p) > 0.05,
        "ks_D":          float(ks_D)  if not np.isnan(ks_D)  else np.nan,
        "ks_p":          float(ks_p)  if not np.isnan(ks_p)  else np.nan,
        "ks_pass":       (not np.isnan(ks_p)) and float(ks_p) >= 0.05,
        "primary":       primary,
        "primary_label": primary_label,
        "pass":          passed,
    }


# ══════════════════════════════════════════════════════════════════════════════
# LINEARITY (ANOVA Deviation from Linearity)
# ══════════════════════════════════════════════════════════════════════════════

def test_linearity(x_series, y_series, x_name="X", y_name="Y"):
    """
    SPSS Means → ANOVA table: Linearity + Deviation from Linearity.
    Satisfied when: Sig. Linearity < .05  AND  Sig. Deviation > .05.
    """
    x = np.array(x_series, dtype=float)
    y = np.array(y_series, dtype=float)
    n = len(y)
    grand_mean = y.mean()

    # OLS for linear component
    X_c    = sm.add_constant(x)
    ols    = sm.OLS(y, X_c).fit()
    ss_reg = float(ols.ess)
    ss_res = float(ols.ssr)

    # Group by unique X values
    groups = {}
    for xi, yi in zip(x, y):
        groups.setdefault(round(float(xi), 10), []).append(yi)
    n_groups  = len(groups)
    df_within = n - n_groups

    # Continuous X (all unique values) — use OLS F directly
    if n_groups >= n - 1 or df_within <= 0:
        ms_within = ss_res / (n - 2) if n > 2 else np.nan
        return {
            "x_name": x_name, "y_name": y_name,
            "ss_reg": ss_reg, "ss_dev": np.nan, "ss_within": np.nan,
            "ss_between": ss_reg, "df_groups": 1,
            "ms_between": ss_reg, "F_between": float(ols.fvalue),
            "p_between":  float(ols.f_pvalue),
            "df_lin": 1, "df_dev": 0, "df_within": n - 2,
            "ms_lin": ss_reg, "ms_dev": np.nan, "ms_within": ms_within,
            "F_lin": float(ols.fvalue), "F_dev": np.nan,
            "p_lin": float(ols.f_pvalue), "p_dev": np.nan,
            "passed": float(ols.f_pvalue) < 0.05,
            "continuous_x": True,
        }

    ss_within  = sum(np.sum((np.array(v) - np.mean(v)) ** 2)
                     for v in groups.values())
    ss_between = sum(len(v) * (np.mean(v) - grand_mean) ** 2
                     for v in groups.values())
    df_groups  = n_groups - 1
    ss_dev     = ss_between - ss_reg
    df_lin     = 1
    df_dev     = df_groups - df_lin

    ms_within  = ss_within  / df_within  if df_within  > 0 else np.nan
    ms_lin     = ss_reg     / df_lin
    ms_dev     = ss_dev     / df_dev     if df_dev > 0 else np.nan
    ms_between = ss_between / df_groups  if df_groups > 0 else np.nan

    def _F(ms, ms_w):
        return float(ms / ms_w) if (ms_w and ms_w > 0 and not np.isnan(ms)) else np.nan

    F_lin     = _F(ms_lin,     ms_within)
    F_dev     = _F(ms_dev,     ms_within) if df_dev > 0 else np.nan
    F_between = _F(ms_between, ms_within)

    def _p(F_, df1, df2):
        if np.isnan(F_) or df1 <= 0 or df2 <= 0: return np.nan
        return float(1 - scipy_stats.f.cdf(F_, df1, df2))

    p_lin     = _p(F_lin,     df_lin,    df_within)
    p_dev     = _p(F_dev,     df_dev,    df_within) if df_dev > 0 else np.nan
    p_between = _p(F_between, df_groups, df_within)

    passed = (
        (not np.isnan(p_lin) and p_lin < 0.05) and
        (np.isnan(p_dev) or p_dev > 0.05)
    )
    return {
        "x_name": x_name, "y_name": y_name,
        "ss_reg": ss_reg, "ss_dev": ss_dev, "ss_within": ss_within,
        "ss_between": ss_between, "df_groups": df_groups,
        "ms_between": ms_between, "F_between": F_between, "p_between": p_between,
        "df_lin": df_lin, "df_dev": df_dev, "df_within": df_within,
        "ms_lin": ms_lin, "ms_dev": ms_dev, "ms_within": ms_within,
        "F_lin": F_lin, "F_dev": F_dev,
        "p_lin": p_lin, "p_dev": p_dev,
        "passed": passed, "continuous_x": False,
    }


# ══════════════════════════════════════════════════════════════════════════════
# MULTICOLLINEARITY (VIF + Tolerance)
# ══════════════════════════════════════════════════════════════════════════════

def test_multicollinearity(X_df):
    """VIF and Tolerance per predictor (SPSS-equivalent)."""
    X    = sm.add_constant(X_df.values.astype(float))
    rows = []
    for i, col in enumerate(X_df.columns):
        try:
            vif = float(variance_inflation_factor(X, i + 1))
        except Exception:
            vif = np.nan
        tol = (1.0 / vif) if (not np.isnan(vif) and vif > 0) else np.nan
        rows.append({
            "Variable":  col,
            "Tolerance": round(tol, 3) if not np.isnan(tol) else np.nan,
            "VIF":       round(vif, 3) if not np.isnan(vif) else np.nan,
            "Status":    ("OK"                  if not np.isnan(vif) and vif < 5
                          else "WARNING (5–10)" if not np.isnan(vif) and vif < 10
                          else "VIOLATION (>10)"),
        })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# HETEROSCEDASTICITY (Glejser)
# ══════════════════════════════════════════════════════════════════════════════

def test_heteroscedasticity(residuals, X_df):
    """Glejser test: regress |residuals| on predictors."""
    abs_res = np.abs(np.array(residuals, dtype=float))
    X_c     = sm.add_constant(X_df.values.astype(float))
    model   = sm.OLS(abs_res, X_c).fit()
    p_arr   = np.asarray(model.params)
    b_arr   = np.asarray(model.bse)
    t_arr   = np.asarray(model.tvalues)
    pv_arr  = np.asarray(model.pvalues)

    rows = [{"Term": "(Constant)",
             "B": float(p_arr[0]), "Std. Error": float(b_arr[0]),
             "t": float(t_arr[0]), "Sig.": float(pv_arr[0])}]
    for i, col in enumerate(X_df.columns):
        rows.append({"Term": col,
                     "B": float(p_arr[i+1]), "Std. Error": float(b_arr[i+1]),
                     "t": float(t_arr[i+1]), "Sig.": float(pv_arr[i+1])})

    pred_rows = [r for r in rows if r["Term"] != "(Constant)"]
    passed    = all(r["Sig."] > 0.05 for r in pred_rows)
    return {
        "coef_df": pd.DataFrame(rows),
        "passed":  passed,
        "note":    ("No heteroscedasticity detected (all predictor Sig.\u2009>\u2009.05)."
                    if passed else
                    "Heteroscedasticity detected "
                    "(at least one predictor Sig.\u2009\u2264\u2009.05). "
                    "Consider log-transforming Y or using WLS."),
    }


# ══════════════════════════════════════════════════════════════════════════════
# AUTOCORRELATION (Durbin-Watson)
# ══════════════════════════════════════════════════════════════════════════════

def test_autocorrelation(residuals):
    """Durbin-Watson statistic. DW ≈ 2 → no autocorrelation."""
    res = np.array(residuals, dtype=float)
    try:
        dw = float(durbin_watson(res))
    except Exception:
        dw = np.nan

    if np.isnan(dw):
        interp = "Could not compute Durbin-Watson statistic."
        passed = False
    elif dw < 1.5:
        interp = "Positive autocorrelation detected (DW\u2009<\u20091.5)."
        passed = False
    elif dw > 2.5:
        interp = "Negative autocorrelation detected (DW\u2009>\u20092.5)."
        passed = False
    else:
        interp = "No substantial autocorrelation (1.5\u2009\u2264\u2009DW\u2009\u2264\u20092.5)."
        passed = True

    return {"dw": dw, "passed": passed, "interpretation": interp}


# ══════════════════════════════════════════════════════════════════════════════
# OUTLIERS (Cook's Distance)
# ══════════════════════════════════════════════════════════════════════════════

def test_outliers(model_sm, n, k):
    """Cook's Distance. Threshold: D > 4/n."""
    try:
        from statsmodels.stats.outliers_influence import OLSInfluence
        influence = OLSInfluence(model_sm)
        cooks_d   = np.array(influence.cooks_distance[0])
    except Exception:
        cooks_d = np.full(n, np.nan)

    threshold = 4 / n
    inf_idx   = list(np.where(cooks_d > threshold)[0])
    inf_rows  = [int(i) + 1 for i in inf_idx[:10]]
    return {
        "cooks_d":         cooks_d,
        "influential_idx": inf_idx,
        "threshold":       threshold,
        "n_influential":   len(inf_idx),
        "passed":          len(inf_idx) == 0,
        "note":            (
            f"No influential outliers detected "
            f"(threshold: Cook\u2019s D\u2009>\u2009{threshold:.4f})."
            if len(inf_idx) == 0 else
            f"{len(inf_idx)} influential observation(s) detected "
            f"(Cook\u2019s D\u2009>\u2009{threshold:.4f}). "
            f"Inspect row(s) {inf_rows}. "
            "Check for data entry errors or extreme values."
        ),
    }


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _compute_partial_correlations(y, X_df, model):
    """
    Partial r = t / sqrt(t² + df_res)  — Field (2018)
    Part r    = sign(B) * sqrt(R²_full - R²_without_j)
                — SPSS method: unique R² contribution of each predictor
    """
    R2_full = float(model.rsquared)
    results = []
    for i, col in enumerate(X_df.columns):
        try:
            # Partial r
            t_val = float(np.asarray(model.tvalues)[i + 1])
            df_r  = float(model.df_resid)
            pr    = t_val / np.sqrt(t_val ** 2 + df_r)

            # Part r — SPSS: drop predictor j, refit, R² difference
            others = [c for c in X_df.columns if c != col]
            X_red  = sm.add_constant(X_df[others].values.astype(float))
            m_red  = sm.OLS(np.array(y, dtype=float), X_red).fit()
            R2_red = float(m_red.rsquared)
            sr2    = float(R2_full - R2_red)
            b_val  = float(np.asarray(model.params)[i + 1])
            sr     = float(np.sign(b_val) * np.sqrt(abs(sr2)))

            # Zero-order
            zo = float(np.corrcoef(X_df[col], y)[0, 1])

            results.append({
                "Variable":   col,
                "Zero-order": round(zo, 3),
                "Partial r":  round(pr, 3),
                "Part r":     round(sr, 3),
                "Partial r²": round(pr ** 2, 3),
                "Part r²":    round(sr2,     3),
            })
        except Exception:
            results.append({
                "Variable":   col,
                "Zero-order": np.nan, "Partial r": np.nan, "Part r": np.nan,
                "Partial r²": np.nan, "Part r²":   np.nan,
            })
    return pd.DataFrame(results)


def _f2_label(f2):
    if np.isnan(f2): return "N/A"
    if f2 < .02:     return "negligible"
    if f2 < .15:     return "small"
    if f2 < .35:     return "medium"
    return "large"


def _power_f_regression(f2, df_num, df_den, alpha=0.05):
    """Post-hoc power via non-central F."""
    if np.isnan(f2) or df_den <= 0 or f2 <= 0:
        return np.nan
    try:
        n   = df_num + df_den + 1
        ncp = f2 * n
        fc  = scipy_stats.f.ppf(1 - alpha, df_num, df_den)
        return float(np.clip(scipy_stats.ncf.sf(fc, df_num, df_den, ncp), 0, 1))
    except Exception:
        return np.nan


def _n_for_power_regression(f2, k, target=0.80, alpha=0.05, n_max=10000):
    """Minimum N for target power = .80."""
    if np.isnan(f2) or f2 <= 0:
        return None
    for n in range(k + 2, n_max):
        df_den = n - k - 1
        if df_den <= 0:
            continue
        pwr = _power_f_regression(f2, k, df_den, alpha)
        if not np.isnan(pwr) and pwr >= target:
            return n
    return None


def _bootstrap_coef_ci(y, X_df, n_boot=2000, alpha=0.05, seed=42):
    """
    Bootstrap percentile CI (2,000 resamples) for all coefficients.
    Returns dict: {name: (lower, upper)}
    """
    rng       = np.random.default_rng(seed)
    y_arr     = np.array(y, dtype=float)
    X_arr     = X_df.values.astype(float)
    n         = len(y_arr)
    col_names = ["(Constant)"] + list(X_df.columns)
    boots     = {c: [] for c in col_names}

    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        y_b = y_arr[idx]; X_b = X_arr[idx]
        try:
            X_bc = sm.add_constant(X_b, has_constant="add")
            m    = sm.OLS(y_b, X_bc).fit()
            p    = np.asarray(m.params)
            for j, c in enumerate(col_names):
                boots[c].append(float(p[j]))
        except Exception:
            pass

    lo = 100 * alpha / 2
    hi = 100 * (1 - alpha / 2)
    ci = {}
    for c, vals in boots.items():
        if len(vals) > 10:
            ci[c] = (round(float(np.percentile(vals, lo)), 3),
                     round(float(np.percentile(vals, hi)), 3))
        else:
            ci[c] = (np.nan, np.nan)
    return ci


# ══════════════════════════════════════════════════════════════════════════════
# MAIN REGRESSION RUNNER
# ══════════════════════════════════════════════════════════════════════════════

def run_regression(y, X_df, y_name="Y", alpha=0.05):
    """
    Core regression: SPSS-equivalent tables + beyond-SPSS features.
    Call run_full_regression() to also run all assumption tests.
    """
    y     = np.array(y, dtype=float)
    n     = len(y)
    k     = X_df.shape[1]
    X_df  = X_df.copy()
    X_c   = sm.add_constant(X_df.values.astype(float))
    model = sm.OLS(y, X_c).fit()

    residuals = pd.Series(model.resid,        name="Residuals")
    fitted    = pd.Series(model.fittedvalues,  name="Fitted")

    # ── Model summary ──────────────────────────────────────────────────────
    R_val  = float(np.sqrt(max(model.rsquared, 0)))
    R2     = float(model.rsquared)
    adj_R2 = float(model.rsquared_adj)
    se_est = float(np.sqrt(model.mse_resid)) if model.mse_resid > 0 else 0.0
    perfect_fit = (se_est == 0.0)  # MSE=0: perfect collinearity
    F_val  = (np.nan if perfect_fit else
              float(model.fvalue) if not np.isnan(model.fvalue) else np.nan)
    p_F    = (np.nan if perfect_fit else
              float(model.f_pvalue) if not np.isnan(model.f_pvalue) else np.nan)
    df_reg = k
    df_res = n - k - 1
    df_tot = n - 1
    ss_reg = float(model.ess)
    ss_res = float(model.ssr)
    ss_tot = float(model.centered_tss)
    ms_reg = ss_reg / df_reg if df_reg > 0 else np.nan
    ms_res = ss_res / df_res if df_res > 0 else np.nan

    # ── Coefficients ────────────────────────────────────────────────────────
    p_arr  = np.asarray(model.params)
    b_arr  = np.asarray(model.bse)
    # For perfect fit (se=0), t and Sig. are undefined — show NaN
    t_arr  = np.where(perfect_fit, np.nan, np.asarray(model.tvalues))
    pv_arr = np.where(perfect_fit, np.nan, np.asarray(model.pvalues))
    try:
        conf = model.conf_int(alpha=alpha)
    except Exception:
        conf = np.full((len(p_arr), 2), np.nan)
    y_std  = float(np.std(y, ddof=1)) if len(y) > 1 else np.nan

    coef_rows = [{
        "Model":            "(Constant)",
        "B":                float(p_arr[0]),
        "Std. Error":       float(b_arr[0]),
        "Beta":             "",
        "t":                float(t_arr[0]),
        "Sig.":             float(pv_arr[0]),
        f"{int((1-alpha)*100)}% CI Lower": float(conf[0][0]),
        f"{int((1-alpha)*100)}% CI Upper": float(conf[0][1]),
    }]
    for i, col in enumerate(X_df.columns):
        x_std = float(X_df[col].std(ddof=1)) if len(X_df) > 1 else np.nan
        beta  = (float(p_arr[i+1]) * x_std / y_std
                 if (not np.isnan(x_std) and y_std and y_std > 0) else np.nan)
        coef_rows.append({
            "Model":            col,
            "B":                float(p_arr[i+1]),
            "Std. Error":       float(b_arr[i+1]),
            "Beta":             beta,
            "t":                float(t_arr[i+1]),
            "Sig.":             float(pv_arr[i+1]),
            f"{int((1-alpha)*100)}% CI Lower": float(conf[i+1][0]),
            f"{int((1-alpha)*100)}% CI Upper": float(conf[i+1][1]),
        })
    coef_df = pd.DataFrame(coef_rows)

    # ── Partial / part correlations ─────────────────────────────────────────
    partial_corr = _compute_partial_correlations(y, X_df, model)

    # ── Effect size ──────────────────────────────────────────────────────────
    f2       = R2 / (1 - R2) if (R2 < 1 and not np.isnan(R2)) else np.nan
    f_cohen  = float(np.sqrt(f2)) if not np.isnan(f2) else np.nan
    f2_label = _f2_label(f2)

    # ── Power ────────────────────────────────────────────────────────────────
    power      = _power_f_regression(f2, df_reg, df_res, alpha)
    n_required = _n_for_power_regression(f2, k, target=0.80, alpha=alpha)

    # ── Bootstrap CI ─────────────────────────────────────────────────────────
    boot_ci = _bootstrap_coef_ci(y, X_df, n_boot=2000, alpha=alpha)

    # ── Equation string ──────────────────────────────────────────────────────
    const = float(p_arr[0])
    parts = [f"{const:.3f}"]
    for _, row in coef_df[coef_df["Model"] != "(Constant)"].iterrows():
        sign = " + " if float(row["B"]) >= 0 else " \u2212 "
        parts.append(f"{sign}{abs(float(row['B'])):.3f} ({row['Model']})")
    equation = "\u0176 = " + "".join(parts)

    # ── Equation interpretation ──────────────────────────────────────────────
    eq_parts = []
    for _, row in coef_df[coef_df["Model"] != "(Constant)"].iterrows():
        direction = "increases" if float(row["B"]) > 0 else "decreases"
        eq_parts.append(
            f"every one-unit increase in <b>{row['Model']}</b> is associated "
            f"with a {direction} of <b>{abs(float(row['B'])):.3f}</b> units "
            f"in <b>{y_name}</b>, holding all other predictors constant"
        )
    eq_interpretation = (
        f"The regression constant (a\u2009=\u2009{const:.3f}) is the predicted "
        f"value of {y_name} when all predictors equal zero. "
        + ("; ".join(eq_parts) + "." if eq_parts else "")
    )

    # ── SPSS tables ──────────────────────────────────────────────────────────
    spss_desc, full_desc = compute_descriptives(y, X_df, y_name, alpha)
    correlations         = compute_correlations(y, X_df, y_name)
    collinearity_diag    = compute_collinearity_diagnostics(X_df)
    # VIF/Tolerance: for simple regression, always 1.000 (one predictor)
    if k == 1:
        from statsmodels.stats.outliers_influence import variance_inflation_factor as _vif
        _col = list(X_df.columns)[0]
        multicollinearity_df = pd.DataFrame([{
            "Variable":  _col,
            "Tolerance": 1.0,
            "VIF":       1.0,
            "Status":    "OK",
        }])
    else:
        multicollinearity_df = None  # filled by run_full_regression
    residuals_stats      = compute_residuals_statistics(fitted, residuals, y, se_est, alpha)

    # ── Variables Entered table ──────────────────────────────────────────────
    vars_entered = pd.DataFrame([{
        "Model": 1,
        "Variables Entered": ", ".join(list(X_df.columns)),
        "Variables Removed": ".",
        "Method": "Enter",
    }])

    # ── Model Summary with Change Statistics ─────────────────────────────────
    dw_val = float(durbin_watson(residuals.values)) if len(residuals) > 1 else np.nan
    model_summary = pd.DataFrame([{
        "Model": 1,
        "R":                          round(R_val, 3),
        "R Square":                   round(R2, 3),
        "Adjusted R Square":          round(adj_R2, 3),
        "Std. Error of the Estimate": round(se_est, 5),
        "R Square Change":            round(R2, 3),
        "F Change":                   round(F_val, 3) if not np.isnan(F_val) else np.nan,
        "df1":                        df_reg,
        "df2":                        df_res,
        "Sig. F Change":              round(p_F, 3) if not np.isnan(p_F) else np.nan,
        "Durbin-Watson":              round(dw_val, 3) if not np.isnan(dw_val) else np.nan,
    }])

    return {
        # Meta
        "y_name":          y_name,
        "x_names":         list(X_df.columns),
        "n":               n, "k": k,
        "reg_type":        "Simple" if k == 1 else "Multiple",
        "alpha":           alpha,
        # Core
        "model":           model,
        "residuals":       residuals,
        "fitted":          fitted,
        # SPSS tables
        "spss_desc":       spss_desc,
        "full_desc":       full_desc,
        "correlations":    correlations,
        "vars_entered":    vars_entered,
        "model_summary":   model_summary,
        "collinearity_diag": collinearity_diag,
        "residuals_stats": residuals_stats,
        # Model summary values
        "R":               R_val, "R2": R2, "adj_R2": adj_R2,
        "se_est":          se_est, "dw": dw_val,
        "F":               F_val,  "p_F": p_F,
        "df_reg":          df_reg, "df_res": df_res, "df_tot": df_tot,
        "ss_reg":          ss_reg, "ss_res": ss_res, "ss_tot": ss_tot,
        "ms_reg":          ms_reg, "ms_res": ms_res,
        # Coefficients
        "coef_df":         coef_df,
        "equation":        equation,
        "eq_interpretation": eq_interpretation,
        # Beyond SPSS
        "partial_corr":    partial_corr,
        "boot_ci":         boot_ci,
        "f2":              f2, "f": f_cohen, "f2_label": f2_label,
        "power":           power, "n_required": n_required,
        # Assumptions (filled by run_full_regression)
        "normality":       None, "linearity":     None,
        "multicollinearity": multicollinearity_df,
        "heteroscedasticity": None,
        "autocorrelation":   None, "outliers":          None,
        "all_assumptions_met": False,
    }


def run_full_regression(y, X_df, y_name="Y", alpha=0.05):
    """
    run_regression() + all six assumption tests in one call.
    Returns complete R dict ready for UI, HTML report, and CSV export.
    """
    R = run_regression(y, X_df, y_name, alpha)

    R["normality"]          = test_normality_residuals(R["residuals"])
    R["linearity"]          = {col: test_linearity(X_df[col], y, col, y_name)
                               for col in X_df.columns}
    # Multiple regression: compute full VIF; simple already set to 1.000
    if R["k"] > 1:
        R["multicollinearity"] = test_multicollinearity(X_df)
    R["heteroscedasticity"] = test_heteroscedasticity(R["residuals"], X_df)
    R["autocorrelation"]    = test_autocorrelation(R["residuals"])
    R["outliers"]           = test_outliers(R["model"], R["n"], R["k"])

    norm_ok  = R["normality"]["pass"]
    lin_ok   = all(v["passed"] for v in R["linearity"].values())
    mc_ok    = bool((R["multicollinearity"]["VIF"] < 10).all())
    het_ok   = R["heteroscedasticity"]["passed"]
    auto_ok  = R["autocorrelation"]["passed"]
    R["all_assumptions_met"] = all([norm_ok, lin_ok, mc_ok, het_ok, auto_ok])
    return R
