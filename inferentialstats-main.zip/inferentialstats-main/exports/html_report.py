"""
exports/html_report.py
======================
Generates a fully self-contained offline HTML report for any t-test analysis.

The report embeds:
  - All statistical tables (normality, descriptives, parametric, non-parametric)
  - Assumption summary
  - Non-parametric effect size (rank-biserial r + bootstrap CI)
  - Statistical power assessment
  - APA 7th edition write-up
  - Diagnostic plots embedded as base64 PNG
  - QRIS support image in cover header

The output is a single .html file that works offline with no internet
connection required (all assets embedded).

Usage:
    from exports.html_report import build_html_report
    html_bytes = build_html_report(test_type, R, meta, interps, fig_bytes_list)
    # html_bytes is ready for st.download_button()
"""

import base64
import numpy as np
from datetime import datetime

from utils.formatters import _f, _p, format_u, effect_label_d
from modules.normality  import recommendation_note_plain, KS_DISCLAIMER
from modules.power      import compute_power, power_table_rows


# ══════════════════════════════════════════════════════════════════════════════
# HTML CSS
# ══════════════════════════════════════════════════════════════════════════════

_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);
  border-radius:16px;padding:44px 52px;margin-bottom:28px;
  border-left:6px solid #e94560;box-shadow:0 12px 48px rgba(233,69,96,.2);}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;letter-spacing:-.5px;}
.cover .sub{color:#94a3b8;font-size:.9rem;margin-bottom:24px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;
  padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.decision-box{padding:12px 20px;border-radius:10px;margin:20px 0;font-size:.9rem;font-weight:600;}
.use-param{background:#dcfce7;color:#14532d;border:1px solid #86efac;}
.use-nonparam{background:#ffedd5;color:#7c2d12;border:1px solid #fdba74;}
.section{background:#fff;border-radius:12px;padding:26px 30px;
  margin-bottom:22px;box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;
  padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;
  letter-spacing:.8px;margin:-26px -30px 22px;font-family:'DM Mono',monospace;
  border-bottom:3px solid #e94560;display:flex;align-items:center;gap:12px;}
.sec-num{background:#e94560;color:#fff;font-size:.72rem;padding:2px 8px;
  border-radius:12px;font-weight:700;flex-shrink:0;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;
  font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);
  border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;
  font-size:.82rem;color:#0c4a6e;margin:12px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;
  font-size:.73rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:8px 10px;text-align:center;
  font-weight:600;border:1px solid #334155;white-space:normal;font-size:.71rem;
  word-wrap:break-word;}
.rtbl td{padding:6px 10px;border:1px solid #e2e8f0;text-align:right;
  white-space:normal;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;
  font-size:.86rem;line-height:1.8;border-left:4px solid #0284c7;
  background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp b{color:#0284c7;}
.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}
.interp.sig b{color:#16a34a;}
.interp.nonsig{border-left-color:#dc2626;background:linear-gradient(135deg,#fef2f2,#fee2e2);}
.interp.nonsig b{color:#dc2626;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
  padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;
  color:#1e293b;line-height:1.8;margin-top:14px;}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;
  text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;}
.fig-wrap{text-align:center;margin:18px 0;}
.fig-cap{font-size:.75rem;color:#64748b;font-style:italic;margin-top:10px;line-height:1.6;}
.warn-box{background:#fffbeb;border-left:4px solid #f59e0b;padding:.7rem 1rem;
  border-radius:0 6px 6px 0;font-size:.82rem;color:#92400e;margin:.4rem 0;}
.info-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:.7rem 1rem;
  border-radius:0 6px 6px 0;font-size:.82rem;color:#1e40af;margin:.4rem 0;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;
  padding-top:16px;border-top:1px solid #e2e8f0;line-height:1.8;}
@media print{body{background:#fff;}.page{padding:0 16px;}.cover{border-radius:0;}}
</style>"""


# ══════════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _rtbl(rows, left_cols=None):
    """Build an HTML table from rows list."""
    if left_cols is None:
        left_cols = {0}
    h = '<table class="rtbl"><thead><tr>'
    for c in rows[0]:
        h += f"<th>{c}</th>"
    h += "</tr></thead><tbody>"
    for i, row in enumerate(rows[1:]):
        h += f'<tr class="{"even" if i % 2 == 0 else "odd"}">'
        for j, cell in enumerate(row):
            cls = ' class="left"' if j in left_cols else ""
            h += f"<td{cls}>{cell}</td>"
        h += "</tr>"
    h += "</tbody></table>"
    return h


def _sh(title, number):
    return (f'<div class="sec-hdr">'
            f'<span class="sec-num">{number}</span>{title}</div>')


def _sub(title):
    return f'<div class="sub-hdr">{title}</div>'


def _rec(text):
    return f'<div class="rec-box">{text}</div>'


def _df_to_rows(df):
    rows = [list(df.columns)]
    for _, r in df.iterrows():
        rows.append([str(v) for v in r.values])
    return rows


# ══════════════════════════════════════════════════════════════════════════════
# SECTION BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _normality_section(R, total_n, prim_lbl):
    """Build the Tests of Normality section HTML."""
    sw_rows = [["Variable", "N", "Statistic (W)", "Sig.", "Result"]]
    ks_rows = [["Variable", "N", "Statistic (D)", "Sig.\u1d43", "Result"]]
    for nm in R["normality"]:
        sw_rows.append([nm["label"], str(nm["n"]),
                        _f(nm["sw_W"]), _p(nm["sw_p"]),
                        "\u2713 Normal" if nm["sw_pass"] else "\u2717 Non-Normal"])
        ks_rows.append([nm["label"], str(nm["n"]),
                        _f(nm["ks_D"]), _p(nm["ks_p"]),
                        "\u2713 Normal" if nm["ks_pass"] else "\u2717 Non-Normal"])

    # Assumption summary — SW and KS as separate rows per variable
    assume_rows = [["Assumption", "Test", "Statistic", "Sig.", "Result", "Decision"]]
    for nm in R["normality"]:
        is_sw_pri = nm["primary_label"] == "Shapiro-Wilk"
        is_ks_pri = nm["primary_label"] == "Kolmogorov-Smirnov"
        assume_rows.append([
            f"Normality \u2014 {nm['label']}",
            f"Shapiro-Wilk{' \u2605' if is_sw_pri else ''}",
            f"W\u2009=\u2009{_f(nm['sw_W'])}", _p(nm["sw_p"]),
            "\u2713 Normal" if nm["sw_pass"] else "\u2717 Non-Normal",
            "Primary criterion" if is_sw_pri else "Supplementary"
        ])
        assume_rows.append([
            "",
            f"KS Lilliefors{' \u2605' if is_ks_pri else ''}",
            f"D\u2009=\u2009{_f(nm['ks_D'])}", _p(nm["ks_p"]),
            "\u2713 Normal" if nm["ks_pass"] else "\u2717 Non-Normal",
            "Primary criterion" if is_ks_pri else "Supplementary"
        ])
    if "levene" in R:
        lv = R["levene"]
        assume_rows.append([
            "Homogeneity of Variance", "Levene\u2019s Test",
            f"F({lv['df1']},\u2009{lv['df2']})\u2009=\u2009{_f(lv['F'])}",
            _p(lv["Sig."]),
            "\u2713 Satisfied" if lv["equal_var"] else "\u2717 Violated",
            "Equal variances assumed" if lv["equal_var"]
            else "Welch correction applied"
        ])
    use_p = R["use_param"]
    assume_rows.append([
        "Overall Decision", f"Primary: {prim_lbl}",
        f"Total N\u2009=\u2009{total_n}", "\u2014",
        "Parametric" if use_p else "Non-parametric",
        "T-Test applied" if use_p else "Wilcoxon / Mann-Whitney U"
    ])

    norm_rec = recommendation_note_plain(total_n)

    return (
        _sub("a) Shapiro-Wilk Test")
        + _rtbl(sw_rows)
        + _sub("b) Kolmogorov-Smirnov Test (Lilliefors Significance Correction)")
        + _rtbl(ks_rows)
        + f'<p class="tbl-note">\u1d43 Lilliefors significance correction applied.</p>'
        + f'<div class="warn-box" style="margin:10px 0;font-size:.79rem;">{KS_DISCLAIMER}</div>'
        + _rec(norm_rec)
        + _sub("Assumption Summary")
        + _rtbl(assume_rows, left_cols={0, 1, 2, 5})
        + f'<p class="tbl-note">\u2605 Primary criterion for normality decision. '
          f'References: Razali &amp; Wah (2011); Field (2018).</p>'
    )


def _parametric_section(test_type, R):
    """Build the Parametric Test Results section HTML."""
    pr = R["parametric"]
    if test_type == "One-Sample T-Test":
        return _rtbl([
            ["", "t", "df", "Sig. (2-tailed)", "Sig. (1-tailed Lower)",
             "Sig. (1-tailed Upper)", "Mean Difference",
             "95% CI Lower", "95% CI Upper", "Cohen\u2019s d", "Effect Size"],
            [f"Test Value\u2009=\u2009{pr['mu0']}",
             _f(pr["t"]), str(pr["df"]), _p(pr["p_two"]),
             _p(pr["p_one_lower"]), _p(pr["p_one_upper"]),
             _f(pr["mean_diff"]), _f(pr["ci_lower"]), _f(pr["ci_upper"]),
             _f(pr["cohens_d"]), effect_label_d(pr["cohens_d"])]
        ])

    elif test_type == "Paired-Sample T-Test":
        html  = _sub("Paired Samples Test") + _rtbl([
            ["Pair", "Mean Diff", "SD", "SE",
             "95% CI Lower", "95% CI Upper", "t", "df",
             "Sig. (2-tailed)", "Sig. (1-tailed L)",
             "Sig. (1-tailed U)", "Cohen\u2019s d"],
            [f"{pr['label1']} \u2013 {pr['label2']}",
             _f(pr["mean_diff"]), _f(pr["sd_diff"]), _f(pr["se_diff"]),
             _f(pr["ci_lower"]), _f(pr["ci_upper"]),
             _f(pr["t"]), str(pr["df"]),
             _p(pr["p_two"]), _p(pr["p_one_lower"]), _p(pr["p_one_upper"]),
             _f(pr["cohens_d"])]
        ])
        return html

    else:  # Independent
        lev   = R["levene"]
        html  = _sub("a) t-Statistics and Significance") + _rtbl([
            ["", "F (Levene)", "Sig.", "t", "df",
             "Sig. (2-tailed)", "Sig. (1-tailed L)", "Sig. (1-tailed U)"],
            ["Equal variances assumed",
             _f(lev["F"]), _p(lev["Sig."]),
             _f(pr["t_eq"]), str(pr["df_eq"]), _p(pr["p_eq"]),
             _p(pr["p_eq_lower"]), _p(pr["p_eq_upper"])],
            ["Equal variances not assumed", "", "",
             _f(pr["t_welch"]), _f(pr["df_welch"], 2), _p(pr["p_welch"]),
             _p(pr["p_welch_lower"]), _p(pr["p_welch_upper"])]
        ])
        html += _sub("b) Mean Difference, Confidence Interval, and Effect Size") + _rtbl([
            ["", "Mean Difference", "SE Difference",
             "95% CI Lower", "95% CI Upper", "Cohen\u2019s d"],
            ["Equal variances assumed",
             _f(pr["mean_diff"]), _f(pr["se_eq"]),
             _f(pr["ci_eq_l"]), _f(pr["ci_eq_u"]), _f(pr["cohens_d"])],
            ["Equal variances not assumed",
             _f(pr["mean_diff"]), _f(pr["se_welch"]),
             _f(pr["ci_welch_l"]), _f(pr["ci_welch_u"]), "\u2014"]
        ])
        active = ("Row 1 (equal variances assumed)"
                  if lev["equal_var"] else "Row 2 (Welch correction)")
        html += (f'<p class="tbl-note">Based on Levene\u2019s test '
                 f'p\u2009=\u2009{_p(lev["Sig."])}: use {active}.</p>')
        return html


def _nonparametric_section(test_type, R):
    """Build Non-Parametric Test Results + Effect Size section HTML."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]

    if test_type == "Independent-Sample T-Test":
        html  = _sub("Ranks") + _rtbl([
            ["Group", "N", "Mean Rank", "Sum of Ranks"],
            [np_r["label1"], str(np_r["n1"]),
             _f(np_r["mean_rank1"]), _f(np_r["R1"], 3)],
            [np_r["label2"], str(np_r["n2"]),
             _f(np_r["mean_rank2"]), _f(np_r["R2"], 3)],
            ["Total", str(np_r["n1"] + np_r["n2"]), "", ""]
        ])
        html += _sub("Test Statistics") + _rtbl([
            ["Statistic", "Value"],
            ["Mann-Whitney U",         format_u(np_r["U"])],
            ["Wilcoxon W",             _f(np_r["W_wilcoxon"], 3)],
            ["Z",                      _f(np_r["Z"])],
            ["Asymp. Sig. (2-tailed)", _p(np_r["p"])],
        ])
        html += (f'<p class="tbl-note">Grouping: '
                 f'{np_r["label1"]} vs.\u2009{np_r["label2"]}. '
                 f'Z based on normal approximation with ties correction (SPSS method).</p>')
    else:
        n_neg  = np_r.get("n_neg", 0)
        n_pos  = np_r.get("n_pos", 0)
        n_ties = np_r.get("n_ties", 0)
        n_tot  = np_r.get("n_total", n_neg + n_pos + n_ties)
        neg_rs = np_r.get("neg_rank_sum", np.nan)
        pos_rs = np_r.get("pos_rank_sum", np.nan)
        neg_mr = neg_rs / n_neg if n_neg > 0 else np.nan
        pos_mr = pos_rs / n_pos if n_pos > 0 else np.nan
        fn     = (test_type == "Paired-Sample T-Test")
        pair_lbl = (f"{pr['label1']} \u2212 {pr['label2']}"
                    if fn else "Variable \u2212 \u03bc\u2080")

        html  = _sub("Ranks") + _rtbl([
            ["", "N", "Mean Rank", "Sum of Ranks"],
            [("Negative Ranks \u1d43" if fn else "Negative Ranks"),
             str(n_neg), _f(neg_mr), _f(neg_rs, 3)],
            [("Positive Ranks \u1d47" if fn else "Positive Ranks"),
             str(n_pos), _f(pos_mr), _f(pos_rs, 3)],
            [("Ties \u1d9c" if fn else "Ties"), str(n_ties), "", ""],
            ["Total", str(n_tot), "", ""]
        ])
        if fn:
            html += (f'<p class="tbl-note">'
                     f'\u1d43 {pr["label2"]} &lt; {pr["label1"]} &nbsp;'
                     f'\u1d47 {pr["label2"]} &gt; {pr["label1"]} &nbsp;'
                     f'\u1d9c {pr["label2"]} = {pr["label1"]}</p>')
        html += _sub("Test Statistics") + _rtbl([
            ["Statistic", pair_lbl],
            ["Test Statistic (W)", _f(np_r["W"], 0)],
            ["Z",                  _f(np_r["Z"])],
            ["Asymp. Sig. (2-tailed)", _p(np_r["p"])],
        ])
        html += (f'<p class="tbl-note">Based on '
                 f'{"negative" if n_neg < n_pos else "positive"} ranks. '
                 f'Z uses ties-corrected variance (SPSS method).</p>')

    # Effect size
    r_rb   = np_r.get("rank_biserial_r", np.nan)
    ci_lo  = np_r.get("rb_ci_lower", np.nan)
    ci_hi  = np_r.get("rb_ci_upper", np.nan)
    r_lab  = np_r.get("rb_label", "N/A")
    ci_str = (f"[{_f(ci_lo)}, {_f(ci_hi)}]"
              if not (np.isnan(ci_lo) or np.isnan(ci_hi)) else ".")

    if test_type == "Independent-Sample T-Test":
        es_lbl    = "Mann-Whitney U"
        pair_desc = f"{np_r['label1']} vs. {np_r['label2']}"
    elif test_type == "Paired-Sample T-Test":
        es_lbl    = "Wilcoxon Signed-Rank"
        pair_desc = f"{pr['label1']} \u2212 {pr['label2']}"
    else:
        es_lbl    = "Wilcoxon Signed-Rank"
        pair_desc = f"Variable \u2212 \u03bc\u2080"

    html += (
        _sub("Non-Parametric Effect Size \u2014 Rank-Biserial Correlation (r)")
        + _rtbl([
            ["Test", "Comparison", "Rank-Biserial r",
             "95% Bootstrap CI", "Effect Size"],
            [es_lbl, pair_desc,
             _f(r_rb) if not np.isnan(r_rb) else ".",
             ci_str, r_lab]
        ], left_cols={0, 1})
        + f'<p class="tbl-note">'
          f'Rank-biserial r \u2208 [\u22121,\u20091]: '
          f'|r|\u2009&lt;\u2009.10 negligible, .10\u2013.29 small, '
          f'.30\u2013.49 medium, \u2265\u2009.50 large. '
          f'Non-parametric effect size not reported by SPSS by default. '
          f'Bootstrap 95% CI based on 2,000 resamples '
          f'(Efron &amp; Tibshirani, 1993; Kerby, 2014).</p>'
    )
    return html


def _power_section(R, test_type, alpha):
    """Build Statistical Power Assessment section HTML."""
    try:
        pw      = compute_power(R, test_type, alpha)
        rows    = power_table_rows(pw)
        pwr_val = pw.get("power", np.nan)

        html = _rtbl(rows, left_cols={0})

        # Colour-coded progress bar
        if not np.isnan(pwr_val):
            bar_c   = ("#16a34a" if pwr_val >= .80
                       else "#f59e0b" if pwr_val >= .60 else "#dc2626")
            bar_pct = int(pwr_val * 100)
            html += (f'<div style="background:#e2e8f0;border-radius:8px;'
                     f'height:16px;width:100%;margin:10px 0;">'
                     f'<div style="background:{bar_c};width:{bar_pct}%;'
                     f'height:16px;border-radius:8px;"></div></div>')

        if not np.isnan(pwr_val) and pwr_val < .80:
            html += ('<div class="warn-box" style="margin-top:10px;">'
                     'Achieved power is below the conventional threshold of .80, '
                     'indicating an elevated risk of Type II error. '
                     'Consider increasing the sample size.</div>')
        elif not np.isnan(pwr_val):
            html += ('<div class="info-box" style="margin-top:10px;">'
                     'Achieved power meets or exceeds the conventional '
                     'threshold of .80.</div>')

        html += ('<p class="tbl-note">Post-hoc power analysis using the '
                 'non-central t-distribution (parametric) or normal '
                 'approximation (non-parametric). '
                 'Reference: Cohen (1988).</p>')
        return html

    except Exception:
        return '<p class="tbl-note">Power analysis not available.</p>'


def _interpretation_section(interps, apa):
    """Build Interpretation + APA write-up section HTML."""
    html = ""
    for line in interps:
        lw  = line.lower()
        cls = ("sig"
               if "statistically significant" in lw and "no statistically" not in lw
               else "nonsig"
               if "no statistically significant" in lw or "did not significantly" in lw
               else "")
        html += f'<div class="interp {cls}">{line}</div>'
    html += (f'<div style="margin-top:20px;">'
             f'<div class="apa-label">APA 7th Edition Write-Up</div>'
             f'<div class="apa-box">{apa}</div>'
             f'</div>')
    return html


def _figures_section(fig_bytes_list, test_type):
    """Embed diagnostic plots as base64 PNG."""
    html = ""
    for i, fb in enumerate(fig_bytes_list, 1):
        b64 = base64.b64encode(fb).decode("utf-8")
        html += (
            f'<div class="fig-wrap">'
            f'<img src="data:image/png;base64,{b64}" '
            f'alt="Diagnostic plots for {test_type}" '
            f'style="width:100%;max-width:960px;border-radius:10px;'
            f'box-shadow:0 4px 20px rgba(0,0,0,.12);"/>'
            f'<p class="fig-cap">Figure {i}. Diagnostic plots for {test_type}. '
            f'From left to right: distribution with fitted normal curve, '
            f'comparison panel, and Normal Q-Q plot.</p>'
            f'</div>'
        )
    return html


# ══════════════════════════════════════════════════════════════════════════════
# MAIN BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_html_report(test_type, R, meta, interps, fig_bytes_list):
    """
    Generate a fully self-contained offline HTML report.

    Parameters
    ----------
    test_type      : str  — e.g. 'Independent-Sample T-Test'
    R              : dict — output of run_*() from modules/t_tests.py
    meta           : dict — analysis metadata (test, variables, N, α, date)
    interps        : list of str — interpretation lines (HTML)
    fig_bytes_list : list of bytes — PNG plot bytes from utils/plots.py

    Returns
    -------
    bytes — complete HTML encoded as UTF-8, ready for download
    """
    alpha    = meta.get("\u03b1", 0.05)
    use_p    = R["use_param"]
    prim_n   = R["normality"][0]["n"]
    prim_lbl = R["normality"][0]["primary_label"]
    total_n  = R.get("total_n", prim_n)

    # ── APA write-up ──────────────────────────────────────────────────────────
    apa = _build_apa(test_type, R, meta, alpha)

    # ── Meta table ─────────────────────────────────────────────────────────────
    meta_html = "<table class='meta-tbl'>"
    for k, v in meta.items():
        meta_html += f"<tr><td class='mk'>{k}</td><td class='mv'>{v}</td></tr>"
    meta_html += "</table>"

    # ── Decision box ───────────────────────────────────────────────────────────
    size_lbl = "Total N\u2009<\u200950" if total_n < 50 else "Total N\u2009\u2265\u200950"
    dcls     = "use-param" if use_p else "use-nonparam"
    dtxt     = (f"Primary normality criterion: <b>{prim_lbl}</b> "
                f"(Total N\u2009=\u2009{total_n}, {size_lbl}) "
                f"\u2192 p\u2009{'>\u2009.05' if use_p else '\u2264\u2009.05'} "
                f"\u2192 <b>{'Parametric' if use_p else 'Non-parametric'} "
                f"analysis applied</b>")

    # ── Optional sections ──────────────────────────────────────────────────────
    sn = 3
    corr_sec = lev_sec = ""

    if "correlation" in R:
        c3 = R["correlation"].copy()
        c3["Pearson Correlation"] = c3["Pearson Correlation"].apply(_f)
        c3["Sig. (2-tailed)"]     = c3["Sig. (2-tailed)"].apply(_p)
        corr_sec = (f'<div class="section">'
                    f'{_sh("PAIRED SAMPLES CORRELATIONS", sn)}'
                    f'{_rtbl(_df_to_rows(c3))}</div>')
        sn += 1

    if "levene" in R:
        lv  = R["levene"]
        res = ("\u2713 Equal variances assumed"
               if lv["equal_var"] else
               "\u2717 Equal variances not assumed (Welch)")
        lev_sec = (
            f'<div class="section">'
            f'{_sh("LEVENE\u2019S TEST FOR EQUALITY OF VARIANCES", sn)}'
            f'{_rtbl([["F","df1","df2","Sig.","Result"],[_f(lv["F"]),str(lv["df1"]),str(lv["df2"]),_p(lv["Sig."]),res]])}'
            f'<p class="tbl-note">Based on mean (SPSS default). '
            f'p\u2009&gt;\u2009.05 \u2192 equal variances assumed.</p></div>'
        )
        sn += 1

    ps = sn; sn += 1
    ns = sn; sn += 1
    ins = sn; sn += 1
    pw_n = sn; sn += 1
    fg_n = sn

    # ── Descriptives ───────────────────────────────────────────────────────────
    dd = R["desc"].copy()
    for c in dd.select_dtypes(include=float).columns:
        dd[c] = dd[c].apply(_f)

    # ── Assemble ───────────────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Inferential Statistics Report \u2014 {test_type}</title>
{_CSS}
</head>
<body>
<div class="page">

<div class="cover">
  <h1>&#128208; Inferential Statistics Report</h1>
  <div class="sub">
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Shapiro-Wilk + KS Lilliefors</span>
    <span class="badge">Parametric &amp; Non-Parametric</span>
  </div>
  {meta_html}
  <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12);
              display:flex;align-items:center;gap:16px;">
    <div>
      <p style="color:#94a3b8;font-size:.76rem;margin:0 0 8px;">
        &#9749; Support this work &mdash; scan QRIS</p>
      <img src="https://muhaiminabdullah.com/media/thumbnails/QRIS-muhaiminabdullahdotcom-340x480.jpeg"
           alt="QRIS Support"
           style="width:130px;border-radius:8px;border:2px solid #e94560;display:block;"/>
    </div>
  </div>
</div>

<div class="section">
  {_sh("ANALYSIS DECISION", "&#9654;")}
  <div class="decision-box {dcls}">{dtxt}</div>
</div>

<div class="section">
  {_sh("TESTS OF NORMALITY", 1)}
  {_normality_section(R, total_n, prim_lbl)}
</div>

<div class="section">
  {_sh("DESCRIPTIVE STATISTICS", 2)}
  {_rtbl(_df_to_rows(dd))}
</div>

{corr_sec}
{lev_sec}

<div class="section">
  {_sh("PARAMETRIC TEST RESULTS", ps)}
  {_parametric_section(test_type, R)}
</div>

<div class="section">
  {_sh("NON-PARAMETRIC TEST RESULTS", ns)}
  {_nonparametric_section(test_type, R)}
</div>

<div class="section">
  {_sh("INTERPRETATION", ins)}
  {_interpretation_section(interps, apa)}
</div>

<div class="section">
  {_sh("STATISTICAL POWER ASSESSMENT", pw_n)}
  {_power_section(R, test_type, alpha)}
</div>

<div class="section">
  {_sh("FIGURES &amp; DIAGNOSTIC PLOTS", fg_n)}
  {_figures_section(fig_bytes_list, test_type)}
</div>

<div class="footer">
  Generated by Inferential Statistics by MA &nbsp;&middot;&nbsp;
  SPSS-equivalent output &nbsp;&middot;&nbsp;
  KS Lilliefors: table method (n\u2009&lt;\u200950), approx method (n\u2009\u2265\u200950)
  &nbsp;&middot;&nbsp;
  Levene center\u2009=\u2009mean &nbsp;&middot;&nbsp;
  Wilcoxon Z ties-corrected &nbsp;&middot;&nbsp;
  Mann-Whitney U SPSS-exact &nbsp;&middot;&nbsp;
  n\u2009&lt;\u200950: SW recommended &nbsp;&middot;&nbsp;
  n\u2009\u2265\u200950: KS recommended<br/>
  Generated: {datetime.now().strftime("%B %d, %Y at %H:%M")}
</div>

</div>
</body>
</html>"""

    return html.encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# APA WRITE-UP BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def _build_apa(test_type, R, meta, alpha):
    """Generate APA 7th edition write-up string."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]
    use_p = R["use_param"]

    if use_p:
        if test_type == "One-Sample T-Test":
            m_v  = float(R["desc"]["Mean"].iloc[0])
            sd_v = float(R["desc"]["Std. Deviation"].iloc[0])
            sig  = pr["p_two"] < alpha
            return (
                f"A one-sample t-test was conducted to examine whether "
                f"{meta.get('Variable', 'the variable')} "
                f"(M\u2009=\u2009{_f(m_v)}, SD\u2009=\u2009{_f(sd_v)}) "
                f"significantly differed from the hypothesised population mean "
                f"(\u03bc\u2080\u2009=\u2009{pr['mu0']}). The result was "
                f"{'statistically significant' if sig else 'not statistically significant'}, "
                f"t({pr['df']})\u2009=\u2009{pr['t']:.2f}, "
                f"p\u2009{'< .001' if pr['p_two'] < .001 else '= ' + _p(pr['p_two'])}, "
                f"d\u2009=\u2009{pr['cohens_d']:.2f}."
            )

        elif test_type == "Paired-Sample T-Test":
            sig = pr["p_two"] < alpha
            return (
                f"A paired-samples t-test was conducted to compare "
                f"{pr['label1']} "
                f"(M\u2009=\u2009{_f(float(R['desc'].iloc[0]['Mean']))}, "
                f"SD\u2009=\u2009{_f(float(R['desc'].iloc[0]['Std. Deviation']))}) "
                f"and {pr['label2']} "
                f"(M\u2009=\u2009{_f(float(R['desc'].iloc[1]['Mean']))}, "
                f"SD\u2009=\u2009{_f(float(R['desc'].iloc[1]['Std. Deviation']))}). "
                f"The difference was "
                f"{'statistically significant' if sig else 'not statistically significant'}, "
                f"t({pr['df']})\u2009=\u2009{pr['t']:.2f}, "
                f"p\u2009{'< .001' if pr['p_two'] < .001 else '= ' + _p(pr['p_two'])}, "
                f"d\u2009=\u2009{pr['cohens_d']:.2f}."
            )

        else:  # Independent
            eq  = R["levene"]["equal_var"]
            tv  = pr["t_eq"]  if eq else pr["t_welch"]
            pv  = pr["p_eq"]  if eq else pr["p_welch"]
            dv  = pr["df_eq"] if eq else pr["df_welch"]
            sig = pv < alpha
            return (
                f"An independent-samples t-test was conducted to compare "
                f"{pr['dep_var']} between {pr['label1']} "
                f"(M\u2009=\u2009{_f(float(R['desc'].iloc[0]['Mean']))}, "
                f"SD\u2009=\u2009{_f(float(R['desc'].iloc[0]['Std. Deviation']))}) "
                f"and {pr['label2']} "
                f"(M\u2009=\u2009{_f(float(R['desc'].iloc[1]['Mean']))}, "
                f"SD\u2009=\u2009{_f(float(R['desc'].iloc[1]['Std. Deviation']))}). "
                f"The difference was "
                f"{'statistically significant' if sig else 'not statistically significant'}, "
                f"t({_f(dv, 2)})\u2009=\u2009{tv:.2f}, "
                f"p\u2009{'< .001' if pv < .001 else '= ' + _p(pv)}, "
                f"d\u2009=\u2009{pr['cohens_d']:.2f}."
            )

    else:
        if test_type == "Independent-Sample T-Test":
            sig = np_r["p"] < alpha if not np.isnan(np_r["p"]) else False
            return (
                f"A Mann-Whitney U test was conducted to compare "
                f"{np_r['dep_var']} between {np_r['label1']} "
                f"and {np_r['label2']}. The result indicated "
                f"{'a statistically significant' if sig else 'no statistically significant'} "
                f"difference, U\u2009=\u2009{format_u(np_r['U'])}, "
                f"W\u2009=\u2009{_f(np_r['W_wilcoxon'], 3)}, "
                f"Z\u2009=\u2009{np_r['Z']:.3f}, "
                f"p\u2009{'< .001' if np_r['p'] < .001 else '= ' + _p(np_r['p'])} "
                f"(asymptotic, 2-tailed)."
            )
        else:
            sig = np_r["p"] < alpha if not np.isnan(np_r["p"]) else False
            return (
                f"A Wilcoxon signed-rank test was conducted. "
                f"The result indicated "
                f"{'a statistically significant' if sig else 'no statistically significant'} "
                f"difference, W\u2009=\u2009{np_r['W']:.0f}, "
                f"Z\u2009=\u2009{np_r['Z']:.3f}, "
                f"p\u2009{'< .001' if np_r['p'] < .001 else '= ' + _p(np_r['p'])} "
                f"(2-tailed, asymptotic)."
            )
