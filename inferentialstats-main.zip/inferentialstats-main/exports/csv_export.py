"""
exports/csv_export.py
=====================
CSV export for all statistical analysis results.

Generates a single multi-section CSV file containing:
  - Analysis metadata
  - Descriptive statistics
  - Normality test results (SW + KS) with recommendation note
  - Paired correlation (if applicable)
  - Levene's test (if applicable)
  - Parametric test results
  - Non-parametric test results
  - Effect sizes (Cohen's d + rank-biserial r + bootstrap CI)
  - Power analysis
  - Interpretation lines
  - APA 7th edition write-up

Sections are separated by blank lines with section headers.
The format is universally readable in Excel, SPSS, R, Python, and Google Sheets.

Usage:
    from exports.csv_export import build_csv
    csv_bytes = build_csv(test_type, R, meta, interps, alpha)
    # csv_bytes is ready for st.download_button()
"""

import io
import numpy as np
import pandas as pd
from datetime import datetime

from utils.formatters import _f, _p, format_u, effect_label_d, effect_label_r
from modules.normality import recommendation_note_plain, KS_DISCLAIMER
from modules.power     import compute_power, power_table_rows


# ══════════════════════════════════════════════════════════════════════════════
# INTERNAL HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _section(title):
    """Return a section header line for the CSV."""
    return f"\n=== {title.upper()} ===\n"


def _df_csv(df):
    """Convert a DataFrame to CSV string."""
    return df.to_csv(index=False)


def _rows_to_df(rows):
    """Convert a list of rows (header + data) to a DataFrame."""
    if len(rows) < 2:
        return pd.DataFrame()
    return pd.DataFrame(rows[1:], columns=rows[0])


def _strip_html(text):
    """Remove basic HTML tags from a string."""
    import re
    return re.sub(r"<[^>]+>", "", str(text)).strip()


# ══════════════════════════════════════════════════════════════════════════════
# SECTION BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def _meta_section(meta):
    """Build metadata section."""
    rows = [{"Parameter": k, "Value": str(v)} for k, v in meta.items()]
    rows.append({"Parameter": "Generated",
                 "Value": datetime.now().strftime("%B %d, %Y %H:%M")})
    return _section("Analysis Information") + pd.DataFrame(rows).to_csv(index=False)


def _normality_section(R, total_n):
    """Build normality tests section with recommendation note."""
    rows = []
    for nm in R["normality"]:
        rows.append({
            "Variable":              nm["label"],
            "N (group)":             nm["n"],
            "Total N (analysis)":    total_n,
            "SW Statistic (W)":      round(nm["sw_W"], 3) if not np.isnan(nm["sw_W"]) else "",
            "SW Sig.":               _p(nm["sw_p"]),
            "SW Result":             "Normal" if nm["sw_pass"] else "Non-Normal",
            "KS Statistic (D)":      round(nm["ks_D"], 3) if not np.isnan(nm["ks_D"]) else "",
            "KS Sig.":               _p(nm["ks_p"]),
            "KS Result":             "Normal" if nm["ks_pass"] else "Non-Normal",
            "Primary Criterion":     nm["primary_label"],
            "Normality Decision":    "Normal" if nm["pass"] else "Non-Normal",
        })
    df = pd.DataFrame(rows)

    note_rows = [
        {"Note": "KS Disclaimer", "Text": KS_DISCLAIMER},
        {"Note": "Recommendation", "Text": recommendation_note_plain(total_n)},
    ]

    return (
        _section("Tests of Normality")
        + df.to_csv(index=False)
        + "\n"
        + pd.DataFrame(note_rows).to_csv(index=False)
    )


def _assumption_section(R, use_p, prim_lbl, total_n):
    """Build assumption summary section."""
    rows = []
    for nm in R["normality"]:
        is_sw_pri = nm["primary_label"] == "Shapiro-Wilk"
        is_ks_pri = nm["primary_label"] == "Kolmogorov-Smirnov"
        rows.append({
            "Assumption":  f"Normality - {nm['label']}",
            "Test":        "Shapiro-Wilk",
            "Statistic":   f"W = {_f(nm['sw_W'])}",
            "Sig.":        _p(nm["sw_p"]),
            "Result":      "Normal" if nm["sw_pass"] else "Non-Normal",
            "Role":        "Primary criterion" if is_sw_pri else "Supplementary",
            "Decision":    "Parametric eligible" if nm["pass"] else "Non-parametric required",
        })
        rows.append({
            "Assumption":  "",
            "Test":        "KS Lilliefors",
            "Statistic":   f"D = {_f(nm['ks_D'])}",
            "Sig.":        _p(nm["ks_p"]),
            "Result":      "Normal" if nm["ks_pass"] else "Non-Normal",
            "Role":        "Primary criterion" if is_ks_pri else "Supplementary",
            "Decision":    "Parametric eligible" if nm["pass"] else "Non-parametric required",
        })

    if "levene" in R:
        lv = R["levene"]
        rows.append({
            "Assumption":  "Homogeneity of Variance",
            "Test":        "Levene's Test (center = mean)",
            "Statistic":   f"F({lv['df1']}, {lv['df2']}) = {_f(lv['F'])}",
            "Sig.":        _p(lv["Sig."]),
            "Result":      "Satisfied" if lv["equal_var"] else "Violated",
            "Role":        "Required",
            "Decision":    ("Equal variances assumed"
                            if lv["equal_var"] else "Welch correction applied"),
        })

    rows.append({
        "Assumption":  "Overall Decision",
        "Test":        f"Primary: {prim_lbl}",
        "Statistic":   f"Total N = {total_n}",
        "Sig.":        "-",
        "Result":      "Parametric" if use_p else "Non-parametric",
        "Role":        "Decision",
        "Decision":    "T-Test applied" if use_p else "Wilcoxon / Mann-Whitney U",
    })

    return _section("Assumption Summary") + pd.DataFrame(rows).to_csv(index=False)


def _descriptives_section(R):
    """Build descriptive statistics section."""
    dd = R["desc"].copy()
    for c in dd.select_dtypes(include=[float, np.float64]).columns:
        dd[c] = dd[c].apply(lambda v: round(v, 3) if not np.isnan(v) else "")
    return _section("Descriptive Statistics") + dd.to_csv(index=False)


def _correlation_section(R):
    """Build paired correlation section (if applicable)."""
    if "correlation" not in R:
        return ""
    co = R["correlation"].copy()
    co["Pearson Correlation"] = co["Pearson Correlation"].apply(lambda v: round(v, 3))
    co["Sig. (2-tailed)"]     = co["Sig. (2-tailed)"].apply(_p)
    return _section("Paired Samples Correlations") + co.to_csv(index=False)


def _levene_section(R):
    """Build Levene's test section (if applicable)."""
    if "levene" not in R:
        return ""
    lv = R["levene"]
    df = pd.DataFrame([{
        "F":         round(lv["F"], 3),
        "df1":       lv["df1"],
        "df2":       lv["df2"],
        "Sig.":      _p(lv["Sig."]),
        "Equal Variances Assumed": lv["equal_var"],
        "Result":    "Equal variances assumed" if lv["equal_var"]
                     else "Equal variances not assumed (Welch)",
        "Note":      "Based on mean (SPSS default).",
    }])
    return _section("Levene's Test for Equality of Variances") + df.to_csv(index=False)


def _parametric_section(test_type, R):
    """Build parametric test results section."""
    pr = R["parametric"]

    if test_type == "One-Sample T-Test":
        df = pd.DataFrame([{
            "Test":                  pr["test"],
            "Variable":              pr.get("var_name", ""),
            "Test Value (mu0)":      pr["mu0"],
            "t":                     round(pr["t"], 3),
            "df":                    pr["df"],
            "Sig. (2-tailed)":       _p(pr["p_two"]),
            "Sig. (1-tailed Lower)": _p(pr["p_one_lower"]),
            "Sig. (1-tailed Upper)": _p(pr["p_one_upper"]),
            "Mean Difference":       round(pr["mean_diff"], 3),
            "95% CI Lower":          round(pr["ci_lower"], 3),
            "95% CI Upper":          round(pr["ci_upper"], 3),
            "Cohen's d":             round(pr["cohens_d"], 3),
            "Effect Size Label":     effect_label_d(pr["cohens_d"]),
        }])

    elif test_type == "Paired-Sample T-Test":
        df = pd.DataFrame([{
            "Test":                  pr["test"],
            "Pair":                  f"{pr['label1']} - {pr['label2']}",
            "Mean Difference":       round(pr["mean_diff"], 3),
            "SD Difference":         round(pr["sd_diff"], 3),
            "SE Difference":         round(pr["se_diff"], 3),
            "95% CI Lower":          round(pr["ci_lower"], 3),
            "95% CI Upper":          round(pr["ci_upper"], 3),
            "t":                     round(pr["t"], 3),
            "df":                    pr["df"],
            "Sig. (2-tailed)":       _p(pr["p_two"]),
            "Sig. (1-tailed Lower)": _p(pr["p_one_lower"]),
            "Sig. (1-tailed Upper)": _p(pr["p_one_upper"]),
            "Cohen's d":             round(pr["cohens_d"], 3),
            "Effect Size Label":     effect_label_d(pr["cohens_d"]),
        }])

    else:  # Independent
        lev = R["levene"]
        rows = []
        for label, t, df_, p, p_l, p_u, se, ci_l, ci_u in [
            ("Equal variances assumed",
             pr["t_eq"], pr["df_eq"], pr["p_eq"],
             pr["p_eq_lower"], pr["p_eq_upper"],
             pr["se_eq"], pr["ci_eq_l"], pr["ci_eq_u"]),
            ("Equal variances not assumed (Welch)",
             pr["t_welch"], pr["df_welch"], pr["p_welch"],
             pr["p_welch_lower"], pr["p_welch_upper"],
             pr["se_welch"], pr["ci_welch_l"], pr["ci_welch_u"]),
        ]:
            rows.append({
                "Variance Assumption":   label,
                "F (Levene)":            round(lev["F"], 3),
                "Sig. (Levene)":         _p(lev["Sig."]),
                "t":                     round(t, 3),
                "df":                    round(df_, 3),
                "Sig. (2-tailed)":       _p(p),
                "Sig. (1-tailed Lower)": _p(p_l),
                "Sig. (1-tailed Upper)": _p(p_u),
                "Mean Difference":       round(pr["mean_diff"], 3),
                "SE Difference":         round(se, 3),
                "95% CI Lower":          round(ci_l, 3),
                "95% CI Upper":          round(ci_u, 3),
                "Cohen's d":             round(pr["cohens_d"], 3),
                "Effect Size Label":     effect_label_d(pr["cohens_d"]),
            })
        df = pd.DataFrame(rows)

    return _section("Parametric Test Results") + df.to_csv(index=False)


def _nonparametric_section(test_type, R):
    """Build non-parametric test results section."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]

    if test_type == "Independent-Sample T-Test":
        # Ranks
        ranks_df = pd.DataFrame([
            {"Group":          np_r["label1"],
             "N":              np_r["n1"],
             "Mean Rank":      round(np_r["mean_rank1"], 3),
             "Sum of Ranks":   round(np_r["R1"], 3)},
            {"Group":          np_r["label2"],
             "N":              np_r["n2"],
             "Mean Rank":      round(np_r["mean_rank2"], 3),
             "Sum of Ranks":   round(np_r["R2"], 3)},
            {"Group":          "Total",
             "N":              np_r["n1"] + np_r["n2"],
             "Mean Rank":      "",
             "Sum of Ranks":   ""},
        ])
        stats_df = pd.DataFrame([{
            "Mann-Whitney U":          format_u(np_r["U"]),
            "Wilcoxon W":              round(np_r["W_wilcoxon"], 3),
            "Z":                       round(np_r["Z"], 3),
            "Asymp. Sig. (2-tailed)":  _p(np_r["p"]),
        }])
        return (
            _section("Non-Parametric Test Results — Mann-Whitney U Test")
            + "=== Ranks ===\n" + ranks_df.to_csv(index=False)
            + "\n=== Test Statistics ===\n" + stats_df.to_csv(index=False)
        )

    else:
        n_neg  = np_r.get("n_neg", 0)
        n_pos  = np_r.get("n_pos", 0)
        n_ties = np_r.get("n_ties", 0)
        n_tot  = np_r.get("n_total", n_neg + n_pos + n_ties)
        neg_rs = np_r.get("neg_rank_sum", np.nan)
        pos_rs = np_r.get("pos_rank_sum", np.nan)
        neg_mr = neg_rs / n_neg if n_neg > 0 else np.nan
        pos_mr = pos_rs / n_pos if n_pos > 0 else np.nan

        ranks_df = pd.DataFrame([
            {"Rank Type":    "Negative Ranks",
             "N":            n_neg,
             "Mean Rank":    round(neg_mr, 3) if not np.isnan(neg_mr) else "",
             "Sum of Ranks": round(neg_rs, 3) if not np.isnan(neg_rs) else ""},
            {"Rank Type":    "Positive Ranks",
             "N":            n_pos,
             "Mean Rank":    round(pos_mr, 3) if not np.isnan(pos_mr) else "",
             "Sum of Ranks": round(pos_rs, 3) if not np.isnan(pos_rs) else ""},
            {"Rank Type":    "Ties",
             "N":            n_ties,
             "Mean Rank":    "", "Sum of Ranks": ""},
            {"Rank Type":    "Total",
             "N":            n_tot,
             "Mean Rank":    "", "Sum of Ranks": ""},
        ])

        pair_lbl = (f"{pr['label1']} - {pr['label2']}"
                    if test_type == "Paired-Sample T-Test"
                    else "Variable - mu0")
        stats_df = pd.DataFrame([{
            "Pair / Variable":         pair_lbl,
            "Test Statistic (W)":      round(np_r["W"], 0),
            "Z":                       round(np_r["Z"], 3),
            "Asymp. Sig. (2-tailed)":  _p(np_r["p"]),
        }])
        return (
            _section("Non-Parametric Test Results — Wilcoxon Signed-Rank Test")
            + "=== Ranks ===\n" + ranks_df.to_csv(index=False)
            + "\n=== Test Statistics ===\n" + stats_df.to_csv(index=False)
        )


def _effect_size_section(R):
    """Build effect size section (Cohen's d + rank-biserial r)."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]

    r_rb  = np_r.get("rank_biserial_r", np.nan)
    ci_lo = np_r.get("rb_ci_lower", np.nan)
    ci_hi = np_r.get("rb_ci_upper", np.nan)
    r_lbl = np_r.get("rb_label", "N/A")

    df = pd.DataFrame([
        {
            "Effect Size Measure":  "Cohen's d (parametric)",
            "Value":                round(pr.get("cohens_d", float("nan")), 3),
            "Interpretation":       effect_label_d(pr.get("cohens_d", 0)),
            "95% CI Lower":         "",
            "95% CI Upper":         "",
            "Reference":            "Cohen (1988)",
        },
        {
            "Effect Size Measure":  "Rank-Biserial r (non-parametric)",
            "Value":                round(r_rb, 3) if not np.isnan(r_rb) else "N/A",
            "Interpretation":       r_lbl,
            "95% CI Lower":         round(ci_lo, 3) if not np.isnan(ci_lo) else "N/A",
            "95% CI Upper":         round(ci_hi, 3) if not np.isnan(ci_hi) else "N/A",
            "Reference":            "Kerby (2014); Efron & Tibshirani (1993)",
        },
    ])
    return _section("Effect Sizes") + df.to_csv(index=False)


def _power_section(R, test_type, alpha):
    """Build power analysis section."""
    try:
        pw   = compute_power(R, test_type, alpha)
        rows = power_table_rows(pw)
        df   = pd.DataFrame(rows[1:], columns=rows[0])
        return _section("Statistical Power Assessment") + df.to_csv(index=False)
    except Exception:
        return _section("Statistical Power Assessment") + "Power analysis not available.\n"


def _interpretation_section(interps):
    """Build interpretation section."""
    rows = [{"Line": i + 1, "Interpretation": _strip_html(line)}
            for i, line in enumerate(interps)]
    return _section("Statistical Interpretation") + pd.DataFrame(rows).to_csv(index=False)


def _apa_section(test_type, R, meta, alpha):
    """Build APA 7th write-up section."""
    # Import APA builder from html_report
    from exports.html_report import _build_apa
    apa = _strip_html(_build_apa(test_type, R, meta, alpha))
    df  = pd.DataFrame([{"APA 7th Edition Write-Up": apa}])
    return _section("APA 7th Edition Write-Up") + df.to_csv(index=False)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_csv(test_type, R, meta, interps, alpha=0.05):
    """
    Build a comprehensive multi-section CSV file.

    All statistical results are included in clearly labelled sections,
    making the file readable in any spreadsheet or statistical software.

    Parameters
    ----------
    test_type : str
    R         : dict — output of run_*() from modules/t_tests.py
    meta      : dict — analysis metadata
    interps   : list of str — interpretation lines
    alpha     : float

    Returns
    -------
    bytes — UTF-8 encoded CSV, ready for st.download_button()
    """
    use_p    = R["use_param"]
    prim_n   = R["normality"][0]["n"]
    prim_lbl = R["normality"][0]["primary_label"]
    total_n  = R.get("total_n", prim_n)

    parts = []
    parts.append(f"INFERENTIAL STATISTICS BY MA — {test_type.upper()}\n")
    parts.append(f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}\n")

    # ── Sections ──────────────────────────────────────────────────────────────
    parts.append(_meta_section(meta))
    parts.append(_normality_section(R, total_n))
    parts.append(_assumption_section(R, use_p, prim_lbl, total_n))
    parts.append(_descriptives_section(R))
    parts.append(_correlation_section(R))
    parts.append(_levene_section(R))
    parts.append(_parametric_section(test_type, R))
    parts.append(_nonparametric_section(test_type, R))
    parts.append(_effect_size_section(R))
    parts.append(_power_section(R, test_type, alpha))
    parts.append(_interpretation_section(interps))
    parts.append(_apa_section(test_type, R, meta, alpha))

    # ── Footer ─────────────────────────────────────────────────────────────────
    parts.append(
        f"\n=== METHODOLOGY NOTES ===\n"
        f"1. Normality: Shapiro-Wilk + Kolmogorov-Smirnov (Lilliefors correction)\n"
        f"2. Primary criterion: {'Shapiro-Wilk' if total_n < 50 else 'Kolmogorov-Smirnov'} "
        f"(Total N {'< 50' if total_n < 50 else '>= 50'})\n"
        f"3. Levene's test: center = mean (SPSS default)\n"
        f"4. Wilcoxon Z: ties-corrected variance (SPSS method)\n"
        f"5. Mann-Whitney U: always 3 decimal places (SPSS format)\n"
        f"6. Rank-biserial r: bootstrap 95% CI (2000 resamples)\n"
        f"7. Power: non-central t-distribution (parametric) or normal approx (non-parametric)\n"
        f"8. {KS_DISCLAIMER}\n"
    )

    return "\n".join(parts).encode("utf-8")
