"""
pages/4_regression.py
=====================
Streamlit page for Linear Regression analysis.

Tests available:
  - Simple Linear Regression   (1 predictor)
  - Multiple Linear Regression (2+ predictors)

Assumption tests (SPSS-equivalent):
  1. Normality of residuals  (SW + KS Lilliefors, Total N criterion)
  2. Linearity               (ANOVA deviation-from-linearity table)
  3. Multicollinearity       (VIF + Tolerance)
  4. Heteroscedasticity      (Glejser test)
  5. Autocorrelation         (Durbin-Watson)
  6. Outliers                (Cook's Distance)

Beyond SPSS:
  - 95% CI for each B coefficient
  - Partial and part correlations
  - Effect size f² (Cohen, 1988)
  - Post-hoc power analysis
  - Bootstrap CI for B coefficients (2,000 resamples)
  - APA 7th edition write-up
  - HTML offline report + CSV export
"""

import streamlit as st
import pandas as pd
import numpy as np
import re
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Regression | Inferential Statistics by MA",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports ────────────────────────────────────────────────────────────────
from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols)
from utils.samples     import SAMPLES
from utils.formatters  import _f, _p, power_label
from utils.tables      import html_tbl
from utils.plots       import fig_to_bytes

from modules.regression import run_full_regression
from modules.normality  import KS_DISCLAIMER

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import statsmodels.api as sm

# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS  (defined early)
# ══════════════════════════════════════════════════════════════════════════════

def _interpret_regression(R, alpha):
    """
    Comprehensive academic-English interpretation for regression.
    Covers: all 6 assumptions + model fit + per-coefficient + descriptives.
    """
    lines = []
    nm    = R["normality"]
    het   = R["heteroscedasticity"]
    auto  = R["autocorrelation"]
    out   = R["outliers"]
    prim  = nm["primary_label"]
    n     = R["n"]
    size  = "N\u2009<\u200950" if n < 50 else "N\u2009\u2265\u200950"

    # 1. Normality of residuals
    nm_ok = nm["pass"]
    lines.append(
        f"<b>1. Normality of Residuals:</b> "
        f"Shapiro-Wilk W\u2009=\u2009{_f(nm['sw_W'])}, "
        f"p\u2009=\u2009{_p(nm['sw_p'])}; "
        f"Kolmogorov-Smirnov (Lilliefors) D\u2009=\u2009{_f(nm['ks_D'])}, "
        f"p\u2009=\u2009{_p(nm['ks_p'])}. "
        f"Primary criterion: <b>{prim}</b> ({size}). "
        + ("The residuals were approximately normally distributed (p\u2009>\u2009.05), "
           "satisfying the normality assumption."
           if nm_ok else
           "The normality assumption was violated (p\u2009\u2264\u2009.05). "
           "Consider log-transforming the outcome variable or using bootstrapped CIs.")
    )

    # 2. Linearity per predictor
    lin_num = 2
    for xn, lr in R["linearity"].items():
        lin_ok = lr["passed"]
        p_lin  = lr.get("p_lin", np.nan)
        p_dev  = lr.get("p_dev", np.nan)
        lines.append(
            f"<b>{lin_num}. Linearity \u2014 {xn} \u2192 {R['y_name']}:</b> "
            f"F (Linearity)\u2009=\u2009{_f(lr.get('F_lin', float('nan')))}, "
            f"p\u2009=\u2009{_p(p_lin)}; "
            f"F (Deviation)\u2009=\u2009{_f(lr.get('F_dev', float('nan')))}, "
            f"p\u2009=\u2009{_p(p_dev)}. "
            + ("A significant linear relationship was found and no significant "
               "deviation from linearity was detected — the linearity assumption "
               "is satisfied."
               if lin_ok else
               "The linearity assumption was not fully satisfied. "
               "Consider polynomial terms or a non-linear model.")
        )
        lin_num += 1

    next_num = lin_num

    # 3. Multicollinearity (Multiple only)
    if R["multicollinearity"] is not None:
        mc      = R["multicollinearity"]
        max_vif = float(mc["VIF"].max())
        min_tol = float(mc["Tolerance"].min())
        mc_ok   = max_vif < 10 and min_tol > 0.10
        lines.append(
            f"<b>{next_num}. Multicollinearity:</b> "
            f"Maximum VIF\u2009=\u2009{_f(max_vif)}, "
            f"Minimum Tolerance\u2009=\u2009{_f(min_tol)}. "
            + ("No problematic multicollinearity detected "
               "(VIF\u2009<\u200910, Tolerance\u2009>\u2009.10)."
               if mc_ok else
               "Multicollinearity detected (VIF\u2009\u2265\u200910). "
               "Consider removing redundant predictors or using ridge regression.")
        )
        next_num += 1

    # Heteroscedasticity
    het_ok = het["passed"]
    lines.append(
        f"<b>{next_num}. Heteroscedasticity (Glejser Test):</b> "
        + (f"No predictor significantly predicted |residuals| "
           f"(all p\u2009>\u2009.05), indicating homoscedasticity."
           if het_ok else
           f"At least one predictor significantly predicted |residuals|, "
           f"indicating heteroscedasticity. "
           f"Consider log-transforming Y or using heteroscedasticity-robust SEs.")
    )
    next_num += 1

    # Autocorrelation
    auto_ok = auto["passed"]
    lines.append(
        f"<b>{next_num}. Autocorrelation (Durbin-Watson):</b> "
        f"DW\u2009=\u2009{_f(auto['dw'])}. "
        + (f"No substantial autocorrelation detected (1.5\u2009\u2264\u2009DW\u2009\u2264\u20092.5)."
           if auto_ok else
           auto["interpretation"] + " "
           "Consider including a lagged outcome or using time-series methods.")
    )
    next_num += 1

    # Outliers
    out_ok = out["passed"]
    lines.append(
        f"<b>{next_num}. Influential Outliers (Cook\u2019s Distance, threshold\u2009=\u20094/N):</b> "
        + (f"No influential observations detected (Cook\u2019s D\u2009\u2264\u2009{out['threshold']:.3f} "
           f"for all {R['n']} cases)."
           if out_ok else
           f"{out['n_influential']} influential observation(s) detected. "
           f"{out['note']}")
    )
    next_num += 1

    # Overall model fit
    sig_model = not np.isnan(R["p_F"]) and R["p_F"] < alpha
    r2_pct    = R["R2"] * 100
    adj_r2    = R["adj_R2"]
    lines.append(
        f"<b>{next_num}. Overall Model Fit:</b> "
        f"F({R['df_reg']},\u2009{R['df_res']})\u2009=\u2009{_f(R['F'])}, "
        f"p\u2009=\u2009{_p(R['p_F'])}, "
        f"R\u00b2\u2009=\u2009{_f(R['R2'])}, "
        f"Adjusted R\u00b2\u2009=\u2009{_f(adj_r2)}. "
        + (f"The overall regression model was statistically significant "
           f"(p\u2009<\u2009{alpha}). The predictor(s) collectively explained "
           f"{r2_pct:.1f}% of the variance in {R['y_name']} "
           f"(Adjusted R\u00b2\u2009=\u2009{_f(adj_r2)}, accounting for the number "
           f"of predictors and sample size)."
           if sig_model else
           f"The overall regression model was not statistically significant "
           f"(p\u2009\u2265\u2009{alpha}). The predictor(s) did not explain a "
           f"statistically significant proportion of variance in {R['y_name']}.")
    )
    next_num += 1

    # Regression equation
    lines.append(
        f"<b>{next_num}. Regression Equation:</b> "
        f"{R['equation']}. "
        + R["eq_interpretation"]
    )
    next_num += 1

    # Per-coefficient interpretation
    coefs   = R["coef_df"]
    pc      = R.get("partial_corr", pd.DataFrame())
    boot_ci = R.get("boot_ci", {})
    for _, row in coefs[coefs["Model"] != "(Constant)"].iterrows():
        xn   = row["Model"]
        B    = float(row["B"])
        beta = row["Beta"]
        t_   = float(row["t"])
        p_   = float(row["Sig."])
        sig_b = p_ < alpha
        ci_l = float(row.get("95% CI Lower", np.nan))
        ci_u = float(row.get("95% CI Upper", np.nan))

        # partial r
        pc_row = pc[pc["Variable"] == xn].iloc[0] if (not pc.empty and xn in pc["Variable"].values) else None
        pr_   = float(pc_row.get("Partial r", np.nan)) if pc_row is not None else np.nan
        sr_   = float(pc_row.get("Part r",    np.nan)) if pc_row is not None else np.nan

        # bootstrap CI
        boot_l, boot_u = boot_ci.get(xn, (np.nan, np.nan))

        direction = "positive" if B > 0 else "negative"
        effect    = "increases" if B > 0 else "decreases"

        lines.append(
            f"<b>{next_num}. {xn}:</b> "
            f"B\u2009=\u2009{_f(B)}, \u03b2\u2009=\u2009{_f(beta)}, "
            f"t({R['df_res']})\u2009=\u2009{_f(t_)}, p\u2009=\u2009{_p(p_)}. "
            f"95% CI [OLS]: [{_f(ci_l)}, {_f(ci_u)}]. "
            f"Bootstrap 95% CI: [{_f(boot_l)}, {_f(boot_u)}]. "
            f"Partial r\u2009=\u2009{_f(pr_)}, Part r\u2009=\u2009{_f(sr_)}. "
            + (f"<b>{xn}</b> was a statistically significant {direction} predictor "
               f"of <b>{R['y_name']}</b>. "
               f"For each one-unit increase in {xn}, {R['y_name']} {effect} by "
               f"{abs(B):.3f} units, holding other predictors constant."
               if sig_b else
               f"<b>{xn}</b> was not a statistically significant predictor "
               f"of <b>{R['y_name']}</b> (p\u2009\u2265\u2009{alpha}).")
        )
        next_num += 1

    # Effect size + power
    if not np.isnan(R["f2"]):
        pwr_pct = f"{R['power']*100:.1f}%" if not np.isnan(R.get("power", np.nan)) else "N/A"
        lines.append(
            f"<b>{next_num}. Effect Size \u0026 Power:</b> "
            f"Cohen\u2019s f\u00b2\u2009=\u2009{_f(R['f2'])} ({R['f2_label']}). "
            f"Achieved statistical power\u2009=\u2009{pwr_pct}. "
            + (f"Minimum N for power\u2009=\u2009.80: {R['n_required']}."
               if R.get("n_required") else "")
        )

    return lines


def _build_apa_regression(R, alpha):
    """APA 7th edition write-up for regression."""
    sig   = R["p_F"] < alpha
    r2pct = R["R2"] * 100
    coefs = R["coef_df"]
    pred  = ", ".join(R["x_names"])

    pred_snts = []
    for _, row in coefs[coefs["Model"] != "(Constant)"].iterrows():
        sig_b = float(row["Sig."]) < alpha
        pred_snts.append(
            f"{row['Model']} (B\u2009=\u2009{float(row['B']):.2f}, "
            f"\u03b2\u2009=\u2009{float(row['Beta']):.2f}, "
            f"p\u2009{'< .001' if float(row['Sig.']) < .001 else '= ' + _p(float(row['Sig.']))})"
            + (" significantly predicted" if sig_b else " did not significantly predict")
            + f" {R['y_name']}"
        )

    reg_type = "simple" if R["k"] == 1 else "multiple"
    return (
        f"A {reg_type} linear regression was conducted to examine "
        f"whether {pred} predicted {R['y_name']}. "
        f"Prior to the analysis, all classical assumption tests were performed. "
        f"The overall model was "
        f"{'statistically significant' if sig else 'not statistically significant'}, "
        f"F({R['df_reg']},\u2009{R['df_res']})\u2009=\u2009"
        f"{float(R['F']):.2f}, "
        f"p\u2009{'< .001' if R['p_F'] < .001 else '= ' + _p(R['p_F'])}, "
        f"R\u00b2\u2009=\u2009{float(R['R2']):.3f}, "
        f"indicating that the predictor(s) accounted for "
        f"{r2pct:.1f}% of the variance in {R['y_name']}. "
        + ". ".join(pred_snts) + "."
    )


# ══════════════════════════════════════════════════════════════════════════════
# PLOT FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

PAL = ["#1a1a2e", "#e94560", "#0f3460", "#16213e"]
BG  = "#f8fafc"


def _style_ax(ax):
    ax.set_facecolor(BG)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color("#cbd5e1")
    ax.tick_params(colors="#64748b", labelsize=7)
    ax.xaxis.label.set_color("#64748b")
    ax.yaxis.label.set_color("#64748b")
    ax.title.set_color(PAL[0])


def plot_regression_diagnostics(R):
    """Four-panel diagnostic plot."""
    residuals = np.array(R["residuals"], dtype=float)
    fitted    = np.array(R["fitted"],    dtype=float)
    n         = len(residuals)

    fig = plt.figure(figsize=(14, 5), facecolor=BG)
    gs  = gridspec.GridSpec(1, 4, figure=fig, wspace=.38)

    # Panel 1: Histogram of residuals
    ax1 = fig.add_subplot(gs[0]); _style_ax(ax1)
    ax1.hist(residuals, bins="auto", color=PAL[1], alpha=0.72,
             edgecolor="white", linewidth=.8)
    from scipy import stats as scp
    mu, sd = residuals.mean(), residuals.std(ddof=1)
    xr = np.linspace(mu - 4*sd, mu + 4*sd, 300)
    bw = (residuals.max() - residuals.min()) / max(int(np.sqrt(n)), 1)
    ax1.plot(xr, scp.norm.pdf(xr, mu, sd) * n * bw,
             color=PAL[0], lw=2, alpha=.85)
    ax1.set_title("Histogram of Residuals", fontsize=9, fontweight="bold")
    ax1.set_xlabel("Residual", fontsize=8)
    ax1.set_ylabel("Frequency", fontsize=8)

    # Panel 2: Normal Q-Q
    ax2 = fig.add_subplot(gs[1]); _style_ax(ax2)
    (osm, osr), (sl, ic, _) = scp.probplot(residuals)
    ax2.plot(osm, osr, "o", color=PAL[1], markersize=4,
             markeredgecolor="white", markeredgewidth=.4, alpha=.8)
    ax2.plot(osm, sl * np.array(osm) + ic, "--",
             color=PAL[0], lw=1.5, alpha=.7)
    ax2.set_title("Normal Q-Q Plot", fontsize=9, fontweight="bold")
    ax2.set_xlabel("Theoretical Quantiles", fontsize=8)
    ax2.set_ylabel("Sample Quantiles", fontsize=8)

    # Panel 3: ZRESID vs ZPRED (Glejser/heteroscedasticity)
    ax3 = fig.add_subplot(gs[2]); _style_ax(ax3)
    zr = (residuals - residuals.mean()) / residuals.std(ddof=1)
    zf = (fitted    - fitted.mean())    / fitted.std(ddof=1)
    ax3.scatter(zf, zr, color=PAL[1], s=22, alpha=.72,
                edgecolors="white", linewidths=.4, zorder=3)
    ax3.axhline(0,  color=PAL[0], lw=1.2, ls="--", alpha=.7)
    ax3.axhline(2,  color="#dc2626", lw=.8, ls=":",  alpha=.5)
    ax3.axhline(-2, color="#dc2626", lw=.8, ls=":",  alpha=.5)
    ax3.set_title("ZRESID vs ZPRED", fontsize=9, fontweight="bold")
    ax3.set_xlabel("Std. Predicted (ZPRED)", fontsize=8)
    ax3.set_ylabel("Std. Residual (ZRESID)", fontsize=8)

    # Panel 4: Cook's Distance
    ax4 = fig.add_subplot(gs[3]); _style_ax(ax4)
    cooks_d  = R["outliers"]["cooks_d"]
    threshold = R["outliers"]["threshold"]
    inf_idx  = set(R["outliers"]["influential_idx"])
    colors   = [PAL[1] if i in inf_idx else PAL[2] for i in range(n)]
    ax4.bar(range(n), cooks_d, color=colors, alpha=.75, width=.8)
    ax4.axhline(threshold, color=PAL[1], lw=1.5, ls="--",
                label=f"Threshold ({threshold:.3f})")
    ax4.set_title("Cook's Distance", fontsize=9, fontweight="bold")
    ax4.set_xlabel("Observation", fontsize=8)
    ax4.set_ylabel("Cook's D", fontsize=8)
    ax4.legend(fontsize=7, framealpha=.7)

    plt.tight_layout()
    return fig


def plot_scatter_simple(x_arr, y_arr, x_name, y_name, model_sm):
    """Scatter + regression line for simple regression."""
    fig, ax = plt.subplots(figsize=(7, 4), facecolor=BG)
    _style_ax(ax)
    import statsmodels.api as sm_
    ax.scatter(x_arr, y_arr, color=PAL[1], s=30, alpha=.72,
               edgecolors="white", linewidths=.4, zorder=3, label="Observed")
    xs = np.linspace(x_arr.min(), x_arr.max(), 300)
    Xp = sm_.add_constant(xs)
    ax.plot(xs, model_sm.predict(Xp),
            color=PAL[0], lw=2.2, zorder=4, label="Regression line")
    ax.set_xlabel(x_name, fontsize=9)
    ax.set_ylabel(y_name, fontsize=9)
    ax.set_title(f"Scatter Plot: {x_name} vs {y_name}",
                 fontsize=10, fontweight="bold")
    ax.legend(fontsize=8, framealpha=.7)
    plt.tight_layout()
    return fig


def plot_obs_vs_fitted(fitted, y_arr, y_name):
    """Observed vs Fitted for multiple regression."""
    fig, ax = plt.subplots(figsize=(7, 4), facecolor=BG)
    _style_ax(ax)
    ax.scatter(fitted, y_arr, color=PAL[1], s=30, alpha=.72,
               edgecolors="white", linewidths=.4, zorder=3)
    mn = min(float(fitted.min()), float(y_arr.min()))
    mx = max(float(fitted.max()), float(y_arr.max()))
    ax.plot([mn, mx], [mn, mx], color=PAL[0], lw=2, ls="--",
            label="Perfect fit")
    ax.set_xlabel("Fitted Values", fontsize=9)
    ax.set_ylabel(f"Observed {y_name}", fontsize=9)
    ax.set_title("Observed vs Fitted Values",
                 fontsize=10, fontweight="bold")
    ax.legend(fontsize=8, framealpha=.7)
    plt.tight_layout()
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# HTML REPORT BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def _build_html_regression(R, meta, interps, apa, fig_bytes_list, alpha):
    """Build standalone HTML report for regression."""
    import base64
    from modules.normality import KS_DISCLAIMER, recommendation_note_plain

    def _rtbl(rows, left_cols=None):
        if left_cols is None: left_cols = {0}
        h = '<table class="rtbl"><thead><tr>'
        for c in rows[0]: h += f"<th>{c}</th>"
        h += "</tr></thead><tbody>"
        for i, row in enumerate(rows[1:]):
            h += f'<tr class="{"even" if i%2==0 else "odd"}">'
            for j, cell in enumerate(row):
                cls = ' class="left"' if j in left_cols else ""
                h += f"<td{cls}>{cell}</td>"
            h += "</tr>"
        h += "</tbody></table>"
        return h

    def _sub(t): return f'<div class="sub-hdr">{t}</div>'
    def _sh(t, n): return (f'<div class="sec-hdr">'
                            f'<span class="sec-num">{n}</span>{t}</div>')

    # Normality table
    nm   = R["normality"]
    norm_rows = [["Variable","N","SW W","SW Sig.","KS D","KS Sig.\u1d43",
                  "Primary Criterion","Decision"]]
    for row_lbl in ["Unstandardized Residual", "Standardized Residual"]:
        norm_rows.append([
            row_lbl, str(nm["n"]),
            _f(nm["sw_W"]), _p(nm["sw_p"]),
            _f(nm["ks_D"]), _p(nm["ks_p"]),
            nm["primary_label"],
            "\u2713 Normal" if nm["pass"] else "\u2717 Non-Normal"
        ])
    norm_html  = _rtbl(norm_rows)
    norm_html += (f'<p class="tbl-note">\u1d43 Lilliefors correction. '
                  f'{KS_DISCLAIMER}</p>')
    norm_html += (f'<div class="rec-box">'
                  f'{recommendation_note_plain(nm["total_n"])}</div>')

    # Linearity tables
    lin_html = ""
    for xn, lr in R["linearity"].items():
        lin_html += _sub(f"{xn} \u2192 {R['y_name']}")
        ss_comb = lr.get("ss_between", lr["ss_reg"])
        lin_rows = [["Source","SS","df","MS","F","Sig."]]
        lin_rows += [
            ["Between Groups (Combined)",
             _f(ss_comb), str(lr.get("df_groups", "-")),
             _f(lr.get("ms_between", float("nan"))),
             _f(lr.get("F_between", float("nan"))),
             _p(lr.get("p_between", float("nan")))],
            ["\u00a0\u00a0Linearity",
             _f(lr["ss_reg"]), str(lr["df_lin"]),
             _f(lr["ms_lin"]), _f(lr["F_lin"]), _p(lr["p_lin"])],
            ["\u00a0\u00a0Deviation from Linearity",
             _f(lr.get("ss_dev", float("nan"))),
             str(lr["df_dev"]) if lr["df_dev"] > 0 else "\u2014",
             _f(lr.get("ms_dev", float("nan"))),
             _f(lr.get("F_dev", float("nan"))),
             _p(lr.get("p_dev", float("nan")))],
            ["Within Groups",
             _f(lr.get("ss_within", float("nan"))),
             str(lr["df_within"]),
             _f(lr.get("ms_within", float("nan"))), "\u2014", "\u2014"],
        ]
        lin_html += _rtbl(lin_rows, left_cols={0})
        status = "\u2713 Satisfied" if lr["passed"] else "\u2717 Violated"
        lin_html += f'<p class="tbl-note">{status}</p>'

    # Multicollinearity
    mc_html = ""
    if R["multicollinearity"] is not None:
        mc  = R["multicollinearity"]
        mc_rows = [["Variable","Tolerance","VIF","Status"]]
        for _, row in mc.iterrows():
            mc_rows.append([row["Variable"], _f(row["Tolerance"]),
                            _f(row["VIF"]), row["Status"]])
        mc_html = _rtbl(mc_rows)

    # Glejser
    g_df  = R["heteroscedasticity"]["coef_df"]
    g_rows = [["Term","B","Std. Error","t","Sig."]]
    for _, row in g_df.iterrows():
        g_rows.append([row["Term"], _f(row["B"]), _f(row["Std. Error"]),
                       _f(row["t"]), _p(row["Sig."])])
    glejser_html = (_rtbl(g_rows, left_cols={0})
                    + f'<p class="tbl-note">{R["heteroscedasticity"]["note"]}</p>')

    # Descriptive Statistics
    spss_desc = R["spss_desc"]
    desc_rows = [["", "Mean", "Std. Deviation", "N"]]
    for _, row in spss_desc.iterrows():
        desc_rows.append([str(row.iloc[0]), _f(row["Mean"]),
                          _f(row["Std. Deviation"]), str(int(row["N"]))])
    desc_html = _rtbl(desc_rows, left_cols={0})

    # Full descriptives (beyond SPSS)
    fd = R["full_desc"]
    fd_rows = [list(fd.columns)]
    for _, row in fd.iterrows():
        fd_rows.append([str(row["Variable"])] +
                       [_f(row[c]) if isinstance(row[c], float) else str(row[c])
                        for c in fd.columns[1:]])
    full_desc_html = _rtbl(fd_rows, left_cols={0})

    # Correlations
    corr  = R["correlations"]
    vars_ = corr["vars"]
    corr_html = ""
    for stat_lbl, df_ in [("Pearson Correlation", corr["r_df"]),
                           ("Sig. (1-tailed)",     corr["p_df"]),
                           ("N",                   corr["n_df"])]:
        rows_ = [[""] + vars_]
        for var in vars_:
            vals = [var]
            for col_ in vars_:
                v = df_.loc[var, col_]
                if stat_lbl == "Pearson Correlation":
                    vals.append("." if var == col_ else _f(v))
                elif stat_lbl == "Sig. (1-tailed)":
                    vals.append("." if var == col_ else _p(v))
                else:
                    vals.append(str(int(v)) if not np.isnan(float(v)) else ".")
            rows_.append(vals)
        corr_html += f'<p class="tbl-note" style="font-weight:600;margin:.6rem 0 .2rem;">{stat_lbl}</p>'
        corr_html += _rtbl(rows_, left_cols={0})

    # Variables Entered
    ve = R["vars_entered"]
    ve_rows = [list(ve.columns)]
    for _, row in ve.iterrows():
        ve_rows.append([str(v) for v in row])
    ve_html = _rtbl(ve_rows, left_cols={0,1,2,3})

    # Model Summary with change statistics
    ms  = R["model_summary"]
    ms_rows = [["Model","R","R\u00b2","Adjusted R\u00b2",
                "Std. Error of the Estimate",
                "R\u00b2 Change","F Change","df1","df2",
                "Sig. F Change","Durbin-Watson"]]
    for _, row in ms.iterrows():
        ms_rows.append([
            str(int(row["Model"])),
            _f(row["R"]), _f(row["R Square"]), _f(row["Adjusted R Square"]),
            _f(row["Std. Error of the Estimate"]),
            _f(row["R Square Change"]),
            _f(row["F Change"]), str(int(row["df1"])), str(int(row["df2"])),
            _p(row["Sig. F Change"]) if not np.isnan(float(row["Sig. F Change"])) else ".",
            _f(row["Durbin-Watson"]),
        ])
    ms_html = _rtbl(ms_rows)

    # ANOVA table
    an_rows = [["Model","","Sum of Squares","df","Mean Square","F","Sig."]]
    an_rows += [
        ["1","Regression", _f(R["ss_reg"]), str(R["df_reg"]),
         _f(R["ms_reg"]), _f(R["F"]), _p(R["p_F"])],
        ["","Residual",    _f(R["ss_res"]), str(R["df_res"]),
         _f(R["ms_res"]), "\u2014", "\u2014"],
        ["","Total",       _f(R["ss_tot"]), str(R["df_tot"]),
         "\u2014", "\u2014", "\u2014"],
    ]
    anova_html = _rtbl(an_rows, left_cols={0,1})

    # Coefficients — full SPSS + beyond
    alpha_ = R["alpha"]
    ci_lo  = f"{int((1-alpha_)*100)}% CI Lower"
    ci_hi  = f"{int((1-alpha_)*100)}% CI Upper"
    pc     = R["partial_corr"]
    bc     = R["boot_ci"]
    mc_df2 = R["multicollinearity"]
    c_df   = R["coef_df"]
    c_rows = [["Model","B","Std. Error","Beta","t","Sig.",
               ci_lo, ci_hi,
               "Zero-order","Partial r","Part r",
               "Tolerance","VIF",
               "Bootstrap CI Lower","Bootstrap CI Upper"]]
    for _, row in c_df.iterrows():
        xn = row["Model"]
        if not pc.empty and xn in pc["Variable"].values:
            pc_r = pc[pc["Variable"]==xn].iloc[0]
            zo_  = _f(pc_r.get("Zero-order", np.nan))
            pr_  = _f(pc_r.get("Partial r",  np.nan))
            sr_  = _f(pc_r.get("Part r",     np.nan))
        else:
            zo_ = pr_ = sr_ = "\u2014"
        if mc_df2 is not None and not mc_df2.empty and xn in mc_df2["Variable"].values:
            mc_r = mc_df2[mc_df2["Variable"]==xn].iloc[0]
            tol_ = _f(mc_r["Tolerance"]); vif_ = _f(mc_r["VIF"])
        else:
            tol_ = vif_ = "\u2014"
        bl, bu = bc.get(xn, (np.nan, np.nan))
        c_rows.append([
            xn, _f(row["B"]), _f(row["Std. Error"]),
            _f(row["Beta"]) if row["Beta"] != "" else "\u2014",
            _f(row["t"]), _p(float(row["Sig."])),
            _f(row.get(ci_lo, np.nan)), _f(row.get(ci_hi, np.nan)),
            zo_, pr_, sr_, tol_, vif_, _f(bl), _f(bu),
        ])
    coef_html = _rtbl(c_rows, left_cols={0})

    # Collinearity Diagnostics
    cd_html = ""
    if R["collinearity_diag"] is not None:
        cd = R["collinearity_diag"]
        cd_rows = [list(cd.columns)]
        for _, row in cd.iterrows():
            cd_rows.append(
                [str(int(row["Dimension"])),
                 _f(row["Eigenvalue"]), _f(row["Condition Index"])] +
                [_f(row[c]) for c in cd.columns[3:]]
            )
        cd_html = (_rtbl(cd_rows) +
                   '<p class="tbl-note">Condition Index\u2009&gt;\u200930 with '
                   'variance proportions\u2009&gt;\u2009.50 indicates '
                   'multicollinearity (Belsley et al., 1980).</p>')

    # Residuals Statistics
    rs = R["residuals_stats"]
    rs_rows = [list(rs.columns)]
    for _, row in rs.iterrows():
        rs_rows.append(
            [str(row.iloc[0])] +
            [_f(row[c]) if isinstance(row[c], float) else str(row[c])
             for c in rs.columns[1:]]
        )
    rs_html = (_rtbl(rs_rows, left_cols={0}) +
               f'<p class="tbl-note">Dependent Variable: {R["y_name"]}.</p>')


    # Partial correlations
    pc_df = R["partial_corr"]
    pc_rows = [["Variable","Partial r","Part r","Partial r\u00b2","Part r\u00b2"]]
    for _, row in pc_df.iterrows():
        pc_rows.append([row["Variable"],
                        _f(row["Partial r"]), _f(row["Part r"]),
                        _f(row["Partial r\u00b2"]), _f(row["Part r\u00b2"])])
    pc_html = _rtbl(pc_rows)

    # Effect size + power
    es_rows = [["Measure","Value","Interpretation"],
               ["Cohen\u2019s f\u00b2", _f(R["f2"]), R["f2_label"]],
               ["Cohen\u2019s f",  _f(R["f"]),  R["f2_label"]],
               ["Achieved Power", (f"{R['power']*100:.1f}%"
                                   if not np.isnan(R["power"]) else "."),
                power_label(R["power"]) if not np.isnan(R["power"]) else "N/A"],
               ["Min N for power\u2009=\u2009.80",
                str(R["n_required"]) if R["n_required"] else "N/A", "\u2014"],
               ]
    es_html = (_rtbl(es_rows, left_cols={0, 2})
               + '<p class="tbl-note">Reference: Cohen (1988). '
                 'f\u00b2 = R\u00b2 / (1\u2009\u2212\u2009R\u00b2). '
                 '\u2265\u2009.02 small, \u2265\u2009.15 medium, \u2265\u2009.35 large.</p>')

    # Interpretation
    interp_html = ""
    for line in interps:
        lw  = line.lower()
        cls = ("sig" if "statistically significant" in lw
                        and "not statistically significant" not in lw
               else "nonsig" if "not statistically significant" in lw else "")
        interp_html += f'<div class="interp {cls}">{line}</div>'
    interp_html += (f'<div style="margin-top:20px;">'
                    f'<div class="apa-label">APA 7th Edition Write-Up</div>'
                    f'<div class="apa-box">{apa}</div></div>')

    # Figures
    figs_html = ""
    for i, fb in enumerate(fig_bytes_list, 1):
        b64 = base64.b64encode(fb).decode()
        figs_html += (
            f'<div class="fig-wrap">'
            f'<img src="data:image/png;base64,{b64}" '
            f'style="width:100%;max-width:960px;border-radius:10px;'
            f'box-shadow:0 4px 20px rgba(0,0,0,.12);"/>'
            f'<p class="fig-cap">Figure {i}. Diagnostic plots. '
            f'From left to right: residual histogram, Normal Q-Q plot, '
            f'ZRESID vs ZPRED, Cook\u2019s Distance.</p>'
            f'</div>'
        )

    # Meta table
    meta_html = "<table class='meta-tbl'>"
    for k, v in meta.items():
        meta_html += f"<tr><td class='mk'>{k}</td><td class='mv'>{v}</td></tr>"
    meta_html += "</table>"

    # Decision box
    all_ok  = R["all_assumptions_met"]
    dcls    = "use-param" if all_ok else "use-nonparam"
    dtxt    = ("\u2713 All classical assumption tests satisfied \u2192 "
               "<b>Regression results are fully valid.</b>"
               if all_ok else
               "\u26a0 One or more assumptions violated. "
               "Interpret regression results with caution. "
               "See recommendations in the Interpretation section.")

    # Section numbering
    mc_section = (f'<div class="section">{_sh("MULTICOLLINEARITY (VIF)", 3)}'
                  f'{mc_html}'
                  f'<p class="tbl-note">VIF\u2009&lt;\u20095: no concern. '
                  f'5\u2013\u200910: moderate. &gt;\u200910: violation. '
                  f'Simple regression: VIF = 1.000 by definition.</p></div>'
                  )

    css = """<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);
  border-radius:16px;padding:44px 52px;margin-bottom:28px;
  border-left:6px solid #e94560;box-shadow:0 12px 48px rgba(233,69,96,.2);}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;}
.cover .sub{color:#94a3b8;font-size:.9rem;margin-bottom:24px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;
  padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.decision-box{padding:12px 20px;border-radius:10px;margin:20px 0;font-size:.9rem;font-weight:600;}
.use-param{background:#dcfce7;color:#14532d;border:1px solid #86efac;}
.use-nonparam{background:#ffedd5;color:#7c2d12;border:1px solid #fdba74;}
.section{background:#fff;border-radius:12px;padding:26px 30px;
  margin-bottom:22px;box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;
  padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;
  letter-spacing:.8px;margin:-26px -30px 22px;font-family:'DM Mono',monospace;
  border-bottom:3px solid #e94560;display:flex;align-items:center;gap:12px;}
.sec-num{background:#e94560;color:#fff;font-size:.72rem;padding:2px 8px;
  border-radius:12px;font-weight:700;flex-shrink:0;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;
  font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);
  border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;
  font-size:.82rem;color:#0c4a6e;margin:12px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;
  font-size:.73rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:8px 10px;text-align:center;
  font-weight:600;border:1px solid #334155;white-space:normal;font-size:.71rem;}
.rtbl td{padding:6px 10px;border:1px solid #e2e8f0;text-align:right;
  white-space:normal;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.eq-box{background:#f8fafc;border:1.5px solid #e94560;border-radius:10px;
  padding:14px 20px;font-family:'DM Mono',monospace;font-size:1.1rem;
  color:#1a1a2e;text-align:center;margin:14px 0;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;
  font-size:.86rem;line-height:1.8;border-left:4px solid #0284c7;
  background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp b{color:#0284c7;}
.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}
.interp.sig b{color:#16a34a;}
.interp.nonsig{border-left-color:#dc2626;background:linear-gradient(135deg,#fef2f2,#fee2e2);}
.interp.nonsig b{color:#dc2626;}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;
  letter-spacing:.8px;margin-bottom:6px;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
  padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;
  color:#1e293b;line-height:1.8;}
.fig-wrap{text-align:center;margin:18px 0;}
.fig-cap{font-size:.75rem;color:#64748b;font-style:italic;margin-top:10px;}
.warn-box{background:#fffbeb;border-left:4px solid #f59e0b;padding:.7rem 1rem;
  border-radius:0 6px 6px 0;font-size:.82rem;color:#92400e;margin:.4rem 0;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;
  padding-top:16px;border-top:1px solid #e2e8f0;line-height:1.8;}
</style>"""

    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Regression Report \u2014 {R['y_name']}</title>{css}</head>
<body><div class="page">
<div class="cover">
  <h1>&#128202; Linear Regression Report</h1>
  <div class="sub">
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Classical Assumptions</span>
    <span class="badge">Beyond SPSS</span>
  </div>
  {meta_html}
  <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12);
              display:flex;align-items:center;gap:16px;">
    <div>
      <p style="color:#94a3b8;font-size:.76rem;margin:0 0 8px;">
        &#9749; Support this work &mdash; scan QRIS</p>
      <img src="https://muhaiminabdullah.com/media/images/qris_muhaiminabdullahdotcom.png"
           style="width:130px;border-radius:8px;border:2px solid #e94560;display:block;"/>
    </div>
  </div>
</div>
<div class="section">
  <div class="sec-hdr"><span class="sec-num">&#9654;</span>ASSUMPTION STATUS</div>
  <div class="decision-box {dcls}">{dtxt}</div>
</div>
<div class="section">
  {_sh("DESCRIPTIVE STATISTICS", "A")}
  {full_desc_html}
  <p class="tbl-note">5% Trimmed Mean: SPSS partial trimming method.
  Skewness and Kurtosis: bias-corrected (Fisher). IQR = Q3 &minus; Q1.</p>
</div>
<div class="section">
  {_sh("CORRELATIONS", "B")}
  {corr_html}
  <p class="tbl-note">Sig. (1-tailed) as per SPSS default. ** p &lt; .01, * p &lt; .05.</p>
</div>
<div class="section">
  {_sh("NORMALITY OF RESIDUALS", 1)}{norm_html}
</div>
<div class="section">
  {_sh("LINEARITY TESTS", 2)}{lin_html}
</div>
{mc_section}
<div class="section">
  {_sh("HETEROSCEDASTICITY \u2014 GLEJSER TEST", "4")}
  {glejser_html}
</div>
<div class="section">
  {_sh("AUTOCORRELATION \u2014 DURBIN-WATSON", "5")}
  <p style="font-size:.86rem;margin:.5rem 0;">
    DW\u2009=\u2009<b>{_f(R["dw"])}</b>. {R["autocorrelation"]["interpretation"]}
    <br/><small>Acceptable range: 1.5 &le; DW &le; 2.5 (no autocorrelation).</small>
  </p>
</div>
<div class="section">
  {_sh("VARIABLES ENTERED / REMOVED", "6")}
  {ve_html}
</div>
<div class="section">
  {_sh("MODEL SUMMARY", "7")}
  {ms_html}
  <p class="tbl-note">
  <b>a.</b> Predictors: (Constant), {", ".join(R["x_names"])}.
  <b>b.</b> Dependent Variable: {R["y_name"]}.
  R&sup2; = {_f(R["R2"])}: {R["R2"]*100:.1f}% variance explained.
  Adjusted R&sup2; corrects for number of predictors and N.
  </p>
  {_sub("ANOVA")}{anova_html}
  <p class="tbl-note"><b>a.</b> Dependent Variable: {R["y_name"]}.
  <b>b.</b> Predictors: (Constant), {", ".join(R["x_names"])}.</p>
  {_sub("Coefficients (SPSS + Bootstrap CI)")}{coef_html}
  <p class="tbl-note"><b>a.</b> Dependent Variable: {R["y_name"]}.
  Beta = standardised coefficient.
  Zero-order r = bivariate Pearson.
  Partial r = controlling all other predictors.
  Part r = unique contribution to R&sup2;.
  Bootstrap CI: 2,000 resamples, percentile method.</p>
  <div class="eq-box">{R["equation"]}</div>
  <div class="interp">{R.get("eq_interpretation", "")}</div>
  {f'<div><div class="sub-hdr">Collinearity Diagnostics</div>{cd_html}</div>' if cd_html else ""}
  {_sub("Residuals Statistics")}{rs_html}
</div>
<div class="section">
  {_sh("EFFECT SIZE &amp; STATISTICAL POWER", "8")}
  {es_html}
</div>
<div class="section">
  {_sh("INTERPRETATION &amp; APA WRITE-UP", "9")}
  {interp_html}
</div>
<div class="section">
  {_sh("DIAGNOSTIC PLOTS", "10")}
  {figs_html}
</div>
<div class="footer">
  Generated by Inferential Statistics by MA &nbsp;&middot;&nbsp;
  SPSS-equivalent regression &nbsp;&middot;&nbsp;
  Descriptive Statistics &middot; Correlations &middot; Collinearity Diagnostics &middot;
  Residuals Statistics &middot; Bootstrap CI (2,000 resamples)<br/>
  Generated: {datetime.now().strftime("%B %d, %Y at %H:%M")}
</div>
</div></body></html>"""

    return html.encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSV EXPORT
# ══════════════════════════════════════════════════════════════════════════════

def _build_csv_regression(R, meta, interps, apa, alpha):
    """Build multi-section CSV for regression."""
    parts = []
    parts.append(f"INFERENTIAL STATISTICS BY MA \u2014 REGRESSION\n")
    parts.append(f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}\n")

    # Meta
    meta_rows = [{"Parameter": k, "Value": str(v)} for k, v in meta.items()]
    parts.append("\n=== ANALYSIS INFORMATION ===\n"
                 + pd.DataFrame(meta_rows).to_csv(index=False))

    # Normality
    nm = R["normality"]
    parts.append("\n=== NORMALITY OF RESIDUALS ===\n"
                 + pd.DataFrame([{
                     "N": nm["n"], "SW W": round(nm["sw_W"], 3),
                     "SW Sig.": _p(nm["sw_p"]),
                     "KS D": round(nm["ks_D"], 3) if not np.isnan(nm["ks_D"]) else "",
                     "KS Sig.": _p(nm["ks_p"]),
                     "Primary Criterion": nm["primary_label"],
                     "Decision": "Normal" if nm["pass"] else "Non-Normal",
                 }]).to_csv(index=False))

    # Linearity
    lin_rows = []
    for xn, lr in R["linearity"].items():
        lin_rows.append({
            "Predictor": xn, "Outcome": R["y_name"],
            "Sig. Linearity": _p(lr["p_lin"]),
            "Sig. Deviation": _p(lr.get("p_dev", float("nan"))),
            "Decision": "Satisfied" if lr["passed"] else "Violated",
        })
    parts.append("\n=== LINEARITY TESTS ===\n"
                 + pd.DataFrame(lin_rows).to_csv(index=False))

    # VIF
    if R["multicollinearity"] is not None:
        mc = R["multicollinearity"].copy()
        mc["Tolerance"] = mc["Tolerance"].apply(lambda v: round(v, 3))
        mc["VIF"]       = mc["VIF"].apply(lambda v: round(v, 3))
        parts.append("\n=== MULTICOLLINEARITY (VIF) ===\n"
                     + mc.to_csv(index=False))

    # Glejser
    g = R["heteroscedasticity"]["coef_df"].copy()
    for c in ["B","Std. Error","t"]:
        g[c] = g[c].apply(lambda v: round(v, 3))
    g["Sig."] = g["Sig."].apply(_p)
    parts.append("\n=== HETEROSCEDASTICITY (GLEJSER) ===\n"
                 + g.to_csv(index=False))

    # Durbin-Watson
    parts.append("\n=== AUTOCORRELATION (DURBIN-WATSON) ===\n"
                 + pd.DataFrame([{
                     "DW": round(R["autocorrelation"]["dw"], 3),
                     "Interpretation": R["autocorrelation"]["interpretation"],
                     "Decision": "Satisfied" if R["autocorrelation"]["passed"] else "Violated",
                 }]).to_csv(index=False))

    # Model summary
    parts.append("\n=== MODEL SUMMARY ===\n"
                 + pd.DataFrame([{
                     "R": round(R["R"], 3), "R Square": round(R["R2"], 3),
                     "Adjusted R Square": round(R["adj_R2"], 3),
                     "Std. Error": round(R["se_est"], 3),
                     "Durbin-Watson": round(R["autocorrelation"]["dw"], 3),
                 }]).to_csv(index=False))

    # ANOVA
    parts.append("\n=== ANOVA ===\n"
                 + pd.DataFrame([
                     {"Model": "Regression", "SS": round(R["ss_reg"], 3),
                      "df": R["df_reg"], "MS": round(R["ms_reg"], 3),
                      "F": round(R["F"], 3), "Sig.": _p(R["p_F"])},
                     {"Model": "Residual",   "SS": round(R["ss_res"], 3),
                      "df": R["df_res"], "MS": round(R["ms_res"], 3),
                      "F": "", "Sig.": ""},
                     {"Model": "Total",      "SS": round(R["ss_tot"], 3),
                      "df": R["df_tot"], "MS": "", "F": "", "Sig.": ""},
                 ]).to_csv(index=False))

    # Coefficients
    c = R["coef_df"].copy()
    for col in ["B","Std. Error","t","95% CI Lower","95% CI Upper"]:
        c[col] = c[col].apply(lambda v: round(float(v), 3)
                              if v != "" else "")
    c["Beta"] = c["Beta"].apply(lambda v: round(float(v), 3)
                                if v != "" else "")
    c["Sig."] = c["Sig."].apply(lambda v: _p(float(v)))
    parts.append("\n=== COEFFICIENTS ===\n" + c.to_csv(index=False))

    # Equation
    parts.append(f"\n=== REGRESSION EQUATION ===\n{R['equation']}\n")
    eq_clean = re.sub(r"<[^>]+>", "", R.get("eq_interpretation", ""))
    parts.append(f"\n=== EQUATION INTERPRETATION ===\n{eq_clean}\n")

    # Effect size
    parts.append("\n=== EFFECT SIZE & POWER ===\n"
                 + pd.DataFrame([{
                     "Cohen's f2": round(R["f2"], 3) if not np.isnan(R["f2"]) else "",
                     "Label": R["f2_label"],
                     "Achieved Power": round(R["power"], 3) if not np.isnan(R["power"]) else "",
                     "Min N for Power=.80": R["n_required"] or "",
                     "Reference": "Cohen (1988)",
                 }]).to_csv(index=False))

    # Interpretation
    clean_interps = [re.sub(r"<[^>]+>", "", l) for l in interps]
    parts.append("\n=== INTERPRETATION ===\n"
                 + pd.DataFrame({"Line": range(1, len(clean_interps)+1),
                                 "Interpretation": clean_interps})
                 .to_csv(index=False))

    # APA
    apa_clean = re.sub(r"<[^>]+>", "", apa)
    parts.append(f"\n=== APA 7TH EDITION WRITE-UP ===\n{apa_clean}\n")

    return "\n".join(parts).encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSS + HEADER
# ══════════════════════════════════════════════════════════════════════════════

st.markdown(load_page_css(), unsafe_allow_html=True)

st.markdown("""
<div class="main-hdr">
  <h1>&#128202; Linear Regression
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">All Assumptions</span>
    <span class="badge">Beyond SPSS</span>
  </h1>
  <p>Simple &nbsp;&middot;&nbsp; Multiple &nbsp;&middot;&nbsp;
     Normality &middot; Linearity &middot; Multicollinearity &middot;
     Heteroscedasticity &middot; Autocorrelation &middot; Outliers</p>
</div>""", unsafe_allow_html=True)

st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:.9rem;margin-bottom:.4rem;">
    &#9749; Support this work &mdash; scan QRIS:</p>
  <img src="https://muhaiminabdullah.com/media/thumbnails/QRIS-muhaiminabdullahdotcom-340x480.jpeg"
       style="width:180px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("### &#9881;&#65039; Configuration")
    st.markdown("---")

    reg_type = st.selectbox(
        "&#128202; Regression Type",
        ["Simple Linear Regression", "Multiple Linear Regression"],
        index=(0 if st.session_state.get("selected_test", "")
               == "Linear Regression" else
               1 if st.session_state.get("selected_test", "")
               == "Multiple Regression" else 0),
    )
    alpha = st.selectbox("\u03b1 Significance Level",
                         [0.05, 0.01, 0.001], index=0)
    st.markdown("---")

    # Sample data
    samp_key = ("Linear Regression" if "Simple" in reg_type
                else "Multiple Regression")
    samp = SAMPLES[samp_key]
    st.markdown(f"**&#128196; Sample Data**")
    st.markdown(f'<p style="font-size:.8rem;color:#64748b;">{samp["note"]}</p>',
                unsafe_allow_html=True)
    st.download_button(
        "&#11015;&#65039; Download Sample CSV",
        samp["csv"].encode(),
        f"sample_{samp_key.replace(' ','_').lower()}.csv",
        "text/csv", use_container_width=True,
    )
    st.markdown("---")

    # File upload
    uploaded = st.file_uploader(
        "&#128194; Upload Data File",
        type=["csv", "xlsx", "xls"],
    )
    if uploaded:
        try:
            df = load_file(uploaded)
            fm = file_metadata(uploaded, df)
            val = validate_file(df)
            if val["errors"]:
                for e in val["errors"]: st.error(e)
                df = None
            else:
                st.success(f"&#10003; {fm['Rows']:,} rows \u00d7 {fm['Columns']} cols")
                for w in val["warnings"]: st.warning(w)
        except Exception as e:
            st.error(str(e)); df = None
    else:
        df = load_from_string(samp["csv"])
        st.info("\u2139\ufe0f Using built-in sample data")

    # Variable selection
    cfg = None
    if df is not None:
        num_cols = get_numeric_cols(df)
        st.markdown("---")

        # Detect and warn about likely ID columns
        def _is_id_col(col, series):
            col_lower = col.lower().strip()
            id_names  = {'id','no','num','number','index','code','nomor',
                         'subject_id','respondent','participant','sampel'}
            id_suffixes = ('_id','_no','_num','_number','_code','_index')
            id_prefixes = ('id_','no_','num_')
            name_match = (col_lower in id_names or
                          any(col_lower.endswith(s) for s in id_suffixes) or
                          any(col_lower.startswith(s) for s in id_prefixes))
            if not name_match:
                return False
            s = series.dropna()
            if len(s) == 0:
                return False
            try:
                return bool((s == s.astype(int)).all()) and s.nunique() == len(s)
            except Exception:
                return False

        id_cols = [c for c in num_cols if _is_id_col(c, df[c])]
        if id_cols:
            pass  # subject_id excluded from defaults silently

        # Default Y: prefer known outcome names, skip ID cols
        non_id = [c for c in num_cols if c not in id_cols]
        _y_defaults = ["outcome", "exam_score", "score", "y"]
        _y_default_idx = next(
            (num_cols.index(c) for c in _y_defaults if c in num_cols),
            num_cols.index(non_id[-1]) if non_id else len(num_cols) - 1
        )
        # Safety clamp — prevents IndexError with any dataset
        _y_default_idx = min(_y_default_idx, max(0, len(num_cols) - 1))
        y_col = st.selectbox(
            "&#127919; Dependent Variable (Y)", num_cols,
            index=_y_default_idx,
        )
        remaining = [c for c in num_cols if c != y_col]
        # Default predictors: exclude ID columns
        remaining_non_id = [c for c in remaining if c not in id_cols]

        if "Simple" in reg_type:
            # index must refer to position within `remaining` (the options list)
            _x_default_idx = (remaining.index(remaining_non_id[0])
                              if remaining_non_id and remaining_non_id[0] in remaining
                              else 0)
            _x_default_idx = min(_x_default_idx, max(0, len(remaining) - 1))
            x_col  = st.selectbox("&#128200; Predictor (X)", remaining,
                                   index=_x_default_idx)
            x_cols = [x_col]
        else:
            x_cols = st.multiselect(
                "&#128200; Predictors (X\u2081, X\u2082, \u2026)",
                remaining,
                default=remaining_non_id[:min(3, len(remaining_non_id))],
            )
            if len(x_cols) < 2:
                st.warning("Select at least 2 predictors."); x_cols = None

        if x_cols:
            cfg = {"y_col": y_col, "x_cols": x_cols}

        st.markdown("---")
        run_btn = st.button("&#128640; Run Analysis",
                             type="primary", use_container_width=True)
    else:
        run_btn = False

# ══════════════════════════════════════════════════════════════════════════════
# DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════
if df is not None:
    with st.expander("&#128269; Data Preview", expanded=False):
        st.dataframe(df.head(20), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# WELCOME STATE
# ══════════════════════════════════════════════════════════════════════════════
if not run_btn and "reg_R" not in st.session_state:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        f'border:1px solid #bae6fd;border-radius:12px;'
        f'padding:1.2rem 1.4rem;margin:.8rem 0;border-left:4px solid #0284c7;">'
        f'<h4 style="margin:0 0 .4rem;font-size:.95rem;font-weight:700;">'
        f'&#128203; {reg_type}</h4>'
        f'<p style="margin:0;font-size:.84rem;color:#475569;">'
        f'{samp["desc"]}</p></div>',
        unsafe_allow_html=True,
    )
    st.info("&#128072; Configure variables in the sidebar, then click **Run Analysis**.")
    st.stop()

# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("&#9888;&#65039; Variable configuration is incomplete."); st.stop()

    with st.spinner("Running regression analysis\u2026"):
        try:
            y    = df[cfg["y_col"]].astype(float)
            X_df = df[cfg["x_cols"]].astype(float)
            valid_idx = y.notna() & X_df.notna().all(axis=1)
            y    = y[valid_idx].reset_index(drop=True)
            X_df = X_df[valid_idx].reset_index(drop=True)

            R = run_full_regression(y, X_df, y_name=cfg["y_col"], alpha=alpha)

            meta = {
                "Test":                   reg_type,
                "Dependent Variable (Y)": cfg["y_col"],
                "Predictor(s) (X)":       ", ".join(cfg["x_cols"]),
                "N":                      R["n"],
                "\u03b1":                 alpha,
                "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
            }
            interps = _interpret_regression(R, alpha)
            apa     = _build_apa_regression(R, alpha)

            # Plots
            fig_diag = plot_regression_diagnostics(R)
            figs_b   = [fig_to_bytes(fig_diag)]
            plt.close(fig_diag)
            if R["k"] == 1:
                x_arr = X_df[cfg["x_cols"][0]].values
                y_arr = y.values
                import statsmodels.api as sm_l
                m_simple = sm_l.OLS(y_arr,
                                     sm_l.add_constant(x_arr)).fit()
                fig_sc = plot_scatter_simple(
                    x_arr, y_arr, cfg["x_cols"][0], cfg["y_col"], m_simple)
            else:
                fig_sc = plot_obs_vs_fitted(
                    R["fitted"].values, y.values, cfg["y_col"])
            figs_b.append(fig_to_bytes(fig_sc))
            plt.close(fig_sc)

        except ZeroDivisionError:
            st.error(
                "&#9888;&#65039; **Analysis could not be completed: insufficient data.**\n\n"
                "The regression analysis requires at least **3 observations** and more observations "
                "than predictors. Please ensure your dataset has enough valid data points."
            )
            st.stop()

        except ValueError as e:
            import traceback as _tb
            st.error(f"ValueError: {e}")
            st.code(_tb.format_exc())
            st.stop()

        except Exception as e:
            msg = str(e).lower()
            if "division by zero" in msg or "divide by zero" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: insufficient data.**\n\n"
                    "Please ensure your dataset has more observations than predictors, "
                    "and that all variables contain valid numeric data."
                )
            elif "singular" in msg or "not invertible" in msg or "multicollinear" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: perfect multicollinearity detected.**\n\n"
                    "Two or more of your predictors are perfectly correlated with each other. "
                    "Please remove one of the correlated predictors and re-run the analysis."
                )
            elif "column" in msg or "key" in msg or "not found" in msg:
                st.error(
                    "&#9888;&#65039; **A required column was not found in your data.**\n\n"
                    "Please check that the selected variable names match the column names "
                    "in your uploaded file."
                )
            else:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed.**\n\n"
                    "Please check that:\n"
                    "- All selected variables contain valid numeric data.\n"
                    "- The dataset has more observations than predictors.\n"
                    "- The correct columns have been selected in the sidebar.\n\n"
                    f"Technical detail (for reference): {e}"
                )
            st.stop()
    st.session_state.update({
        "reg_R":      R,
        "reg_meta":   meta,
        "reg_interps": interps,
        "reg_apa":    apa,
        "reg_figs":   figs_b,
        "reg_alpha":  alpha,
        "reg_cfg":    cfg,
        "reg_type":   reg_type,
    })

# ══════════════════════════════════════════════════════════════════════════════
# LOAD FROM SESSION
# ══════════════════════════════════════════════════════════════════════════════
R        = st.session_state["reg_R"]
meta     = st.session_state["reg_meta"]
interps  = st.session_state["reg_interps"]
apa      = st.session_state["reg_apa"]
figs_b   = st.session_state["reg_figs"]
alpha    = st.session_state.get("reg_alpha", 0.05)

st.success("&#10003; Analysis complete!")

# ══════════════════════════════════════════════════════════════════════════════
# ASSUMPTION STATUS BANNER
# ══════════════════════════════════════════════════════════════════════════════
all_ok = R["all_assumptions_met"]
cls    = "use-param" if all_ok else "use-nonparam"
txt    = ("\u2713 All classical assumptions satisfied \u2192 "
          "<b>Regression results are fully valid.</b>"
          if all_ok else
          "\u26a0 One or more assumptions violated. "
          "Interpret results with caution.")
st.markdown(f'<div class="decision-banner {cls}">{txt}</div>',
            unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# QUICK METRICS
# ══════════════════════════════════════════════════════════════════════════════
cols = st.columns(5)
metrics = [
    (_f(R["R"]),        "R"),
    (_f(R["R2"]),       "R\u00b2"),
    (_f(R["adj_R2"]),   "Adjusted R\u00b2"),
    (_f(R["F"]),        f"F({R['df_reg']},\u2009{R['df_res']})"),
    (_p(R["p_F"]),      "Sig."),
]
for col, (val, lbl) in zip(cols, metrics):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{val}</div>'
        f'<div class="metric-lbl">{lbl}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
st.markdown("<br>", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab_labels = [
    "&#128203; Assumptions",
    "&#128202; Model Summary",
    "&#9889; Effect Size & Power",
    "&#128200; Plots",
    "&#128172; Interpretation",
]
tabs = st.tabs(tab_labels)

# ── Tab: Assumptions ────────────────────────────────────────────────────────
with tabs[0]:
    nm   = R["normality"]
    prim = nm["primary_label"]
    n    = nm["total_n"]
    size = "Total N\u2009<\u200950" if n < 50 else "Total N\u2009\u2265\u200950"

    # 1. Normality
    st.markdown('<div class="sec-title">1. Normality of Residuals</div>',
                unsafe_allow_html=True)
    from utils.tables import normality_table
    # Show both Unstandardized and Standardized (SPSS style — same values, scale-invariant)
    nm_unstd = dict(nm); nm_unstd["label"] = "Unstandardized Residual"
    nm_std   = dict(nm); nm_std["label"]   = "Standardized Residual"
    sw_html, ks_html = normality_table([nm_unstd, nm_std], prim)
    st.markdown('<div class="sub-title">Shapiro-Wilk Test</div>',
                unsafe_allow_html=True)
    st.markdown(sw_html, unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Kolmogorov-Smirnov Test (Lilliefors)</div>',
                unsafe_allow_html=True)
    st.markdown(ks_html, unsafe_allow_html=True)
    st.markdown(
        f'<div class="info-box" style="margin-top:.5rem;">{KS_DISCLAIMER}</div>',
        unsafe_allow_html=True)
    if nm["pass"]:
        st.markdown(
            f'<div class="info-box">&#10003; <b>{prim}</b> ({size}) p\u2009>\u2009.05 '
            f'\u2192 Normality of residuals satisfied.</div>',
            unsafe_allow_html=True)
    else:
        st.markdown(
            f'<div class="warn-box">&#9888; <b>{prim}</b> ({size}) p\u2009\u2264\u2009.05 '
            f'\u2192 Normality violated. Consider log-transforming Y.</div>',
            unsafe_allow_html=True)

    # 2. Linearity
    st.markdown('<div class="sec-title">2. Linearity Tests</div>',
                unsafe_allow_html=True)
    for xn, lr in R["linearity"].items():
        st.markdown(f'<div class="sub-title">{xn} \u2192 {R["y_name"]}</div>',
                    unsafe_allow_html=True)
        ss_comb = lr.get("ss_between", lr["ss_reg"])
        lin_rows = [["Source","SS","df","MS","F","Sig."]]
        lin_rows += [
            ["Between Groups (Combined)",
             _f(ss_comb), str(lr.get("df_groups","\u2014")),
             _f(lr.get("ms_between",float("nan"))),
             _f(lr.get("F_between",float("nan"))),
             _p(lr.get("p_between",float("nan")))],
            ["\u00a0\u00a0Linearity",
             _f(lr["ss_reg"]), str(lr["df_lin"]),
             _f(lr["ms_lin"]), _f(lr["F_lin"]), _p(lr["p_lin"])],
            ["\u00a0\u00a0Deviation from Linearity",
             _f(lr.get("ss_dev",float("nan"))),
             str(lr["df_dev"]) if lr["df_dev"] > 0 else "\u2014",
             _f(lr.get("ms_dev",float("nan"))),
             _f(lr.get("F_dev",float("nan"))),
             _p(lr.get("p_dev",float("nan")))],
            ["Within Groups",
             _f(lr.get("ss_within",float("nan"))),
             str(lr["df_within"]),
             _f(lr.get("ms_within",float("nan"))), "\u2014", "\u2014"],
        ]
        st.markdown(html_tbl(lin_rows, left_cols={0}),
                    unsafe_allow_html=True)
        if lr["passed"]:
            st.markdown(
                '<div class="info-box">&#10003; Linearity satisfied.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="warn-box">&#9888; Linearity violated. '
                'Consider transforming the predictor.</div>',
                unsafe_allow_html=True)

    # 3. Multicollinearity
    if R["multicollinearity"] is not None:
        st.markdown('<div class="sec-title">3. Multicollinearity (VIF)</div>',
                    unsafe_allow_html=True)
        mc  = R["multicollinearity"]
        mc_rows = [["Variable","Tolerance","VIF","Status"]]
        for _, row in mc.iterrows():
            mc_rows.append([row["Variable"], _f(row["Tolerance"]),
                            _f(row["VIF"]), row["Status"]])
        st.markdown(html_tbl(mc_rows, left_cols={0,3}),
                    unsafe_allow_html=True)
        mc_ok = bool((mc["VIF"] < 10).all())
        if mc_ok:
            st.markdown(
                '<div class="info-box">&#10003; No multicollinearity detected '
                '(all VIF\u2009<\u200910).</div>', unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="warn-box">&#9888; Multicollinearity detected '
                '(VIF\u2009\u2265\u200910). Consider removing or combining predictors.'
                '</div>', unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">VIF\u2009&lt;\u20095: no concern. '
            '5\u2013\u200910: moderate. &gt;\u200910: violation.</p>',
            unsafe_allow_html=True)

    # 4. Heteroscedasticity
    st.markdown('<div class="sec-title">4. Heteroscedasticity \u2014 Glejser Test</div>',
                unsafe_allow_html=True)
    g_df  = R["heteroscedasticity"]["coef_df"]
    g_rows = [["Term","B","Std. Error","t","Sig."]]
    for _, row in g_df.iterrows():
        g_rows.append([row["Term"], _f(row["B"]),
                       _f(row["Std. Error"]), _f(row["t"]),
                       _p(row["Sig."])])
    st.markdown(html_tbl(g_rows, left_cols={0}), unsafe_allow_html=True)
    if R["heteroscedasticity"]["passed"]:
        st.markdown(
            '<div class="info-box">&#10003; No heteroscedasticity '
            '(all predictor Sig.\u2009>\u2009.05).</div>',
            unsafe_allow_html=True)
    else:
        st.markdown(
            '<div class="warn-box">&#9888; Heteroscedasticity detected. '
            'Consider log-transforming Y or using WLS.</div>',
            unsafe_allow_html=True)

    # 5. Autocorrelation
    st.markdown('<div class="sec-title">5. Autocorrelation \u2014 Durbin-Watson</div>',
                unsafe_allow_html=True)
    auto = R["autocorrelation"]
    dw_rows = [["Durbin-Watson","Acceptable Range","Interpretation","Decision"],
               [_f(auto["dw"]), "1.5\u2009\u2013\u20092.5",
                auto["interpretation"],
                "\u2713 Satisfied" if auto["passed"] else "\u2717 Violated"]]
    st.markdown(html_tbl(dw_rows, left_cols={2,3}), unsafe_allow_html=True)

    # 6. Outliers
    st.markdown('<div class="sec-title">6. Outliers \u2014 Cook\u2019s Distance</div>',
                unsafe_allow_html=True)
    out = R["outliers"]
    out_rows = [["Threshold (4/n)","Influential Observations","Decision"],
                [_f(out["threshold"]), str(out["n_influential"]),
                 "\u2713 No influential outliers" if out["passed"]
                 else f"\u2717 {out['n_influential']} outlier(s) detected"]]
    st.markdown(html_tbl(out_rows, left_cols={2}), unsafe_allow_html=True)
    st.markdown(f'<p class="note-txt">{out["note"]}</p>',
                unsafe_allow_html=True)

    # Assumption summary
    st.markdown('<div class="sec-title">&#9989; Assumption Summary</div>',
                unsafe_allow_html=True)
    nm_ok  = nm["pass"]
    lin_ok = all(v["passed"] for v in R["linearity"].values())
    mc_ok2 = bool((R["multicollinearity"]["VIF"] < 10).all())
    het_ok = R["heteroscedasticity"]["passed"]
    aut_ok = auto["passed"]
    out_ok = out["passed"]

    sum_rows = [["Assumption","Key Statistic","Decision"]]
    sum_rows.append([
        "1. Normality",
        f"{nm['primary_label']} p\u2009=\u2009{_p(nm['sw_p'] if nm['primary']=='sw' else nm['ks_p'])}",
        "\u2713 Satisfied" if nm_ok else "\u2717 Violated"
    ])
    for xn, lr in R["linearity"].items():
        sum_rows.append([
            f"2. Linearity ({xn})",
            f"Sig. Linearity\u2009=\u2009{_p(lr['p_lin'])}",
            "\u2713 Satisfied" if lr["passed"] else "\u2717 Violated"
        ])
    if R["multicollinearity"] is not None:
        mc = R["multicollinearity"]
        sum_rows.append([
            "3. Multicollinearity",
            f"Max VIF\u2009=\u2009{_f(float(mc['VIF'].max()))}",
            "\u2713 Satisfied" if mc_ok2 else "\u2717 Violated"
        ])
    sum_rows += [
        ["4. Heteroscedasticity",
         f"Glejser \u2014 {R['heteroscedasticity']['note'][:40]}\u2026",
         "\u2713 Satisfied" if het_ok else "\u2717 Violated"],
        ["5. Autocorrelation",
         f"DW\u2009=\u2009{_f(auto['dw'])}",
         "\u2713 Satisfied" if aut_ok else "\u2717 Violated"],
        ["6. Outliers",
         f"Cook\u2019s D threshold\u2009=\u2009{_f(out['threshold'])}",
         "\u2713 No influential outliers" if out_ok
         else f"\u2717 {out['n_influential']} outlier(s)"],
        ["<b>Overall</b>", "\u2014",
         "<b>\u2713 All Satisfied</b>" if all_ok
         else "<b>\u2717 Review Violations</b>"],
    ]
    st.markdown(html_tbl(sum_rows, left_cols={0,1}), unsafe_allow_html=True)

# ── Tab: Model Summary ───────────────────────────────────────────────────────
with tabs[1]:
    st.markdown('<div class="sec-title">Model Summary</div>',
                unsafe_allow_html=True)
    ms_rows = [["R","R\u00b2","Adjusted R\u00b2",
                "Std. Error of the Estimate","Durbin-Watson"],
               [_f(R["R"]), _f(R["R2"]), _f(R["adj_R2"]),
                _f(R["se_est"]), _f(R["autocorrelation"]["dw"])]]
    st.markdown(html_tbl(ms_rows), unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">'
        f'R\u00b2\u2009=\u2009{_f(R["R2"])}: {R["R2"]*100:.1f}% of variance in '
        f'{R["y_name"]} is explained by the predictor(s).</p>',
        unsafe_allow_html=True)

    st.markdown('<div class="sec-title">ANOVA</div>', unsafe_allow_html=True)
    an_rows = [["Model","Sum of Squares","df","Mean Square","F","Sig."]]
    an_rows += [
        ["Regression", _f(R["ss_reg"]), str(R["df_reg"]),
         _f(R["ms_reg"]), _f(R["F"]), _p(R["p_F"])],
        ["Residual",   _f(R["ss_res"]), str(R["df_res"]),
         _f(R["ms_res"]), "\u2014", "\u2014"],
        ["Total",      _f(R["ss_tot"]), str(R["df_tot"]),
         "\u2014",     "\u2014", "\u2014"],
    ]
    st.markdown(html_tbl(an_rows, left_cols={0}), unsafe_allow_html=True)

    st.markdown('<div class="sec-title">Coefficients</div>',
                unsafe_allow_html=True)
    c_rows = [["Model","B","Std. Error","Beta","t","Sig.",
               "95% CI Lower","95% CI Upper"]]
    for _, row in R["coef_df"].iterrows():
        c_rows.append([
            row["Model"], _f(row["B"]), _f(row["Std. Error"]),
            _f(row["Beta"]) if row["Beta"] != "" else "\u2014",
            _f(row["t"]), _p(float(row["Sig."])),
            _f(row["95% CI Lower"]), _f(row["95% CI Upper"]),
        ])
    st.markdown(html_tbl(c_rows, left_cols={0}), unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">Beta = standardised coefficient. '
        '95% CI based on t-distribution. * p\u2009<\u2009.05.</p>',
        unsafe_allow_html=True)

# ── Tab: Model Summary ───────────────────────────────────────────────────────
with tabs[1]:
    # 1. Descriptive Statistics
    st.markdown('<div class="sec-title">Descriptive Statistics</div>', unsafe_allow_html=True)
    full_desc = R["full_desc"]
    fd_rows = [list(full_desc.columns)]
    for _, row in full_desc.iterrows():
        fd_rows.append([str(row["Variable"])] +
                       [_f(row[c]) if isinstance(row[c], float) else str(row[c])
                        for c in full_desc.columns[1:]])
    st.markdown(html_tbl(fd_rows, left_cols={0}), unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">5% Trimmed Mean: SPSS partial trimming. '
        'Skewness and Kurtosis: bias-corrected (Fisher). '
        'IQR = Q3 \u2212 Q1. 95% CI: t-distribution.</p>',
        unsafe_allow_html=True)

    # 2. Correlations
    st.markdown('<div class="sec-title">Correlations</div>', unsafe_allow_html=True)
    corr  = R["correlations"]
    vars_ = corr["vars"]
    for stat_lbl, df_ in [("Pearson Correlation", corr["r_df"]),
                           ("Sig. (1-tailed)",     corr["p_df"]),
                           ("N",                   corr["n_df"])]:
        rows_ = [[""] + vars_]
        for var in vars_:
            vals = [var]
            for col_ in vars_:
                v = df_.loc[var, col_]
                if stat_lbl == "Pearson Correlation":
                    vals.append("." if var == col_ else _f(v))
                elif stat_lbl == "Sig. (1-tailed)":
                    vals.append("." if var == col_ else _p(v))
                else:
                    vals.append(str(int(v)) if not np.isnan(float(v)) else ".")
            rows_.append(vals)
        st.markdown(
            f'<p style="font-size:.8rem;font-weight:600;margin:.8rem 0 .3rem;">{stat_lbl}</p>',
            unsafe_allow_html=True)
        st.markdown(html_tbl(rows_, left_cols={0}), unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">Sig. (1-tailed) reported as per SPSS default. '
        '** p\u2009&lt;\u2009.01, * p\u2009&lt;\u2009.05.</p>',
        unsafe_allow_html=True)

    # 3. Variables Entered
    st.markdown('<div class="sec-title">Variables Entered/Removed</div>', unsafe_allow_html=True)
    ve = R["vars_entered"]
    ve_rows = [list(ve.columns)]
    for _, row in ve.iterrows():
        ve_rows.append([str(v) for v in row])
    st.markdown(html_tbl(ve_rows, left_cols={0,1,2,3}), unsafe_allow_html=True)

    # 4. Model Summary with change statistics
    st.markdown('<div class="sec-title">Model Summary</div>', unsafe_allow_html=True)
    ms  = R["model_summary"]
    ms_rows = [["Model","R","R\u00b2","Adjusted R\u00b2",
                "Std. Error of the Estimate",
                "R\u00b2 Change","F Change","df1","df2",
                "Sig. F Change","Durbin-Watson"]]
    for _, row in ms.iterrows():
        ms_rows.append([
            str(int(row["Model"])),
            _f(row["R"]), _f(row["R Square"]), _f(row["Adjusted R Square"]),
            _f(row["Std. Error of the Estimate"]),
            _f(row["R Square Change"]),
            _f(row["F Change"]), str(int(row["df1"])), str(int(row["df2"])),
            _p(row["Sig. F Change"]) if not np.isnan(float(row["Sig. F Change"])) else ".",
            _f(row["Durbin-Watson"]),
        ])
    st.markdown(html_tbl(ms_rows), unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">'
        f'<b>a.</b> Predictors: (Constant), {", ".join(R["x_names"])}. '
        f'<b>b.</b> Dependent Variable: {R["y_name"]}.<br>'
        f'R\u00b2\u2009=\u2009{_f(R["R2"])}: {R["R2"]*100:.1f}% of variance explained. '
        f'Adjusted R\u00b2 corrects for number of predictors and sample size.</p>',
        unsafe_allow_html=True)

    # 5. ANOVA
    st.markdown('<div class="sec-title">ANOVA</div>', unsafe_allow_html=True)
    an_rows = [["Model","","Sum of Squares","df","Mean Square","F","Sig."]]
    an_rows += [
        ["1","Regression", _f(R["ss_reg"]), str(R["df_reg"]),
         _f(R["ms_reg"]), _f(R["F"]), _p(R["p_F"])],
        ["", "Residual",   _f(R["ss_res"]), str(R["df_res"]),
         _f(R["ms_res"]), "\u2014", "\u2014"],
        ["", "Total",      _f(R["ss_tot"]), str(R["df_tot"]),
         "\u2014", "\u2014", "\u2014"],
    ]
    st.markdown(html_tbl(an_rows, left_cols={0,1}), unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">'
        f'<b>a.</b> Dependent Variable: {R["y_name"]}. '
        f'<b>b.</b> Predictors: (Constant), {", ".join(R["x_names"])}.</p>',
        unsafe_allow_html=True)

    # 6. Coefficients — full SPSS + beyond
    st.markdown('<div class="sec-title">Coefficients</div>', unsafe_allow_html=True)
    alpha_ = R["alpha"]
    ci_lo  = f"{int((1-alpha_)*100)}% CI Lower"
    ci_hi  = f"{int((1-alpha_)*100)}% CI Upper"
    pc     = R["partial_corr"]
    bc     = R["boot_ci"]
    mc_df  = R["multicollinearity"]
    c_rows = [["Model","B","Std. Error","Beta","t","Sig.",
               ci_lo, ci_hi,
               "Zero-order","Partial r","Part r",
               "Tolerance","VIF",
               "Bootstrap CI Lower","Bootstrap CI Upper"]]
    for _, row in R["coef_df"].iterrows():
        xn = row["Model"]
        if not pc.empty and xn in pc["Variable"].values:
            pc_r = pc[pc["Variable"]==xn].iloc[0]
            zo_  = _f(pc_r.get("Zero-order", np.nan))
            pr_  = _f(pc_r.get("Partial r",  np.nan))
            sr_  = _f(pc_r.get("Part r",     np.nan))
        else:
            zo_ = pr_ = sr_ = "\u2014"
        if mc_df is not None and not mc_df.empty and xn in mc_df["Variable"].values:
            mc_r = mc_df[mc_df["Variable"]==xn].iloc[0]
            tol_ = _f(mc_r["Tolerance"]); vif_ = _f(mc_r["VIF"])
        else:
            tol_ = vif_ = "\u2014"
        bl, bu = bc.get(xn, (np.nan, np.nan))
        c_rows.append([
            xn, _f(row["B"]), _f(row["Std. Error"]),
            _f(row["Beta"]) if row["Beta"] != "" else "\u2014",
            _f(row["t"]), _p(float(row["Sig."])),
            _f(row.get(ci_lo, np.nan)), _f(row.get(ci_hi, np.nan)),
            zo_, pr_, sr_, tol_, vif_, _f(bl), _f(bu),
        ])
    st.markdown(html_tbl(c_rows, left_cols={0}), unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">'
        f'<b>a.</b> Dependent Variable: {R["y_name"]}.<br>'
        f'Beta = standardised coefficient. '
        f'Zero-order r = bivariate Pearson. '
        f'Partial r = unique association controlling other predictors. '
        f'Part r = unique contribution to R\u00b2. '
        f'Bootstrap CI: 2,000 resamples, percentile method (seed=42).</p>',
        unsafe_allow_html=True)

    # Equation + interpretation
    st.markdown(
        f'<div style="background:#f1f5f9;border:2px solid #e94560;'
        f'border-radius:10px;padding:1rem;font-family:monospace;'
        f'font-size:1rem;text-align:center;margin:1rem 0;">'
        f'{R["equation"]}</div>',
        unsafe_allow_html=True)
    st.markdown(
        f'<div class="interp-box">{R.get("eq_interpretation","")}</div>',
        unsafe_allow_html=True)

    # 7. Collinearity Diagnostics
    if R["collinearity_diag"] is not None:
        st.markdown('<div class="sec-title">Collinearity Diagnostics</div>',
                    unsafe_allow_html=True)
        cd = R["collinearity_diag"]
        cd_rows = [list(cd.columns)]
        for _, row in cd.iterrows():
            cd_rows.append(
                [str(int(row["Dimension"])),
                 _f(row["Eigenvalue"]), _f(row["Condition Index"])] +
                [_f(row[c]) for c in cd.columns[3:]]
            )
        st.markdown(html_tbl(cd_rows), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">Condition Index\u2009&gt;\u200930 with variance '
            'proportions\u2009&gt;\u2009.50 for two or more predictors indicates '
            'multicollinearity (Belsley et al., 1980). '
            'Method: SVD of column-norm-scaled [1|X] matrix (SPSS-equivalent).</p>',
            unsafe_allow_html=True)

    # 8. Residuals Statistics
    st.markdown('<div class="sec-title">Residuals Statistics</div>',
                unsafe_allow_html=True)
    rs = R["residuals_stats"]
    rs_rows = [list(rs.columns)]
    for _, row in rs.iterrows():
        rs_rows.append(
            [str(row.iloc[0])] +
            [_f(row[c]) if isinstance(row[c], float) else str(row[c])
             for c in rs.columns[1:]]
        )
    st.markdown(html_tbl(rs_rows, left_cols={0}), unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">Dependent Variable: {R["y_name"]}.</p>',
        unsafe_allow_html=True)

with tabs[2]:
    st.markdown('<div class="sec-title">Effect Size \u2014 Cohen\u2019s f\u00b2</div>',
                unsafe_allow_html=True)
    es_rows = [["Measure","Value","Interpretation"],
               ["Cohen\u2019s f\u00b2", _f(R["f2"]), R["f2_label"]],
               ["Cohen\u2019s f",  _f(R["f"]),  R["f2_label"]],
               ["R\u00b2",         _f(R["R2"]),
                f"{R['R2']*100:.1f}% variance explained"],
               ["Adjusted R\u00b2", _f(R["adj_R2"]),
                "Corrected for k and n"],
               ]
    st.markdown(html_tbl(es_rows, left_cols={0, 2}),
                unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">Cohen (1988) benchmarks for f\u00b2: '
        '\u2265\u2009.02 small, \u2265\u2009.15 medium, \u2265\u2009.35 large. '
        'f\u00b2 = R\u00b2 / (1\u2009\u2212\u2009R\u00b2).</p>',
        unsafe_allow_html=True)

    st.markdown('<div class="sec-title">Statistical Power Assessment</div>',
                unsafe_allow_html=True)
    pwr_val = R["power"]
    pw_rows = [["Parameter","Value"],
               ["Sample size (n)", str(R["n"])],
               ["Number of predictors (k)", str(R["k"])],
               ["Effect size (f\u00b2)",
                _f(R["f2"]) + f" ({R['f2_label']})"],
               ["Significance level (\u03b1)", str(alpha)],
               ["Achieved statistical power",
                f"{pwr_val*100:.1f}%" if not np.isnan(pwr_val) else "N/A"],
               ["Power classification",
                power_label(pwr_val) if not np.isnan(pwr_val) else "N/A"],
               ["Recommended minimum", "\u2265\u2009.80 (Cohen, 1988)"],
               ["Minimum n for power\u2009=\u2009.80",
                str(R["n_required"]) if R["n_required"] else "N/A"],
               ]
    st.markdown(html_tbl(pw_rows, left_cols={0}), unsafe_allow_html=True)

    if not np.isnan(pwr_val):
        bar_c   = ("#16a34a" if pwr_val >= .80
                   else "#f59e0b" if pwr_val >= .60 else "#dc2626")
        bar_pct = int(pwr_val * 100)
        st.markdown(
            f'<div style="background:#e2e8f0;border-radius:8px;'
            f'height:18px;width:100%;margin:8px 0;">'
            f'<div style="background:{bar_c};width:{bar_pct}%;'
            f'height:18px;border-radius:8px;"></div></div>',
            unsafe_allow_html=True)
        if pwr_val < .80:
            st.markdown(
                '<div class="warn-box">&#9888; Achieved power is below .80. '
                'Consider increasing the sample size.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="info-box">&#10003; Adequate power '
                '(\u2265\u2009.80).</div>',
                unsafe_allow_html=True)

    st.markdown(
        '<p class="note-txt">Post-hoc power via non-central F-distribution. '
        'Reference: Cohen (1988); Faul et al. (2007).</p>',
        unsafe_allow_html=True)

# ── Tab: Plots ───────────────────────────────────────────────────────────────
with tabs[3]:
    for fb in figs_b:
        st.image(fb, use_container_width=True)

# ── Tab: Interpretation ───────────────────────────────────────────────────────
with tabs[4]:
    st.markdown("### &#128221; Statistical Interpretation")
    for line in interps:
        lw  = line.lower()
        cls = ("sig" if "statistically significant" in lw
                        and "not statistically significant" not in lw
               else "nonsig" if "not statistically significant" in lw else "")
        st.markdown(f'<div class="interp-box {cls}">{line}</div>',
                    unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**APA 7th Edition Write-Up:**")
    apa_plain = re.sub(r"<[^>]+>", "", apa)
    st.code(apa_plain, language=None)

# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
st.markdown("### &#128229; Download Results")
dc1, dc2 = st.columns(2)

with dc1:
    with st.spinner("Generating HTML report\u2026"):
        html_data = _build_html_regression(
            R, meta, interps, apa, figs_b, alpha)
    st.download_button(
        "&#127760; HTML Report (Full)",
        html_data,
        f"Regression_{R['y_name']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
        "text/html", use_container_width=True,
    )

with dc2:
    csv_data = _build_csv_regression(R, meta, interps, apa, alpha)
    st.download_button(
        "&#128221; CSV Tables",
        csv_data,
        f"Regression_{R['y_name']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        "text/csv", use_container_width=True,
    )
