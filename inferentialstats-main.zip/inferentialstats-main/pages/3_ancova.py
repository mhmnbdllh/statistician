"""
pages/3_ancova.py
=================
Streamlit page for ANCOVA family analysis.

Tests available:
  - One-Way ANCOVA
  - Factorial ANCOVA
  - Repeated Measures ANCOVA
  - Mixed ANCOVA
  - MANCOVA

Features:
  - SPSS-equivalent output (Type III SS, GG correction)
  - Normality criterion based on Total N
  - Partial η², Cohen's f, Power
  - Multiple post-hoc methods (LSD, Bonferroni, Sidak, Scheffe)
  - Mauchly's sphericity + GG epsilon
  - Multivariate tests (Wilks, Pillai, Hotelling, Roy)
  - EMMs + Pairwise comparisons
  - APA interpretation
  - HTML report + CSV download
"""

import streamlit as st
import pandas as pd
import numpy as np
import re
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="ANCOVA | Inferential Statistics by MA",
    page_icon="🎛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports ────────────────────────────────────────────────────────────────
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols,
                                get_categorical_cols)
from utils.samples     import SAMPLES
from utils.formatters  import _f, _p
from utils.tables      import html_tbl, normality_table

from modules.ancova    import (run_one_way_ancova, run_factorial_ancova,
                                run_rm_ancova, run_mixed_ancova, run_mancova)
from modules.normality import (recommendation_note, KS_DISCLAIMER,
                                get_primary_label, get_total_n,
                                test_normality)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import io, base64

PAL = ["#1a1a2e", "#e94560", "#0f3460", "#16213e",
       "#7c3aed", "#0891b2", "#16a34a", "#b45309"]
BG  = "#f8fafc"


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _style_ax(ax):
    ax.set_facecolor(BG)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.3, linestyle="--")

def _fig_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=120, bbox_inches="tight", facecolor=BG)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode()

def _effect_label(eta2):
    if np.isnan(eta2): return "N/A"
    if eta2 < .01:  return "negligible"
    if eta2 < .06:  return "small"
    if eta2 < .14:  return "medium"
    return "large"

def _is_id_col(col, series):
    cl = col.lower().strip()
    id_n = {'id','no','num','number','index','code','subject_id',
            'respondent','participant','sampel','nomor','subject'}
    id_s = ('_id','_no','_num','_number','_code','_index')
    id_p = ('id_','no_','num_','subject')
    nm = (cl in id_n or any(cl.endswith(s) for s in id_s)
          or any(cl.startswith(s) for s in id_p))
    if not nm: return False
    s = series.dropna()
    try: return bool((s == s.astype(int)).all()) and s.nunique() == len(s)
    except: return False

def _guess_covariate(cols):
    """Guess the covariate column for RM/Mixed ANCOVA by name.
    Time-point columns form a series (time1/2/3, pre/mid/post); the covariate
    is a baseline/demographic measure. Returns the best covariate candidate."""
    kws = ['baseline','base_line','age','iq','covariate','_cov','ses',
           'income','weight','height','bmi','aptitude','motivation']
    for c in cols:
        cl = c.lower()
        if any(kw in cl for kw in kws):
            return c
    # Fallback: a column NOT matching time-series patterns
    time_pat = ('time','wave','t1','t2','t3','t4','pre','mid','post','week','month','day')
    non_time = [c for c in cols if not any(p in c.lower() for p in time_pat)]
    if non_time:
        return non_time[0]
    return cols[-1] if cols else None

def _render_df(df_, left_cols=None):
    """Render a DataFrame as html_tbl."""
    if df_ is None or (hasattr(df_,'empty') and df_.empty): return ""
    if left_cols is None: left_cols = {0}
    def _cell(v):
        if isinstance(v, str): return v if v else "\u2014"
        if isinstance(v, (int, np.integer)): return str(int(v))
        if isinstance(v, float) and not np.isnan(v): return _f(v)
        return "\u2014"
    rows = [list(df_.columns)]
    for _, row in df_.iterrows():
        rows.append([_cell(row[c]) for c in df_.columns])
    return html_tbl(rows, left_cols=left_cols)


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _interpret(R, alpha):
    lines = []
    t = R["type"]
    nr = R.get("normality", {})
    norm_list = [nr] if isinstance(nr, dict) and "sw_W" in nr else []

    # 1. Normality
    if norm_list:
        prim = get_primary_label(norm_list)
        tn   = get_total_n(norm_list)
        size = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
        passed = norm_list[0].get("pass", False)
        lines.append(
            f"<b>1. Normality of Residuals ({prim}, {size}):</b> "
            + (f"p\u2009>\u2009.05 \u2192 Residuals approximately normally distributed. "
               f"The normality assumption is satisfied."
               if passed else
               f"p\u2009\u2264\u2009.05 \u2192 Normality may be violated. "
               f"ANCOVA is robust to moderate violations with N\u2009\u2265\u200930."))

    # 2. Levene
    lev = R.get("levene", {})
    if lev:
        passed_l = lev.get("passed", lev.get("equal_var", False))
        lines.append(
            f"<b>2. Homogeneity of Variance (Levene's):</b> "
            f"F\u2009=\u2009{_f(lev.get('F',np.nan))}, "
            f"p\u2009=\u2009{_p(lev.get('p',lev.get('Sig.',np.nan)))}. "
            + ("Equal variances assumed (p\u2009>\u2009.05)."
               if passed_l else
               "Unequal variances detected (p\u2009\u2264\u2009.05). "
               "Interpret results with caution."))

    # 3. Homogeneity of slopes
    n_item = 3
    for skey, slbl in [("slopes",""), ("slopes_a"," — Factor A"),
                       ("slopes_b"," — Factor B")]:
        if skey in R:
            sl = R[skey]
            lines.append(
                f"<b>{n_item}. Homogeneity of Regression Slopes{slbl}:</b> "
                f"F\u2009=\u2009{_f(sl.get('F',np.nan))}, "
                f"p\u2009=\u2009{_p(sl.get('p',np.nan))}. "
                + sl.get("note",""))
            n_item += 1

    # Main results
    def _sig(p_v):
        return "statistically significant" if not np.isnan(p_v) and p_v < alpha \
               else "not statistically significant"

    if t == "One-Way ANCOVA":
        p = R.get("p_factor", np.nan)
        lines.append(
            f"<b>{n_item}. Group Effect (adjusted):</b> "
            f"F\u2009=\u2009{_f(R.get('F_factor',np.nan))}, "
            f"p\u2009=\u2009{_p(p)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R.get('partial_eta2',np.nan))} "
            f"({_effect_label(R.get('partial_eta2',np.nan))}). "
            f"After controlling for {R['cov_name']}, group differences were "
            f"<b>{_sig(p)}</b> at \u03b1\u2009=\u2009{alpha}.")
        n_item += 1
        lines.append(
            f"<b>{n_item}. Estimated Marginal Means:</b> "
            f"Computed at grand mean of {R['cov_name']}\u2009=\u2009"
            f"{_f(R.get('grand_cov_mean',np.nan))}. "
            f"These represent predicted scores for each group had all participants "
            f"started at the same covariate level — enabling a fairer group comparison.")

    elif t == "Factorial ANCOVA":
        for eff, fv, pv, eta, nm in [
            ("Factor A", R.get("F_a",np.nan), R.get("p_a",np.nan),
             R.get("eta2_a",np.nan), R.get("fa_name","A")),
            ("Factor B", R.get("F_b",np.nan), R.get("p_b",np.nan),
             R.get("eta2_b",np.nan), R.get("fb_name","B")),
            ("Interaction A\u00d7B", R.get("F_ab",np.nan), R.get("p_ab",np.nan),
             R.get("eta2_ab",np.nan), "A\u00d7B"),
        ]:
            lines.append(
                f"<b>{n_item}. {eff} ({nm}):</b> "
                f"F\u2009=\u2009{_f(fv)}, p\u2009=\u2009{_p(pv)}, "
                f"partial \u03b7\u00b2\u2009=\u2009{_f(eta)} ({_effect_label(eta)}). "
                f"{_sig(pv).capitalize()} at \u03b1\u2009=\u2009{alpha}.")
            n_item += 1

    elif t == "Repeated Measures ANCOVA":
        p = R.get("p_time", np.nan)
        lines.append(
            f"<b>{n_item}. Within-Subjects TIME Effect:</b> "
            f"F\u2009=\u2009{_f(R.get('F_time',np.nan))}, "
            f"p\u2009=\u2009{_p(p)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R.get('eta2_time',np.nan))} "
            f"({_effect_label(R.get('eta2_time',np.nan))}). "
            f"GG corrected: p\u2009=\u2009{_p(R.get('p_time_gg',np.nan))} "
            f"(\u03b5\u2009=\u2009{_f(R.get('eps_gg',np.nan))}). "
            f"After adjusting for {R['cov_name']}, time effect was <b>{_sig(p)}</b>.")
        n_item += 1
        lines.append(
            f"<b>{n_item}. Covariate ({R['cov_name']}):</b> "
            f"F\u2009=\u2009{_f(R.get('F_cov',np.nan))}, "
            f"p\u2009=\u2009{_p(R.get('p_cov',np.nan))}, "
            f"B\u2009=\u2009{_f(R.get('B_cov',np.nan))}. "
            + ("The covariate significantly predicted the outcome (between-subjects)."
               if not np.isnan(R.get("p_cov",np.nan)) and R.get("p_cov",1) < alpha
               else "The covariate did not significantly predict the outcome."))

    elif t == "Mixed ANCOVA":
        for eff, fv, pv in [
            ("Between-Subjects Factor", R.get("F_between",np.nan), R.get("p_between",np.nan)),
            ("Within-Subjects Time",    R.get("F_time",np.nan),    R.get("p_time",np.nan)),
            ("Interaction (Group\u00d7Time)", R.get("F_interact",np.nan), R.get("p_interact",np.nan)),
        ]:
            lines.append(
                f"<b>{n_item}. {eff}:</b> "
                f"F\u2009=\u2009{_f(fv)}, p\u2009=\u2009{_p(pv)}. "
                f"{_sig(pv).capitalize()} at \u03b1\u2009=\u2009{alpha}.")
            n_item += 1

    elif t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        if mv:
            lines.append(
                f"<b>{n_item}. Multivariate Group Effect:</b> "
                f"Wilks\u2019 \u039b\u2009=\u2009{_f(mv.get('Wilks',np.nan))}, "
                f"F\u2009=\u2009{_f(mv.get('F_Wilks',np.nan))}, "
                f"p\u2009=\u2009{_p(mv.get('p_Wilks',np.nan))}. "
                f"After controlling for {R['cov_name']}, combined DVs were "
                f"<b>{_sig(mv.get('p_Wilks',np.nan))}</b>.")
            n_item += 1
        univ = R.get("univariate", pd.DataFrame())
        if not univ.empty:
            lines.append(f"<b>{n_item}. Univariate Follow-Up ANCOVAs:</b>")
            _skip_src = {"Corrected Model", "Intercept", "Error", "Corrected Total", "Total"}
            for _, row in univ.iterrows():
                src = str(row.get("Source",""))
                if src in _skip_src: continue
                dv  = row.get("Dependent Variable","DV")
                pv  = row.get("Sig.", np.nan)
                eta = row.get("Partial η²", np.nan)
                try: pv  = float(pv)
                except Exception: pv = np.nan
                try: eta = float(eta)
                except Exception: eta = np.nan
                try: F_v = float(row.get("F", np.nan))
                except Exception: F_v = np.nan
                lines.append(
                    f"&nbsp;&nbsp;&bull; <b>{dv} \u2014 {src}:</b> "
                    f"F\u2009=\u2009{_f(F_v)}, "
                    f"p\u2009=\u2009{_p(pv)}, "
                    f"partial \u03b7\u00b2\u2009=\u2009{_f(eta)} ({_effect_label(eta)}). "
                    f"{_sig(pv).capitalize()}.")

    # Plain language
    lines.append(f"<b>{n_item}. Plain Language Summary:</b> " + _plain(R, alpha))
    return lines


def _plain(R, alpha):
    t = R["type"]
    if t == "One-Way ANCOVA":
        sig = R.get("p_factor", 1) < alpha
        return (
            f"After accounting for {R['cov_name']}, the groups "
            f"{'differed significantly' if sig else 'did not differ significantly'} "
            f"in {R['y_name']}. The Estimated Marginal Means show what each group "
            f"would score if everyone started at the same covariate level "
            f"({_f(R.get('grand_cov_mean',np.nan))}).")
    if t == "Factorial ANCOVA":
        return (f"After adjusting for {R['cov_name']}, we examined how {R['fa_name']} "
                f"and {R['fb_name']} (and their combination) affected {R['y_name']}.")
    if t == "Repeated Measures ANCOVA":
        sig = R.get("p_time", 1) < alpha
        return (f"After controlling for {R['cov_name']}, scores across {R['T']} "
                f"time points changed "
                f"{'significantly' if sig else 'non-significantly'}.")
    if t == "Mixed ANCOVA":
        sig_i = R.get("p_interact", 1) < alpha
        return (f"After adjusting for {R['cov_name']}, "
                f"{'a significant interaction means the groups changed differently over time.' if sig_i else 'no significant interaction — groups changed similarly over time.'}")
    if t == "MANCOVA":
        mv = R.get("mv_factor") or {}
        sig = mv.get("p_Wilks", 1) < alpha
        return (f"After accounting for {R['cov_name']}, groups "
                f"{'differed significantly' if sig else 'did not differ significantly'} "
                f"on the combined outcome variables ({', '.join(R.get('y_names',[]))}).")
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# PLOTS
# ══════════════════════════════════════════════════════════════════════════════

def _make_plot(R):
    t = R["type"]
    figs = []

    # EMM bar (between-subjects)
    if t in ("One-Way ANCOVA", "Factorial ANCOVA"):
        emm = R.get("emm", pd.DataFrame())
        if not emm.empty and "Adjusted Mean" in emm.columns:
            fig, ax = plt.subplots(figsize=(7, 4), facecolor=BG)
            _style_ax(ax)
            groups = emm.iloc[:, 0].astype(str).values
            means  = emm["Adjusted Mean"].values.astype(float)
            ses    = emm["Std. Error"].values.astype(float)
            x_pos  = np.arange(len(groups))
            cols   = [PAL[i % len(PAL)] for i in range(len(groups))]
            ax.bar(x_pos, means, yerr=ses, capsize=5, color=cols,
                   alpha=0.82, width=0.6,
                   error_kw={"elinewidth":1.5,"ecolor":"#475569"})
            for i,(m,s) in enumerate(zip(means,ses)):
                ax.text(x_pos[i], m+s*1.15, f"{m:.2f}",
                        ha="center", va="bottom", fontsize=9, fontweight="600")
            ax.set_xticks(x_pos); ax.set_xticklabels(groups, fontsize=10)
            ax.set_ylabel(f"Adjusted Mean ({R.get('y_name','Y')})")
            ax.set_title("Estimated Marginal Means ± SE", fontweight="600")
            if t == "One-Way ANCOVA":
                ax.set_xlabel(R.get("factor_name","Group"))
            plt.tight_layout()
            figs.append(("Estimated Marginal Means", _fig_b64(fig)))

    # Profile plot (within-subjects)
    if t in ("Repeated Measures ANCOVA", "Mixed ANCOVA"):
        emm = R.get("emm", pd.DataFrame())
        t_col = R.get("time_name","Time")
        if not emm.empty and "Adjusted Mean" in emm.columns:
            fig, ax = plt.subplots(figsize=(8, 4.5), facecolor=BG)
            _style_ax(ax)
            if t == "Repeated Measures ANCOVA":
                times = emm[t_col].values
                means = emm["Adjusted Mean"].values.astype(float)
                ses   = emm["Std. Error"].values.astype(float)
                x = np.arange(len(times))
                ax.plot(x, means, "o-", color=PAL[1], lw=2.5, ms=8, zorder=3)
                ax.fill_between(x, means-ses, means+ses, alpha=0.18, color=PAL[1])
                for i,m in enumerate(means):
                    ax.text(x[i], m+ses[i]*1.1, f"{m:.2f}",
                            ha="center", fontsize=9, fontweight="600")
                ax.set_xticks(x); ax.set_xticklabels(times)
            else:
                btw = R.get("between_name","Group")
                if btw in emm.columns:
                    groups = sorted(emm[btw].unique())
                    t_lbls = sorted(emm[t_col].unique())
                    for i, grp in enumerate(groups):
                        sub   = emm[emm[btw]==grp].set_index(t_col).reindex(t_lbls)
                        x     = np.arange(len(t_lbls))
                        means = sub["Adjusted Mean"].values.astype(float)
                        ses   = sub["Std. Error"].values.astype(float)
                        ax.plot(x, means, "o-", color=PAL[i%len(PAL)],
                                lw=2.5, ms=8, label=str(grp), zorder=3)
                        ax.fill_between(x, means-ses, means+ses,
                                        alpha=0.15, color=PAL[i%len(PAL)])
                    ax.set_xticks(np.arange(len(t_lbls)))
                    ax.set_xticklabels(t_lbls)
                    ax.legend(title=btw, framealpha=0.7)
            ax.set_xlabel(t_col); ax.set_ylabel("Adjusted Mean")
            ax.set_title("Profile Plot — Adjusted Means ± SE", fontweight="600")
            plt.tight_layout()
            figs.append(("Profile Plot", _fig_b64(fig)))

    # MANCOVA effect sizes
    if t == "MANCOVA":
        univ = R.get("univariate", pd.DataFrame())
        if not univ.empty and "Partial η²" in univ.columns:
            # Only plot factor/covariate rows (skip Corrected Model, Intercept, Error)
            _skip = {"Corrected Model", "Intercept", "Error"}
            univ_plot = univ[~univ["Source"].isin(_skip)].copy() if "Source" in univ.columns else univ.copy()
            univ_plot["Partial η²"] = pd.to_numeric(univ_plot["Partial η²"], errors="coerce")
            univ_plot = univ_plot.dropna(subset=["Partial η²"])
            if not univ_plot.empty:
                fig, ax = plt.subplots(figsize=(7,4), facecolor=BG)
                _style_ax(ax)
                dvs  = univ_plot["Dependent Variable"].values if "Dependent Variable" in univ_plot.columns else univ_plot.index.values
                etas = univ_plot["Partial η²"].values.astype(float)
                cols = [PAL[1] if (not np.isnan(e) and e>=.14)
                        else PAL[2] if (not np.isnan(e) and e>=.06)
                        else PAL[0] for e in etas]
                ax.barh(dvs, etas, color=cols, alpha=0.82)
                for thresh, lbl, c in [(.01,"Small","#64748b"),(.06,"Medium",PAL[2]),(.14,"Large",PAL[1])]:
                    ax.axvline(thresh, color=c, ls="--", lw=1.2, label=f"{lbl} ({thresh})")
                ax.set_xlabel("Partial η²")
                ax.set_title("Effect Size per Dependent Variable", fontweight="600")
                ax.legend(fontsize=8, framealpha=0.7)
                plt.tight_layout()
                figs.append(("Effect Sizes per DV", _fig_b64(fig)))

    # Residual diagnostics (between-subjects models)
    model = R.get("model")
    if model is not None:
        resid  = model.resid.values
        fitted = model.fittedvalues.values
        fig2, axes = plt.subplots(1, 2, figsize=(10, 4), facecolor=BG)
        for ax_ in axes: _style_ax(ax_)
        axes[0].scatter(fitted, resid, color=PAL[1], s=25, alpha=0.7)
        axes[0].axhline(0, color=PAL[0], lw=1.5, ls="--")
        axes[0].set_xlabel("Fitted Values"); axes[0].set_ylabel("Residuals")
        axes[0].set_title("Residuals vs Fitted")
        try:
            from scipy import stats as sc
            (osm,osr),(sl,ic,_) = sc.probplot(resid)
            axes[1].plot(osm, osr, "o", color=PAL[1], ms=4, alpha=0.7)
            axes[1].plot(osm, sl*np.array(osm)+ic, "--", color=PAL[0], lw=1.5)
        except: pass
        axes[1].set_xlabel("Theoretical Quantiles"); axes[1].set_ylabel("Sample Quantiles")
        axes[1].set_title("Normal Q-Q (Residuals)")
        plt.tight_layout()
        figs.append(("Residual Diagnostics", _fig_b64(fig2)))

    return figs


# ══════════════════════════════════════════════════════════════════════════════
# HTML REPORT
# ══════════════════════════════════════════════════════════════════════════════

def _build_html(R, meta, interps, figs_b, alpha):
    t = R["type"]
    def _cell(v):
        if isinstance(v, str): return v if v else "\u2014"
        if isinstance(v, (int, np.integer)): return str(int(v))
        if isinstance(v, float) and not np.isnan(v): return _f(v)
        return "\u2014"
    def _rtbl(rows, lc=None):
        if not rows: return ""
        left = lc or set()
        hd = "".join(f"<th>{c}</th>" for c in rows[0])
        bd = ""
        for i, row in enumerate(rows[1:]):
            cls = "even" if i % 2 == 0 else "odd"
            cells = "".join(
                f'<td class="left">{cell}</td>' if j in left else f'<td>{cell}</td>'
                for j, cell in enumerate(row))
            bd += f'<tr class="{cls}">{cells}</tr>'
        return f'<table class="rtbl"><thead><tr>{hd}</tr></thead><tbody>{bd}</tbody></table>'
    def _sub(tt):
        return f'<div class="sub-hdr">{tt}</div>'
    def _dfhtml(df_, lc=None):
        if df_ is None or (hasattr(df_,"empty") and df_.empty): return ""
        rows = [list(df_.columns)]
        for _, row in df_.iterrows():
            rows.append([_cell(row[c]) for c in df_.columns])
        return _rtbl(rows, lc or {0})

    css = """<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);border-radius:16px;padding:44px 52px;margin-bottom:28px;border-left:6px solid #e94560;box-shadow:0 12px 48px rgba(233,69,96,.2);}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.section{background:#fff;border-radius:12px;padding:26px 30px;margin-bottom:22px;box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;letter-spacing:.8px;margin:-26px -30px 22px;font-family:'DM Mono',monospace;border-bottom:3px solid #e94560;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;font-size:.82rem;color:#0c4a6e;margin:12px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;font-size:.73rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:8px 10px;text-align:center;font-weight:600;border:1px solid #334155;white-space:normal;font-size:.71rem;}
.rtbl td{padding:6px 10px;border:1px solid #e2e8f0;text-align:right;white-space:normal;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;font-size:.86rem;line-height:1.8;border-left:4px solid #0284c7;background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp b{color:#0284c7;}.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}.interp.sig b{color:#16a34a;}
.interp.nonsig{border-left-color:#dc2626;background:linear-gradient(135deg,#fef2f2,#fee2e2);}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;color:#1e293b;line-height:1.8;}
.warn-box{background:#fffbeb;border-left:4px solid #f59e0b;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#92400e;margin:.4rem 0;}
.info-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#1e40af;margin:.4rem 0;}
.fig-wrap{text-align:center;margin:18px 0;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;padding-top:16px;border-top:1px solid #e2e8f0;line-height:1.8;}
</style>"""

    nr = R.get("normality", {})
    all_ok = R.get("all_ok", False)
    cls    = "use-param" if all_ok else "use-nonparam"
    _html_lbl = {
        "One-Way ANCOVA":           "Parametric ANCOVA",
        "Factorial ANCOVA":         "Parametric Factorial ANCOVA",
        "Repeated Measures ANCOVA": "Parametric RM ANCOVA",
        "Mixed ANCOVA":             "Parametric Mixed ANCOVA",
        "MANCOVA":                  "Parametric MANCOVA",
    }.get(t, "Parametric ANCOVA")
    dtxt = (f"\u2713 All assumption checks passed \u2014 {_html_lbl} results are reliable."
            if all_ok else
            f"\u26a0 One or more assumptions may be violated \u2014 review tests.")

    # ANCOVA / Univariate table
    left_01 = {0, 1}
    anova_html = ""
    if R.get("anova_table") is not None:
        anova_html = _dfhtml(R["anova_table"])
    elif R.get("univariate") is not None:
        anova_html = ('<div class="sub-hdr">Tests of Between-Subjects Effects</div>'
                      + _dfhtml(R["univariate"], left_01))
    # Parameter Estimates (Factorial)
    _pe = R.get("param_estimates")
    if _pe is not None and hasattr(_pe,"empty") and not _pe.empty:
        anova_html += ('<div class="sub-hdr">Parameter Estimates</div>'
                       + _dfhtml(_pe, {0}))
    # Univariate Tests (Factorial)
    _ut = R.get("univariate_tests")
    if _ut is not None and hasattr(_ut,"empty") and not _ut.empty:
        anova_html += ('<div class="sub-hdr">Univariate Tests</div>'
                       + _dfhtml(_ut, {0,1}))

    # Descriptives (MANCOVA) — Mean, SD, N per group per DV
    desc_html = ""
    desc_df = R.get("descriptives")
    if desc_df is not None and hasattr(desc_df,"empty") and not desc_df.empty:
        desc_html = ('<div class="sub-hdr">Descriptive Statistics</div>'
                     + _dfhtml(desc_df, {0}))

    # Levene's per DV (MANCOVA)
    lev_html = ""
    lev_mc = R.get("levene_mancova")
    if lev_mc is not None and hasattr(lev_mc,"empty") and not lev_mc.empty:
        lev_html = ('<div class="sub-hdr">Levene\'s Test of Equality of Error Variances</div>'
                    + _dfhtml(lev_mc, {0}))

    # Multivariate tests (MANCOVA) — Intercept, Covariate, Factor
    mv_html = ""
    def _mv_html_block(mv, lbl):
        if not mv: return ""
        rows = [
            ["Statistic","Value","F","Hyp df","Error df","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
            ["Pillai\u2019s Trace",
             _f(mv["Pillai"]),    _f(mv["F_Pillai"]),
             str(mv.get("df_hyp_Pillai","—")), str(mv.get("df_err_Pillai","—")),
             _p(mv["p_Pillai"]),  _f(mv.get("eta2_Pillai","")),
             _f(mv.get("noncent_Pillai",""))],
            ["Wilks\u2019 Lambda",
             _f(mv["Wilks"]),     _f(mv["F_Wilks"]),
             str(mv.get("df_hyp_Wilks","—")),  str(mv.get("df_err_Wilks","—")),
             _p(mv["p_Wilks"]),   _f(mv.get("eta2_Wilks","")),
             _f(mv.get("noncent_Wilks",""))],
            ["Hotelling-Lawley",
             _f(mv["Hotelling"]), _f(mv["F_HL"]),
             str(mv.get("df_hyp_HL","—")),     str(mv.get("df_err_HL","—")),
             _p(mv["p_HL"]),      _f(mv.get("eta2_HL","")),
             _f(mv.get("noncent_HL",""))],
            ["Roy\u2019s Largest Root",
             _f(mv["Roy"]),       _f(mv["F_Roy"]),
             str(mv.get("df_hyp_Roy","—")),    str(mv.get("df_err_Roy","—")),
             _p(mv["p_Roy"]),     _f(mv.get("eta2_Roy","")),
             _f(mv.get("noncent_Roy",""))],
        ]
        left_0 = {0}
        return f'<div class="sub-hdr">Multivariate Tests \u2014 {lbl}</div>' + _rtbl(rows, left_0)

    for _eff, _key in [("Intercept",                   "mv_intercept"),
                       (R.get("cov_name","Covariate"),  "mv_cov"),
                       (R.get("factor_name","Group"),   "mv_factor")]:
        mv_html += _mv_html_block(R.get(_key), _eff)

    # ── RM / Mixed ANCOVA: Mauchly, Within-Subjects, Between-Subjects ──────
    def _nc(F, dfn):
        try: return _f(round(float(F)*float(dfn), 3))
        except Exception: return "\u2014"
    if t in ("Repeated Measures ANCOVA", "Mixed ANCOVA") and "mauchly_W" in R:
        cn = R.get("cov_name","Covariate"); bn = R.get("between_name","Group")
        # Multivariate Tests (within-subjects) — before Mauchly, matching SPSS order
        def _mvw_html(mv, lbl):
            if not mv: return ""
            rows = [["Statistic","Value","F","Hyp df","Error df","Sig.","Partial \u03b7\u00b2","Noncent."],
                ["Pillai\u2019s Trace",_f(mv["Pillai"]),_f(mv["F_Pillai"]),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv["p_Pillai"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Wilks\u2019 Lambda",_f(mv["Wilks"]),_f(mv["F_Wilks"]),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv["p_Wilks"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Hotelling-Lawley",_f(mv.get("Hotelling",np.nan)),_f(mv.get("F_HL",np.nan)),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv.get("p_HL",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
                ["Roy\u2019s Largest Root",_f(mv.get("Roy",np.nan)),_f(mv.get("F_Roy",np.nan)),
                 str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
                 _p(mv.get("p_Roy",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ]
            return f'<div class="sub-hdr">Multivariate Tests \u2014 {lbl}</div>' + _rtbl(rows, {0})
        mv_html += _mvw_html(R.get("mv_time"), "TIME")
        if t == "Mixed ANCOVA":
            mv_html += _mvw_html(R.get("mv_tg"), f"TIME \u00d7 {bn}")
        mv_html += _mvw_html(R.get("mv_tc"), f"TIME \u00d7 {cn}")
        # Mauchly
        mau_rows = [["Within Subjects Effect","Mauchly's W","Approx. Chi-Square","df","Sig.","\u03b5 (GG)"],
                    ["TIME", _f(R.get("mauchly_W",np.nan)), _f(R.get("mauchly_chi2",np.nan)),
                     str(R.get("mauchly_df","?")), _p(R.get("mauchly_p",np.nan)),
                     _f(R.get("eps_gg",np.nan))]]
        mv_html += '<div class="sub-hdr">Mauchly\u2019s Test of Sphericity</div>' + _rtbl(mau_rows, {0})

        if t == "Repeated Measures ANCOVA":
            ws_rows = [["Source","Type III SS","df","MS","F","Sig. (Uncorr.)","Sig. (GG)","Partial \u03b7\u00b2","Noncent."],
                ["TIME", _f(R.get("SS_time",np.nan)), str(R.get("df_time","?")),
                 _f(R.get("MS_time",np.nan)), _f(R.get("F_time",np.nan)),
                 _p(R.get("p_time",np.nan)), _p(R.get("p_time_gg",np.nan)),
                 _f(R.get("eta2_time",np.nan)), _nc(R.get("F_time",np.nan), R.get("df_time",1))],
                [f"TIME \u00d7 {cn}", _f(R.get("SS_tc",np.nan)), str(R.get("df_tc","?")),
                 "\u2014", _f(R.get("F_tc",np.nan)), _p(R.get("p_tc",np.nan)), "\u2014",
                 _f(R.get("eta2_tc",np.nan)), _nc(R.get("F_tc",np.nan), R.get("df_tc",1))]]
            mv_html += '<div class="sub-hdr">Tests of Within-Subjects Effects</div>' + _rtbl(ws_rows, {0})
            bs_rows = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent."],
                [cn, _f(R.get("SS_cov",np.nan)), "1", _f(R.get("F_cov",np.nan)),
                 _p(R.get("p_cov",np.nan)), _f(R.get("eta2_cov",np.nan)), _nc(R.get("F_cov",np.nan),1)],
                ["Error", "\u2014", str(R.get("df_err_between","?")), "\u2014","\u2014","\u2014","\u2014"]]
            mv_html += '<div class="sub-hdr">Tests of Between-Subjects Effects</div>' + _rtbl(bs_rows, {0})
        else:  # Mixed ANCOVA
            T_ = R.get("T",3); k_ = R.get("k",2)
            ws_rows = [["Source","SS","df","F","Sig.","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent."],
                ["TIME", _f(R.get("SS_time",np.nan)), str(R.get("df_time",T_-1)),
                 _f(R.get("F_time",np.nan)), _p(R.get("p_time",np.nan)),
                 _f(R.get("eps_gg",np.nan)), _f(R.get("eta2_time",np.nan)),
                 _nc(R.get("F_time",np.nan), R.get("df_time",T_-1))],
                [f"TIME \u00d7 {R.get('between_name','Group')}", _f(R.get("SS_interact",R.get("SS_tg",np.nan))),
                 str((T_-1)*(k_-1)), _f(R.get("F_interact",R.get("F_tg",np.nan))),
                 _p(R.get("p_interact",R.get("p_tg",np.nan))), "\u2014",
                 _f(R.get("eta2_interact",R.get("eta2_tg",np.nan))),
                 _nc(R.get("F_interact",R.get("F_tg",np.nan)),(T_-1)*(k_-1))],
                [f"TIME \u00d7 {cn}", _f(R.get("SS_tc",np.nan)), str(T_-1),
                 _f(R.get("F_tc",np.nan)), _p(R.get("p_tc",np.nan)), "\u2014",
                 _f(R.get("eta2_tc",np.nan)), _nc(R.get("F_tc",np.nan), T_-1)]]
            mv_html += '<div class="sub-hdr">Tests of Within-Subjects Effects</div>' + _rtbl(ws_rows, {0})
            bs_rows = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent."],
                [R.get("between_name","Group"), _f(R.get("SS_between",np.nan)),
                 str(R.get("df_between","?")), _f(R.get("F_between",np.nan)),
                 _p(R.get("p_between",np.nan)), _f(R.get("eta2_between",np.nan)),
                 _nc(R.get("F_between",np.nan), R.get("df_between",1))],
                [cn, _f(R.get("SS_cov",np.nan)), "1", _f(R.get("F_cov",np.nan)),
                 _p(R.get("p_cov",np.nan)), _f(R.get("eta2_cov",np.nan)), _nc(R.get("F_cov",np.nan),1)],
                ["Error","\u2014", str(R.get("df_resid_between","?")), "\u2014","\u2014","\u2014","\u2014"]]
            mv_html += '<div class="sub-hdr">Tests of Between-Subjects Effects</div>' + _rtbl(bs_rows, {0})

        # Within-Subjects Contrasts (RM & Mixed)
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            crows = [list(_cdf.columns)]
            for _i in _cdf.index:
                crows.append([_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[_i]])
            mv_html += ('<div class="sub-hdr">Tests of Within-Subjects Contrasts</div>'
                        + _rtbl(crows, {0,1}))

    # Box's M
    bm_html = ""
    bm = R.get("boxes_m")
    if bm:
        bm_rows = [["Box's M","F","df1","df2","Sig."],
                   [_f(bm["M"]),_f(bm["F"]),str(bm["df1"]),_f(bm["df2"]),_p(bm["Sig."])]]
        bm_html = '<div class="sub-hdr">Box\'s M Test</div>' + _rtbl(bm_rows)

    # EMMs
    emm_html = ""
    for k, lbl in [("emm","Estimated Marginal Means"),
                   ("emm_cell","Cell EMMs"),
                   ("emm_group","Group EMMs (avg over time)"),
                   ("emm_time","Time EMMs (avg over groups)"),
                   ("emm_a",f"Marginal Means — {R.get('fa_name','')} (avg over {R.get('fb_name','')})"),
                   ("emm_b",f"Marginal Means — {R.get('fb_name','')} (avg over {R.get('fa_name','')})") ]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_, "empty") and not df_.empty:
            emm_html += f'<div class="sub-hdr">{lbl}</div>' + _dfhtml(df_)

    # Post-hoc
    pw_html = ""
    for k, lbl in [("pairwise","Pairwise Comparisons (Bonferroni)"),
                   ("pairwise_a",f"Pairwise — {R.get('fa_name','')}"),
                   ("pairwise_b",f"Pairwise — {R.get('fb_name','')}"),
                   ("pairwise_time","Pairwise Time Comparisons"),
                   ("pairwise_group","Pairwise Group Comparisons")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_,"empty") and not df_.empty:
            pw_html += f'<div class="sub-hdr">{lbl}</div>' + _dfhtml(df_, {0,1})

    # Normality of residuals
    norm_html = ""
    nr_html   = R.get("normality", {})
    left_07   = {0, 6, 7}
    left_0    = {0}
    if isinstance(nr_html, dict) and "sw_W" in nr_html:
        # Single normality (ANCOVA)
        nr_rows = [["Variable","N","KS D","KS Sig.","SW W","SW Sig.","Primary","Decision"],
                   [nr_html.get("label","Residuals"),
                    str(nr_html.get("total_n", nr_html.get("n","?"))),
                    _f(nr_html.get("ks_D",np.nan)), _p(nr_html.get("ks_p",np.nan)),
                    _f(nr_html.get("sw_W",np.nan)), _p(nr_html.get("sw_p",np.nan)),
                    nr_html.get("primary_label","?"),
                    "\u2713 Normal" if nr_html.get("pass") else "\u2717 Non-Normal"]]
        norm_html = _sub("Normality of Residuals") + _rtbl(nr_rows, left_07)
    elif isinstance(nr_html, dict) and nr_html:
        # Per-DV normality (MANCOVA)
        nr_rows = [["Dependent Variable","N","KS D","KS Sig.","SW W","SW Sig.","Primary","Decision"]]
        for dv, dv_nr in nr_html.items():
            if isinstance(dv_nr, dict) and "sw_W" in dv_nr:
                nr_rows.append([
                    dv,
                    str(dv_nr.get("total_n", dv_nr.get("n","?"))),
                    _f(dv_nr.get("ks_D",np.nan)), _p(dv_nr.get("ks_p",np.nan)),
                    _f(dv_nr.get("sw_W",np.nan)), _p(dv_nr.get("sw_p",np.nan)),
                    dv_nr.get("primary_label","?"),
                    "\u2713 Normal" if dv_nr.get("pass") else "\u2717 Non-Normal"
                ])
        norm_html = _sub("Normality of Residuals (per DV)") + _rtbl(nr_rows, left_07)

    # Meta table (cover style)
    meta_html = "<table class='meta-tbl'>"
    for k_, v in meta.items():
        meta_html += f"<tr><td class='mk'>{k_}</td><td class='mv'>{v}</td></tr>"
    meta_html += "</table>"

    # Interp blocks → use .interp class
    interp_html = "".join(f'<div class="interp">{line}</div>' for line in interps)

    # Figures → .fig-wrap
    figs_html = "".join(
        f'<div class="fig-wrap"><div class="sub-hdr">{lbl}</div>'
        f'<img src="data:image/png;base64,{b64}" style="max-width:100%;border-radius:8px;"/></div>'
        for lbl, b64 in figs_b)

    _ds = f'<div class="sec-hdr">2. DESCRIPTIVE STATISTICS</div>{desc_html}' if desc_html else ""
    _bx = f'{bm_html}' if bm_html else ""
    _lv = f'{lev_html}' if lev_html else ""
    _mv = f'{mv_html}' if mv_html else ""
    _emm_note = (f'<p class="tbl-note">Computed at grand mean of covariate = '
                 f'{_f(R.get("grand_cov_mean",np.nan))}.</p>')

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>{t} | Inferential Statistics by MA</title>{css}</head>
<body><div class="page">
<div class="cover">
  <h1>&#127907; {t} Report</h1>
  <div style="margin-bottom:20px;">
    <span class="badge">SPSS-Equivalent</span><span class="badge">Type III SS</span>
    <span class="badge">EMMs</span><span class="badge">Partial &#951;&#178;</span>
    <span class="badge">Noncent.</span>
  </div>
  {meta_html}
  <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12);">
    <p style="color:#94a3b8;font-size:.76rem;margin:0 0 8px;">&#9749; Support this work &mdash; scan QRIS</p>
    <img src="https://muhaiminabdullah.com/media/thumbnails/QRIS-muhaiminabdullahdotcom-340x480.jpeg"
         style="width:130px;border-radius:8px;border:2px solid #e94560;display:block;"/>
  </div>
</div>
<div class="section"><div class="sec-hdr">1. NORMALITY &amp; ASSUMPTION TESTS</div>
  <div class="{cls.replace('use-param','info-box').replace('use-nonparam','warn-box')}"
       style="font-weight:600;margin-bottom:12px;">{dtxt}</div>
  {norm_html}
  {_lv}
</div>
{_ds and f'<div class="section">{_ds}</div>'}
<div class="section"><div class="sec-hdr">3. OMNIBUS / MULTIVARIATE TESTS</div>
  {_bx}
  {_mv}
  <div class="sub-hdr">Results Table &#8212; Type III SS</div>
  {anova_html}
  <p class="tbl-note">Partial &#951;&#178;: &lt;.01 negligible, .01&#8211;.06 small,
  .06&#8211;.14 medium, &#8805;.14 large (Cohen, 1988). Noncent.\u2009=\u2009F\u2009\u00d7\u2009df.</p>
</div>
<div class="section"><div class="sec-hdr">4. ESTIMATED MARGINAL MEANS</div>
  {emm_html}
  {_emm_note}
</div>
<div class="section"><div class="sec-hdr">5. POST-HOC COMPARISONS</div>
  {pw_html if pw_html else '<p class="tbl-note">No pairwise comparisons available.</p>'}
</div>
<div class="section"><div class="sec-hdr">6. INTERPRETATION</div>
  {interp_html}
</div>
<div class="section"><div class="sec-hdr">7. DIAGNOSTIC PLOTS</div>
  {figs_html}
</div>
<div class="footer">Generated by Inferential Statistics by MA &nbsp;&middot;&nbsp; {t}
  &nbsp;&middot;&nbsp; {datetime.now().strftime("%B %d, %Y at %H:%M")}</div>
</div></body></html>""".encode("utf-8")


# ══════════════════════════════════════════════════════════════════════════════
# CSS + HEADER  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(load_page_css(), unsafe_allow_html=True)

st.markdown("""
<div class="main-hdr">
  <h1>&#127907; ANCOVA Family
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Type&nbsp;III&nbsp;SS</span>
    <span class="badge">EMMs</span>
    <span class="badge">Partial&nbsp;&#951;&#178;</span>
  </h1>
  <p>One-Way &nbsp;&middot;&nbsp; Factorial &nbsp;&middot;&nbsp;
     Repeated Measures &nbsp;&middot;&nbsp; Mixed &nbsp;&middot;&nbsp; MANCOVA</p>
</div>""", unsafe_allow_html=True)

st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:.9rem;margin-bottom:.4rem;">
    &#9749; Support this work &mdash; scan QRIS:</p>
  <img src="https://muhaiminabdullah.com/media/thumbnails/QRIS-muhaiminabdullahdotcom-340x480.jpeg"
       style="width:180px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### &#9881;&#65039; Configuration")
    st.markdown("---")

    _tests = [
        "One-Way ANCOVA",
        "Factorial ANCOVA",
        "Repeated Measures ANCOVA",
        "Mixed ANCOVA",
        "MANCOVA",
    ]
    # Honor a navigation request from the landing page:
    #   - query param  ?test=Mixed+ANCOVA
    #   - session key  ancova_goto / selected_test (set by home page buttons)
    _nav = None
    try:
        _qp = st.query_params.get("test")
        if isinstance(_qp, list): _qp = _qp[0] if _qp else None
        _nav = _qp
    except Exception:
        pass
    _nav = (st.session_state.pop("ancova_goto", None)
            or st.session_state.pop("selected_test", None)
            or _nav)
    if _nav in _tests:
        st.session_state["ancova_test_sel"] = _nav

    if "ancova_test_sel" not in st.session_state:
        st.session_state["ancova_test_sel"] = st.session_state.get(
            "ancova_test", "One-Way ANCOVA")

    test_type = st.selectbox("&#127907; Select Test", _tests,
                             key="ancova_test_sel")

    # If the user switches test type without re-running, clear stale RESULTS so
    # the page shows the "ready to run" state for the new test (do NOT clear the
    # selector key itself, or the dropdown would reset to One-Way).
    if ("ancova_last_run" in st.session_state
            and st.session_state["ancova_last_run"] != test_type):
        for _k in ("ancova_R", "ancova_meta", "ancova_interps", "ancova_figs"):
            st.session_state.pop(_k, None)

    alpha = st.selectbox("\u03b1 Significance Level", [0.05, 0.01, 0.001], index=0)

    posthoc_method = st.selectbox(
        "Post-Hoc Method",
        ["bonferroni", "lsd", "sidak", "scheffe"],
        format_func={
            "bonferroni": "Bonferroni (conservative)",
            "lsd":        "LSD (Fisher, no correction)",
            "sidak":      "Sidak",
            "scheffe":    "Scheff\u00e9 (most flexible)",
        }.get,
        index=0)

    st.markdown("---")

    _samp_key = {
        "One-Way ANCOVA":           "One-Way ANCOVA",
        "Factorial ANCOVA":         "Factorial ANCOVA",
        "Repeated Measures ANCOVA": "Repeated Measures ANCOVA",
        "Mixed ANCOVA":             "Mixed ANCOVA",
        "MANCOVA":                  "MANCOVA",
    }[test_type]
    samp = SAMPLES[_samp_key]
    st.markdown("**&#128196; Sample Data**")
    st.markdown(
        f'<p style="font-size:.8rem;color:#64748b;">{samp["note"]}</p>',
        unsafe_allow_html=True)
    st.download_button(
        "&#11015;&#65039; Download Sample CSV",
        samp["csv"].encode(),
        f"sample_{_samp_key.replace(' ','_').lower()}.csv",
        "text/csv", use_container_width=True)
    st.markdown("---")

    uploaded = st.file_uploader(
        "&#128194; Upload Data File",
        type=["csv", "xlsx", "xls"])
    if uploaded:
        try:
            df = load_file(uploaded)
            fm = file_metadata(uploaded, df)
            val = validate_file(df)
            if val["errors"]:
                for e in val["errors"]: st.error(e)
                df = None
            else:
                st.success(f"&#10003; {fm['Rows']:,} rows \u00d7 {fm['Columns']} cols")
                for w in val["warnings"]: st.warning(w)
        except Exception as e:
            st.error(str(e)); df = None
    else:
        df = load_from_string(samp["csv"])
        st.info("\u2139\ufe0f Using built-in sample data")

    # ── Variable selection ──────────────────────────────────────────────────
    cfg = None
    if df is not None:
        num_cols = get_numeric_cols(df)
        cat_cols = get_categorical_cols(df)
        all_cols = list(df.columns)
        id_cols  = [c for c in num_cols if _is_id_col(c, df[c])]
        non_id   = [c for c in num_cols if c not in id_cols]
        grp_cols = cat_cols + [c for c in num_cols
                               if c not in id_cols and df[c].nunique() <= 15]
        st.markdown("---")

        if test_type == "One-Way ANCOVA":
            gc = st.selectbox("&#128101; Factor (Group)", grp_cols, index=0,
                              key="ow_group")
            cc = st.selectbox("&#128202; Covariate", non_id, index=0,
                              key="ow_cov")
            rem = [c for c in non_id if c != cc]
            dc = st.selectbox("&#127919; Dependent Variable (Y)", rem,
                               index=max(0, len(rem)-1), key="ow_dv")
            cfg = {"type":"oneway","group":gc,"cov":cc,"dv":dc}

        elif test_type == "Factorial ANCOVA":
            fa = st.selectbox("Factor A", grp_cols, index=0,
                              key="fac_factorA")
            _fb_opts = [c for c in grp_cols if c != fa]
            if _fb_opts:
                fb = st.selectbox("Factor B", _fb_opts, index=0,
                                  key="fac_factorB")
            else:
                fb = None
                st.warning("Factorial ANCOVA needs **2 different** categorical "
                           "factors, but only one was found.")
            # Covariate: prefer a pretest/baseline-named numeric column
            _covF = next((c for c in non_id
                          if any(kw in c.lower() for kw in
                                 ("pre", "base", "cov", "prior", "iq", "age"))), None)
            _ciF = non_id.index(_covF) if _covF in non_id else 0
            cc = st.selectbox("&#128202; Covariate", non_id, index=_ciF,
                              key="fac_cov")
            rem = [c for c in non_id if c != cc]
            dc = st.selectbox("&#127919; Dependent Variable (Y)", rem,
                               index=0 if rem else 0, key="fac_dv")
            if fb is not None:
                cfg = {"type":"factorial","fa":fa,"fb":fb,"cov":cc,"dv":dc}

        elif test_type == "Repeated Measures ANCOVA":
            _cov_guess = _guess_covariate(non_id)
            _time_def  = [c for c in non_id if c != _cov_guess]
            tc = st.multiselect(
                "Time-Point Columns (≥2)",
                non_id,
                default=_time_def if len(_time_def) >= 2 else non_id[:min(3, len(non_id))],
                key="rm_times",
                help="Select 2+ numeric columns representing repeated measurements.")
            rem = [c for c in non_id if c not in tc]
            _ci = rem.index(_cov_guess) if _cov_guess in rem else 0
            cc = st.selectbox("&#128202; Covariate (between-subjects)", rem,
                               index=_ci if rem else 0, key="rm_cov")
            if len(tc) >= 2:
                cfg = {"type":"rm","times":tc,"cov":cc}
            else:
                st.warning("Select at least 2 time-point columns.")

        elif test_type == "Mixed ANCOVA":
            bc = st.selectbox("&#128101; Between-Subjects Factor", grp_cols,
                              index=0, key="mx_between")
            _cov_guess = _guess_covariate(non_id)
            _time_def  = [c for c in non_id if c != _cov_guess]
            tc = st.multiselect(
                "Time-Point Columns (≥2)",
                non_id,
                default=_time_def if len(_time_def) >= 2 else non_id[:min(3, len(non_id))],
                key="mx_times")
            rem = [c for c in non_id if c not in tc]
            _ci = rem.index(_cov_guess) if _cov_guess in rem else 0
            cc = st.selectbox("&#128202; Covariate", rem,
                               index=_ci if rem else 0, key="mx_cov")
            if len(tc) >= 2:
                cfg = {"type":"mixed","between":bc,"times":tc,"cov":cc}
            else:
                st.warning("Select at least 2 time-point columns.")

        else:  # MANCOVA
            gc = st.selectbox("&#128101; Factor (Group)", grp_cols, index=0,
                              key="mc_group")
            cc = st.selectbox("&#128202; Covariate", non_id, index=0,
                              key="mc_cov")
            rem = [c for c in non_id if c != cc]
            dvs = st.multiselect(
                "&#127919; Dependent Variables (≥2)", rem,
                default=rem[:min(3, len(rem))], key="mc_dvs")
            if len(dvs) >= 2:
                cfg = {"type":"mancova","group":gc,"cov":cc,"dvs":dvs}
            else:
                st.warning("Select at least 2 dependent variables.")

        st.markdown("---")
        run_btn = st.button("&#128640; Run Analysis",
                             type="primary", use_container_width=True)
    else:
        run_btn = False


# ══════════════════════════════════════════════════════════════════════════════
# DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════
if df is not None:
    with st.expander("&#128269; Data Preview", expanded=False):
        st.dataframe(df.head(20), use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# WELCOME
# ══════════════════════════════════════════════════════════════════════════════
if not run_btn and "ancova_R" not in st.session_state:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        f'border:1px solid #bae6fd;border-radius:12px;padding:1.2rem 1.4rem;'
        f'margin:.8rem 0;border-left:4px solid #0284c7;">'
        f'<h4 style="margin:0 0 .4rem;font-size:.95rem;font-weight:700;">'
        f'&#128203; {test_type}</h4>'
        f'<p style="margin:0;font-size:.84rem;color:#475569;">'
        f'{samp["desc"]}</p></div>',
        unsafe_allow_html=True)
    st.info("&#128072; Configure variables in the sidebar, then click **Run Analysis**.")
    st.stop()


# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("&#9888;&#65039; Variable configuration is incomplete."); st.stop()

    with st.spinner("Running analysis\u2026"):
        try:
            if cfg["type"] == "oneway":
                R = run_one_way_ancova(
                    y=df[cfg["dv"]].values,
                    factor=df[cfg["group"]].values,
                    covariate=df[cfg["cov"]].values.astype(float),
                    y_name=cfg["dv"], factor_name=cfg["group"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor":cfg["group"],"Covariate":cfg["cov"],
                        "DV":cfg["dv"],"N":R["n"],"Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "factorial":
                R = run_factorial_ancova(
                    y=df[cfg["dv"]].values,
                    factor_a=df[cfg["fa"]].values,
                    factor_b=df[cfg["fb"]].values,
                    covariate=df[cfg["cov"]].values.astype(float),
                    y_name=cfg["dv"], fa_name=cfg["fa"], fb_name=cfg["fb"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor A":cfg["fa"],"Factor B":cfg["fb"],
                        "Covariate":cfg["cov"],"DV":cfg["dv"],"N":R["n"],
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "rm":
                R = run_rm_ancova(
                    data_wide=df[cfg["times"]].values.astype(float),
                    time_labels=cfg["times"],
                    covariate=df[cfg["cov"]].values.astype(float),
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Time Points":", ".join(cfg["times"]),
                        "Covariate":cfg["cov"],"N":R["n"],"Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            elif cfg["type"] == "mixed":
                R = run_mixed_ancova(
                    data_wide=df[cfg["times"]].values.astype(float),
                    time_labels=cfg["times"],
                    between_factor=df[cfg["between"]].values,
                    covariate=df[cfg["cov"]].values.astype(float),
                    between_name=cfg["between"], cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Between Factor":cfg["between"],
                        "Time Points":", ".join(cfg["times"]),
                        "Covariate":cfg["cov"],"N":R["n"],
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

            else:  # MANCOVA
                R = run_mancova(
                    y_matrix=df[cfg["dvs"]].values.astype(float),
                    factor=df[cfg["group"]].values,
                    covariate=df[cfg["cov"]].values.astype(float),
                    y_names=cfg["dvs"], factor_name=cfg["group"],
                    cov_name=cfg["cov"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {"Test":test_type,"Factor":cfg["group"],"Covariate":cfg["cov"],
                        "DVs":", ".join(cfg["dvs"]),"N":R["n"],
                        "Post-Hoc":posthoc_method.title(),
                        "\u03b1":alpha,"Date":datetime.now().strftime("%B %d, %Y %H:%M")}

        except Exception as e:
            import traceback
            st.error(f"Analysis error: {e}")
            st.code(traceback.format_exc()); st.stop()

    with st.spinner("Generating plots\u2026"):
        figs_b = _make_plot(R)

    interps = _interpret(R, alpha)

    st.session_state.update({
        "ancova_R":       R,
        "ancova_meta":    meta,
        "ancova_interps": interps,
        "ancova_figs":    figs_b,
        "ancova_alpha":   alpha,
        "ancova_test":    test_type,
        "ancova_last_run": test_type,
        "ancova_posthoc": posthoc_method,
    })


# ══════════════════════════════════════════════════════════════════════════════
# LOAD FROM SESSION
# ══════════════════════════════════════════════════════════════════════════════
R         = st.session_state["ancova_R"]
meta      = st.session_state["ancova_meta"]
interps   = st.session_state["ancova_interps"]
figs_b    = st.session_state["ancova_figs"]
alpha     = st.session_state.get("ancova_alpha", 0.05)
test_type = st.session_state["ancova_test"]

st.success("&#10003; Analysis complete!")

# ══════════════════════════════════════════════════════════════════════════════
# DECISION BANNER
# ══════════════════════════════════════════════════════════════════════════════
nr       = R.get("normality", {})
norm_ok  = nr.get("pass", False) if isinstance(nr, dict) else False
lev_ok   = R.get("levene", {}).get("passed",
           R.get("levene", {}).get("equal_var", True))
all_ok   = R.get("all_ok", False)
cls      = "use-param" if all_ok else "use-nonparam"

# Use correct analysis name per test type
_analysis_lbl = {
    "One-Way ANCOVA":           "Parametric ANCOVA",
    "Factorial ANCOVA":         "Parametric Factorial ANCOVA",
    "Repeated Measures ANCOVA": "Parametric RM ANCOVA",
    "Mixed ANCOVA":             "Parametric Mixed ANCOVA",
    "MANCOVA":                  "Parametric MANCOVA",
}.get(test_type, "Parametric ANCOVA")

if isinstance(nr, dict) and "sw_W" in nr:
    prim = nr.get("primary_label","Shapiro-Wilk")
    tn   = nr.get("total_n", nr.get("n", 0))
    size = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
    txt  = (f"\u2713 <b>{prim}</b> ({size}) p\u2009>\u2009.05 "
            f"\u2192 Normality satisfied \u2192 <b>{_analysis_lbl} applied.</b>"
            if norm_ok else
            f"\u26a0 <b>{prim}</b> ({size}) p\u2009\u2264\u2009.05 "
            f"\u2192 Normality violated \u2192 <b>Interpret with caution.</b>")
elif isinstance(nr, dict) and nr:
    # MANCOVA — dict of dicts per DV
    all_dv_ok = all(v.get("pass", False) for v in nr.values()
                    if isinstance(v, dict))
    txt = (f"\u2713 All DVs residuals normal \u2192 <b>{_analysis_lbl} applied.</b>"
           if all_dv_ok else
           f"\u26a0 Normality violated for one or more DVs \u2192 "
           f"<b>Interpret with caution.</b>")
else:
    txt = (f"\u2713 <b>{_analysis_lbl} applied.</b>"
           if all_ok else
           f"\u26a0 Check assumptions below.")

st.markdown(f'<div class="decision-banner {cls}">{txt}</div>',
            unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# QUICK METRICS
# ══════════════════════════════════════════════════════════════════════════════
t_type = R["type"]
if t_type == "One-Way ANCOVA":
    metrics = [
        (_f(R.get("F_factor",np.nan)),    f"F(1,\u2009{R.get('n',0)-3})"),
        (_p(R.get("p_factor",np.nan)),     "Sig."),
        (_f(R.get("partial_eta2",np.nan)), "Partial \u03b7\u00b2"),
        (_f(R.get("grand_cov_mean",np.nan)), f"\u0078\u0305 {R.get('cov_name','Cov')}"),
        (str(R.get("n","?")),              "N"),
    ]
elif t_type == "Factorial ANCOVA":
    metrics = [
        (_f(R.get("F_a",np.nan)),  f"F {R.get('fa_name','A')}"),
        (_p(R.get("p_a",np.nan)),   "Sig. A"),
        (_f(R.get("F_b",np.nan)),  f"F {R.get('fb_name','B')}"),
        (_p(R.get("p_b",np.nan)),   "Sig. B"),
        (str(R.get("n","?")),       "N"),
    ]
elif t_type == "Repeated Measures ANCOVA":
    metrics = [
        (_f(R.get("F_time",np.nan)),     f"F({R.get('df_time',2)},\u2009{R.get('df_resid_within','?')})"),
        (_p(R.get("p_time_gg",np.nan)),  "Sig. (GG)"),
        (_f(R.get("eta2_time",np.nan)),  "Partial \u03b7\u00b2"),
        (_f(R.get("eps_gg",np.nan)),     "\u03b5 (GG)"),
        (str(R.get("n","?")),            "N Subjects"),
    ]
elif t_type == "Mixed ANCOVA":
    metrics = [
        (_f(R.get("F_interact",np.nan)),  "F Interaction"),
        (_p(R.get("p_interact",np.nan)),   "Sig. Interaction"),
        (_f(R.get("eta2_interact",np.nan)),"Partial \u03b7\u00b2"),
        (_f(R.get("eps_gg",np.nan)),       "\u03b5 (GG)"),
        (str(R.get("n","?")),              "N Subjects"),
    ]
else:  # MANCOVA
    mv = R.get("mv_factor") or {}
    metrics = [
        (_f(mv.get("Wilks",np.nan)),   "Wilks' \u039b"),
        (_p(mv.get("p_Wilks",np.nan)), "Sig. (Wilks)"),
        (_f(mv.get("Pillai",np.nan)),  "Pillai's Trace"),
        (str(R.get("p", R.get("n","?"))), "No. DVs"),
        (str(R.get("n","?")),           "N"),
    ]

cols = st.columns(5)
for col, (val, lbl) in zip(cols, metrics):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{val}</div>'
        f'<div class="metric-lbl">{lbl}</div>'
        f'</div>',
        unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab_labels = [
    "&#128203; Assumptions",
    "&#128202; Descriptives",
    "&#128200; ANCOVA Results",
    "&#128201; EMMs &amp; Post-Hoc",
    "&#9889; Effect Size &amp; Power",
    "&#128200; Plots",
    "&#128172; Interpretation",
]
tabs = st.tabs(tab_labels)


# ── Tab 0: Assumptions ──────────────────────────────────────────────────────
with tabs[0]:
    nr = R.get("normality", {})
    norm_list = [nr] if isinstance(nr, dict) and "sw_W" in nr else []

    if norm_list:
        prim_lbl  = get_primary_label(norm_list)
        total_n   = get_total_n(norm_list)
        size_lbl  = "Total N\u2009<\u200950" if total_n < 50 else "Total N\u2009\u2265\u200950"
        st.markdown(
            f'<div class="norm-rec-box">{recommendation_note(total_n)}</div>',
            unsafe_allow_html=True)
        st.markdown('<div class="sec-title">Normality of Residuals</div>',
                    unsafe_allow_html=True)
        sw_html, ks_html = normality_table(norm_list, prim_lbl)
        st.markdown('<div class="sub-title">Shapiro-Wilk Test</div>',
                    unsafe_allow_html=True)
        st.markdown(sw_html, unsafe_allow_html=True)
        st.markdown('<div class="sub-title">Kolmogorov-Smirnov Test (Lilliefors)</div>',
                    unsafe_allow_html=True)
        st.markdown(ks_html, unsafe_allow_html=True)
        st.markdown(
            f'<div class="info-box" style="margin-top:.5rem;">{KS_DISCLAIMER}</div>',
            unsafe_allow_html=True)
        if norm_list[0].get("pass"):
            st.markdown(
                f'<div class="info-box">&#10003; <b>{prim_lbl}</b> ({size_lbl}) '
                f'p\u2009>\u2009.05 \u2192 Normality of residuals satisfied.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                f'<div class="warn-box">&#9888; <b>{prim_lbl}</b> ({size_lbl}) '
                f'p\u2009\u2264\u2009.05 \u2192 Normality violated. '
                f'ANCOVA is robust for N\u2009\u2265\u200930.</div>',
                unsafe_allow_html=True)
    # MANCOVA per DV
    elif isinstance(nr, dict) and nr:
        _sec_shown = False
        for dv, dv_nr in nr.items():
            if isinstance(dv_nr, dict) and "sw_W" in dv_nr:
                if not _sec_shown:
                    st.markdown('<div class="sec-title">Normality of Residuals (per DV)</div>',
                                unsafe_allow_html=True)
                    total_n_dv = get_total_n([dv_nr])
                    st.markdown(
                        f'<div class="norm-rec-box">{recommendation_note(total_n_dv)}</div>',
                        unsafe_allow_html=True)
                    _sec_shown = True
                st.markdown(f'<div class="sub-title">{dv}</div>', unsafe_allow_html=True)
                prim_lbl = get_primary_label([dv_nr])
                sw_h, ks_h = normality_table([dv_nr], prim_lbl)
                st.markdown(sw_h, unsafe_allow_html=True)
                st.markdown(ks_h, unsafe_allow_html=True)

    # Levene
    lev = R.get("levene", {})
    if lev:
        F_l = lev.get("F", np.nan)
        p_l = lev.get("p", lev.get("Sig.", np.nan))
        eq  = lev.get("passed", lev.get("equal_var", False))
        st.markdown('<div class="sec-title">Levene\u2019s Test for Equality of Variances</div>',
                    unsafe_allow_html=True)
        lev_rows = [["F","Sig.","Decision"],
                    [_f(F_l), _p(p_l),
                     "\u2713 Equal variances" if eq else "\u2717 Unequal variances"]]
        st.markdown(html_tbl(lev_rows), unsafe_allow_html=True)
        if eq:
            st.markdown('<div class="info-box">&#10003; p\u2009>\u2009.05 '
                        '\u2192 Equal variances assumed.</div>',
                        unsafe_allow_html=True)
        else:
            st.markdown('<div class="warn-box">&#9888; p\u2009\u2264\u2009.05 '
                        '\u2192 Unequal variances. Interpret with caution.</div>',
                        unsafe_allow_html=True)

    # Homogeneity of slopes
    for skey, slbl in [("slopes","Homogeneity of Regression Slopes"),
                       ("slopes_a","Regression Slopes — Factor A"),
                       ("slopes_b","Regression Slopes — Factor B")]:
        if skey in R:
            sl = R[skey]
            st.markdown(f'<div class="sec-title">{slbl}</div>',
                        unsafe_allow_html=True)
            s_rows = [["F","Sig.","Decision"],
                      [_f(sl.get("F",np.nan)), _p(sl.get("p",np.nan)),
                       "\u2713 Satisfied" if sl.get("passed") else "\u2717 Violated"]]
            st.markdown(html_tbl(s_rows), unsafe_allow_html=True)
            note = sl.get("note","")
            if note:
                box_cls = "info-box" if sl.get("passed") else "warn-box"
                st.markdown(f'<div class="{box_cls}">{note}</div>',
                            unsafe_allow_html=True)

    # Mauchly (RM / Mixed)
    if "mauchly_W" in R and not np.isnan(R.get("mauchly_W", np.nan)):
        st.markdown('<div class="sec-title">Mauchly\u2019s Test of Sphericity</div>',
                    unsafe_allow_html=True)
        sph_rows = [
            ["Mauchly W","\u03c7\u00b2","df","Sig.","\u03b5 (GG)","Decision"],
            [_f(R["mauchly_W"]), _f(R.get("mauchly_chi2",np.nan)),
             str(R.get("mauchly_df","?")), _p(R.get("mauchly_p",np.nan)),
             _f(R.get("eps_gg",np.nan)),
             "\u2713 Sphericity assumed" if R.get("mauchly_p",0) > 0.05
             else "\u2717 Sphericity violated \u2192 use GG-corrected"],
        ]
        st.markdown(html_tbl(sph_rows, left_cols={5}), unsafe_allow_html=True)
        if R.get("mauchly_p", 1) > 0.05:
            st.markdown('<div class="info-box">&#10003; Sphericity assumed (p\u2009>\u2009.05). '
                        'Uncorrected p-values are valid.</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="warn-box">&#9888; Sphericity violated (p\u2009\u2264\u2009.05). '
                        f'Use GG-corrected p-values (\u03b5\u2009=\u2009{_f(R.get("eps_gg",np.nan))}).'
                        f'</div>', unsafe_allow_html=True)

    # Linearity
    for lkey, llbl in [("linearity","Linearity: Covariate vs DV"),
                       ("linearity_a","Linearity per Factor A Group"),
                       ("linearity_b","Linearity per Factor B Group")]:
        if lkey in R:
            lin = R[lkey]
            if not lin.empty:
                st.markdown(f'<div class="sec-title">{llbl}</div>',
                            unsafe_allow_html=True)
                lrows = [["Group","N","r","Sig.","Linear?"]]
                for _, row in lin.iterrows():
                    lrows.append([row["Group"],str(row["N"]),
                                  _f(row["r"]), _p(row["Sig."]),
                                  "\u2713 Yes" if row["passed"] else "\u2717 No"])
                st.markdown(html_tbl(lrows, left_cols={0}), unsafe_allow_html=True)
                st.markdown('<p class="note-txt">Significant r (p\u2009&lt;\u2009.05) '
                            'confirms linear covariate\u2013DV relationship.</p>',
                            unsafe_allow_html=True)


# ── Tab 1: Descriptives ─────────────────────────────────────────────────────
with tabs[1]:
    st.markdown('<div class="sec-title">Descriptive Statistics</div>',
                unsafe_allow_html=True)
    desc = R.get("descriptives", pd.DataFrame()).copy()
    if not desc.empty:
        for c in desc.select_dtypes(include=float).columns:
            desc[c] = desc[c].apply(lambda v: _f(v) if not np.isnan(v) else ".")
        st.dataframe(desc, use_container_width=True, hide_index=True)


# ── Tab 2: ANCOVA Results ───────────────────────────────────────────────────
with tabs[2]:
    # One-Way / Factorial — Between-Subjects Effects
    if "anova_table" in R:
        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects — Type III SS</div>',
                    unsafe_allow_html=True)
        st.markdown(_render_df(R["anova_table"]), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Type III (Marginal) SS \u2014 SPSS GLM default. '
            f'Partial \u03b7\u00b2: &lt;.01 negligible, .01\u2013.06 small, '
            f'.06\u2013.14 medium, \u2265.14 large. '
            f'Covariate: {R.get("cov_name","?")}.</p>',
            unsafe_allow_html=True)

        # Parameter Estimates (Factorial)
        _pe = R.get("param_estimates")
        if _pe is not None and hasattr(_pe,"empty") and not _pe.empty:
            st.markdown('<div class="sec-title">Parameter Estimates</div>',
                        unsafe_allow_html=True)
            prows=[list(_pe.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _pe.loc[i]] for i in _pe.index]
            st.markdown(html_tbl(prows, left_cols={0}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Reference category (last level) set to 0. '
                'Partial η² = t²/(t²+df<sub>error</sub>).</p>',
                unsafe_allow_html=True)

        # Univariate Tests (simple/EMM main effects)
        _ut = R.get("univariate_tests")
        if _ut is not None and hasattr(_ut,"empty") and not _ut.empty:
            st.markdown('<div class="sec-title">Univariate Tests</div>',
                        unsafe_allow_html=True)
            urows=[list(_ut.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _ut.loc[i]] for i in _ut.index]
            st.markdown(html_tbl(urows, left_cols={0,1}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">F tests the effect of each factor on the '
                'estimated marginal means, adjusted for the covariate.</p>',
                unsafe_allow_html=True)
        # Box's M
        bm = R.get("boxes_m")
        if bm:
            st.markdown('<div class="sec-title">Box\'s Test of Equality of Covariance Matrices</div>',
                        unsafe_allow_html=True)
            bm_rows = [["Box's M","F","df1","df2","Sig."],
                       [_f(bm["M"]), _f(bm["F"]), str(bm["df1"]),
                        _f(bm["df2"]), _p(bm["Sig."])]]
            st.markdown(html_tbl(bm_rows), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Tests H₀: observed covariance matrices are equal. '
                'p &gt; .05 → assumption satisfied. '
                'This test is sensitive to non-normality.</p>',
                unsafe_allow_html=True)

        # Multivariate Tests — all 3 effects: Intercept, Covariate, Factor (SPSS order)
        _mv_hdr = ["Statistic","Value","F","Hypothesis df","Error df",
                   "Sig.","Partial \u03b7\u00b2","Noncent. Parameter"]

        def _mv_block(mv):
            if not mv: return []
            return [
                ["Pillai\u2019s Trace",
                 _f(mv["Pillai"]),    _f(mv["F_Pillai"]),
                 str(mv.get("df_hyp_Pillai","—")), str(mv.get("df_err_Pillai","—")),
                 _p(mv["p_Pillai"]),  _f(mv.get("eta2_Pillai","")),
                 _f(mv.get("noncent_Pillai",""))],
                ["Wilks\u2019 Lambda",
                 _f(mv["Wilks"]),     _f(mv["F_Wilks"]),
                 str(mv.get("df_hyp_Wilks","—")),  str(mv.get("df_err_Wilks","—")),
                 _p(mv["p_Wilks"]),   _f(mv.get("eta2_Wilks","")),
                 _f(mv.get("noncent_Wilks",""))],
                ["Hotelling-Lawley Trace",
                 _f(mv["Hotelling"]), _f(mv["F_HL"]),
                 str(mv.get("df_hyp_HL","—")),     str(mv.get("df_err_HL","—")),
                 _p(mv["p_HL"]),      _f(mv.get("eta2_HL","")),
                 _f(mv.get("noncent_HL",""))],
                ["Roy\u2019s Largest Root",
                 _f(mv["Roy"]),       _f(mv["F_Roy"]),
                 str(mv.get("df_hyp_Roy","—")),    str(mv.get("df_err_Roy","—")),
                 _p(mv["p_Roy"]),     _f(mv.get("eta2_Roy","")),
                 _f(mv.get("noncent_Roy",""))],
            ]

        for _eff_lbl, _mv_data in [
            ("Intercept",                    R.get("mv_intercept")),
            (R.get("cov_name","Covariate"),  R.get("mv_cov")),
            (R.get("factor_name","Group"),   R.get("mv_factor")),
        ]:
            _rows = _mv_block(_mv_data)
            if _rows:
                st.markdown(f'<div class="sec-title">Multivariate Tests \u2014 {_eff_lbl}</div>',
                            unsafe_allow_html=True)
                st.markdown(html_tbl([_mv_hdr]+_rows, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">Partial \u03b7\u00b2: Pillai=V/s; Wilks=1\u2212\u039b\u00b9\u141f\u02e2; '
            'Hotelling=T\u2080/(T\u2080+s); Roy=\u03b8/(1+\u03b8). '
            'Noncent.\u2009=\u2009F\u00d7df\u2099\u1d64\u2098.</p>',
            unsafe_allow_html=True)

        # Levene per DV
        lev_mc = R.get("levene_mancova", pd.DataFrame())
        if not lev_mc.empty:
            st.markdown('<div class="sec-title">Levene\'s Test of Equality of Error Variances</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(lev_mc, left_cols={0}), unsafe_allow_html=True)

        # Univariate ANCOVA per DV
        univ = R.get("univariate", pd.DataFrame())
        if not univ.empty:
            st.markdown('<div class="sec-title">Tests of Between-Subjects Effects (Univariate ANCOVAs)</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(univ, left_cols={0,1}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Type III SS. Each DV tested separately with the covariate. '
                'Partial η²: ≥.01 small, ≥.06 medium, ≥.14 large.</p>',
                unsafe_allow_html=True)

    # Noncentrality helper (shared by RM and Mixed within/between tables)
    def _nc(F, df):
        try: return _f(round(float(F)*float(df), 3))
        except Exception: return "\u2014"

    # Reusable multivariate block (RM/Mixed within-subjects)
    def _mv_within_tbl(mv, eff_lbl):
        if not mv: return ""
        rows = [["Statistic","Value","F","Hypothesis df","Error df","Sig.","Partial \u03b7\u00b2","Noncent."],
            ["Pillai\u2019s Trace",_f(mv["Pillai"]),_f(mv["F_Pillai"]),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv["p_Pillai"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Wilks\u2019 Lambda",_f(mv["Wilks"]),_f(mv["F_Wilks"]),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv["p_Wilks"]),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Hotelling-Lawley",_f(mv.get("Hotelling",np.nan)),_f(mv.get("F_HL",np.nan)),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv.get("p_HL",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
            ["Roy\u2019s Largest Root",_f(mv.get("Roy",np.nan)),_f(mv.get("F_Roy",np.nan)),
             str(mv.get("df_hyp","?")),str(mv.get("df_err","?")),
             _p(mv.get("p_Roy",np.nan)),_f(mv.get("eta2","")),_f(mv.get("noncent",""))],
        ]
        return (f'<div class="sec-title">Multivariate Tests \u2014 {eff_lbl}</div>'
                + html_tbl(rows, left_cols={0}))

    # RM ANCOVA
    if t_type == "Repeated Measures ANCOVA":
        cn = R.get("cov_name","Covariate")
        if R.get("mv_time"):
            st.markdown(_mv_within_tbl(R["mv_time"], "TIME"), unsafe_allow_html=True)
        if R.get("mv_tc"):
            st.markdown(_mv_within_tbl(R["mv_tc"], f"TIME \u00d7 {cn}"), unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                    unsafe_allow_html=True)
        wr = [["Source","Type III SS","df","MS","F",
               "Sig. (Uncorrected)","Sig. (GG)","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent. Parameter"],
              ["TIME",_f(R.get("SS_time",np.nan)),str(R.get("df_time","?")),
               _f(R.get("MS_time",np.nan)),_f(R.get("F_time",np.nan)),
               _p(R.get("p_time",np.nan)),_p(R.get("p_time_gg",np.nan)),
               _f(R.get("eps_gg",np.nan)),_f(R.get("eta2_time",np.nan)),
               _nc(R.get("F_time",np.nan), R.get("df_time",1))],
              [f"TIME \u00d7 {R.get('cov_name','COV')}",
               _f(R.get("SS_tc",np.nan)),str(R.get("df_tc","?")),"\u2014",
               _f(R.get("F_tc",np.nan)),_p(R.get("p_tc",np.nan)),"\u2014","\u2014",
               _f(R.get("eta2_tc",np.nan)),
               _nc(R.get("F_tc",np.nan), R.get("df_tc",1))]]
        st.markdown(html_tbl(wr, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Error df\u2009=\u2009{R.get("df_resid_within","?")} '
            f'= (T\u22121)(N\u22121\u2212p) \u2014 SPSS formula.</p>',
            unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects (Covariate)</div>',
                    unsafe_allow_html=True)
        br = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
              [R.get("cov_name","Covariate"),_f(R.get("SS_cov",np.nan)),"1",
               _f(R.get("F_cov",np.nan)),_p(R.get("p_cov",np.nan)),
               _f(R.get("eta2_cov",np.nan)),_nc(R.get("F_cov",np.nan), 1)],
              ["Error","\u2014",str(R.get("df_err_between","?")),"\u2014","\u2014","\u2014","\u2014"]]
        st.markdown(html_tbl(br, left_cols={0}), unsafe_allow_html=True)

        # Within-Subjects Contrasts
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            crows=[list(_cdf.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[i]] for i in _cdf.index]
            st.markdown(html_tbl(crows, left_cols={0,1}), unsafe_allow_html=True)

    # Mixed ANCOVA
    if t_type == "Mixed ANCOVA":
        cn = R.get("cov_name","Covariate"); bn = R.get("between_name","Group")
        # Box's M Test
        bm = R.get("boxes_m")
        if bm:
            st.markdown('<div class="sec-title">Box\'s Test of Equality of Covariance Matrices</div>',
                        unsafe_allow_html=True)
            bm_rows = [["Box's M","F","df1","df2","Sig."],
                       [_f(bm["M"]), _f(bm["F"]), str(bm["df1"]),
                        _f(bm["df2"]), _p(bm["Sig."])]]
            st.markdown(html_tbl(bm_rows), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Tests H₀: covariance matrices of the repeated '
                'measures are equal across groups. p &gt; .05 → assumption satisfied.</p>',
                unsafe_allow_html=True)
        if R.get("mv_time"):
            st.markdown(_mv_within_tbl(R["mv_time"], "TIME"), unsafe_allow_html=True)
        if R.get("mv_tg"):
            st.markdown(_mv_within_tbl(R["mv_tg"], f"TIME \u00d7 {bn}"), unsafe_allow_html=True)
        if R.get("mv_tc"):
            st.markdown(_mv_within_tbl(R["mv_tc"], f"TIME \u00d7 {cn}"), unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                    unsafe_allow_html=True)
        wh = [["Source","SS","df","F","Sig.","\u03b5 (GG)","Partial \u03b7\u00b2","Noncent. Parameter"],
              ["TIME",_f(R.get("SS_time",np.nan)),str(R.get("df_time",2)),
               _f(R.get("F_time",np.nan)),_p(R.get("p_time",np.nan)),
               _f(R.get("eps_gg",np.nan)),_f(R.get("eta2_time",np.nan)),
               _nc(R.get("F_time",np.nan), R.get("df_time",2))],
              [f"TIME \u00d7 {R.get('between_name','Group')}",
               _f(R.get("SS_interact",np.nan)),
               str((R.get("T",3)-1)*(R.get("k",2)-1)),
               _f(R.get("F_interact",np.nan)),_p(R.get("p_interact",np.nan)),
               "\u2014",_f(R.get("eta2_interact",np.nan)),
               _nc(R.get("F_interact",np.nan),(R.get("T",3)-1)*(R.get("k",2)-1))],
              [f"TIME \u00d7 {R.get('cov_name','COV')}",
               _f(R.get("SS_tc",np.nan)),str(R.get("T",3)-1),
               _f(R.get("F_tc",np.nan)),_p(R.get("p_tc",np.nan)),
               "\u2014",_f(R.get("eta2_tc",np.nan)),
               _nc(R.get("F_tc",np.nan), R.get("T",3)-1)]]
        st.markdown(html_tbl(wh, left_cols={0}), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">Error df\u2009=\u2009{R.get("df_resid_within","?")} '
            f'= (T\u22121)(N\u2212k\u2212p) \u2014 SPSS formula.</p>',
            unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Tests of Between-Subjects Effects</div>',
                    unsafe_allow_html=True)
        bh = [["Source","SS","df","F","Sig.","Partial \u03b7\u00b2","Noncent. Parameter"],
              [R.get("between_name","Group"),_f(R.get("SS_between",np.nan)),
               str(R.get("df_between","?")),_f(R.get("F_between",np.nan)),
               _p(R.get("p_between",np.nan)),_f(R.get("eta2_between",np.nan)),
               _nc(R.get("F_between",np.nan), R.get("df_between",1))],
              [R.get("cov_name","Covariate"),_f(R.get("SS_cov",np.nan)),"1",
               _f(R.get("F_cov",np.nan)),_p(R.get("p_cov",np.nan)),
               _f(R.get("eta2_cov",np.nan)),
               _nc(R.get("F_cov",np.nan), 1)],
              ["Error","\u2014",str(R.get("df_resid_between","?")),"\u2014","\u2014","\u2014","\u2014"]]
        st.markdown(html_tbl(bh, left_cols={0}), unsafe_allow_html=True)

        # Within-Subjects Contrasts
        _cdf = R.get("contrasts")
        if _cdf is not None and hasattr(_cdf,"empty") and not _cdf.empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            crows=[list(_cdf.columns)]+[[_f(v) if isinstance(v,float) else str(v) for v in _cdf.loc[i]] for i in _cdf.index]
            st.markdown(html_tbl(crows, left_cols={0,1}), unsafe_allow_html=True)


# ── Tab 3: EMMs & Post-Hoc ──────────────────────────────────────────────────
with tabs[3]:
    st.markdown('<div class="sec-title">Estimated Marginal Means</div>',
                unsafe_allow_html=True)
    st.markdown(
        f'<p class="note-txt">Computed at grand mean of '
        f'{R.get("cov_name","covariate")}\u2009=\u2009'
        f'{_f(R.get("grand_cov_mean",np.nan))} \u2014 SPSS method.</p>',
        unsafe_allow_html=True)

    for k, lbl in [("emm","Group / Time EMMs"),
                   ("emm_cell","Cell EMMs (Group \u00d7 Time)"),
                   ("emm_group","Group EMMs (averaged over time)"),
                   ("emm_time","Time EMMs (averaged over groups)"),
                   ("emm_a",f"Marginal Means \u2014 {R.get('fa_name','')} (averaged over {R.get('fb_name','')})"),
                   ("emm_b",f"Marginal Means \u2014 {R.get('fb_name','')} (averaged over {R.get('fa_name','')})")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_,"empty") and not df_.empty:
            st.markdown(f'<div class="sub-title">{lbl}</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(df_), unsafe_allow_html=True)

    has_pw = any(
        R.get(k) is not None and hasattr(R.get(k),"empty") and not R[k].empty
        for k in ["pairwise","pairwise_a","pairwise_b","pairwise_time","pairwise_group"])
    if has_pw:
        st.markdown('<div class="sec-title">Pairwise Comparisons</div>',
                    unsafe_allow_html=True)
        for k, lbl in [("pairwise", f"Pairwise ({posthoc_method.title()})"),
                       ("pairwise_a", f"Pairwise \u2014 {R.get('fa_name','')} ({posthoc_method.title()})"),
                       ("pairwise_b", f"Pairwise \u2014 {R.get('fb_name','')} ({posthoc_method.title()})"),
                       ("pairwise_time",f"Pairwise TIME ({posthoc_method.title()})"),
                       ("pairwise_group",f"Pairwise GROUP ({posthoc_method.title()})")]:
            df_ = R.get(k)
            if df_ is not None and hasattr(df_,"empty") and not df_.empty:
                st.markdown(f'<div class="sub-title">{lbl}</div>',
                            unsafe_allow_html=True)
                st.markdown(_render_df(df_, {0,1}), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">* = significant at selected \u03b1. '
            'Two-tailed. 95% CI adjusted for family-wise error rate.</p>',
            unsafe_allow_html=True)
    else:
        st.info("Pairwise comparisons not available for this ANCOVA type.")


# ── Tab 4: Effect Size & Power ───────────────────────────────────────────────
with tabs[4]:
    st.markdown('<div class="sec-title">Effect Size &amp; Statistical Power</div>',
                unsafe_allow_html=True)
    from scipy import stats as sc
    def _pwr(eta2, df_num=1, df_den=None):
        if np.isnan(eta2) or eta2 >= 1: return np.nan
        f2 = eta2 / (1-eta2)
        dn = df_den or max(R.get("n",30)-2, 1)
        try:
            ncp = f2 * (df_num + dn + 1)
            fc  = sc.f.ppf(1-alpha, df_num, dn)
            return float(np.clip(sc.ncf.sf(fc, df_num, dn, ncp), 0, 1))
        except: return np.nan

    es_rows = [["Effect","Partial \u03b7\u00b2","Cohen's f","Interpretation","Power"]]
    def _add(lbl, eta2, dfn=1, dfd=None):
        if np.isnan(eta2): return
        f_val = float(np.sqrt(eta2/(1-eta2))) if eta2 < 1 else np.nan
        pwr   = _pwr(eta2, dfn, dfd or max(R.get("n",30)-2,1))
        es_rows.append([lbl, _f(eta2),
                        _f(f_val) if not np.isnan(f_val) else "\u2014",
                        _effect_label(eta2),
                        f"{pwr*100:.1f}%" if not np.isnan(pwr) else "\u2014"])
    for key, lbl in [("partial_eta2","Group (Factor)"),("eta2_a","Factor A"),
                     ("eta2_b","Factor B"),("eta2_ab","Interaction A\u00d7B"),
                     ("eta2_time","Time (Within)"),("eta2_between","Between-Subjects"),
                     ("eta2_interact","Interaction"),("eta2_cov","Covariate")]:
        v = R.get(key, np.nan)
        if v is not None and not np.isnan(v): _add(lbl, v)
    st.markdown(html_tbl(es_rows, left_cols={0,3}),
                unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">Partial \u03b7\u00b2 benchmarks: '
        '\u2265.01 small, \u2265.06 medium, \u2265.14 large (Cohen, 1988). '
        'Power based on non-central F distribution at selected \u03b1.</p>',
        unsafe_allow_html=True)


# ── Tab 5: Plots ─────────────────────────────────────────────────────────────
with tabs[5]:
    if figs_b:
        for lbl, b64 in figs_b:
            st.markdown(f'<div class="sec-title">{lbl}</div>',
                        unsafe_allow_html=True)
            st.image(base64.b64decode(b64))
    else:
        st.info("No plots available for this analysis.")


# ── Tab 6: Interpretation ────────────────────────────────────────────────────
with tabs[6]:
    st.markdown('<div class="sec-title">Academic Interpretation</div>',
                unsafe_allow_html=True)
    for line in interps:
        sig_cls = ""
        if "statistically significant" in line and "not statistically" not in line:
            sig_cls = " sig"
        st.markdown(f'<div class="interp-box{sig_cls}">{line}</div>',
                    unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS  (identical pattern to 2_anova.py)
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
dc1, dc2 = st.columns(2)
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
nm = test_type.replace(" ", "_")

with dc1:
    with st.spinner("Generating HTML report\u2026"):
        html_data = _build_html(R, meta, interps, figs_b, alpha)
    st.download_button(
        "&#127760; HTML Report (Full)",
        html_data,
        f"ANCOVA_{nm}_{ts}.html",
        "text/html", use_container_width=True)

with dc2:
    parts = [f"INFERENTIAL STATISTICS BY MA \u2014 ANCOVA\n"]
    parts.append(f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}\n")
    parts.append("\n=== ANALYSIS INFORMATION ===\n"
                 + pd.DataFrame([{"Parameter": k, "Value": str(v)}
                                  for k, v in meta.items()]).to_csv(index=False))
    for k, lbl in [("anova_table","ANOVA TABLE"), ("emm","EMMs"),
                   ("emm_group","GROUP EMMs"), ("emm_time","TIME EMMs"),
                   ("pairwise","PAIRWISE"), ("pairwise_time","PAIRWISE TIME"),
                   ("pairwise_group","PAIRWISE GROUP"),
                   ("descriptives","DESCRIPTIVES")]:
        df_ = R.get(k)
        if df_ is not None and hasattr(df_, "empty") and not df_.empty:
            parts.append(f"\n=== {lbl} ===\n" + df_.to_csv(index=False))
    clean = [re.sub(r"<[^>]+>", "", ln) for ln in interps]
    parts.append("\n=== INTERPRETATION ===\n"
                 + pd.DataFrame({"Line": range(1, len(clean)+1), "Text": clean})
                 .to_csv(index=False))
    csv_data = "\n".join(parts).encode("utf-8")
    st.download_button(
        "&#128221; CSV Tables",
        csv_data,
        f"ANCOVA_{nm}_{ts}.csv",
        "text/csv", use_container_width=True)
