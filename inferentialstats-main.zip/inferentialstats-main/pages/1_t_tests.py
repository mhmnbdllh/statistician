"""
pages/1_T_Tests.py
==================
Streamlit page for T-Test family analysis.

Tests available:
  - One-Sample T-Test       + Wilcoxon Signed-Rank
  - Paired-Sample T-Test    + Wilcoxon Signed-Rank
  - Independent-Sample T-Test + Mann-Whitney U

Features:
  - SPSS-equivalent output
  - Auto-selection of parametric vs non-parametric based on normality
  - Normality criterion based on Total N (not per-group n)
  - Cohen's d + rank-biserial r + 95% bootstrap CI
  - Post-hoc statistical power analysis
  - Assumption summary table
  - APA 7th edition write-up
  - HTML offline report + CSV download
"""

import streamlit as st
import pandas as pd
import numpy as np
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

# ── Page config ────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="T-Tests | Inferential Statistics by MA",
    page_icon="📐",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports ────────────────────────────────────────────────────────────────
from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols,
                                get_categorical_cols, get_group_levels)
from utils.samples     import SAMPLES
from utils.tables      import (html_tbl, df_to_rows,
                                descriptives_table, normality_table,
                                assumption_summary_table,
                                levene_table, correlation_table,
                                effect_size_table, power_table,
                                one_sample_parametric_table,
                                paired_parametric_table,
                                independent_parametric_tables,
                                wilcoxon_tables, mannwhitney_tables)
from utils.plots       import (plot_one_sample, plot_paired,
                                plot_independent, fig_to_bytes)

from modules.t_tests    import run_one_sample, run_paired, run_independent
from modules.normality  import (recommendation_note, KS_DISCLAIMER,
                                 normality_decision_text, get_primary_label,
                                 get_total_n)
from modules.power      import compute_power, power_table_rows
from modules.assumptions import build_assumption_summary

from exports.html_report import build_html_report
from exports.csv_export  import build_csv

from utils.formatters import (_f, _p, format_u,
                               effect_label_d, effect_label_r, power_label)

import matplotlib.pyplot as plt

# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS  (defined early — called during run_btn block)
# ══════════════════════════════════════════════════════════════════════════════

def _interpret_one_sample(R, var_name, alpha):
    """Generate interpretation lines for One-Sample T-Test."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]
    nm   = R["normality"][0]
    lines = []

    prim = nm["primary_label"]
    n    = nm["total_n"]
    sw   = "normally distributed" if nm["sw_pass"] else "non-normally distributed"
    ks   = "normally distributed" if nm["ks_pass"] else "non-normally distributed"
    size = "n\u2009<\u200950" if n < 50 else "n\u2009\u2265\u200950"

    lines.append(
        f"<b>Normality Assessment:</b> "
        f"Shapiro-Wilk W\u2009=\u2009{_f(nm['sw_W'])}, "
        f"p\u2009=\u2009{_p(nm['sw_p'])} ({sw}); "
        f"Kolmogorov-Smirnov D\u2009=\u2009{_f(nm['ks_D'])}, "
        f"p\u2009=\u2009{_p(nm['ks_p'])} ({ks}). "
        f"Given Total N\u2009=\u2009{n} ({size}), "
        f"the <b>{prim}</b> test was used as the primary criterion. "
        f"{'Parametric analysis was applied.' if R['use_param'] else 'Non-parametric analysis was applied.'}"
    )

    if R["use_param"]:
        sig = pr["p_two"] < alpha
        lines.append(
            f"<b>One-Sample T-Test:</b> "
            f"t({pr['df']})\u2009=\u2009{_f(pr['t'])}, "
            f"p\u2009=\u2009{_p(pr['p_two'])} (2-tailed). "
            f"Mean difference\u2009=\u2009{_f(pr['mean_diff'])}, "
            f"95% CI [{_f(pr['ci_lower'])},\u2009{_f(pr['ci_upper'])}], "
            f"Cohen\u2019s d\u2009=\u2009{_f(pr['cohens_d'])} "
            f"({effect_label_d(pr['cohens_d'])} effect). "
            f"The sample mean "
            f"{'significantly differed from' if sig else 'did not significantly differ from'} "
            f"the hypothesised population mean "
            f"(\u03bc\u2080\u2009=\u2009{pr['mu0']}) "
            f"at \u03b1\u2009=\u2009{alpha}."
        )
    else:
        sig = (not np.isnan(np_r["p"])) and np_r["p"] < alpha
        lines.append(
            f"<b>Wilcoxon Signed-Rank Test:</b> "
            f"W\u2009=\u2009{_f(np_r['W'], 3)}, "
            f"Z\u2009=\u2009{_f(np_r['Z'])}, "
            f"p\u2009=\u2009{_p(np_r['p'])} (2-tailed, asymptotic). "
            f"{'A statistically significant' if sig else 'No statistically significant'} "
            f"difference from \u03bc\u2080\u2009=\u2009{np_r['mu0']} "
            f"was detected at \u03b1\u2009=\u2009{alpha}."
        )
    return lines


def _interpret_paired(R, alpha):
    """Generate interpretation lines for Paired-Sample T-Test."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]
    nm   = R["normality"][0]
    corr = R["correlation"]
    rv   = float(corr["Pearson Correlation"].iloc[0])
    pv   = float(corr["Sig. (2-tailed)"].iloc[0])
    lines = []

    prim = nm["primary_label"]
    n    = nm["total_n"]
    sw   = "normally distributed" if nm["sw_pass"] else "non-normally distributed"
    ks   = "normally distributed" if nm["ks_pass"] else "non-normally distributed"
    size = "n\u2009<\u200950" if n < 50 else "n\u2009\u2265\u200950"

    lines.append(
        f"<b>Normality of Differences:</b> "
        f"Shapiro-Wilk W\u2009=\u2009{_f(nm['sw_W'])}, "
        f"p\u2009=\u2009{_p(nm['sw_p'])} ({sw}); "
        f"Kolmogorov-Smirnov D\u2009=\u2009{_f(nm['ks_D'])}, "
        f"p\u2009=\u2009{_p(nm['ks_p'])} ({ks}). "
        f"Given Total N\u2009=\u2009{n} ({size}), "
        f"the <b>{prim}</b> test was used as the primary criterion. "
        f"{'Parametric analysis was applied.' if R['use_param'] else 'Non-parametric analysis was applied.'}"
    )
    lines.append(
        f"<b>Paired Samples Correlation:</b> "
        f"{pr['label1']} and {pr['label2']} were "
        f"{'significantly' if pv < alpha else 'not significantly'} correlated, "
        f"r({pr['df']})\u2009=\u2009{_f(rv)}, p\u2009=\u2009{_p(pv)}."
    )

    if R["use_param"]:
        sig = pr["p_two"] < alpha
        lines.append(
            f"<b>Paired Samples T-Test:</b> "
            f"t({pr['df']})\u2009=\u2009{_f(pr['t'])}, "
            f"p\u2009=\u2009{_p(pr['p_two'])} (2-tailed). "
            f"Mean difference\u2009=\u2009{_f(pr['mean_diff'])} "
            f"(SD\u2009=\u2009{_f(pr['sd_diff'])}), "
            f"95% CI [{_f(pr['ci_lower'])},\u2009{_f(pr['ci_upper'])}], "
            f"Cohen\u2019s d\u2009=\u2009{_f(pr['cohens_d'])} "
            f"({effect_label_d(pr['cohens_d'])} effect). "
            f"{'A statistically significant difference was found' if sig else 'No statistically significant difference was found'} "
            f"between {pr['label1']} and {pr['label2']} "
            f"at \u03b1\u2009=\u2009{alpha}."
        )
    else:
        sig = (not np.isnan(np_r["p"])) and np_r["p"] < alpha
        lines.append(
            f"<b>Wilcoxon Signed-Rank Test:</b> "
            f"W\u2009=\u2009{_f(np_r['W'], 3)}, "
            f"Z\u2009=\u2009{_f(np_r['Z'])}, "
            f"p\u2009=\u2009{_p(np_r['p'])} (2-tailed, asymptotic). "
            f"{'A statistically significant' if sig else 'No statistically significant'} "
            f"difference between {pr['label1']} and {pr['label2']} "
            f"was detected at \u03b1\u2009=\u2009{alpha}."
        )
    return lines


def _interpret_independent(R, dep_var, alpha):
    """Generate interpretation lines for Independent-Sample T-Test."""
    pr   = R["parametric"]
    np_r = R["nonparametric"]
    lev  = R["levene"]
    lines = []

    for nm in R["normality"]:
        prim = nm["primary_label"]
        n    = nm["total_n"]
        sw   = "normal" if nm["sw_pass"] else "non-normal"
        ks   = "normal" if nm["ks_pass"] else "non-normal"
        size = "Total N\u2009<\u200950" if n < 50 else "Total N\u2009\u2265\u200950"
        lines.append(
            f"<b>Normality \u2014 {nm['label']}:</b> "
            f"Shapiro-Wilk W\u2009=\u2009{_f(nm['sw_W'])}, "
            f"p\u2009=\u2009{_p(nm['sw_p'])} ({sw}); "
            f"KS D\u2009=\u2009{_f(nm['ks_D'])}, "
            f"p\u2009=\u2009{_p(nm['ks_p'])} ({ks}). "
            f"Primary criterion: <b>{prim}</b> ({size})."
        )

    lines.append(
        f"<b>Overall Normality Decision:</b> "
        + ("Both groups satisfied the normality assumption; "
           "parametric analysis was applied."
           if R["use_param"] else
           "The normality assumption was violated in at least one group; "
           "non-parametric analysis was applied.")
    )
    lines.append(
        f"<b>Levene\u2019s Test for Equality of Variances:</b> "
        f"F({lev['df1']},\u2009{lev['df2']})\u2009=\u2009{_f(lev['F'])}, "
        f"p\u2009=\u2009{_p(lev['Sig.'])}. "
        + ("Equal variances were assumed (p\u2009>\u2009.05)."
           if lev["equal_var"] else
           "Equal variances were not assumed "
           "(p\u2009\u2264\u2009.05); the Welch correction was applied.")
    )

    if R["use_param"]:
        eq  = lev["equal_var"]
        tv  = pr["t_eq"]    if eq else pr["t_welch"]
        pv  = pr["p_eq"]    if eq else pr["p_welch"]
        dfv = pr["df_eq"]   if eq else pr["df_welch"]
        cil = pr["ci_eq_l"] if eq else pr["ci_welch_l"]
        ciu = pr["ci_eq_u"] if eq else pr["ci_welch_u"]
        sig = pv < alpha
        lines.append(
            f"<b>Independent Samples T-Test "
            f"({'equal variances assumed' if eq else 'Welch correction'}):</b> "
            f"t({_f(dfv, 2)})\u2009=\u2009{_f(tv)}, "
            f"p\u2009=\u2009{_p(pv)} (2-tailed). "
            f"Mean difference\u2009=\u2009{_f(pr['mean_diff'])}, "
            f"95% CI [{_f(cil)},\u2009{_f(ciu)}], "
            f"Cohen\u2019s d\u2009=\u2009{_f(pr['cohens_d'])} "
            f"({effect_label_d(pr['cohens_d'])} effect). "
            + ("A statistically significant" if sig
               else "No statistically significant")
            + f" difference in {dep_var} was found between the two groups "
            f"at \u03b1\u2009=\u2009{alpha}."
        )
    else:
        sig = (not np.isnan(np_r["p"])) and np_r["p"] < alpha
        lines.append(
            f"<b>Mann-Whitney U Test:</b> "
            f"U\u2009=\u2009{format_u(np_r['U'])}, "
            f"W\u2009=\u2009{_f(np_r['W_wilcoxon'], 3)}, "
            f"Z\u2009=\u2009{_f(np_r['Z'])}, "
            f"p\u2009=\u2009{_p(np_r['p'])} (2-tailed, asymptotic). "
            + ("A statistically significant" if sig
               else "No statistically significant")
            + f" difference in {dep_var} was found between the two groups "
            f"at \u03b1\u2009=\u2009{alpha}."
        )
    return lines


# ══════════════════════════════════════════════════════════════════════════════
# CSS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(load_page_css(), unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# HEADER
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div class="main-hdr">
  <h1>&#128208; T-Tests
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Auto-Select</span>
  </h1>
  <p>One-Sample &nbsp;&middot;&nbsp; Paired-Sample &nbsp;&middot;&nbsp;
     Independent-Sample &nbsp;&middot;&nbsp;
     Wilcoxon &nbsp;&middot;&nbsp; Mann-Whitney U</p>
</div>""", unsafe_allow_html=True)

st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:1rem;margin-bottom:.4rem;">
    &#9749; Support this work &mdash; scan QRIS:</p>
  <img src="https://muhaiminabdullah.com/media/images/qris_muhaiminabdullahdotcom.png"
       style="width:220px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### &#9881;&#65039; Configuration")
    st.markdown("---")

    _tests = [
        "One-Sample T-Test",
        "Paired-Sample T-Test",
        "Independent-Sample T-Test",
    ]
    _default = st.session_state.get("selected_test", "One-Sample T-Test")
    _default_idx = _tests.index(_default) if _default in _tests else 0

    test_type = st.selectbox(
        "&#128202; Select Test",
        _tests,
        index=_default_idx,
    )
    alpha = st.selectbox(
        "\u03b1 Significance Level",
        [0.05, 0.01, 0.001],
        index=0,
    )
    st.markdown("---")

    # ── Sample data ────────────────────────────────────────────────────────
    samp = SAMPLES[test_type]
    st.markdown(f"**&#128196; Sample Data \u2014 {test_type}**")
    st.markdown(f'<p style="font-size:.8rem;color:#64748b;">{samp["note"]}</p>',
                unsafe_allow_html=True)
    st.download_button(
        "&#11015;&#65039; Download Sample CSV",
        samp["csv"].encode(),
        f"sample_{test_type.replace(' ', '_').replace('-', '_').lower()}.csv",
        "text/csv",
        use_container_width=True,
    )
    st.markdown("---")

    # ── File upload ────────────────────────────────────────────────────────
    uploaded = st.file_uploader(
        "&#128194; Upload Data File",
        type=["csv", "xlsx", "xls"],
        help="Accepted formats: .csv, .xlsx, .xls",
    )

    if uploaded:
        try:
            df = load_file(uploaded)
            fm = file_metadata(uploaded, df)
            val = validate_file(df)
            if val["errors"]:
                for e in val["errors"]:
                    st.error(e)
                df = None
            else:
                st.success(
                    f"&#10003; {fm['Rows']:,} rows \u00d7 "
                    f"{fm['Columns']} columns"
                )
                for w in val["warnings"]:
                    st.warning(w)
        except Exception as e:
            st.error(str(e))
            df = None
    else:
        df = load_from_string(samp["csv"])
        st.info("\u2139\ufe0f Using built-in sample data")

    # ── Variable selection ─────────────────────────────────────────────────
    cfg = None
    if df is not None:
        num_cols = get_numeric_cols(df)
        cat_cols = get_categorical_cols(df)
        st.markdown("---")

        if test_type == "One-Sample T-Test":
            tv  = st.selectbox(
                "&#127919; Test Variable", num_cols,
                index=num_cols.index("score") if "score" in num_cols else 0,
            )
            mu0 = st.number_input(
                "&#128207; Hypothesised Population Mean (\u03bc\u2080)",
                value=75.0, step=0.5,
            )
            cfg = {"test_var": tv, "mu0": mu0}

        elif test_type == "Paired-Sample T-Test":
            # Detect and skip ID columns for default selection
            def _is_id(col, series):
                cl = col.lower().strip()
                id_names = {'id','no','num','number','index','code',
                            'subject_id','respondent','participant','sampel','nomor'}
                id_sfx   = ('_id','_no','_num','_number','_code','_index')
                id_pfx   = ('id_','no_','num_')
                name_match = (cl in id_names or
                              any(cl.endswith(s) for s in id_sfx) or
                              any(cl.startswith(s) for s in id_pfx))
                if not name_match:
                    return False
                s = series.dropna()
                if len(s) == 0: return False
                try:
                    return bool((s == s.astype(int)).all()) and s.nunique() == len(s)
                except Exception:
                    return False

            non_id_cols = [c for c in num_cols
                           if not _is_id(c, df[c])]
            _v1_defaults = ["pre","pre_score","pre_test","before","time1",
                            "baseline","var1","variable1"]
            _v2_defaults = ["post","post_score","post_test","after","time2",
                            "followup","var2","variable2"]
            _v1_idx = next(
                (num_cols.index(c) for c in _v1_defaults if c in num_cols),
                num_cols.index(non_id_cols[0]) if non_id_cols else 0
            )
            _v2_idx = next(
                (num_cols.index(c) for c in _v2_defaults if c in num_cols),
                num_cols.index(non_id_cols[1])
                    if len(non_id_cols) > 1
                    else min(1, len(num_cols) - 1)
            )
            v1 = st.selectbox(
                "Variable 1 (Pre / Time 1)", num_cols,
                index=_v1_idx,
            )
            v2 = st.selectbox(
                "Variable 2 (Post / Time 2)", num_cols,
                index=_v2_idx,
            )
            cfg = {"v1": v1, "v2": v2}

        else:
            gc = st.selectbox(
                "&#128101; Grouping Variable",
                cat_cols if cat_cols else num_cols,
                index=cat_cols.index("group") if "group" in cat_cols else 0,
            )
            dc = st.selectbox(
                "&#127919; Dependent Variable", num_cols,
                index=num_cols.index("score") if "score" in num_cols else 0,
            )
            groups = get_group_levels(df, gc)
            if len(groups) >= 2:
                g1l = st.selectbox("Group 1", groups, index=0)
                g2l = st.selectbox("Group 2", groups,
                                    index=min(1, len(groups) - 1))
                cfg = {"grp_col": gc, "dep_col": dc,
                       "g1": g1l, "g2": g2l}
            else:
                st.error(
                    "The grouping variable must contain at least "
                    "two distinct groups."
                )

        st.markdown("---")
        run_btn = st.button(
            "&#128640; Run Analysis",
            type="primary",
            use_container_width=True,
        )
    else:
        run_btn = False

# ══════════════════════════════════════════════════════════════════════════════
# DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════
if df is not None:
    with st.expander("&#128269; Data Preview", expanded=False):
        st.dataframe(df.head(20), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# WELCOME STATE
# ══════════════════════════════════════════════════════════════════════════════
if not run_btn and "stats_R" not in st.session_state:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        f'border:1px solid #bae6fd;border-radius:12px;'
        f'padding:1.2rem 1.4rem;margin:.8rem 0;'
        f'border-left:4px solid #0284c7;">'
        f'<h4 style="margin:0 0 .4rem;font-size:.95rem;font-weight:700;">'
        f'&#128203; {test_type}</h4>'
        f'<p style="margin:0;font-size:.84rem;color:#475569;">'
        f'{samp["desc"]}</p></div>',
        unsafe_allow_html=True,
    )
    st.info(
        "&#128072; Configure your variables in the sidebar, "
        "then click **Run Analysis**."
    )
    st.stop()

# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("&#9888;&#65039; Variable configuration is incomplete.")
        st.stop()

    with st.spinner("Running analysis\u2026"):
        try:
            if test_type == "One-Sample T-Test":
                data = df[cfg["test_var"]].dropna().values.tolist()
                R    = run_one_sample(data, cfg["mu0"],
                                      cfg["test_var"], alpha)
                meta = {
                    "Test":                     test_type,
                    "Variable":                 cfg["test_var"],
                    "Hypothesised Mean (\u03bc\u2080)": cfg["mu0"],
                    "N":                        len(data),
                    "\u03b1":                   alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps  = _interpret_one_sample(R, cfg["test_var"], alpha)
                fig_main = plot_one_sample(data, cfg["mu0"], cfg["test_var"])

            elif test_type == "Paired-Sample T-Test":
                pdata = df[[cfg["v1"], cfg["v2"]]].dropna()
                d1    = pdata[cfg["v1"]].values.tolist()
                d2    = pdata[cfg["v2"]].values.tolist()
                R     = run_paired(d1, d2, cfg["v1"], cfg["v2"], alpha)
                meta  = {
                    "Test":        test_type,
                    "Variable 1":  cfg["v1"],
                    "Variable 2":  cfg["v2"],
                    "N (pairs)":   len(d1),
                    "\u03b1":      alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps  = _interpret_paired(R, alpha)
                fig_main = plot_paired(d1, d2, cfg["v1"], cfg["v2"])

            else:
                g1d = (df[df[cfg["grp_col"]] == cfg["g1"]]
                       [cfg["dep_col"]].dropna().values.tolist())
                g2d = (df[df[cfg["grp_col"]] == cfg["g2"]]
                       [cfg["dep_col"]].dropna().values.tolist())
                R   = run_independent(g1d, g2d, cfg["g1"], cfg["g2"],
                                      cfg["dep_col"], alpha)
                meta = {
                    "Test":               test_type,
                    "Grouping Variable":  cfg["grp_col"],
                    "Dependent Variable": cfg["dep_col"],
                    "Group 1": f"{cfg['g1']} (n\u2009=\u2009{len(g1d)})",
                    "Group 2": f"{cfg['g2']} (n\u2009=\u2009{len(g2d)})",
                    "\u03b1":  alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps  = _interpret_independent(R, cfg["dep_col"], alpha)
                fig_main = plot_independent(
                    g1d, g2d, cfg["g1"], cfg["g2"], cfg["dep_col"])

        except ZeroDivisionError:
            st.error(
                "&#9888;&#65039; **Analysis could not be completed: insufficient data in one or more groups.**\n\n"
                "This error usually occurs when one of the groups contains only **1 observation**. "
                "Statistical tests require at least **2 observations per group** to calculate variance and degrees of freedom.\n\n"
                "**What to check:**\n"
                "- Make sure your grouping variable has been set correctly.\n"
                "- Make sure the selected groups each contain at least 2 valid (non-missing) data points.\n"
                "- If you uploaded your own data, verify that the grouping column contains the correct group labels."
            )
            st.stop()

        except ValueError as e:
            msg = str(e).lower()
            if "sample" in msg or "size" in msg or "empty" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: one or more groups appear to be empty.**\n\n"
                    "Please check that:\n"
                    "- The grouping variable contains valid group labels.\n"
                    "- Both groups have at least 2 observations after removing missing values.\n"
                    "- The dependent variable column contains numeric data."
                )
            elif "constant" in msg or "variance" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: one or more variables have zero variance.**\n\n"
                    "This means all values in a variable are identical. "
                    "Statistical tests cannot be performed on constant data. "
                    "Please check your data for data entry errors or select a different variable."
                )
            else:
                st.error(
                    f"&#9888;&#65039; **Analysis could not be completed due to a data issue.**\n\n"
                    f"Please verify that:\n"
                    f"- All selected variables contain valid numeric data.\n"
                    f"- There are no unexpected characters or missing values.\n\n"
                    f"Technical detail (for reference): {e}"
                )
            st.stop()

        except Exception as e:
            msg = str(e).lower()
            if "division by zero" in msg or "divide by zero" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: insufficient data in one or more groups.**\n\n"
                    "At least **2 observations per group** are required. "
                    "Please check your grouping variable and ensure each group has enough data."
                )
            elif "singular" in msg or "not invertible" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: the data matrix is singular.**\n\n"
                    "This can happen when two variables are perfectly correlated, "
                    "or when there are too few observations relative to the number of variables. "
                    "Please check your data."
                )
            elif "memory" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: the dataset is too large for available memory.**\n\n"
                    "Please try reducing the size of your dataset and re-run the analysis."
                )
            elif "column" in msg or "key" in msg or "not found" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: a required column was not found in your data.**\n\n"
                    "Please check that the selected variable names match the column names in your uploaded file."
                )
            else:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed.**\n\n"
                    "Please check that:\n"
                    "- All selected variables contain valid numeric data.\n"
                    "- Each group has at least 2 observations.\n"
                    "- The correct columns have been selected in the sidebar.\n\n"
                    f"Technical detail (for reference): {e}"
                )
            st.stop()

    figs_b = [fig_to_bytes(fig_main)]
    plt.close(fig_main)

    st.session_state.update({
        "stats_R":       R,
        "stats_meta":    meta,
        "stats_interps": interps,
        "stats_test":    test_type,
        "stats_figs":    figs_b,
        "stats_alpha":   alpha,
        "stats_cfg":     cfg,
    })

# ══════════════════════════════════════════════════════════════════════════════
# LOAD FROM SESSION
# ══════════════════════════════════════════════════════════════════════════════
R         = st.session_state["stats_R"]
meta      = st.session_state["stats_meta"]
interps   = st.session_state["stats_interps"]
test_type = st.session_state["stats_test"]
figs_b    = st.session_state["stats_figs"]
alpha     = st.session_state.get("stats_alpha", 0.05)

st.success("&#10003; Analysis complete!")

# ══════════════════════════════════════════════════════════════════════════════
# DECISION BANNER
# ══════════════════════════════════════════════════════════════════════════════
use_p    = R["use_param"]
prim_lbl = get_primary_label(R["normality"])
total_n  = get_total_n(R["normality"])
size_lbl = "Total N\u2009<\u200950" if total_n < 50 else "Total N\u2009\u2265\u200950"

test_used = (
    {"One-Sample T-Test":        "One-Sample T-Test",
     "Paired-Sample T-Test":     "Paired Samples T-Test",
     "Independent-Sample T-Test":"Independent Samples T-Test"}[test_type]
    if use_p else
    {"One-Sample T-Test":        "Wilcoxon Signed-Rank Test",
     "Paired-Sample T-Test":     "Wilcoxon Signed-Rank Test",
     "Independent-Sample T-Test":"Mann-Whitney U Test"}[test_type]
)
cls = "use-param" if use_p else "use-nonparam"
st.markdown(
    f'<div class="decision-banner {cls}">'
    f'{"&#10003;" if use_p else "&#9888;&#65039;"} '
    f'Primary normality criterion: <b>{prim_lbl}</b> '
    f'({size_lbl}, Total N\u2009=\u2009{total_n}) '
    f'\u2192 p\u2009{">" if use_p else "\u2264"}\u2009.05 '
    f'\u2192 <b>{test_used}</b> applied'
    f'</div>',
    unsafe_allow_html=True,
)

# ══════════════════════════════════════════════════════════════════════════════
# QUICK METRICS
# ══════════════════════════════════════════════════════════════════════════════
pr   = R["parametric"]
np_r = R["nonparametric"]

if use_p:
    if test_type == "One-Sample T-Test":
        metrics = [
            (_f(pr["t"]),        f"t({pr['df']})"),
            (_p(pr["p_two"]),    "Sig. (2-tailed)"),
            (_f(pr["mean_diff"]), "Mean Difference"),
            (_f(pr["cohens_d"]), "Cohen\u2019s d"),
            (effect_label_d(pr["cohens_d"]).title(), "Effect Size"),
        ]
    elif test_type == "Paired-Sample T-Test":
        metrics = [
            (_f(pr["t"]),         f"t({pr['df']})"),
            (_p(pr["p_two"]),     "Sig. (2-tailed)"),
            (_f(pr["mean_diff"]), "Mean Difference"),
            (_f(pr["sd_diff"]),   "SD of Differences"),
            (_f(pr["cohens_d"]),  "Cohen\u2019s d"),
        ]
    else:
        metrics = [
            (_f(pr["t_eq"]),   f"t({pr['df_eq']}) Equal Var."),
            (_f(pr["t_welch"]), "t (Welch)"),
            (_p(pr["p_eq"]),   "Sig. Equal Var."),
            (_p(pr["p_welch"]), "Sig. Welch"),
            (_f(pr["cohens_d"]), "Cohen\u2019s d"),
        ]
else:
    if test_type == "Independent-Sample T-Test":
        metrics = [
            (format_u(np_r["U"]),          "Mann-Whitney U"),
            (_f(np_r["W_wilcoxon"], 3),    "Wilcoxon W"),
            (_f(np_r["Z"]),                "Z"),
            (_p(np_r["p"]),                "Sig. (2-tailed)"),
            (str(np_r["n1"] + np_r["n2"]), "Total N"),
        ]
    else:
        metrics = [
            (_f(np_r["W"], 3),               "Wilcoxon W"),
            (_f(np_r["Z"]),                  "Z"),
            (_p(np_r["p"]),                  "Sig. (2-tailed)"),
            (str(np_r.get("n_total", "\u2014")), "Total N"),
            (str(np_r.get("n_ties", 0)),     "Ties"),
        ]

cols = st.columns(5)
for col, (val, lbl) in zip(cols, metrics):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{val}</div>'
        f'<div class="metric-lbl">{lbl}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
st.markdown("<br>", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab_labels = ["&#128203; Normality", "&#128202; Descriptives"]
if "correlation" in R: tab_labels.append("&#128279; Paired Correlation")
if "levene"      in R: tab_labels.append("\u2696\ufe0f Levene\u2019s Test")
tab_labels += [
    "&#128200; Parametric",
    "&#128201; Non-Parametric",
    "&#128200; Plots",
    "&#128172; Interpretation",
]
tabs = st.tabs(tab_labels)
ti   = 0

# ── Tab: Normality ─────────────────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    # Recommendation note
    st.markdown(
        f'<div class="norm-rec-box">{recommendation_note(total_n)}</div>',
        unsafe_allow_html=True,
    )

    sw_html, ks_html = normality_table(R["normality"], prim_lbl)

    st.markdown('<div class="sec-title">a) Shapiro-Wilk Test</div>',
                unsafe_allow_html=True)
    st.markdown(sw_html, unsafe_allow_html=True)

    note_sw = ("&#9733; Shapiro-Wilk is the recommended primary criterion "
               f"for this sample size ({size_lbl}). Decision based on this result."
               if prim_lbl == "Shapiro-Wilk" else
               f"Reported for informational purposes ({size_lbl}; "
               "Kolmogorov-Smirnov is the recommended criterion).")
    st.markdown(f'<p class="note-txt">{note_sw}</p>', unsafe_allow_html=True)

    st.markdown(
        '<div class="sec-title">'
        'b) Kolmogorov-Smirnov Test (Lilliefors Significance Correction)'
        '</div>',
        unsafe_allow_html=True,
    )
    st.markdown(ks_html, unsafe_allow_html=True)

    note_ks = ("&#9733; Kolmogorov-Smirnov (Lilliefors correction) is the "
               f"recommended primary criterion for this sample size ({size_lbl}). "
               "Decision based on this result."
               if prim_lbl == "Kolmogorov-Smirnov" else
               f"\u1d43 Lilliefors significance correction applied. "
               f"Reported for informational purposes ({size_lbl}; "
               "Shapiro-Wilk is the recommended criterion).")
    st.markdown(f'<p class="note-txt">{note_ks}</p>', unsafe_allow_html=True)

    # KS disclaimer
    st.markdown(
        f'<div class="info-box" style="margin-top:.6rem;">{KS_DISCLAIMER}</div>',
        unsafe_allow_html=True,
    )

    # Decision box
    if use_p:
        st.markdown(
            f'<div class="info-box">&#10003; <b>{prim_lbl}</b> '
            f'(recommended criterion, {size_lbl}) p\u2009&gt;\u2009.05 '
            f'\u2192 Normality satisfied \u2192 <b>Parametric analysis applied.</b>'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f'<div class="warn-box">&#9888; <b>{prim_lbl}</b> '
            f'(recommended criterion, {size_lbl}) p\u2009\u2264\u2009.05 '
            f'\u2192 Normality violated \u2192 <b>Non-parametric analysis applied.</b>'
            f'</div>',
            unsafe_allow_html=True,
        )

    # Assumption summary
    st.markdown('<div class="sec-title">&#9989; Assumption Summary</div>',
                unsafe_allow_html=True)
    assume_html = assumption_summary_table(R, use_p, prim_lbl, total_n)
    st.markdown(assume_html, unsafe_allow_html=True)
    st.markdown(
        '<p class="note-txt">&#9733; Primary criterion for normality decision. '
        'References: Razali &amp; Wah (2011); Field (2018).</p>',
        unsafe_allow_html=True,
    )

# ── Tab: Descriptives ───────────────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    st.markdown('<div class="sec-title">Descriptive Statistics</div>',
                unsafe_allow_html=True)
    st.markdown(descriptives_table(R["desc"]), unsafe_allow_html=True)

    # ── Descriptive Interpretation ───────────────────────────────────────
    st.markdown('<div class="sec-title">Interpretation</div>',
                unsafe_allow_html=True)
    desc_df = R["desc"]
    interp_lines = []

    def _skew_label(s):
        if abs(s) < 0.5: return "approximately symmetric"
        if abs(s) < 1.0: return "moderately skewed"
        return "highly skewed"

    def _kurt_label(k):
        if abs(k) < 1.0: return "mesokurtic (approximately normal)"
        if k > 1.0:      return "leptokurtic (heavy-tailed)"
        return "platykurtic (light-tailed)"

    if "Variable" in desc_df.columns:
        # Paired or One-Sample
        for _, row in desc_df.iterrows():
            vn   = row.get("Variable", row.get("Group", "Variable"))
            m    = row.get("Mean", float("nan"))
            med  = row.get("Median", float("nan"))
            sd   = row.get("Std. Deviation", float("nan"))
            skw  = row.get("Skewness", float("nan"))
            kur  = row.get("Kurtosis", float("nan"))
            mn_  = row.get("Minimum", float("nan"))
            mx_  = row.get("Maximum", float("nan"))
            iqr_ = row.get("IQR", float("nan"))
            cv_  = (sd / abs(m) * 100) if (not np.isnan(m) and m != 0
                                           and not np.isnan(sd)) else float("nan")
            line = (
                f"<b>{vn}:</b> Mean = {_f(m)}, Median = {_f(med)}, "
                f"SD = {_f(sd)}, IQR = {_f(iqr_)}, "
                f"Range = [{_f(mn_)}, {_f(mx_)}]. "
            )
            if not np.isnan(skw):
                line += f"Distribution is {_skew_label(skw)} (Skewness = {_f(skw)})"
                if not np.isnan(kur):
                    line += f" and {_kurt_label(kur)} (Kurtosis = {_f(kur)}). "
                else:
                    line += ". "
            if not np.isnan(cv_):
                line += (f"Coefficient of variation = {cv_:.1f}% — "
                         + ("low variability." if cv_ < 15
                            else "moderate variability." if cv_ < 30
                            else "high variability."))
            interp_lines.append(line)
    elif "Group" in desc_df.columns:
        # Independent
        rows_ = list(desc_df.iterrows())
        if len(rows_) >= 2:
            r0, r1 = rows_[0][1], rows_[1][1]
            g0, g1 = r0["Group"], r1["Group"]
            m0, m1 = r0.get("Mean",float("nan")), r1.get("Mean",float("nan"))
            sd0    = r0.get("Std. Deviation", float("nan"))
            sd1    = r1.get("Std. Deviation", float("nan"))
            diff_  = m0 - m1 if not (np.isnan(m0) or np.isnan(m1)) else float("nan")
            interp_lines.append(
                f"<b>{g0}</b>: Mean = {_f(m0)}, SD = {_f(sd0)}. "
                f"<b>{g1}</b>: Mean = {_f(m1)}, SD = {_f(sd1)}. "
                f"Mean difference = {_f(diff_)} ({g0} − {g1})."
            )
            for _, row in desc_df.iterrows():
                vn   = row.get("Group", "Group")
                skw  = row.get("Skewness", float("nan"))
                kur  = row.get("Kurtosis", float("nan"))
                mn_  = row.get("Minimum", float("nan"))
                mx_  = row.get("Maximum", float("nan"))
                iqr_ = row.get("IQR", float("nan"))
                if not np.isnan(skw):
                    interp_lines.append(
                        f"<b>{vn}</b>: Range = [{_f(mn_)}, {_f(mx_)}], "
                        f"IQR = {_f(iqr_)}, "
                        f"Skewness = {_f(skw)} ({_skew_label(skw)}), "
                        f"Kurtosis = {_f(kur)} ({_kurt_label(kur)})."
                    )

    for i, line in enumerate(interp_lines, 1):
        st.markdown(
            f'<div class="interp-box" style="margin-bottom:.5rem;">'
            f'{i}. {line}</div>',
            unsafe_allow_html=True)
    if not interp_lines:
        st.markdown(
            '<p class="note-txt">No additional interpretation available.</p>',
            unsafe_allow_html=True)

# ── Tab: Paired Correlation ─────────────────────────────────────────────────
if "correlation" in R:
    _t = ti; ti += 1
    with tabs[_t]:
        st.markdown(
            '<div class="sec-title">Paired Samples Correlations</div>',
            unsafe_allow_html=True,
        )
        st.markdown(correlation_table(R["correlation"]),
                    unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">Pearson product-moment correlation '
            'between the two paired variables.</p>',
            unsafe_allow_html=True,
        )

# ── Tab: Levene's Test ──────────────────────────────────────────────────────
if "levene" in R:
    _t = ti; ti += 1
    with tabs[_t]:
        lev = R["levene"]
        vv  = lev.get("variants", {})

        st.markdown(
            '<div class="sec-title">'
            "Levene\u2019s Test for Equality of Variances"
            '</div>',
            unsafe_allow_html=True,
        )

        # 4-variant table identical to SPSS
        lev_rows = [["", "Levene Statistic", "df1", "df2", "Sig."]]
        lev_rows.append([
            "Based on Mean",
            _f(vv.get("mean", {}).get("F", lev["F"])),
            str(lev["df1"]), str(lev["df2"]),
            _p(vv.get("mean", {}).get("p", lev["Sig."])),
        ])
        lev_rows.append([
            "Based on Median",
            _f(vv.get("median", {}).get("F", float("nan"))),
            str(lev["df1"]), str(lev["df2"]),
            _p(vv.get("median", {}).get("p", float("nan"))),
        ])
        lev_rows.append([
            "Based on Median and with adjusted df",
            _f(vv.get("median_adjusted", {}).get("F", float("nan"))),
            str(lev["df1"]),
            _f(vv.get("median_adjusted", {}).get("df2", lev["df2"])),
            _p(vv.get("median_adjusted", {}).get("p", float("nan"))),
        ])
        lev_rows.append([
            "Based on Trimmed Mean",
            _f(vv.get("trimmed", {}).get("F", float("nan"))),
            str(lev["df1"]), str(lev["df2"]),
            _p(vv.get("trimmed", {}).get("p", float("nan"))),
        ])
        st.markdown(html_tbl(lev_rows, left_cols={0}),
                    unsafe_allow_html=True)

        # Decision
        if lev["equal_var"]:
            st.markdown(
                '<div class="info-box">&#10003; <b>Based on Mean</b> '
                'p\u2009&gt;\u2009.05 \u2192 Equal variances assumed '
                '\u2192 use Row 1 (equal variances) of the t-test table.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="warn-box">&#9888; <b>Based on Mean</b> '
                'p\u2009\u2264\u2009.05 \u2192 Equal variances not assumed '
                '\u2192 use Row 2 (Welch correction) of the t-test table.</div>',
                unsafe_allow_html=True)

        # Guidance — when to use which variant
        st.markdown("""
<div style="margin-top:1rem;padding:1rem 1.2rem;background:#f8fafc;
border-radius:8px;border-left:4px solid #0284c7;font-size:.84rem;line-height:1.85;">
<b>&#128218; When to Use Each Variant</b><br/><br/>
<b>Based on Mean</b> &mdash; the original Levene (1960) test. Recommended when data are
approximately normally distributed. This is the SPSS default and the standard reported
in most research publications (Field, 2018).<br/><br/>
<b>Based on Median</b> &mdash; the Brown-Forsythe (1974) modification. More robust than
Based on Mean when data are non-normal or contain outliers. Preferred when the normality
assumption is violated.<br/><br/>
<b>Based on Median and with adjusted df</b> &mdash; the most conservative variant.
Uses the Welch-Satterthwaite correction for degrees of freedom, providing the most
accurate p-value when group sizes are unequal and distributions are skewed.<br/><br/>
<b>Based on Trimmed Mean</b> &mdash; uses a 5% trimmed mean (removes the most extreme
5% of values before computing). Moderately robust to outliers; a compromise between
Based on Mean and Based on Median.<br/><br/>
<b>Recommended practice:</b> If Based on Mean and Based on Median agree (both p &gt; .05
or both p &le; .05), report Based on Mean as the primary result. If they disagree,
report Based on Median as it is more robust to the condition that caused the disagreement.
</div>""", unsafe_allow_html=True)

        st.markdown(
            '<p class="note-txt">References: Levene (1960); '
            'Brown &amp; Forsythe (1974); Field (2018).</p>',
            unsafe_allow_html=True)

# ── Tab: Parametric Results ─────────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    if test_type == "One-Sample T-Test":
        st.markdown(
            f'<div class="sec-title">One-Sample T-Test '
            f'&nbsp;&middot;&nbsp; '
            f'Test Value (\u03bc\u2080)\u2009=\u2009{pr["mu0"]}'
            f'</div>',
            unsafe_allow_html=True,
        )
        st.markdown(one_sample_parametric_table(pr),
                    unsafe_allow_html=True)

    elif test_type == "Paired-Sample T-Test":
        st.markdown(
            '<div class="sec-title">Paired Samples Correlations</div>',
            unsafe_allow_html=True,
        )
        st.markdown(correlation_table(R["correlation"]),
                    unsafe_allow_html=True)
        st.markdown(
            '<div class="sec-title">Paired Samples Test</div>',
            unsafe_allow_html=True,
        )
        st.markdown(paired_parametric_table(pr), unsafe_allow_html=True)

    else:
        lev = R["levene"]
        st.markdown(
            '<div class="sec-title">Independent Samples T-Test</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div class="sub-title">a) t-Statistics and Significance</div>',
            unsafe_allow_html=True,
        )
        tbl_a, tbl_b, note = independent_parametric_tables(pr, lev)
        st.markdown(tbl_a, unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-title">'
            'b) Mean Difference, Confidence Interval, and Effect Size'
            '</div>',
            unsafe_allow_html=True,
        )
        st.markdown(tbl_b, unsafe_allow_html=True)
        st.markdown(note, unsafe_allow_html=True)

    if not use_p:
        st.markdown(
            '<div class="warn-box">&#9888; Normality assumption violated. '
            'Refer to the <b>Non-Parametric</b> tab for the recommended analysis.'
            '</div>',
            unsafe_allow_html=True,
        )

# ── Tab: Non-Parametric Results ─────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    if test_type == "Independent-Sample T-Test":
        st.markdown(
            '<div class="sec-title">Mann-Whitney U Test</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div class="sub-title">Ranks</div>',
            unsafe_allow_html=True,
        )
        ranks_html, stats_html, note_html = mannwhitney_tables(np_r)
        st.markdown(ranks_html, unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-title">Test Statistics</div>',
            unsafe_allow_html=True,
        )
        st.markdown(stats_html, unsafe_allow_html=True)
        st.markdown(note_html, unsafe_allow_html=True)
    else:
        st.markdown(
            '<div class="sec-title">Wilcoxon Signed-Rank Test</div>',
            unsafe_allow_html=True,
        )
        st.markdown(
            '<div class="sub-title">Ranks</div>',
            unsafe_allow_html=True,
        )
        ranks_html, stats_html, fn_html = wilcoxon_tables(
            np_r, test_type, pr)
        st.markdown(ranks_html, unsafe_allow_html=True)
        st.markdown(fn_html, unsafe_allow_html=True)
        st.markdown(
            '<div class="sub-title">Test Statistics</div>',
            unsafe_allow_html=True,
        )
        st.markdown(stats_html, unsafe_allow_html=True)

    # Effect size
    st.markdown(
        '<div class="sec-title">Non-Parametric Effect Size '
        '&nbsp;&middot;&nbsp; Rank-Biserial Correlation (r)</div>',
        unsafe_allow_html=True,
    )
    es_tbl, es_note = effect_size_table(np_r, test_type, pr)
    st.markdown(es_tbl, unsafe_allow_html=True)
    st.markdown(es_note, unsafe_allow_html=True)

    if use_p:
        st.markdown(
            '<div class="info-box">&#8505; Normality was satisfied. '
            'The <b>Parametric</b> tab contains the recommended analysis.</div>',
            unsafe_allow_html=True,
        )

# ── Tab: Plots ──────────────────────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    for fb in figs_b:
        st.image(fb, use_container_width=True)

# ── Tab: Interpretation ─────────────────────────────────────────────────────
_t = ti; ti += 1
with tabs[_t]:
    st.markdown("### &#128221; Statistical Interpretation")
    for line in interps:
        lw  = line.lower()
        cls = ("sig"
               if "statistically significant" in lw and "no statistically" not in lw
               else "nonsig"
               if "no statistically significant" in lw or "did not significantly" in lw
               else "")
        st.markdown(f'<div class="interp-box {cls}">{line}</div>',
                    unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**APA 7th Edition Write-Up:**")
    from exports.html_report import _build_apa
    apa = _build_apa(test_type, R, meta, alpha)
    # Strip HTML tags for code block display
    import re
    apa_plain = re.sub(r"<[^>]+>", "", apa)
    st.code(apa_plain, language=None)

    # Power analysis
    st.markdown("---")
    st.markdown("### &#9889; Statistical Power Assessment")
    try:
        pw      = compute_power(R, test_type, alpha)
        pw_rows = power_table_rows(pw)
        pw_tbl, pw_bar, pw_note = power_table(pw, alpha)
        st.markdown(pw_tbl,  unsafe_allow_html=True)
        st.markdown(pw_bar,  unsafe_allow_html=True)
        pwr_val = pw.get("power", np.nan)
        if not np.isnan(pwr_val) and pwr_val < .80:
            st.markdown(
                '<div class="warn-box">&#9888; <b>Insufficient power.</b> '
                'Achieved power is below .80. Risk of Type II error is elevated. '
                'Consider increasing the sample size.</div>',
                unsafe_allow_html=True,
            )
        elif not np.isnan(pwr_val):
            st.markdown(
                '<div class="info-box">&#10003; <b>Adequate power.</b> '
                'Achieved power meets or exceeds the conventional threshold of .80.'
                '</div>',
                unsafe_allow_html=True,
            )
        st.markdown(pw_note, unsafe_allow_html=True)
    except Exception as e_pw:
        st.markdown(
            f'<div class="warn-box">Power analysis unavailable: {e_pw}</div>',
            unsafe_allow_html=True,
        )

# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
st.markdown("### &#128229; Download Results")
dc1, dc2 = st.columns(2)

with dc1:
    with st.spinner("Generating HTML report\u2026"):
        html_data = build_html_report(
            test_type, R, meta, interps, figs_b)
    st.download_button(
        "&#127760; HTML Report (Full)",
        html_data,
        f"TTest_{test_type.replace(' ', '_')}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
        "text/html",
        use_container_width=True,
    )

with dc2:
    csv_data = build_csv(test_type, R, meta, interps, alpha)
    st.download_button(
        "&#128221; CSV Tables",
        csv_data,
        f"TTest_{test_type.replace(' ', '_')}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        "text/csv",
        use_container_width=True,
    )


# (interpretation helpers defined at top of file)
