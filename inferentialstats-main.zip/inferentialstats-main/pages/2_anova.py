"""
pages/2_anova.py
================
Streamlit page for ANOVA family analysis.

Tests available:
  - One-Way ANOVA              + Kruskal-Wallis
  - Two-Way Factorial ANOVA    + Scheirer-Ray-Hare (placeholder)
  - Repeated Measures ANOVA    + Friedman
  - Mixed ANOVA (Split-Plot)   + non-parametric fallback

Features:
  - SPSS-equivalent output (Type III SS, GG/HF corrections)
  - Auto-selection parametric vs non-parametric
  - Normality criterion based on Total N
  - partial η², ω², Cohen's f
  - Post-hoc power analysis
  - Multiple post-hoc methods (Tukey, Bonferroni, Holm, FDR, Scheffe)
  - APA 7th write-up
  - HTML offline report + CSV download
"""

import streamlit as st
import pandas as pd
import numpy as np
import re
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="ANOVA | Inferential Statistics by MA",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Imports ────────────────────────────────────────────────────────────────
from utils.styles      import load_page_css
from utils.file_loader import (load_file, load_from_string, validate_file,
                                file_metadata, get_numeric_cols,
                                get_categorical_cols, get_group_levels)
from utils.samples     import SAMPLES
from utils.formatters  import _f, _p, power_label, effect_label_eta2
from utils.tables      import html_tbl
from utils.plots       import (fig_to_bytes, plot_oneway_anova,
                                plot_repeated_measures)

from modules.anova      import (run_oneway_anova, run_twoway_anova,
                                 run_repeated_measures, run_mixed_anova,
                                 _mauchly_test)
from modules.normality  import (recommendation_note, KS_DISCLAIMER,
                                 get_primary_label, get_total_n)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

PAL = ["#1a1a2e", "#e94560", "#0f3460", "#16213e",
       "#7c3aed", "#0891b2", "#16a34a", "#b45309"]
BG  = "#f8fafc"


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION HELPERS  (defined early — called during run_btn block)
# ══════════════════════════════════════════════════════════════════════════════

def _interpret_oneway(R, alpha):
    """Academic-English interpretation for One-Way ANOVA."""
    lines = []
    prim  = get_primary_label(R["normality"])
    tn    = get_total_n(R["normality"])
    size  = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"

    # Normality
    violated = [nm["label"] for nm in R["normality"] if not nm["pass"]]
    lines.append(
        f"<b>Normality:</b> "
        f"Primary criterion: <b>{prim}</b> ({size}). "
        + ("All groups satisfied the normality assumption. "
           "Parametric analysis was applied."
           if R["use_param"] else
           f"Normality was violated in: {', '.join(violated)}. "
           "Non-parametric analysis (Kruskal-Wallis) was applied.")
    )

    # Levene
    lev = R["levene"]
    lines.append(
        f"<b>Homogeneity of Variance (Levene\u2019s test):</b> "
        f"F({lev['df1']},\u2009{lev['df2']})\u2009=\u2009{_f(lev['F'])}, "
        f"p\u2009=\u2009{_p(lev['Sig.'])}. "
        + ("Equal variances were assumed (p\u2009>\u2009.05)."
           if lev["equal_var"] else
           "Equal variances were not assumed (p\u2009\u2264\u2009.05). "
           "Interpret the F-ratio with caution.")
    )

    if R["use_param"]:
        sig = R["sig"]
        lines.append(
            f"<b>One-Way ANOVA:</b> "
            f"F({R['df_between']},\u2009{R['df_within']})\u2009=\u2009{_f(R['F'])}, "
            f"p\u2009=\u2009{_p(R['p'])}. "
            f"Partial \u03b7\u00b2\u2009=\u2009{_f(R['partial_eta2'])} "
            f"({R['eta2_label']} effect); "
            f"\u03c9\u00b2\u2009=\u2009{_f(R['omega2'])} "
            f"({R['omega2_label']} effect, less biased estimate). "
            + ("A statistically significant" if sig
               else "No statistically significant")
            + f" difference in {R['dep_var']} was found among the {R['k']} groups "
            f"at \u03b1\u2009=\u2009{alpha}."
        )
        if sig and not R["posthoc"].empty:
            sig_pairs = R["posthoc"][R["posthoc"]["Significant"]]
            lines.append(
                f"<b>Post-Hoc ({R['posthoc_method'].title()}):</b> "
                f"{len(sig_pairs)} of {len(R['posthoc'])} pairwise comparison(s) "
                f"were statistically significant."
            )
    else:
        kw = R["kruskal_wallis"]
        lines.append(
            f"<b>Kruskal-Wallis Test:</b> "
            f"H({kw['df']})\u2009=\u2009{_f(kw['H'])}, "
            f"p\u2009=\u2009{_p(kw['p'])}. "
            + ("A statistically significant" if kw["p"] < alpha
               else "No statistically significant")
            + f" difference was found among the groups."
        )
    return lines


def _interpret_twoway(R, alpha):
    """Academic-English interpretation for Two-Way Factorial ANOVA."""
    lines = []
    prim  = get_primary_label(R["normality"])
    tn    = get_total_n(R["normality"])
    size  = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
    fa, fb = R["factor_a"], R["factor_b"]
    dep    = R["dep_var"]
    ka, kb = R["ka"], R["kb"]

    # 1. Normality
    violated = [nm["label"] for nm in R["normality"] if not nm["pass"]]
    lines.append(
        f"<b>1. Normality:</b> Primary criterion: <b>{prim}</b> ({size}). "
        + (f"All {ka * kb} cells satisfied the normality assumption. "
           "Parametric analysis was applied."
           if R["use_param"] else
           f"Normality was violated in: {', '.join(violated)}. "
           "Interpret results with caution.")
    )

    # 2. Homogeneity of variance
    lev = R["levene"]
    lines.append(
        f"<b>2. Homogeneity of Variance (Levene\u2019s test, Based on Mean):</b> "
        f"F({lev['df1']},\u2009{lev['df2']})\u2009=\u2009{_f(lev['F'])}, "
        f"p\u2009=\u2009{_p(lev['Sig.'])}. "
        + ("Equal variances were assumed across all cells (p\u2009>\u2009.05)."
           if lev["equal_var"] else
           "Equal variances were not assumed (p\u2009\u2264\u2009.05). "
           "Interpret F-ratios with caution.")
    )

    # 3. Main Effect A
    sig_A = not np.isnan(R["p_A"]) and R["p_A"] < alpha
    at    = R["anova_table"]
    df_A  = at[at["Source"] == fa]["df"].values[0] \
            if not at[at["Source"] == fa].empty else "?"
    df_err_A = at[at["Source"] == "Error"]["df"].values[0] \
               if not at[at["Source"] == "Error"].empty else "?"
    lines.append(
        f"<b>3. Main Effect of {fa}:</b> "
        f"F({df_A},\u2009{df_err_A})\u2009=\u2009{_f(R['F_A'])}, "
        f"p\u2009=\u2009{_p(R['p_A'])}, "
        f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_A']['partial_eta2'])} "
        f"({R['es_A']['label']} effect). "
        + (f"The main effect of {fa} was <b>statistically significant</b>, "
           f"indicating that scores on {dep} differed significantly across "
           f"the {ka} levels of {fa}, averaged across all levels of {fb}."
           if sig_A else
           f"The main effect of {fa} was <b>not statistically significant</b>, "
           f"indicating no overall difference in {dep} across the levels of {fa} "
           f"when averaged across all levels of {fb}.")
    )

    # 4. Main Effect B
    sig_B = not np.isnan(R["p_B"]) and R["p_B"] < alpha
    df_B  = at[at["Source"] == fb]["df"].values[0] \
            if not at[at["Source"] == fb].empty else "?"
    lines.append(
        f"<b>4. Main Effect of {fb}:</b> "
        f"F({df_B},\u2009{df_err_A})\u2009=\u2009{_f(R['F_B'])}, "
        f"p\u2009=\u2009{_p(R['p_B'])}, "
        f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_B']['partial_eta2'])} "
        f"({R['es_B']['label']} effect). "
        + (f"The main effect of {fb} was <b>statistically significant</b>, "
           f"indicating that scores on {dep} differed significantly across "
           f"the {kb} levels of {fb}, averaged across all levels of {fa}."
           if sig_B else
           f"The main effect of {fb} was <b>not statistically significant</b>, "
           f"indicating no overall difference in {dep} across the levels of {fb} "
           f"when averaged across all levels of {fa}.")
    )

    # 5. Interaction
    sig_AB = not np.isnan(R["p_AB"]) and R["p_AB"] < alpha
    ab_src = f"{fa} \u00d7 {fb}"
    df_AB  = at[at["Source"] == ab_src]["df"].values[0] \
             if not at[at["Source"] == ab_src].empty else "?"
    if sig_AB:
        interaction_text = (
            f"The {fa} \u00d7 {fb} interaction was <b>statistically significant</b>, "
            f"indicating that the effect of {fa} on {dep} <b>depended on the level of {fb}</b> "
            f"(and vice versa). "
            f"Because the interaction is significant, the main effects of {fa} and {fb} "
            f"should <b>not</b> be interpreted in isolation \u2014 "
            f"the combined pattern of means (shown in the interaction plot) "
            f"provides the most meaningful interpretation. "
            f"Post-hoc pairwise comparisons are recommended to identify which "
            f"specific combinations of {fa} and {fb} differed significantly."
        )
    else:
        interaction_text = (
            f"The {fa} \u00d7 {fb} interaction was <b>not statistically significant</b>, "
            f"indicating that the effect of {fa} on {dep} did <b>not depend</b> on the "
            f"level of {fb}. The two factors operated independently. "
            f"Consequently, the main effects of {fa} and {fb} can be interpreted "
            f"independently of one another."
        )
    lines.append(
        f"<b>5. {fa} \u00d7 {fb} Interaction:</b> "
        f"F({df_AB},\u2009{df_err_A})\u2009=\u2009{_f(R['F_AB'])}, "
        f"p\u2009=\u2009{_p(R['p_AB'])}, "
        f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_AB']['partial_eta2'])} "
        f"({R['es_AB']['label']} effect). "
        + interaction_text
    )

    # 6 & 7. Post-hoc — descriptive per comparison, single line format
    ph_A = R.get("posthoc_A", pd.DataFrame())
    ph_B = R.get("posthoc_B", pd.DataFrame())
    step = 6

    def _ph_lines(ph_df, factor_name, step_n):
        """One descriptive line per comparison — header merged with content."""
        if ph_df.empty: return []
        method = R.get("posthoc_method", "").title()
        out = []
        for idx, row in ph_df.iterrows():
            ga    = str(row.get("Group A", ""))
            gb    = str(row.get("Group B", ""))
            ma    = float(row.get("Mean A",  np.nan))
            mb    = float(row.get("Mean B",  np.nan))
            md    = float(row.get("Mean Diff", np.nan))
            p_adj = float(row.get("p_adj",   np.nan))
            d     = row.get("Cohen's d", np.nan)
            es    = str(row.get("Effect Size", ""))
            sig   = bool(row.get("Significant", False))
            higher = ga if md > 0 else gb
            lower  = gb if md > 0 else ga
            d_str  = (f" Cohen\u2019s d\u2009=\u2009{_f(abs(float(d)))} ({es}) effect."
                      if not (isinstance(d, float) and np.isnan(d)) else "")
            step_label = step_n if idx == ph_df.index[0] else " " * len(str(step_n))
            if sig:
                out.append(
                    f"<b>{step_n}. Post-Hoc Comparisons for {factor_name} ({method}):</b> "
                    f"<b>{ga}</b> (M\u2009=\u2009{_f(ma)}) vs. "
                    f"<b>{gb}</b> (M\u2009=\u2009{_f(mb)}): "
                    f"<b>{higher}</b> scored significantly higher than <b>{lower}</b> "
                    f"(mean difference\u2009=\u2009{_f(abs(md))}, "
                    f"p_adj\u2009=\u2009{_p(p_adj)}).{d_str}"
                )
            else:
                out.append(
                    f"<b>{step_n}. Post-Hoc Comparisons for {factor_name} ({method}):</b> "
                    f"<b>{ga}</b> (M\u2009=\u2009{_f(ma)}) vs. "
                    f"<b>{gb}</b> (M\u2009=\u2009{_f(mb)}): "
                    f"No statistically significant difference was found "
                    f"(mean difference\u2009=\u2009{_f(abs(md))}, "
                    f"p_adj\u2009=\u2009{_p(p_adj)}).{d_str}"
                )
            # For subsequent comparisons (more than 2 levels), use continuation label
            step_n = f"{step_n} (cont.)"
        return out

    if sig_A and not ph_A.empty:
        for ln in _ph_lines(ph_A, fa, step):
            lines.append(ln)
        step += 1

    if sig_B and not ph_B.empty:
        for ln in _ph_lines(ph_B, fb, step):
            lines.append(ln)

    return lines


def _interpret_repeated(R, alpha):
    """Academic-English interpretation for Repeated Measures ANOVA."""
    lines = []
    prim  = get_primary_label(R["normality"])
    tn    = get_total_n(R["normality"])
    size  = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
    k     = R["k"]
    N     = R["N"]
    dep   = R["dep_var"]
    tc    = R["time_cols"]

    # 1. Normality
    violated = [nm["label"] for nm in R["normality"] if not nm["pass"]]
    lines.append(
        f"<b>1. Normality:</b> Primary criterion: <b>{prim}</b> ({size}). "
        + (f"All {k} time points satisfied the normality assumption. "
           "Parametric analysis was applied."
           if R["use_param"] else
           f"Normality was violated at: {', '.join(violated)}. "
           "The non-parametric Friedman test was applied as an alternative.")
    )

    # 2. Sphericity
    sph = R.get("sphericity")
    if sph and k > 2:
        sph_ok = sph["sphericity_assumed"]
        lines.append(
            f"<b>2. Sphericity (Mauchly\u2019s Test):</b> "
            f"W\u2009=\u2009{_f(sph['W'])}, "
            f"\u03c7\u00b2({sph['df']})\u2009=\u2009{_f(sph['chi2'])}, "
            f"p\u2009=\u2009{_p(sph['p'])}. "
            f"\u03b5 (GG)\u2009=\u2009{_f(sph['epsilon_gg'])}, "
            f"\u03b5 (HF)\u2009=\u2009{_f(sph['epsilon_hf'])}. "
            + (f"The sphericity assumption was <b>satisfied</b> (p\u2009&gt;\u2009.05). "
               f"Uncorrected (Sphericity Assumed) F-ratios are reported."
               if sph_ok else
               f"The sphericity assumption was <b>violated</b> (p\u2009\u2264\u2009.05). "
               f"{sph['correction']}. "
               f"Corrected p-values are reported in the Tests of Within-Subjects Effects table.")
        )
    elif k <= 2:
        lines.append(
            "<b>2. Sphericity:</b> Not applicable for k\u2009=\u20092 time points "
            "(sphericity is automatically satisfied)."
        )

    # 3. Multivariate Tests
    mv = R.get("multivariate_tests")
    if mv is not None and not mv.empty:
        try:
            p_row = mv[mv['']==" Pillai\u2019s Trace"].iloc[0] \
                    if " Pillai\u2019s Trace" in mv[''].values \
                    else mv[mv[''].str.contains("Pillai", na=False)].iloc[0]
            lines.append(
                f"<b>3. Multivariate Tests:</b> "
                f"Pillai\u2019s Trace\u2009=\u2009{_f(p_row['Value'])}, "
                f"F({p_row['Hypothesis df']},\u2009{p_row['Error df']})\u2009=\u2009{_f(p_row['F'])}, "
                f"p\u2009=\u2009{_p(float(p_row['Sig.']) if isinstance(p_row['Sig.'], (int,float)) else 0.0)}, "
                f"partial \u03b7\u00b2\u2009=\u2009{_f(p_row['Partial η²'])}. "
                "The multivariate approach does not require the sphericity assumption and "
                "is recommended as a supplementary test."
            )
        except Exception:
            pass

    # 4. Main effect of time
    if R["use_param"]:
        we  = R.get("within_effects")
        sig = R["sig"]
        F_  = R["F"]; p_  = R["p_primary"]
        eta = R["partial_eta2"]
        eff_label = effect_label_eta2(eta)
        sph_ok_ = sph["sphericity_assumed"] if sph and k > 2 else True
        p_label = "p (Sphericity Assumed)" if sph_ok_ else \
                  f"p (GG-corrected, \u03b5\u2009=\u2009{_f(R.get('epsilon_gg',1.0))})"

        lines.append(
            f"<b>4. Tests of Within-Subjects Effects:</b> "
            f"F({R['df_num']},\u2009{R['df_den']})\u2009=\u2009{_f(F_)}, "
            f"{p_label}\u2009=\u2009{_p(p_)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(eta)} (<b>{eff_label}</b> effect). "
            + (f"There was a <b>statistically significant</b> effect of time on {dep}, "
               f"indicating that mean scores differed significantly across the "
               f"{k} time points."
               if sig else
               f"The effect of time on {dep} was <b>not statistically significant</b>, "
               f"indicating no reliable change across the {k} time points.")
        )

        # 5. Contrasts
        ct = R.get("contrasts")
        if ct is not None and not ct.empty:
            ct_src = ct[ct['Source']==dep] if dep in ct['Source'].values \
                     else ct[~ct['Source'].str.contains('Error', na=False)]
            ct_lines = []
            for _, row in ct_src.iterrows():
                lbl = row.get('Contrast','')
                F_c = row.get('F', np.nan)
                p_c = row.get('Sig.', np.nan)
                e_c = row.get('Partial η²', np.nan)
                if not np.isnan(float(F_c)):
                    sig_c = float(p_c) < alpha if not np.isnan(float(p_c)) else False
                    ct_lines.append(
                        f"{lbl}: F\u2009=\u2009{_f(F_c)}, p\u2009=\u2009{_p(p_c)}, "
                        f"\u03b7\u00b2\u2009=\u2009{_f(e_c)} "
                        f"({'significant' if sig_c else 'not significant'})"
                    )
            if ct_lines:
                lines.append(
                    f"<b>5. Within-Subjects Contrasts:</b> "
                    + "; ".join(ct_lines) + ". "
                    "Polynomial contrasts partition the time effect into orthogonal "
                    "trend components. A significant Linear trend indicates a consistent "
                    "increase or decrease across time."
                )

        # 6. Between-Subjects Effects (Intercept)
        bs = R.get("between_bs_effects")
        if bs is not None and not bs.empty:
            try:
                int_row = bs[bs['Source']=='Intercept'].iloc[0]
                lines.append(
                    f"<b>6. Tests of Between-Subjects Effects (Intercept):</b> "
                    f"F(1,\u2009{R['N']-1})\u2009=\u2009{_f(int_row['F'])}, "
                    f"p\u2009=\u2009{_p(int_row['Sig.'])}, "
                    f"partial \u03b7\u00b2\u2009=\u2009{_f(int_row['Partial η²'])}. "
                    "Tests whether the grand mean significantly differs from zero "
                    "(typically not of substantive interest)."
                )
            except Exception:
                pass

        # 7. Post-hoc
        ph = R.get("posthoc", pd.DataFrame())
        if not ph.empty and sig:
            ph_method = R.get("posthoc_method", "Bonferroni").title()
            sig_pairs = ph[ph["Significant"]] if "Significant" in ph.columns \
                        else pd.DataFrame()
            lines.append(
                f"<b>7. Post-Hoc Comparisons ({ph_method} correction):</b> "
                f"{len(sig_pairs)} of {len(ph)} pairwise comparison(s) were "
                f"statistically significant after correction. "
                + ("; ".join(
                    f"<b>{r['Time A']}</b> (M\u2009=\u2009{_f(r['Mean A'])}) vs. "
                    f"<b>{r['Time B']}</b> (M\u2009=\u2009{_f(r['Mean B'])}): "
                    f"mean difference\u2009=\u2009{_f(abs(float(r['Mean Diff'])))}, "
                    f"p_adj\u2009=\u2009{_p(r['p_adj'])}"
                    for _, r in sig_pairs.iterrows()
                ) if not sig_pairs.empty else "")
            )
    else:
        # Non-parametric
        fr = R.get("friedman", {})
        lines.append(
            f"<b>4. Friedman Test (non-parametric):</b> "
            f"\u03c7\u00b2({fr.get('df','?')})\u2009=\u2009{_f(fr.get('chi2', float('nan')))}, "
            f"p\u2009=\u2009{_p(fr.get('p', float('nan')))}. "
            + ("A statistically significant difference across time points was found."
               if fr.get('p', 1) < alpha else
               "No statistically significant difference across time points was found.")
        )

    return lines


def _interpret_mixed(R, alpha):
    """Academic-English interpretation for Mixed ANOVA."""
    lines = []
    prim  = R["normality"][0]["primary_label"] if R["normality"] else "Shapiro-Wilk"
    tn    = R["total_n"]
    size  = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"

    lines.append(
        f"<b>Normality:</b> Primary criterion: <b>{prim}</b> ({size}). "
        + ("All cells satisfied normality."
           if R["use_param"] else
           "Normality was violated in one or more cells.")
    )

    sph = R["sphericity"]
    if sph and R["k"] > 2:
        lines.append(
            f"<b>Sphericity (Mauchly\u2019s test):</b> "
            f"W\u2009=\u2009{_f(sph['W'])}, p\u2009=\u2009{_p(sph['p'])}. "
            + ("Sphericity assumed."
               if sph["sphericity_assumed"] else
               f"Sphericity violated. GG correction applied "
               f"(\u03b5\u2009=\u2009{_f(R['epsilon_gg'])}).")
        )

    # Between
    lines.append(
        f"<b>Main Effect — {R['between_col']} (Between-Subjects):</b> "
        f"F({R['anova_table'].iloc[0]['df']},\u2009"
        f"{R['anova_table'].iloc[0]['df_err']})\u2009=\u2009"
        f"{_f(R['F_A'])}, p\u2009=\u2009{_p(R['p_A'])}. "
        f"Partial \u03b7\u00b2\u2009=\u2009{_f(R['es_A']['partial_eta2'])} "
        f"({R['es_A']['label']}). "
        + ("Statistically significant." if R["p_A"] < alpha
           else "Not statistically significant.")
    )

    # Within
    lines.append(
        f"<b>Main Effect — Time (Within-Subjects):</b> "
        f"F({R['anova_table'].iloc[2]['df']},\u2009"
        f"{R['anova_table'].iloc[2]['df_err']})\u2009=\u2009"
        f"{_f(R['F_B'])}, p (GG)\u2009=\u2009{_p(R['p_B_gg'])}. "
        f"Partial \u03b7\u00b2\u2009=\u2009{_f(R['es_B']['partial_eta2'])} "
        f"({R['es_B']['label']}). "
        + ("Statistically significant." if R["p_B_gg"] < alpha
           else "Not statistically significant.")
    )

    # Interaction
    p_int = R["p_AB_gg"]
    sig_int = p_int < alpha
    lines.append(
        f"<b>Group \u00d7 Time Interaction:</b> "
        f"F({R['anova_table'].iloc[3]['df']},\u2009"
        f"{R['anova_table'].iloc[3]['df_err']})\u2009=\u2009"
        f"{_f(R['F_AB'])}, p (GG)\u2009=\u2009{_p(p_int)}. "
        f"Partial \u03b7\u00b2\u2009=\u2009{_f(R['es_AB']['partial_eta2'])} "
        f"({R['es_AB']['label']}). "
        + ("The interaction was statistically significant, indicating that "
           f"the trajectory of change over time differed between the {R['n_groups']} groups. "
           "The main effects should be interpreted in the context of this interaction."
           if sig_int else
           "The interaction was not statistically significant. "
           f"The {R['n_groups']} groups followed a similar pattern of change over time. "
           "Main effects can be interpreted independently.")
    )
    return lines


def _build_apa(test_type, R, alpha):
    """APA 7th edition write-up."""
    if test_type == "One-Way ANOVA":
        sig = R["sig"]
        return (
            f"A one-way ANOVA was conducted to examine whether {R['dep_var']} "
            f"differed among {R['k']} groups. "
            f"The result was {'statistically significant' if sig else 'not statistically significant'}, "
            f"F({R['df_between']},\u2009{R['df_within']})\u2009=\u2009{float(R['F']):.2f}, "
            f"p\u2009{'< .001' if R['p'] < .001 else '= ' + _p(R['p'])}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['partial_eta2'])}, "
            f"\u03c9\u00b2\u2009=\u2009{_f(R['omega2'])}."
        )
    elif test_type == "Two-Way Factorial ANOVA":
        fa, fb = R["factor_a"], R["factor_b"]
        dep    = R["dep_var"]
        sig_AB = not np.isnan(R["p_AB"]) and R["p_AB"] < alpha
        sig_A  = not np.isnan(R["p_A"])  and R["p_A"]  < alpha
        sig_B  = not np.isnan(R["p_B"])  and R["p_B"]  < alpha
        at     = R["anova_table"]
        df_err = at[at["Source"] == "Error"]["df"].values[0] \
                 if not at[at["Source"] == "Error"].empty else "?"
        return (
            f"A {R['ka']}\u2009\u00d7\u2009{R['kb']} between-subjects factorial ANOVA "
            f"was conducted to examine the effects of {fa} and {fb} on {dep} "
            f"(N\u2009=\u2009{R['N']}). "
            f"The {fa} \u00d7 {fb} interaction was "
            f"{'statistically significant' if sig_AB else 'not statistically significant'}, "
            f"F({R['df_AB']},\u2009{df_err})\u2009=\u2009{float(R['F_AB']):.2f}, "
            f"p\u2009{'< .001' if R['p_AB'] < .001 else '= ' + _p(R['p_AB'])}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_AB']['partial_eta2'])}. "
            f"The main effect of {fa} was "
            f"{'statistically significant' if sig_A else 'not statistically significant'}, "
            f"F({R['df_A']},\u2009{df_err})\u2009=\u2009{float(R['F_A']):.2f}, "
            f"p\u2009{'< .001' if R['p_A'] < .001 else '= ' + _p(R['p_A'])}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_A']['partial_eta2'])}. "
            f"The main effect of {fb} was "
            f"{'statistically significant' if sig_B else 'not statistically significant'}, "
            f"F({R['df_B']},\u2009{df_err})\u2009=\u2009{float(R['F_B']):.2f}, "
            f"p\u2009{'< .001' if R['p_B'] < .001 else '= ' + _p(R['p_B'])}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_B']['partial_eta2'])}."
        )
    elif test_type == "Repeated Measures ANOVA":
        return (
            f"A one-way repeated measures ANOVA was conducted to examine "
            f"the effect of time on {R['dep_var']} across {R['k']} time points (N\u2009=\u2009{R['N']}). "
            + (f"Mauchly\u2019s test indicated that sphericity was "
               f"{'satisfied' if R['sph_ok'] else 'violated'}; "
               f"{'uncorrected F is reported.' if R['sph_ok'] else 'Greenhouse-Geisser correction was applied.'} "
               if R["sphericity"] else "") +
            f"The effect of time was "
            f"{'statistically significant' if R['sig'] else 'not statistically significant'}, "
            f"F({R['df_num']},\u2009{R['df_den']})\u2009=\u2009{float(R['F']):.2f}, "
            f"p\u2009{'< .001' if R['p_primary'] < .001 else '= ' + _p(R['p_primary'])}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['partial_eta2'])}."
        )
    elif test_type == "Mixed ANOVA":
        p_int = R["p_AB_gg"]
        return (
            f"A mixed-design ANOVA was conducted with {R['between_col']} as the "
            f"between-subjects factor and Time as the within-subjects factor (N\u2009=\u2009{R['N']}). "
            f"The Group \u00d7 Time interaction was "
            f"{'statistically significant' if p_int < alpha else 'not statistically significant'}, "
            f"F({R['anova_table'].iloc[3]['df']},\u2009{R['anova_table'].iloc[3]['df_err']})"
            f"\u2009=\u2009{float(R['F_AB']):.2f}, "
            f"p\u2009{'< .001' if p_int < .001 else '= ' + _p(p_int)}, "
            f"partial \u03b7\u00b2\u2009=\u2009{_f(R['es_AB']['partial_eta2'])}."
        )
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# PLOT HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _style_ax(ax):
    ax.set_facecolor(BG)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color("#cbd5e1")
    ax.tick_params(colors="#64748b", labelsize=7)
    ax.xaxis.label.set_color("#64748b")
    ax.yaxis.label.set_color("#64748b")
    ax.title.set_color(PAL[0])


def _plot_mixed(R):
    """Profile plot (line + bar) for Mixed ANOVA."""
    desc      = R["desc"]
    groups    = R["groups"]
    time_cols = R["time_cols"]
    dep_var   = R["dep_var"]

    # desc has columns: "Dependent Variable", "Group", "Mean", "Std. Deviation", "N"
    # Filter out "Total" rows
    desc_data = desc[desc["Group"] != "Total"].copy()

    # Build means/SE per group per time point
    def _group_stats(g):
        rows = []
        for t in time_cols:
            sub = desc_data[
                (desc_data["Group"].astype(str) == str(g)) &
                (desc_data["Dependent Variable"] == t)]
            if sub.empty:
                rows.append({"Time": t, "Mean": np.nan, "SE": np.nan})
            else:
                n_   = float(sub["N"].values[0])
                sd_  = float(sub["Std. Deviation"].values[0]) \
                       if "Std. Deviation" in sub.columns else np.nan
                se_  = sd_ / np.sqrt(n_) if (not np.isnan(sd_) and n_ > 0) else np.nan
                rows.append({"Time": t,
                             "Mean": float(sub["Mean"].values[0]),
                             "SE": se_})
        return pd.DataFrame(rows)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5), facecolor=BG)
    for ax in axes: _style_ax(ax)

    # Panel 1 — Profile (line) plot
    ax = axes[0]
    for i, g in enumerate(groups):
        gdf = _group_stats(g)
        ax.errorbar(range(len(time_cols)), gdf["Mean"], yerr=gdf["SE"],
                    marker="o", markersize=8, lw=2.5,
                    color=PAL[i % len(PAL)], label=str(g),
                    capsize=5, capthick=1.5, elinewidth=1.5,
                    markeredgecolor="white", markeredgewidth=1.5)
    ax.set_xticks(range(len(time_cols)))
    ax.set_xticklabels(time_cols, fontsize=9)
    ax.set_ylabel(dep_var, fontsize=9)
    ax.set_title("Profile Plot (Mean \u00b1 SE)", fontsize=10, fontweight="bold")
    ax.legend(title=R["between_col"], fontsize=8, framealpha=.8)

    # Panel 2 — Bar chart
    ax = axes[1]
    ngrp = len(groups); w = 0.7 / ngrp
    xs   = np.arange(len(time_cols))
    for i, g in enumerate(groups):
        gdf = _group_stats(g)
        off = (i - ngrp / 2 + .5) * w
        ax.bar(xs + off, gdf["Mean"], width=w * .88,
               color=PAL[i % len(PAL)], alpha=0.78,
               label=str(g), edgecolor="white", linewidth=.5)
        ax.errorbar(xs + off, gdf["Mean"], yerr=1.96 * gdf["SE"],
                    fmt="none", color="#374151",
                    capsize=3, capthick=1, elinewidth=1, alpha=.65)
    ax.set_xticks(xs)
    ax.set_xticklabels(time_cols, fontsize=9)
    ax.set_ylabel(dep_var, fontsize=9)
    ax.set_title("Bar Chart (Mean \u00b1 95% CI)", fontsize=10, fontweight="bold")
    ax.legend(title=R["between_col"], fontsize=8, framealpha=.8)

    plt.tight_layout()
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# CSS + HEADER
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(load_page_css(), unsafe_allow_html=True)

st.markdown("""
<div class="main-hdr">
  <h1>&#128202; ANOVA Family
    <span class="badge">SPSS-Equivalent</span>
    <span class="badge">Auto-Select</span>
    <span class="badge">Type III SS</span>
  </h1>
  <p>One-Way &nbsp;&middot;&nbsp; Two-Way Factorial &nbsp;&middot;&nbsp;
     Repeated Measures &nbsp;&middot;&nbsp; Mixed (Split-Plot) &nbsp;&middot;&nbsp;
     Kruskal-Wallis &nbsp;&middot;&nbsp; Friedman</p>
</div>""", unsafe_allow_html=True)

st.markdown("""
<div style="margin-bottom:1rem;">
  <p style="color:#64748b;font-size:.9rem;margin-bottom:.4rem;">
    &#9749; Support this work &mdash; scan QRIS:</p>
  <img src="https://muhaiminabdullah.com/media/images/qris_muhaiminabdullahdotcom.png"
       style="width:180px;border-radius:10px;border:2px solid #e94560;display:block;"/>
</div>""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### &#9881;&#65039; Configuration")
    st.markdown("---")

    _tests_anova = [
        "One-Way ANOVA",
        "Two-Way Factorial ANOVA",
        "Repeated Measures ANOVA",
        "Mixed ANOVA",
    ]
    _default_sel = st.session_state.get("selected_test", "One-Way ANOVA")
    _default_idx = _tests_anova.index(_default_sel) \
                   if _default_sel in _tests_anova else 0

    test_type = st.selectbox(
        "&#128202; Select Test", _tests_anova, index=_default_idx)

    alpha = st.selectbox("\u03b1 Significance Level",
                         [0.05, 0.01, 0.001], index=0)
    posthoc_method = st.selectbox(
        "Post-Hoc Method",
        ["tukey", "bonferroni", "holm", "fdr_bh", "scheffe"],
        format_func={
            "tukey":      "Tukey HSD (recommended for equal n)",
            "bonferroni": "Bonferroni (most conservative)",
            "holm":       "Holm (step-down, less conservative)",
            "fdr_bh":     "FDR Benjamini-Hochberg",
            "scheffe":    "Scheff\u00e9 (most flexible)",
        }.get,
        index=0,
    )
    st.markdown("---")

    # Sample data
    samp_key = {
        "One-Way ANOVA":           "One-Way ANOVA",
        "Two-Way Factorial ANOVA": "Factorial ANOVA",
        "Repeated Measures ANOVA": "Repeated Measures ANOVA",
        "Mixed ANOVA":             "Mixed ANOVA",
    }[test_type]
    samp = SAMPLES[samp_key]
    st.markdown("**&#128196; Sample Data**")
    st.markdown(
        f'<p style="font-size:.8rem;color:#64748b;">{samp["note"]}</p>',
        unsafe_allow_html=True)
    st.download_button(
        "&#11015;&#65039; Download Sample CSV",
        samp["csv"].encode(),
        f"sample_{samp_key.replace(' ','_').lower()}.csv",
        "text/csv", use_container_width=True,
    )
    st.markdown("---")

    uploaded = st.file_uploader(
        "&#128194; Upload Data File",
        type=["csv", "xlsx", "xls"])
    if uploaded:
        try:
            df = load_file(uploaded)
            fm = file_metadata(uploaded, df)
            val = validate_file(df)
            if val["errors"]:
                for e in val["errors"]: st.error(e)
                df = None
            else:
                st.success(f"&#10003; {fm['Rows']:,} rows \u00d7 {fm['Columns']} cols")
                for w in val["warnings"]: st.warning(w)
        except Exception as e:
            st.error(str(e)); df = None
    else:
        df = load_from_string(samp["csv"])
        st.info("\u2139\ufe0f Using built-in sample data")

    # ── Variable selection ──────────────────────────────────────────────────
    cfg = None
    if df is not None:
        num_cols = get_numeric_cols(df)
        cat_cols = get_categorical_cols(df)
        all_cols = list(df.columns)
        st.markdown("---")

        if test_type == "One-Way ANOVA":
            gc = st.selectbox("&#128101; Grouping Variable",
                               cat_cols if cat_cols else all_cols, index=0)
            dc = st.selectbox("&#127919; Dependent Variable",
                               num_cols,
                               index=num_cols.index("score")
                               if "score" in num_cols else 0)
            cfg = {"type": "oneway", "group_col": gc, "dep_col": dc}

        elif test_type == "Two-Way Factorial ANOVA":
            fa = st.selectbox("Factor A", cat_cols if cat_cols else all_cols,
                               index=0)
            remaining_cat = [c for c in (cat_cols if cat_cols else all_cols)
                             if c != fa]
            fb = st.selectbox("Factor B", remaining_cat,
                               index=0 if remaining_cat else 0)
            dc = st.selectbox("&#127919; Dependent Variable", num_cols,
                               index=num_cols.index("score")
                               if "score" in num_cols else 0)
            cfg = {"type": "twoway", "fa": fa, "fb": fb, "dep_col": dc}

        elif test_type == "Repeated Measures ANOVA":
            sc = st.selectbox("Subject ID Column", all_cols, index=0)
            tc = st.multiselect(
                "Time-Point Columns",
                [c for c in num_cols if c != sc],
                default=[c for c in num_cols if c != sc][:3],
                help="Select 2 or more numeric columns representing repeated measurements.")
            if len(tc) >= 2:
                cfg = {"type": "repeated", "subj_col": sc, "time_cols": tc}
            else:
                st.warning("Select at least 2 time-point columns.")

        else:  # Mixed ANOVA
            sc  = st.selectbox("Subject ID Column", all_cols, index=0)
            bc  = st.selectbox(
                "Between-Subjects Factor (Group)",
                [c for c in (cat_cols if cat_cols else all_cols) if c != sc],
                index=0)
            tc  = st.multiselect(
                "Time-Point Columns (Within-Subjects)",
                [c for c in num_cols if c not in [sc, bc]],
                default=[c for c in num_cols if c not in [sc, bc]][:3])
            if len(tc) >= 2:
                cfg = {"type": "mixed", "subj_col": sc,
                       "between_col": bc, "time_cols": tc}
            else:
                st.warning("Select at least 2 time-point columns.")

        st.markdown("---")
        run_btn = st.button("&#128640; Run Analysis",
                             type="primary", use_container_width=True)
    else:
        run_btn = False

# ══════════════════════════════════════════════════════════════════════════════
# DATA PREVIEW
# ══════════════════════════════════════════════════════════════════════════════
if df is not None:
    with st.expander("&#128269; Data Preview", expanded=False):
        st.dataframe(df.head(20), use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# WELCOME
# ══════════════════════════════════════════════════════════════════════════════
if not run_btn and "anova_R" not in st.session_state:
    st.markdown(
        f'<div style="background:linear-gradient(135deg,#f0f9ff,#e0f2fe);'
        f'border:1px solid #bae6fd;border-radius:12px;padding:1.2rem 1.4rem;'
        f'margin:.8rem 0;border-left:4px solid #0284c7;">'
        f'<h4 style="margin:0 0 .4rem;font-size:.95rem;font-weight:700;">'
        f'&#128203; {test_type}</h4>'
        f'<p style="margin:0;font-size:.84rem;color:#475569;">'
        f'{samp["desc"]}</p></div>',
        unsafe_allow_html=True)
    st.info("&#128072; Configure variables in the sidebar, then click **Run Analysis**.")
    st.stop()

# ══════════════════════════════════════════════════════════════════════════════
# RUN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
if run_btn:
    if cfg is None:
        st.error("&#9888;&#65039; Variable configuration is incomplete."); st.stop()

    with st.spinner("Running analysis\u2026"):
        try:
            if cfg["type"] == "oneway":
                groups_data  = [
                    df[df[cfg["group_col"]] == g][cfg["dep_col"]].dropna().values
                    for g in sorted(df[cfg["group_col"]].dropna().unique())
                ]
                group_labels = sorted(df[cfg["group_col"]].dropna().unique().tolist())
                R = run_oneway_anova(
                    groups_data, group_labels,
                    dep_var=cfg["dep_col"], alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {
                    "Test":              test_type,
                    "Grouping Variable": cfg["group_col"],
                    "Dependent Variable": cfg["dep_col"],
                    "Groups":            ", ".join(str(g) for g in group_labels),
                    "N":                 R["N"],
                    "Post-Hoc Method":   posthoc_method.title(),
                    "\u03b1":            alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps = _interpret_oneway(R, alpha)
                apa     = _build_apa(test_type, R, alpha)
                fig_main = plot_oneway_anova(
                    groups_data, group_labels, cfg["dep_col"])

            elif cfg["type"] == "twoway":
                R = run_twoway_anova(
                    df, cfg["dep_col"], cfg["fa"], cfg["fb"],
                    alpha=alpha, posthoc_method=posthoc_method)
                meta = {
                    "Test":               test_type,
                    "Factor A":           cfg["fa"],
                    "Factor B":           cfg["fb"],
                    "Dependent Variable": cfg["dep_col"],
                    "N":                  R["N"],
                    f"Design":            f"{R['ka']} \u00d7 {R['kb']}",
                    "Post-Hoc Method":    posthoc_method.title(),
                    "\u03b1":             alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps = _interpret_twoway(R, alpha)
                apa     = _build_apa(test_type, R, alpha)

                # ── Interaction plot (line) + bar chart side by side ──────────
                fig_main, axes = plt.subplots(
                    1, 2, figsize=(13, 5), facecolor=BG)

                lvl_a = R["levels_a"]
                lvl_b = R["levels_b"]
                dep   = cfg["dep_col"]

                # Panel 1 — Interaction line plot (proper)
                ax1 = axes[0]; _style_ax(ax1)
                for bi, bv in enumerate(lvl_b):
                    means = [
                        float(df[(df[cfg["fa"]] == av) &
                                  (df[cfg["fb"]] == bv)][dep].mean())
                        for av in lvl_a
                    ]
                    ses = [
                        float(df[(df[cfg["fa"]] == av) &
                                  (df[cfg["fb"]] == bv)][dep].sem())
                        for av in lvl_a
                    ]
                    ax1.errorbar(
                        range(len(lvl_a)), means, yerr=ses,
                        marker="o", markersize=8, lw=2.5,
                        color=PAL[bi % len(PAL)], label=str(bv),
                        capsize=5, capthick=1.5, elinewidth=1.5,
                        markeredgecolor="white", markeredgewidth=1.5)
                ax1.set_xticks(range(len(lvl_a)))
                ax1.set_xticklabels([str(a) for a in lvl_a], fontsize=9)
                ax1.set_xlabel(cfg["fa"], fontsize=9)
                ax1.set_ylabel(dep, fontsize=9)
                ax1.set_title(
                    f"Interaction Plot: {cfg['fa']} \u00d7 {cfg['fb']} "
                    f"(Mean \u00b1 SE)",
                    fontsize=10, fontweight="bold")
                ax1.legend(title=cfg["fb"], fontsize=8, framealpha=.8)
                # Note: non-parallel lines indicate interaction
                sig_ab = not np.isnan(R["p_AB"]) and R["p_AB"] < alpha
                note   = ("\u26a0 Non-parallel lines indicate a significant interaction."
                          if sig_ab else
                          "\u2713 Approximately parallel lines (no significant interaction).")
                ax1.text(0.5, -0.13, note, transform=ax1.transAxes,
                         ha="center", fontsize=7.5, color="#64748b",
                         style="italic")

                # Panel 2 — Grouped bar chart
                ax2 = axes[1]; _style_ax(ax2)
                n_b = len(lvl_b)
                w   = 0.7 / n_b
                xs  = np.arange(len(lvl_a))
                for bi, bv in enumerate(lvl_b):
                    means = [
                        float(df[(df[cfg["fa"]] == av) &
                                  (df[cfg["fb"]] == bv)][dep].mean())
                        for av in lvl_a
                    ]
                    ses = [
                        float(df[(df[cfg["fa"]] == av) &
                                  (df[cfg["fb"]] == bv)][dep].sem())
                        for av in lvl_a
                    ]
                    off = (bi - n_b / 2 + .5) * w
                    ax2.bar(xs + off, means, width=w * .88,
                            color=PAL[bi % len(PAL)], alpha=0.78,
                            label=str(bv), edgecolor="white", linewidth=.5)
                    ax2.errorbar(xs + off, means, yerr=[1.96 * s for s in ses],
                                 fmt="none", color="#374151",
                                 capsize=3, capthick=1, elinewidth=1, alpha=.65)
                ax2.set_xticks(xs)
                ax2.set_xticklabels([str(a) for a in lvl_a], fontsize=9)
                ax2.set_xlabel(cfg["fa"], fontsize=9)
                ax2.set_ylabel(dep, fontsize=9)
                ax2.set_title(
                    f"Bar Chart: {cfg['fa']} \u00d7 {cfg['fb']} "
                    f"(Mean \u00b1 95% CI)",
                    fontsize=10, fontweight="bold")
                ax2.legend(title=cfg["fb"], fontsize=8, framealpha=.8)
                plt.tight_layout()

            elif cfg["type"] == "repeated":
                df_rm = df[[cfg["subj_col"]] + cfg["time_cols"]].dropna()
                R = run_repeated_measures(
                    df_rm, cfg["subj_col"], cfg["time_cols"],
                    dep_var="Score", alpha=alpha,
                    posthoc_method=posthoc_method)
                meta = {
                    "Test":         test_type,
                    "Subject ID":   cfg["subj_col"],
                    "Time Points":  ", ".join(cfg["time_cols"]),
                    "N (subjects)": R["N"],
                    "Post-Hoc Method": posthoc_method.title(),
                    "\u03b1":       alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps  = _interpret_repeated(R, alpha)
                apa      = _build_apa(test_type, R, alpha)
                fig_main = plot_repeated_measures(
                    df_rm[cfg["time_cols"]].values,
                    cfg["time_cols"], "Score")

            else:  # mixed
                df_mix = df[[cfg["subj_col"], cfg["between_col"]] +
                             cfg["time_cols"]].dropna()
                R = run_mixed_anova(
                    df_mix, cfg["subj_col"], cfg["between_col"],
                    cfg["time_cols"], dep_var="Score",
                    alpha=alpha, posthoc_method=posthoc_method)
                meta = {
                    "Test":           test_type,
                    "Subject ID":     cfg["subj_col"],
                    "Between Factor": cfg["between_col"],
                    "Time Points":    ", ".join(cfg["time_cols"]),
                    "N (subjects)":   R["N"],
                    "Post-Hoc Method": posthoc_method.title(),
                    "\u03b1":         alpha,
                    "Date": datetime.now().strftime("%B %d, %Y %H:%M"),
                }
                interps  = _interpret_mixed(R, alpha)
                apa      = _build_apa(test_type, R, alpha)
                fig_main = _plot_mixed(R)

        except ZeroDivisionError:
            st.error(
                "&#9888;&#65039; **Analysis could not be completed: insufficient data in one or more groups or cells.**\n\n"
                "This error usually occurs when a group or cell contains only **1 observation**. "
                "ANOVA requires at least **2 observations per group** at each time point.\n\n"
                "**What to check:**\n"
                "- Ensure each group has at least 2 valid (non-missing) observations.\n"
                "- Ensure the grouping and time-point columns are correctly selected.\n"
                "- Check that your data does not have unexpected missing values."
            )
            st.stop()

        except ValueError as e:
            msg = str(e).lower()
            if "empty" in msg or "sample" in msg or "size" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: one or more groups are empty.**\n\n"
                    "Please ensure all selected groups contain at least 2 valid observations."
                )
            elif "constant" in msg or "variance" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: one or more variables have zero variance (all values are identical).**\n\n"
                    "Statistical tests cannot be performed on constant data. "
                    "Please select a different variable or check your data for data entry errors."
                )
            else:
                st.error(
                    f"&#9888;&#65039; **Analysis could not be completed due to a data issue.**\n\n"
                    f"Please verify that all selected variables contain valid numeric data "
                    f"and that each group has at least 2 observations.\n\n"
                    f"Technical detail (for reference): {e}"
                )
            st.stop()

        except Exception as e:
            msg = str(e).lower()
            if "division by zero" in msg or "divide by zero" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: insufficient data in one or more groups.**\n\n"
                    "At least **2 observations per group** are required. "
                    "Please check your grouping variable and ensure each group has enough data."
                )
            elif "singular" in msg or "not invertible" in msg:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed: the data matrix is singular.**\n\n"
                    "This can occur when variables are perfectly correlated or when there are "
                    "too few observations. Please check your data."
                )
            elif "column" in msg or "key" in msg or "not found" in msg:
                st.error(
                    "&#9888;&#65039; **A required column was not found in your data.**\n\n"
                    "Please check that the selected variable names match the column names "
                    "in your uploaded file."
                )
            else:
                st.error(
                    "&#9888;&#65039; **Analysis could not be completed.**\n\n"
                    "Please check that:\n"
                    "- All selected variables contain valid numeric data.\n"
                    "- Each group has at least 2 observations.\n"
                    "- The correct columns have been selected in the sidebar.\n\n"
                    f"Technical detail (for reference): {e}"
                )
            st.stop()
    figs_b = [fig_to_bytes(fig_main)]
    plt.close(fig_main)

    st.session_state.update({
        "anova_R":       R,
        "anova_meta":    meta,
        "anova_interps": interps,
        "anova_apa":     apa,
        "anova_figs":    figs_b,
        "anova_alpha":   alpha,
        "anova_cfg":     cfg,
        "anova_test":    test_type,
        "anova_posthoc": posthoc_method,
    })

# ══════════════════════════════════════════════════════════════════════════════
# LOAD FROM SESSION
# ══════════════════════════════════════════════════════════════════════════════
R          = st.session_state["anova_R"]
meta       = st.session_state["anova_meta"]
interps    = st.session_state["anova_interps"]
apa        = st.session_state["anova_apa"]
figs_b     = st.session_state["anova_figs"]
alpha      = st.session_state.get("anova_alpha", 0.05)
test_type  = st.session_state["anova_test"]

st.success("&#10003; Analysis complete!")

# ══════════════════════════════════════════════════════════════════════════════
# DECISION BANNER
# ══════════════════════════════════════════════════════════════════════════════
use_p = R.get("use_param", True)
cls   = "use-param" if use_p else "use-nonparam"

if test_type in ["One-Way ANOVA", "Two-Way Factorial ANOVA"]:
    prim = get_primary_label(R["normality"])
    tn   = get_total_n(R["normality"])
    size = "Total N\u2009<\u200950" if tn < 50 else "Total N\u2009\u2265\u200950"
    txt  = (f"\u2713 <b>{prim}</b> ({size}) p\u2009>\u2009.05 "
            f"\u2192 Normality satisfied \u2192 <b>Parametric analysis applied.</b>"
            if use_p else
            f"\u26a0 <b>{prim}</b> ({size}) p\u2009\u2264\u2009.05 "
            f"\u2192 Normality violated \u2192 <b>Non-parametric analysis applied.</b>")
else:
    sph    = R.get("sphericity")
    sph_ok = R.get("sph_ok", True)
    eps_gg = R.get("epsilon_gg", 1.0)
    txt = (f"\u2713 Normality {'satisfied' if use_p else 'violated'} &nbsp;&middot;&nbsp; "
           f"Sphericity {'satisfied' if sph_ok else f'violated \u2192 GG correction applied (\u03b5\u2009=\u2009{_f(eps_gg)})'}"
           if sph else
           f"\u2713 Normality {'satisfied' if use_p else 'violated'}")

st.markdown(f'<div class="decision-banner {cls}">{txt}</div>',
            unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# QUICK METRICS
# ══════════════════════════════════════════════════════════════════════════════
if test_type == "One-Way ANOVA":
    metrics = [
        (_f(R["F"]),            f"F({R['df_between']},\u2009{R['df_within']})"),
        (_p(R["p"]),             "Sig."),
        (_f(R["partial_eta2"]), "Partial \u03b7\u00b2"),
        (_f(R["omega2"]),        "\u03c9\u00b2"),
        (R["eta2_label"].title(), "Effect Size"),
    ]
elif test_type == "Two-Way Factorial ANOVA":
    metrics = [
        (_f(R["F_A"]),   f"F\u2009{R['factor_a']}"),
        (_p(R["p_A"]),    "Sig. A"),
        (_f(R["F_AB"]),  "F\u2009A\u00d7B"),
        (_p(R["p_AB"]),   "Sig. A\u00d7B"),
        (str(R["N"]),     "N"),
    ]
elif test_type == "Repeated Measures ANOVA":
    metrics = [
        (_f(R["F"]),             f"F({R['df_num']},\u2009{R['df_den']})"),
        (_p(R["p_primary"]),      "Sig. (GG)"),
        (_f(R["partial_eta2"]),  "Partial \u03b7\u00b2"),
        (_f(R["epsilon_gg"]),     "\u03b5 (GG)"),
        (str(R["N"]),             "N Subjects"),
    ]
else:  # Mixed
    metrics = [
        (_f(R["F_AB"]),    "F Interaction"),
        (_p(R["p_AB_gg"]), "Sig. (GG)"),
        (_f(R["es_AB"]["partial_eta2"]), "Partial \u03b7\u00b2"),
        (_f(R["epsilon_gg"]),             "\u03b5 (GG)"),
        (str(R["N"]),                      "N Subjects"),
    ]

cols = st.columns(5)
for col, (val, lbl) in zip(cols, metrics):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{val}</div>'
        f'<div class="metric-lbl">{lbl}</div>'
        f'</div>',
        unsafe_allow_html=True)
st.markdown("<br>", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TABS
# ══════════════════════════════════════════════════════════════════════════════
tab_labels = [
    "&#128203; Assumptions",
    "&#128202; Descriptives",
    "&#128200; ANOVA Results",
    "&#128201; Post-Hoc",
    "&#9889; Effect Size & Power",
    "&#128200; Plots",
    "&#128172; Interpretation",
]
tabs = st.tabs(tab_labels)

# ── Tab 0: Assumptions ──────────────────────────────────────────────────────
with tabs[0]:
    from utils.tables import normality_table
    norm_list = R["normality"]
    prim_lbl  = get_primary_label(norm_list)
    total_n   = get_total_n(norm_list)
    size_lbl  = "Total N\u2009<\u200950" if total_n < 50 else "Total N\u2009\u2265\u200950"

    st.markdown(
        f'<div class="norm-rec-box">{recommendation_note(total_n)}</div>',
        unsafe_allow_html=True)

    st.markdown('<div class="sec-title">Normality Tests</div>',
                unsafe_allow_html=True)
    sw_html, ks_html = normality_table(norm_list, prim_lbl)
    st.markdown('<div class="sub-title">Shapiro-Wilk Test</div>',
                unsafe_allow_html=True)
    st.markdown(sw_html, unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Kolmogorov-Smirnov Test (Lilliefors)</div>',
                unsafe_allow_html=True)
    st.markdown(ks_html, unsafe_allow_html=True)
    st.markdown(
        f'<div class="info-box" style="margin-top:.5rem;">{KS_DISCLAIMER}</div>',
        unsafe_allow_html=True)

    # Levene
    lev = R.get("levene")
    if lev is not None and isinstance(lev, dict):
        vv = lev.get("variants", {})
        st.markdown(
            '<div class="sec-title">Levene\u2019s Test for Equality of Variances</div>',
            unsafe_allow_html=True)

        if vv:
            # 4-variant table (SPSS-equivalent)
            lev_rows = [["", "Levene Statistic", "df1", "df2", "Sig."]]
            lev_rows.append(["Based on Mean",
                _f(vv.get("mean",{}).get("F", lev["F"])),
                str(lev["df1"]), str(lev["df2"]),
                _p(vv.get("mean",{}).get("p", lev["Sig."]))])
            lev_rows.append(["Based on Median",
                _f(vv.get("median",{}).get("F", float("nan"))),
                str(lev["df1"]), str(lev["df2"]),
                _p(vv.get("median",{}).get("p", float("nan")))])
            lev_rows.append(["Based on Median and with adjusted df",
                _f(vv.get("median_adjusted",{}).get("F", float("nan"))),
                str(lev["df1"]),
                _f(vv.get("median_adjusted",{}).get("df2", lev["df2"])),
                _p(vv.get("median_adjusted",{}).get("p", float("nan")))])
            lev_rows.append(["Based on Trimmed Mean",
                _f(vv.get("trimmed",{}).get("F", float("nan"))),
                str(lev["df1"]), str(lev["df2"]),
                _p(vv.get("trimmed",{}).get("p", float("nan")))])
            st.markdown(html_tbl(lev_rows, left_cols={0}), unsafe_allow_html=True)
        else:
            lev_rows = [["F", "df1", "df2", "Sig.", "Decision"],
                        [_f(lev["F"]), str(lev["df1"]), str(lev["df2"]),
                         _p(lev["Sig."]),
                         "\u2713 Equal" if lev["equal_var"] else "\u2717 Not Equal"]]
            st.markdown(html_tbl(lev_rows, left_cols={4}), unsafe_allow_html=True)

        # Decision
        if lev["equal_var"]:
            st.markdown(
                '<div class="info-box">&#10003; <b>Based on Mean</b> '
                'p\u2009&gt;\u2009.05 \u2192 Equal variances assumed.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                '<div class="warn-box">&#9888; <b>Based on Mean</b> '
                'p\u2009\u2264\u2009.05 \u2192 Equal variances not assumed. '
                'Interpret F-ratio with caution.</div>',
                unsafe_allow_html=True)

        # Guidance
        st.markdown("""
<div style="margin-top:.8rem;padding:1rem 1.2rem;background:#f8fafc;
border-radius:8px;border-left:4px solid #0284c7;font-size:.84rem;line-height:1.85;">
<b>&#128218; When to Use Each Variant</b><br/><br/>
<b>Based on Mean</b> &mdash; original Levene (1960). Use when data are approximately
normally distributed. SPSS default and the standard in most publications (Field, 2018).<br/><br/>
<b>Based on Median</b> &mdash; Brown-Forsythe (1974) modification. More robust when data
are non-normal or contain outliers. Preferred when normality is violated.<br/><br/>
<b>Based on Median and with adjusted df</b> &mdash; most conservative. Uses
Welch-Satterthwaite correction for df, giving the most accurate p-value for
unequal group sizes and skewed distributions.<br/><br/>
<b>Based on Trimmed Mean</b> &mdash; removes the most extreme 5% of values before
computing. A compromise between Mean and Median approaches; suitable for moderate outliers.<br/><br/>
<b>Recommended practice:</b> If all four variants agree, report Based on Mean.
If they disagree, report Based on Median as it is more robust to the condition that
caused the disagreement. Always report which variant you used.
</div>""", unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">References: Levene (1960); '
            'Brown &amp; Forsythe (1974); Field (2018).</p>',
            unsafe_allow_html=True)

    elif lev is not None and isinstance(lev, pd.DataFrame) and not lev.empty:
        st.markdown('<div class="sec-title">Levene\u2019s Test for Equality of Variances</div>',
                    unsafe_allow_html=True)
        lev_rows = [list(lev.columns)]
        for _, row in lev.iterrows():
            lev_rows.append([_f(v) if isinstance(v, float) and not np.isnan(v)
                             else str(v) if v != "" else "\u2014"
                             for v in row])
        st.markdown(html_tbl(lev_rows, left_cols={0, 1}), unsafe_allow_html=True)
        st.markdown(
            '<p class="note-txt">'
            'Tests the null hypothesis that the error variance of the dependent variable '
            'is equal across groups.<br>'
            '<b>a.</b> Design: Intercept + GROUP &nbsp; Within Subjects Design: TIME<br>'
            '<b>Based on Mean</b>: default SPSS, use when normality holds. '
            '<b>Based on Median</b>: Brown-Forsythe, robust to non-normality. '
            '<b>Based on Trimmed Mean</b>: SPSS 5% partial trim, '
            'robust to moderate outliers (not equivalent to scipy default).'
            '</p>',
            unsafe_allow_html=True)

    # Sphericity
    sph = R.get("sphericity")
    if sph and R.get("k", 2) > 2:
        st.markdown('<div class="sec-title">Mauchly\u2019s Test of Sphericity</div>',
                    unsafe_allow_html=True)
        sph_rows = [
            ["Mauchly W", "\u03c7\u00b2", "df", "Sig.",
             "\u03b5 (GG)", "\u03b5 (HF)", "\u03b5 (LB)", "Decision"],
            [_f(sph["W"]), _f(sph["chi2"]), str(sph["df"]),
             _p(sph["p"]), _f(sph["epsilon_gg"]),
             _f(sph["epsilon_hf"]), _f(sph["epsilon_lb"]),
             sph["correction"]],
        ]
        st.markdown(html_tbl(sph_rows, left_cols={7}), unsafe_allow_html=True)
        st.markdown(
            f'<p class="note-txt">'
            f'Tests the null hypothesis that the error covariance matrix of the '
            f'orthonormalized transformed dependent variables is proportional to an identity matrix.<br>'
            f'<b>a.</b> Design: Intercept + {R.get("between_col","GROUP")} &nbsp; '
            f'Within Subjects Design: TIME<br>'
            f'<b>b.</b> \u03b5 may be used to adjust the degrees of freedom for averaged tests '
            f'of significance. GG/HF/LB corrections are shown in Tests of Within-Subjects Effects.<br>'
            f'<b>Interpretation:</b> p\u2009&gt;\u2009.05 \u2192 sphericity assumed; '
            f'p\u2009\u2264\u2009.05 \u2192 sphericity violated; '
            f'use GG if \u03b5\u2009&lt;\u2009.75, HF if .75\u2009\u2264\u2009\u03b5\u2009&lt;\u20091.0.'
            f'</p>',
            unsafe_allow_html=True)
        if sph["sphericity_assumed"]:
            st.markdown(
                '<div class="info-box">&#10003; Sphericity assumed (p\u2009&gt;\u2009.05). '
                'Uncorrected p-values reported in Within-Subjects Effects.</div>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                f'<div class="warn-box">&#9888; Sphericity violated (p\u2009\u2264\u2009.05). '
                f'{sph["correction"]}. '
                f'GG-corrected p-values reported.</div>',
                unsafe_allow_html=True)

# ── Tab 1: Descriptives ─────────────────────────────────────────────────────
with tabs[1]:
    st.markdown('<div class="sec-title">Descriptive Statistics</div>',
                unsafe_allow_html=True)
    desc = R["desc"].copy()
    for c in desc.select_dtypes(include=float).columns:
        desc[c] = desc[c].apply(lambda v: _f(v) if not np.isnan(v) else ".")
    st.dataframe(desc, use_container_width=True, hide_index=True)

# ── Tab 2: ANOVA Results ────────────────────────────────────────────────────
with tabs[2]:
    st.markdown('<div class="sec-title">ANOVA Table</div>',
                unsafe_allow_html=True)

    if test_type == "One-Way ANOVA":
        at   = R["anova_table"]
        cols_at = list(at.columns)
        rows_at = [cols_at]

        def _cell_at(v):
            if isinstance(v, str): return v
            if isinstance(v, (int, np.integer)): return str(int(v))
            if isinstance(v, float) and not np.isnan(v): return _f(v)
            return "\u2014"

        for _, row in at.iterrows():
            rows_at.append([_cell_at(row[c]) for c in cols_at])
        st.markdown(html_tbl(rows_at, left_cols={0}), unsafe_allow_html=True)

    elif test_type == "Two-Way Factorial ANOVA":
        def _cell_at(v):
            if isinstance(v, str): return v
            if isinstance(v, (int, np.integer)): return str(int(v))
            if isinstance(v, float) and not np.isnan(v): return _f(v)
            return "\u2014"
        def _render_at(df_, left_cols=None):
            if left_cols is None: left_cols = {0}
            rows = [list(df_.columns)]
            for _, row in df_.iterrows():
                rows.append([_cell_at(row[c]) for c in df_.columns])
            return html_tbl(rows, left_cols=left_cols)

        # Between-Subjects Factors
        if "between_subjects_factors" in R:
            st.markdown('<div class="sec-title">Between-Subjects Factors</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_at(R["between_subjects_factors"], left_cols={0,1}),
                        unsafe_allow_html=True)

        # Tests of Between-Subjects Effects
        be = R.get("between_effects", R.get("anova_table", pd.DataFrame()))
        if not be.empty:
            st.markdown('<div class="sec-title">Tests of Between-Subjects Effects</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_at(be, left_cols={0}), unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Type III Sum of Squares. '
                'Dependent Variable: ' + R["dep_var"] + '. '
                'Partial \u03b7\u00b2 benchmarks: '
                '\u2265\u2009.01 small, \u2265\u2009.06 medium, \u2265\u2009.14 large. '
                'Observed Power computed at \u03b1\u2009=\u2009' + str(alpha) + '.</p>',
                unsafe_allow_html=True)


    elif test_type == "Repeated Measures ANOVA":
        def _cell_rm(v):
            if isinstance(v, str): return v if v else "\u2014"
            if isinstance(v, (int, np.integer)): return str(int(v))
            if isinstance(v, float) and not np.isnan(v): return _f(v)
            return "\u2014"
        def _render_rm(df_, left_cols=None):
            if left_cols is None: left_cols = {0}
            rows = [list(df_.columns)]
            for _, row in df_.iterrows():
                rows.append([_cell_rm(row[c]) for c in df_.columns])
            return html_tbl(rows, left_cols=left_cols)

        # Within-Subjects Factors
        if "within_subjects_factors" in R:
            st.markdown('<div class="sec-title">Within-Subjects Factors</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_rm(R["within_subjects_factors"], left_cols={0,1,2}),
                        unsafe_allow_html=True)

        # Multivariate Tests
        if R.get("multivariate_tests") is not None and not R["multivariate_tests"].empty:
            st.markdown('<div class="sec-title">Multivariate Tests</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_rm(R["multivariate_tests"], left_cols={0,1}),
                        unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Design: Intercept. '
                'Within Subjects Design: TIME. '
                'All four statistics are exact when p\u2009=\u20092 (2 difference scores).</p>',
                unsafe_allow_html=True)

        # Tests of Within-Subjects Effects
        if R.get("within_effects") is not None and not R["within_effects"].empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_rm(R["within_effects"], left_cols={0,1}),
                        unsafe_allow_html=True)
            sph = R.get("sphericity")
            if sph:
                st.markdown(
                    f'<p class="note-txt">Sphericity assumed: {R.get("sph_ok",True)}. '
                    f'\u03b5 (GG)\u2009=\u2009{_f(R.get("epsilon_gg",1.0))}, '
                    f'\u03b5 (HF)\u2009=\u2009{_f(R.get("epsilon_hf",1.0))}. '
                    f'Use GG-corrected row when sphericity is violated.</p>',
                    unsafe_allow_html=True)

        # Tests of Within-Subjects Contrasts
        if R.get("contrasts") is not None and not R["contrasts"].empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_rm(R["contrasts"], left_cols={0,1}),
                        unsafe_allow_html=True)

        # Tests of Between-Subjects Effects
        if R.get("between_bs_effects") is not None and not R["between_bs_effects"].empty:
            st.markdown('<div class="sec-title">Tests of Between-Subjects Effects</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_rm(R["between_bs_effects"], left_cols={0}),
                        unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">Transformed Variable: Average. '
                'Tests the grand mean intercept and between-subjects error.</p>',
                unsafe_allow_html=True)


    else:  # Mixed ANOVA — full SPSS-equivalent output
        def _cell(v):
            if isinstance(v, str): return v if v else "\u2014"
            if isinstance(v, (int, np.integer)): return str(int(v))
            if isinstance(v, float) and not np.isnan(v): return _f(v)
            return "\u2014"

        def _render_df(df_, left_cols=None):
            if left_cols is None: left_cols = {0}
            rows = [list(df_.columns)]
            for _, row in df_.iterrows():
                rows.append([_cell(row[c]) for c in df_.columns])
            return html_tbl(rows, left_cols=left_cols)

        # Between-Subjects Factors
        if "between_subjects_factors" in R:
            st.markdown('<div class="sec-title">Between-Subjects Factors</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(R["between_subjects_factors"], left_cols={0,1}),
                        unsafe_allow_html=True)

        # Multivariate Tests
        if R.get("multivariate_tests") is not None and not R["multivariate_tests"].empty:
            st.markdown('<div class="sec-title">Multivariate Tests</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(R["multivariate_tests"], left_cols={0,1}),
                        unsafe_allow_html=True)
            st.markdown(
                '<p class="note-txt">'
                '<b>a.</b> Design: Intercept + ' + R["between_col"] + ' &nbsp;'
                'Within Subjects Design: TIME<br>'
                '<b>b.</b> Exact statistic<br>'
                '<b>c.</b> Computed using \u03b1\u2009=\u2009' + str(alpha) + '<br>'
                '<b>Roy\u2019s Largest Root Value</b> = \u03bb\u2081 (largest eigenvalue). '
                '<b>Pillai\u2019s Trace</b> = \u03a3\u03bb/(1+\u03bb). '
                '<b>Wilks\u2019 Lambda</b> = \u220f1/(1+\u03bb). '
                '<b>Hotelling\u2019s Trace</b> = \u03a3\u03bb. '
                'All four are exact when Hypothesis df\u2009=\u20092.'
                '</p>',
                unsafe_allow_html=True)

        # Tests of Within-Subjects Effects
        if R.get("within_effects") is not None and not R["within_effects"].empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Effects</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(R["within_effects"], left_cols={0,1}),
                        unsafe_allow_html=True)
            sph = R.get("sphericity")
            eps_gg = R.get("epsilon_gg", 1.0)
            eps_hf = R.get("epsilon_hf", 1.0)
            sph_ok = R.get("sph_ok", True)
            st.markdown(
                f'<p class="note-txt">'
                f'<b>a.</b> Computed using \u03b1\u2009=\u2009{alpha}<br>'
                f'<b>Measure:</b> MEASURE_1 &nbsp; '
                f'<b>Sphericity assumed:</b> {sph_ok}<br>'
                f'<b>\u03b5 (GG)</b>\u2009=\u2009{_f(eps_gg)} &nbsp; '
                f'<b>\u03b5 (HF)</b>\u2009=\u2009{_f(eps_hf)} &nbsp; '
                f'<b>\u03b5 (LB)</b>\u2009=\u2009{_f(R.get("epsilon_lb", 0.5))}<br>'
                f'GG/HF/LB corrections adjust df and p-value when sphericity is violated. '
                f'Use <b>Sphericity Assumed</b> row when Mauchly p\u2009&gt;\u2009.05, '
                f'<b>Greenhouse-Geisser</b> when \u03b5\u2009&lt;\u2009.75, '
                f'<b>Huynh-Feldt</b> when .75\u2009\u2264\u2009\u03b5\u2009&lt;\u20091.0.'
                f'</p>',
                unsafe_allow_html=True)

        # Tests of Within-Subjects Contrasts
        if R.get("contrasts") is not None and not R["contrasts"].empty:
            st.markdown('<div class="sec-title">Tests of Within-Subjects Contrasts</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(R["contrasts"], left_cols={0,1}),
                        unsafe_allow_html=True)
            st.markdown(
                f'<p class="note-txt">'
                f'<b>a.</b> Computed using \u03b1\u2009=\u2009{alpha}<br>'
                f'<b>Measure:</b> MEASURE_1<br>'
                f'Polynomial contrasts partition the within-subjects SS into '
                f'orthogonal trend components (Linear, Quadratic, etc.). '
                f'<b>Linear</b> tests for a straight-line trend across time. '
                f'<b>Quadratic</b> tests for a U-shaped or inverted-U trend. '
                f'Error term for each contrast is the pooled within-group variability '
                f'on the corresponding contrast scores, divided by \u03a3c\u00b2 (Type III SS formulation).'
                f'</p>',
                unsafe_allow_html=True)

        # Tests of Between-Subjects Effects
        if R.get("between_bs_effects") is not None and not R["between_bs_effects"].empty:
            st.markdown('<div class="sec-title">Tests of Between-Subjects Effects</div>',
                        unsafe_allow_html=True)
            st.markdown(_render_df(R["between_bs_effects"], left_cols={0}),
                        unsafe_allow_html=True)
            st.markdown(
                f'<p class="note-txt">'
                f'<b>a.</b> Computed using \u03b1\u2009=\u2009{alpha}<br>'
                f'<b>Measure:</b> MEASURE_1 &nbsp; '
                f'<b>Transformed Variable:</b> Average<br>'
                f'Tests between-subjects effects on the average of all time points. '
                f'Error term = Subjects-within-Groups '
                f'(MS\u2009=\u2009SS_sWG\u2009/\u2009df_sWG\u2009=\u2009'
                f'{_f(R.get("anova_table",pd.DataFrame()).get("MS",pd.Series()).iloc[-2] if not R.get("anova_table",pd.DataFrame()).empty else float("nan"))}). '
                f'Type III Sum of Squares.'
                f'</p>',
                unsafe_allow_html=True)


    if use_p:
        st.markdown(
            '<div class="info-box">&#10003; Parametric analysis applied. '
            'Results above are based on the ANOVA.</div>',
            unsafe_allow_html=True)
    else:
        np_label = ("Kruskal-Wallis" if test_type == "One-Way ANOVA"
                    else "Friedman")
        st.markdown(
            f'<div class="warn-box">&#9888; Normality violated. '
            f'Refer to the <b>Post-Hoc</b> tab for the {np_label} results.</div>',
            unsafe_allow_html=True)

# ── Tab 3: Post-Hoc ─────────────────────────────────────────────────────────
with tabs[3]:
    if test_type == "One-Way ANOVA":
        if use_p:
            ph = R["posthoc"]
            if ph.empty:
                st.info("\u2139\ufe0f ANOVA was not significant — post-hoc tests not conducted.")
            else:
                st.markdown(
                    f'<div class="sec-title">Post-Hoc: {R["posthoc_method"].title()}</div>',
                    unsafe_allow_html=True)
                ph_rows = [list(ph.columns)]
                for _, row in ph.iterrows():
                    ph_rows.append([
                        str(v) if isinstance(v, (str, bool))
                        else str(int(v)) if isinstance(v, (int, np.integer))
                        else _f(v) if isinstance(v, float) and not np.isnan(v)
                        else "\u2014"
                        for v in row
                    ])
                st.markdown(html_tbl(ph_rows, left_cols={0, 1}),
                            unsafe_allow_html=True)
        else:
            kw = R["kruskal_wallis"]
            st.markdown('<div class="sec-title">Kruskal-Wallis Test</div>',
                        unsafe_allow_html=True)
            kw_rows = [["H", "df", "Sig.", "N Total"],
                       [_f(kw["H"]), str(kw["df"]),
                        _p(kw["p"]), str(kw["N_total"])]]
            st.markdown(html_tbl(kw_rows), unsafe_allow_html=True)
            for gs in kw.get("group_stats", []):
                pass

            if not R["kruskal_ph"].empty:
                st.markdown(
                    '<div class="sec-title">Dunn\u2019s Post-Hoc (Bonferroni)</div>',
                    unsafe_allow_html=True)
                kw_ph = R["kruskal_ph"]
                kph_rows = [list(kw_ph.columns)]
                for _, row in kw_ph.iterrows():
                    kph_rows.append([str(v) for v in row])
                st.markdown(html_tbl(kph_rows, left_cols={0, 1}),
                            unsafe_allow_html=True)

    elif test_type == "Two-Way Factorial ANOVA":
        for label, ph_df, factor in [
            (f"Post-Hoc: {R['factor_a']}", R["posthoc_A"], R["factor_a"]),
            (f"Post-Hoc: {R['factor_b']}", R["posthoc_B"], R["factor_b"]),
        ]:
            if not ph_df.empty:
                st.markdown(f'<div class="sec-title">{label}</div>',
                            unsafe_allow_html=True)
                ph_rows = [list(ph_df.columns)]
                for _, row in ph_df.iterrows():
                    ph_rows.append([
                        str(v) if isinstance(v, (str, bool))
                        else str(int(v)) if isinstance(v, (int, np.integer))
                        else _f(v) if isinstance(v, float) and not np.isnan(v)
                        else "\u2014" for v in row
                    ])
                st.markdown(html_tbl(ph_rows, left_cols={0, 1}),
                            unsafe_allow_html=True)
        if R["posthoc_A"].empty and R["posthoc_B"].empty:
            st.info("Neither main effect was significant — no post-hoc tests conducted.")

    elif test_type == "Repeated Measures ANOVA":
        if use_p:
            ph = R["posthoc"]
            if ph.empty:
                st.info("ANOVA was not significant — post-hoc tests not conducted.")
            else:
                st.markdown(
                    f'<div class="sec-title">Pairwise Comparisons '
                    f'({R["posthoc_method"].title()} correction)</div>',
                    unsafe_allow_html=True)
                ph_rows = [list(ph.columns)]
                for _, row in ph.iterrows():
                    ph_rows.append([
                        str(v) if isinstance(v, (str, bool))
                        else str(int(v)) if isinstance(v, (int, np.integer))
                        else _f(v) if isinstance(v, float) and not np.isnan(v)
                        else "\u2014" for v in row
                    ])
                st.markdown(html_tbl(ph_rows, left_cols={0, 1}),
                            unsafe_allow_html=True)
        else:
            fr  = R["friedman"]
            frh = R["friedman_ph"]
            st.markdown('<div class="sec-title">Friedman Test</div>',
                        unsafe_allow_html=True)
            fr_rows = [["\u03c7\u00b2", "df", "Sig.", "N", "k"],
                       [_f(fr["chi2"]), str(fr["df"]),
                        _p(fr["p"]), str(fr["N"]), str(fr["k"])]]
            st.markdown(html_tbl(fr_rows), unsafe_allow_html=True)
            if not frh.empty:
                st.markdown(
                    '<div class="sec-title">Wilcoxon Post-Hoc (Bonferroni)</div>',
                    unsafe_allow_html=True)
                frh_rows = [list(frh.columns)]
                for _, row in frh.iterrows():
                    frh_rows.append([str(v) for v in row])
                st.markdown(html_tbl(frh_rows, left_cols={0, 1}),
                            unsafe_allow_html=True)

    else:  # Mixed
        ph_bt = R.get("posthoc_between", pd.DataFrame())
        ph_wt = R.get("posthoc_within",  pd.DataFrame())
        if ph_bt.empty and ph_wt.empty:
            st.info("Interaction was not significant — post-hoc tests not conducted.")
        else:
            def _ph_cell(v):
                if isinstance(v, (str, bool)): return str(v)
                if isinstance(v, (int, np.integer)): return str(int(v))
                if isinstance(v, float) and not np.isnan(v): return _f(v)
                return "\u2014"

            if not ph_bt.empty:
                st.markdown(
                    '<div class="sec-title">Between-Group Comparisons at Each Time Point</div>',
                    unsafe_allow_html=True)
                btr = [list(ph_bt.columns)]
                for _, row in ph_bt.iterrows():
                    btr.append([_ph_cell(v) for v in row])
                st.markdown(html_tbl(btr, left_cols={0, 1, 2, 3}),
                            unsafe_allow_html=True)
            if not ph_wt.empty:
                st.markdown(
                    '<div class="sec-title">Within-Subject Time Comparisons per Group</div>',
                    unsafe_allow_html=True)
                wtr = [list(ph_wt.columns)]
                for _, row in ph_wt.iterrows():
                    wtr.append([_ph_cell(v) for v in row])
                st.markdown(html_tbl(wtr, left_cols={0, 1, 2, 3}),
                            unsafe_allow_html=True)

# ── Tab 4: Effect Size & Power ───────────────────────────────────────────────
with tabs[4]:
    st.markdown('<div class="sec-title">Effect Size</div>', unsafe_allow_html=True)

    if test_type == "One-Way ANOVA":
        es_rows = [["Measure","Value","Interpretation","Note"],
                   ["Partial \u03b7\u00b2", _f(R["partial_eta2"]),
                    R["eta2_label"],
                    "SS_between / (SS_between + SS_within)"],
                   ["\u03c9\u00b2 (omega-squared)", _f(R["omega2"]),
                    R["omega2_label"],
                    "Less biased than \u03b7\u00b2 (Field, 2018)"],
                   ["Cohen\u2019s f", _f(R["cohens_f"]),
                    R["f2_label"].title() if R.get("f2_label") else "N/A",
                    "f\u2009=\u2009\u221a(\u03b7\u00b2 / (1\u2009\u2212\u2009\u03b7\u00b2))"],
                   ]
        st.markdown(html_tbl(es_rows, left_cols={0, 2, 3}), unsafe_allow_html=True)

        st.markdown('<div class="sec-title">Statistical Power</div>',
                    unsafe_allow_html=True)
        pwr = R.get("power", np.nan)
        pw_rows = [["Parameter","Value"],
                   ["F-statistic", _f(R["F"])],
                   ["df (between/within)", f"{R['df_between']}\u2009/\u2009{R['df_within']}"],
                   ["Effect size (f\u00b2)", _f(R["cohens_f"] ** 2
                     if not np.isnan(R["cohens_f"]) else np.nan)],
                   ["Achieved power", f"{pwr*100:.1f}%" if not np.isnan(pwr) else "N/A"],
                   ["Power label", power_label(pwr) if not np.isnan(pwr) else "N/A"],
                   ["Recommended minimum", "\u2265\u2009.80 (Cohen, 1988)"],
                   ]
        st.markdown(html_tbl(pw_rows, left_cols={0}), unsafe_allow_html=True)
        if not np.isnan(pwr):
            bar_c   = "#16a34a" if pwr >= .80 else "#f59e0b" if pwr >= .60 else "#dc2626"
            st.markdown(
                f'<div style="background:#e2e8f0;border-radius:8px;height:16px;'
                f'width:100%;margin:8px 0;">'
                f'<div style="background:{bar_c};width:{int(pwr*100)}%;'
                f'height:16px;border-radius:8px;"></div></div>',
                unsafe_allow_html=True)

    elif test_type == "Two-Way Factorial ANOVA":
        es_rows = [["Source","Partial \u03b7\u00b2","Interpretation",
                    "Power"]]
        for label, es_dict in [
            (R["factor_a"], R["es_A"]),
            (R["factor_b"], R["es_B"]),
            (f"{R['factor_a']} \u00d7 {R['factor_b']}", R["es_AB"]),
        ]:
            es_rows.append([
                label,
                _f(es_dict["partial_eta2"]),
                es_dict["label"],
                f"{es_dict['power']*100:.1f}%"
                if not np.isnan(es_dict["power"]) else "N/A",
            ])
        st.markdown(html_tbl(es_rows, left_cols={0, 2}), unsafe_allow_html=True)

    elif test_type == "Repeated Measures ANOVA":
        pwr = R.get("power", np.nan)
        es_rows = [["Measure","Value","Interpretation"],
                   ["Partial \u03b7\u00b2", _f(R["partial_eta2"]),
                    effect_label_eta2(R["partial_eta2"])],
                   ["Cohen\u2019s f", _f(R.get("cohens_f", np.nan)), ""],
                   ["Achieved Power",
                    f"{pwr*100:.1f}%" if not np.isnan(pwr) else "N/A",
                    power_label(pwr) if not np.isnan(pwr) else "N/A"],
                   ]
        st.markdown(html_tbl(es_rows, left_cols={0, 2}), unsafe_allow_html=True)

    else:  # Mixed
        es_rows = [["Source","Partial \u03b7\u00b2","Interpretation","Power"]]
        for label, es_dict in [
            (R["between_col"], R["es_A"]),
            ("Time",           R["es_B"]),
            (f"{R['between_col']} \u00d7 Time", R["es_AB"]),
        ]:
            es_rows.append([
                label,
                _f(es_dict["partial_eta2"]),
                es_dict["label"],
                f"{es_dict['power']*100:.1f}%"
                if not np.isnan(es_dict["power"]) else "N/A",
            ])
        st.markdown(html_tbl(es_rows, left_cols={0, 2}), unsafe_allow_html=True)

    st.markdown(
        '<p class="note-txt">'
        'Benchmarks for partial \u03b7\u00b2: '
        '\u2265\u2009.01 small, \u2265\u2009.06 medium, \u2265\u2009.14 large. '
        '\u03c9\u00b2 is less biased than \u03b7\u00b2 and preferred for reporting. '
        'Post-hoc power uses non-central F-distribution. '
        'Reference: Cohen (1988); Field (2018).'
        '</p>',
        unsafe_allow_html=True)

# ── Tab 5: Plots ─────────────────────────────────────────────────────────────
with tabs[5]:
    for fb in figs_b:
        st.image(fb, use_container_width=True)

# ── Tab 6: Interpretation ────────────────────────────────────────────────────
with tabs[6]:
    st.markdown("### &#128221; Statistical Interpretation")
    for line in interps:
        lw  = line.lower()
        cls_ = ("sig" if "statistically significant" in lw
                         and "not statistically significant" not in lw
                else "nonsig" if "not statistically significant" in lw else "")
        st.markdown(f'<div class="interp-box {cls_}">{line}</div>',
                    unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**APA 7th Edition Write-Up:**")
    apa_plain = re.sub(r"<[^>]+>", "", apa)
    st.code(apa_plain, language=None)

# ══════════════════════════════════════════════════════════════════════════════
# DOWNLOADS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("---")
st.markdown("### &#128229; Download Results")
dc1, dc2 = st.columns(2)

def _build_html_anova(R, meta, interps, apa, figs_b, alpha, test_type):
    """Build standalone HTML report for ANOVA — complete, matching Streamlit display."""
    import base64
    from modules.normality import KS_DISCLAIMER, recommendation_note_plain

    def _rtbl(rows, left_cols=None):
        if left_cols is None: left_cols = {0}
        h = '<table class="rtbl"><thead><tr>'
        for c in rows[0]: h += f"<th>{c}</th>"
        h += "</tr></thead><tbody>"
        for i, row in enumerate(rows[1:]):
            h += f'<tr class="{("even" if i%2==0 else "odd")}">' 
            for j, cell in enumerate(row):
                cls = ' class="left"' if j in left_cols else ""
                h += f"<td{cls}>{cell}</td>"
            h += "</tr>"
        h += "</tbody></table>"
        return h

    def _sub(t):
        return f'<div class="sub-hdr">{t}</div>'

    def _hcell(v):
        if isinstance(v, str): return v if v != "" else "\u2014"
        if isinstance(v, (int, __import__("numpy").integer)): return str(int(v))
        if isinstance(v, float) and not __import__("numpy").isnan(v): return _f(v)
        return "\u2014"

    def _at_rows(at):
        rows = [list(at.columns)]
        for _, row in at.iterrows():
            rows.append([_hcell(row[c]) for c in at.columns])
        return rows

    def _ph_rows(ph):
        rows = [list(ph.columns)]
        for _, row in ph.iterrows():
            rows.append([_hcell(v) for v in row])
        return rows

    # meta
    meta_html = "<table class='meta-tbl'>"
    for k_, v in meta.items():
        meta_html += f"<tr><td class='mk'>{k_}</td><td class='mv'>{v}</td></tr>"
    meta_html += "</table>"

    # normality
    norm_list = R["normality"]
    prim = get_primary_label(norm_list)
    tn   = get_total_n(norm_list)
    norm_rec = recommendation_note_plain(tn)
    sw_rows = [["Variable / Cell","N","W","Sig.","Result"]]
    ks_rows = [["Variable / Cell","N","D","Sig.\u1d43","Result"]]
    for nm in norm_list:
        sw_rows.append([nm["label"],str(nm["n"]),_f(nm["sw_W"]),_p(nm["sw_p"]),
                        "\u2713 Normal" if nm["sw_pass"] else "\u2717 Non-Normal"])
        ks_rows.append([nm["label"],str(nm["n"]),_f(nm["ks_D"]),_p(nm["ks_p"]),
                        "\u2713 Normal" if nm["ks_pass"] else "\u2717 Non-Normal"])
    norm_html = (f'<div class="rec-box">{norm_rec}</div>'
        + _sub("Shapiro-Wilk Test") + _rtbl(sw_rows)
        + _sub("Kolmogorov-Smirnov Test (Lilliefors Correction)") + _rtbl(ks_rows)
        + f'<p class="tbl-note">\u1d43 Lilliefors correction. Primary criterion: <b>{prim}</b>.</p>'
        + f'<div class="warn-box" style="font-size:.79rem;">{KS_DISCLAIMER}</div>'
        + ('<div class="info-box">\u2713 All cells satisfied normality.</div>' if R.get("use_param")
           else '<div class="warn-box">\u26a0 Normality violated in one or more cells.</div>'))

    # levene / sphericity
    assume_html = ""
    lev = R.get("levene")
    if lev is not None and isinstance(lev, pd.DataFrame) and not lev.empty:
        lev_rows = [list(lev.columns)]
        for _, row in lev.iterrows():
            lev_rows.append([_hcell(v) for v in row])
        assume_html += _sub("Levene\u2019s Test for Equality of Variances (per Time Point)") \
                       + _rtbl(lev_rows, left_cols={0, 1})
        assume_html += '<p class="tbl-note">4 variants shown (SPSS-equivalent). Decision based on Based on Mean.</p>'
    elif lev is not None and isinstance(lev, dict):
        vv = lev.get("variants", {})
        if vv:
            df1_ = lev["df1"]; df2_ = lev["df2"]
            lev_rows = [["", "Levene Statistic", "df1", "df2", "Sig."]]
            lev_rows.append(["Based on Mean",
                _f(vv.get("mean",{}).get("F", lev["F"])),
                str(df1_), str(df2_),
                _p(vv.get("mean",{}).get("p", lev["Sig."]))])
            lev_rows.append(["Based on Median",
                _f(vv.get("median",{}).get("F", float("nan"))),
                str(df1_), str(df2_),
                _p(vv.get("median",{}).get("p", float("nan")))])
            lev_rows.append(["Based on Median and with adjusted df",
                _f(vv.get("median_adjusted",{}).get("F", float("nan"))),
                str(df1_),
                _f(vv.get("median_adjusted",{}).get("df2", df2_)),
                _p(vv.get("median_adjusted",{}).get("p", float("nan")))])
            lev_rows.append(["Based on Trimmed Mean",
                _f(vv.get("trimmed",{}).get("F", float("nan"))),
                str(df1_), str(df2_),
                _p(vv.get("trimmed",{}).get("p", float("nan")))])
            assume_html += _sub("Levene\u2019s Test for Equality of Variances") \
                           + _rtbl(lev_rows, left_cols={0})
            dec = "\u2713 Equal variances assumed" if lev["equal_var"] else "\u2717 Equal variances not assumed"
            assume_html += (
                f'<div class="{"info-box" if lev["equal_var"] else "warn-box"}">'
                f'{"&#10003;" if lev["equal_var"] else "&#9888;"} '
                f'<b>Based on Mean</b> p\u2009{"&gt;" if lev["equal_var"] else "&le;"}\u2009.05 '
                f'\u2192 {dec}.</div>'
                f'<div style="margin-top:.6rem;padding:.8rem 1rem;background:#f8fafc;'
                f'border-radius:6px;border-left:4px solid #0284c7;font-size:.78rem;line-height:1.8;">'
                f'<b>When to Use Each Variant:</b><br/>'
                f'<b>Based on Mean</b> \u2014 original Levene (1960), SPSS default. Use when data are approximately normal.<br/>'
                f'<b>Based on Median</b> \u2014 Brown-Forsythe (1974). More robust when data are non-normal or contain outliers.<br/>'
                f'<b>Based on Median and with adjusted df</b> \u2014 most conservative; Welch-Satterthwaite df correction.<br/>'
                f'<b>Based on Trimmed Mean</b> \u2014 SPSS 5% partial trim. Suitable for moderate outliers.<br/>'
                f'<b>Recommended:</b> If all four agree, report Based on Mean. If they disagree, report Based on Median.'
                f'</div>'
                f'<p class="tbl-note">References: Levene (1960); Brown &amp; Forsythe (1974); Field (2018).</p>'
            )
        else:
            lev_rows = [["F","df1","df2","Sig.","Decision"],
                        [_f(lev["F"]),str(lev["df1"]),str(lev["df2"]),_p(lev["Sig."]),
                         "\u2713 Equal" if lev["equal_var"] else "\u2717 Not Equal"]]
            assume_html += _sub("Levene\u2019s Test") + _rtbl(lev_rows, left_cols={4})

    sph = R.get("sphericity")
    if sph and R.get("k",2) > 2:
        sph_rows = [["Mauchly W","\u03c7\u00b2","df","Sig.","\u03b5 (GG)","\u03b5 (HF)","\u03b5 (LB)","Decision"],
                    [_f(sph["W"]),_f(sph["chi2"]),str(sph["df"]),_p(sph["p"]),
                     _f(sph["epsilon_gg"]),_f(sph["epsilon_hf"]),_f(sph["epsilon_lb"]),sph["correction"]]]
        assume_html += _sub("Mauchly\u2019s Test of Sphericity") + _rtbl(sph_rows, left_cols={7})
        assume_html += (
            '<div class="info-box">&#10003; Sphericity assumed (p\u2009&gt;\u2009.05). Uncorrected F reported.</div>'
            if sph["sphericity_assumed"] else
            f'<div class="warn-box">&#9888; Sphericity violated (p\u2009&le;\u2009.05). {sph["correction"]}. '
            f'GG-corrected p-values are reported in Tests of Within-Subjects Effects.</div>'
        )
        eps_gg = sph["epsilon_gg"]; eps_hf = sph["epsilon_hf"]
        assume_html += (
            f'<div style="margin-top:.6rem;padding:.8rem 1rem;background:#f8fafc;'
            f'border-radius:6px;border-left:4px solid #0284c7;font-size:.78rem;line-height:1.8;">'
            f'Tests the null hypothesis that the error covariance matrix of the orthonormalized '
            f'transformed dependent variables is proportional to an identity matrix '
            f'(orthonormal Helmert contrasts, SPSS method).<br/>'
            f'<b>\u03b5 (GG)</b>\u2009=\u2009{_f(eps_gg)}, '
            f'<b>\u03b5 (HF)</b>\u2009=\u2009{_f(eps_hf)}, '
            f'<b>\u03b5 (LB)</b>\u2009=\u2009{_f(sph["epsilon_lb"])}<br/>'
            f'<b>Interpretation:</b> p\u2009&gt;\u2009.05 \u2192 sphericity assumed; '
            f'p\u2009&le;\u2009.05 \u2192 violated. '
            f'Use GG correction when \u03b5\u2009&lt;\u2009.75; '
            f'HF when .75\u2009&le;\u2009\u03b5\u2009&lt;\u20091.0.'
            f'</div>'
        )

    # descriptives
    desc_rows = [list(R["desc"].columns)]
    for _, row in R["desc"].iterrows():
        desc_rows.append([_hcell(v) for v in row])
    desc_html = _rtbl(desc_rows, left_cols={0,1})

    # ANOVA table — SPSS-equivalent for all types
    anova_html = ""
    if test_type == "One-Way ANOVA":
        if "anova_table" in R and not R["anova_table"].empty:
            anova_html = _rtbl(_at_rows(R["anova_table"]), left_cols={0})
    elif test_type == "Two-Way Factorial ANOVA":
        if "between_subjects_factors" in R:
            anova_html += _sub("Between-Subjects Factors") \
                          + _rtbl(_at_rows(R["between_subjects_factors"]), left_cols={0,1})
        be = R.get("between_effects", pd.DataFrame())
        if not be.empty:
            anova_html += _sub("Tests of Between-Subjects Effects") \
                          + _rtbl(_at_rows(be), left_cols={0})
            anova_html += (f'<p class="tbl-note">Type III Sum of Squares. Dependent Variable: {R["dep_var"]}. '
                           f'Partial \u03b7\u00b2: \u2265.01 small, \u2265.06 medium, \u2265.14 large. '
                           f'Observed Power computed at \u03b1\u2009=\u2009{alpha}.</p>')
    elif test_type == "Repeated Measures ANOVA":
        # Within-Subjects Factors
        if "within_subjects_factors" in R:
            anova_html += _sub("Within-Subjects Factors") \
                          + _rtbl(_at_rows(R["within_subjects_factors"]), left_cols={0,1,2})
        # Multivariate Tests
        mv = R.get("multivariate_tests")
        if mv is not None and not mv.empty:
            anova_html += _sub("Multivariate Tests") \
                          + _rtbl(_at_rows(mv), left_cols={0,1})
            anova_html += '<p class="tbl-note">Design: Intercept. Within Subjects Design: TIME. All statistics exact when Hypothesis df\u2009=\u20092.</p>'
        # Within-Subjects Effects
        we = R.get("within_effects")
        if we is not None and not we.empty:
            anova_html += _sub("Tests of Within-Subjects Effects") \
                          + _rtbl(_at_rows(we), left_cols={0,1})
            eps_gg = R.get("epsilon_gg", 1.0)
            anova_html += (f'<p class="tbl-note">Sphericity assumed: {R.get("sph_ok",True)}. '
                           f'\u03b5 (GG)\u2009=\u2009{_f(eps_gg)}. '
                           f'Use GG row when sphericity is violated. Observed Power at \u03b1\u2009=\u2009{alpha}.</p>')
        # Within-Subjects Contrasts
        ct = R.get("contrasts")
        if ct is not None and not ct.empty:
            anova_html += _sub("Tests of Within-Subjects Contrasts") \
                          + _rtbl(_at_rows(ct), left_cols={0,1})
            anova_html += '<p class="tbl-note">Polynomial contrasts. Linear = straight-line trend. Quadratic = U-shaped trend.</p>'
        # Between-Subjects Effects
        bs = R.get("between_bs_effects")
        if bs is not None and not bs.empty:
            anova_html += _sub("Tests of Between-Subjects Effects") \
                          + _rtbl(_at_rows(bs), left_cols={0})
            anova_html += '<p class="tbl-note">Transformed Variable: Average. Tests grand mean intercept.</p>'
    else:  # Mixed ANOVA
        if "between_subjects_factors" in R:
            anova_html += _sub("Between-Subjects Factors") \
                          + _rtbl(_at_rows(R["between_subjects_factors"]), left_cols={0,1})
        mv = R.get("multivariate_tests")
        if mv is not None and not mv.empty:
            anova_html += _sub("Multivariate Tests") \
                          + _rtbl(_at_rows(mv), left_cols={0,1})
            anova_html += f'<p class="tbl-note">Design: Intercept + {R.get("between_col","")}. Within: TIME. Exact statistic.</p>'
        we = R.get("within_effects")
        if we is not None and not we.empty:
            anova_html += _sub("Tests of Within-Subjects Effects") \
                          + _rtbl(_at_rows(we), left_cols={0,1})
            anova_html += (f'<p class="tbl-note">GG\u2009=\u2009{_f(R.get("epsilon_gg",1.0))}, '
                           f'HF\u2009=\u2009{_f(R.get("epsilon_hf",1.0))}. Observed Power at \u03b1\u2009=\u2009{alpha}.</p>')
        ct = R.get("contrasts")
        if ct is not None and not ct.empty:
            anova_html += _sub("Tests of Within-Subjects Contrasts") \
                          + _rtbl(_at_rows(ct), left_cols={0,1})
        bs = R.get("between_bs_effects")
        if bs is not None and not bs.empty:
            anova_html += _sub("Tests of Between-Subjects Effects") \
                          + _rtbl(_at_rows(bs), left_cols={0})
            anova_html += '<p class="tbl-note">Transformed Variable: Average. Error term: Subjects-within-Groups.</p>'


    # effect sizes
    es_html = ""
    if test_type == "One-Way ANOVA":
        pwr = R.get("power", float("nan"))
        es_rows = [["Measure","Value","Interpretation"],
                   ["Partial \u03b7\u00b2",_f(R["partial_eta2"]),R["eta2_label"]],
                   ["\u03c9\u00b2 (omega-squared)",_f(R["omega2"]),R["omega2_label"]],
                   ["Cohen\u2019s f",_f(R["cohens_f"]),""],
                   ["Achieved Power",f"{pwr*100:.1f}%" if not __import__("numpy").isnan(pwr) else "N/A",""]]
        es_html = _rtbl(es_rows, left_cols={0,2})
    elif test_type in ["Two-Way Factorial ANOVA","Mixed ANOVA"]:
        srcs = ([(R["factor_a"],R["es_A"]),(R["factor_b"],R["es_B"]),(f"{R['factor_a']} \u00d7 {R['factor_b']}",R["es_AB"])]
                if test_type=="Two-Way Factorial ANOVA" else
                [(R["between_col"],R["es_A"]),("Time",R["es_B"]),(f"{R['between_col']} \u00d7 Time",R["es_AB"])])
        es_rows = [["Source","Partial \u03b7\u00b2","Interpretation","Power"]]
        for lbl,es in srcs:
            es_rows.append([lbl,_f(es["partial_eta2"]),es["label"],
                            f"{es['power']*100:.1f}%" if not __import__("numpy").isnan(es["power"]) else "N/A"])
        es_html = _rtbl(es_rows, left_cols={0,2})
    elif test_type == "Repeated Measures ANOVA":
        pwr = R.get("power", float("nan"))
        es_rows = [["Measure","Value","Interpretation"],
                   ["Partial \u03b7\u00b2",_f(R["partial_eta2"]),effect_label_eta2(R["partial_eta2"])],
                   ["Cohen\u2019s f",_f(R.get("cohens_f",float("nan"))),""],
                   ["Achieved Power",f"{pwr*100:.1f}%" if not __import__("numpy").isnan(pwr) else "N/A",""]]
        es_html = _rtbl(es_rows, left_cols={0,2})

    # post-hoc
    ph_method_lbl = R.get('posthoc_method', 'tukey').title()
    ph_html = ""
    if test_type == "One-Way ANOVA":
        ph = R.get("posthoc", pd.DataFrame())
        if not ph.empty:
            ph_html = _sub(f"Post-Hoc Comparisons: {ph_method_lbl}") + _rtbl(_ph_rows(ph), left_cols={0,1})
            ph_html += f'<p class="tbl-note">Method: <b>{ph_method_lbl}</b>. Significant if p_adj\u2009&lt;\u2009{alpha}.</p>'
        if not R.get("use_param") and R.get("kruskal_wallis"):
            kw = R["kruskal_wallis"]
            ph_html += _sub("Kruskal-Wallis") + _rtbl([["H","df","Sig.","N"],[_f(kw["H"]),str(kw["df"]),_p(kw["p"]),str(kw["N_total"])]])
    elif test_type == "Two-Way Factorial ANOVA":
        for lbl,df_ in [(R["factor_a"],R.get("posthoc_A",pd.DataFrame())),(R["factor_b"],R.get("posthoc_B",pd.DataFrame()))]:
            if not df_.empty:
                ph_html += _sub(f"Post-Hoc Comparisons for {lbl} ({ph_method_lbl})") \
                           + _rtbl(_ph_rows(df_), left_cols={0,1})
        if ph_html:
            ph_html += f'<p class="tbl-note">Method: <b>{ph_method_lbl}</b>. Applied only to significant main effects.</p>'
    elif test_type == "Repeated Measures ANOVA":
        ph = R.get("posthoc", pd.DataFrame())
        if not ph.empty:
            ph_html = _sub(f"Pairwise Comparisons ({ph_method_lbl} correction)") \
                      + _rtbl(_ph_rows(ph), left_cols={0,1})
            ph_html += f'<p class="tbl-note">Method: <b>{ph_method_lbl}</b>. Significant if p_adj\u2009&lt;\u2009{alpha}.</p>'
        elif R.get("friedman"):
            fr = R["friedman"]
            ph_html = _sub("Friedman Test (Non-Parametric)") \
                      + _rtbl([["\u03c7\u00b2","df","Sig.","N","k"],
                                [_f(fr["chi2"]),str(fr["df"]),_p(fr["p"]),str(fr["N"]),str(fr["k"])]])
    else:
        ph_bt = R.get("posthoc_between", pd.DataFrame())
        ph_wt = R.get("posthoc_within",  pd.DataFrame())
        if not ph_bt.empty:
            ph_html += _sub(f"Between-Group Comparisons at Each Time Point ({ph_method_lbl})") \
                       + _rtbl(_ph_rows(ph_bt), left_cols={0,1,2,3})
        if not ph_wt.empty:
            ph_html += _sub(f"Within-Subject Time Comparisons per Group ({ph_method_lbl})") \
                       + _rtbl(_ph_rows(ph_wt), left_cols={0,1,2,3})
        if ph_html:
            ph_html += f'<p class="tbl-note">Method: <b>{ph_method_lbl}</b>. Conducted when TIME\u00d7GROUP interaction is significant.</p>'
        else:
            ph_html = "<p>Interaction not significant \u2014 post-hoc not conducted.</p>"

    # interpretation
    interp_html = ""
    for line in interps:
        lw = line.lower()
        cls = ("sig" if "statistically significant" in lw and "not statistically significant" not in lw
               else "nonsig" if "not statistically significant" in lw else "")
        interp_html += f'<div class="interp {cls}">{line}</div>'
    interp_html += ('<div style="margin-top:20px;"><div class="apa-label">APA 7th Edition Write-Up</div>'
                    + f'<div class="apa-box">{apa}</div></div>')

    # figures
    figs_html = ""
    for fb in figs_b:
        b64 = base64.b64encode(fb).decode()
        figs_html += (f'<div class="fig-wrap"><img src="data:image/png;base64,{b64}" '
                      f'style="width:100%;max-width:960px;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.12);"/></div>')

    css = """<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:#f0f4f8;color:#1e293b;font-size:14px;line-height:1.6;}
.page{max-width:1120px;margin:0 auto;padding:32px 24px 80px;}
.cover{background:linear-gradient(135deg,#0a0a0a 0%,#1a1a2e 50%,#16213e 100%);border-radius:16px;padding:44px 52px;margin-bottom:28px;border-left:6px solid #e94560;box-shadow:0 12px 48px rgba(233,69,96,.2);}
.cover h1{color:#fff;font-size:2rem;font-weight:700;margin-bottom:8px;}
.cover .badge{display:inline-block;background:#e94560;color:#fff;font-size:.7rem;padding:3px 10px;border-radius:20px;font-weight:600;margin-right:6px;}
.meta-tbl{width:100%;border-collapse:collapse;margin-top:20px;}
.meta-tbl td{padding:5px 10px;font-size:.82rem;}
.meta-tbl td.mk{color:#94a3b8;font-weight:600;width:220px;font-family:'DM Mono',monospace;}
.meta-tbl td.mv{color:#e2e8f0;}
.section{background:#fff;border-radius:12px;padding:26px 30px;margin-bottom:22px;box-shadow:0 2px 14px rgba(0,0,0,.06);}
.sec-hdr{background:linear-gradient(90deg,#1a1a2e,#16213e);color:#e2e8f0;padding:11px 20px;border-radius:8px 8px 0 0;font-weight:700;font-size:.82rem;letter-spacing:.8px;margin:-26px -30px 22px;font-family:'DM Mono',monospace;border-bottom:3px solid #e94560;}
.sub-hdr{background:#f1f5f9;color:#1a1a2e;padding:8px 14px;border-radius:6px;font-weight:600;font-size:.8rem;margin:18px 0 10px;border-left:3px solid #e94560;}
.rec-box{background:linear-gradient(135deg,#f0f9ff,#e0f2fe);border-left:4px solid #0284c7;padding:12px 16px;border-radius:0 8px 8px 0;font-size:.82rem;color:#0c4a6e;margin:12px 0;line-height:1.75;}
.rtbl{width:100%;border-collapse:collapse;font-family:'DM Mono',monospace;font-size:.73rem;margin-bottom:6px;table-layout:fixed;word-wrap:break-word;}
.rtbl th{background:#1a1a2e;color:#e2e8f0;padding:8px 10px;text-align:center;font-weight:600;border:1px solid #334155;white-space:normal;font-size:.71rem;}
.rtbl td{padding:6px 10px;border:1px solid #e2e8f0;text-align:right;white-space:normal;word-wrap:break-word;}
.rtbl tr.even td{background:#fff;}.rtbl tr.odd td{background:#f8fafc;}
.rtbl td.left{text-align:left;font-weight:500;background:#f1f5f9!important;}
.tbl-note{font-size:.73rem;color:#64748b;font-style:italic;margin-top:8px;line-height:1.6;}
.interp{padding:12px 18px;border-radius:0 10px 10px 0;margin:10px 0;font-size:.86rem;line-height:1.8;border-left:4px solid #0284c7;background:linear-gradient(135deg,#f8fafc,#f1f5f9);}
.interp b{color:#0284c7;}.interp.sig{border-left-color:#16a34a;background:linear-gradient(135deg,#f0fdf4,#dcfce7);}.interp.sig b{color:#16a34a;}
.interp.nonsig{border-left-color:#dc2626;background:linear-gradient(135deg,#fef2f2,#fee2e2);}
.apa-label{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;}
.apa-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;font-family:'DM Mono',monospace;font-size:.78rem;color:#1e293b;line-height:1.8;}
.warn-box{background:#fffbeb;border-left:4px solid #f59e0b;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#92400e;margin:.4rem 0;}
.info-box{background:#eff6ff;border-left:4px solid #3b82f6;padding:.7rem 1rem;border-radius:0 6px 6px 0;font-size:.82rem;color:#1e40af;margin:.4rem 0;}
.fig-wrap{text-align:center;margin:18px 0;}
.footer{text-align:center;color:#94a3b8;font-size:.72rem;margin-top:44px;padding-top:16px;border-top:1px solid #e2e8f0;line-height:1.8;}
</style>"""

    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>ANOVA \u2014 {test_type}</title>{css}</head>
<body><div class="page">
<div class="cover">
  <h1>&#128202; {test_type} Report</h1>
  <div style="margin-bottom:20px;">
    <span class="badge">SPSS-Equivalent</span><span class="badge">Type III SS</span><span class="badge">GG/HF Corrections</span>
  </div>
  {meta_html}
  <div style="margin-top:18px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12);">
    <p style="color:#94a3b8;font-size:.76rem;margin:0 0 8px;">&#9749; Support this work &mdash; scan QRIS</p>
    <img src="https://muhaiminabdullah.com/media/thumbnails/QRIS-muhaiminabdullahdotcom-340x480.jpeg"
         style="width:130px;border-radius:8px;border:2px solid #e94560;display:block;"/>
  </div>
</div>
<div class="section"><div class="sec-hdr">1. NORMALITY &amp; ASSUMPTION TESTS</div>{norm_html}{assume_html}</div>
<div class="section"><div class="sec-hdr">2. DESCRIPTIVE STATISTICS</div>{desc_html}</div>
<div class="section"><div class="sec-hdr">3. ANOVA TABLE</div>{anova_html}</div>
<div class="section"><div class="sec-hdr">4. EFFECT SIZE &amp; POWER</div>{es_html}
  <p class="tbl-note">Partial \u03b7\u00b2: \u2265.01 small, \u2265.06 medium, \u2265.14 large (Cohen, 1988).</p></div>
<div class="section"><div class="sec-hdr">5. POST-HOC TESTS</div>{ph_html if ph_html else "<p>No post-hoc tests conducted.</p>"}</div>
<div class="section"><div class="sec-hdr">6. INTERPRETATION &amp; APA WRITE-UP</div>{interp_html}</div>
<div class="section"><div class="sec-hdr">7. DIAGNOSTIC PLOTS</div>{figs_html}</div>
<div class="footer">Generated by Inferential Statistics by MA &nbsp;&middot;&nbsp; {test_type} &nbsp;&middot;&nbsp; {datetime.now().strftime("%B %d, %Y at %H:%M")}</div>
</div></body></html>"""
    return html.encode("utf-8")


def _build_csv_anova(R, meta, interps, apa, alpha, test_type):
    """Build multi-section CSV for ANOVA — complete, matching Streamlit display."""
    parts = [f"INFERENTIAL STATISTICS BY MA \u2014 {test_type.upper()}\n",
             f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}\n"]

    # meta
    parts.append("\n=== ANALYSIS INFORMATION ===\n"
                 + pd.DataFrame([{"Parameter":k,"Value":str(v)} for k,v in meta.items()]).to_csv(index=False))

    # normality
    norm_rows = []
    for nm in R["normality"]:
        norm_rows.append({"Variable/Cell":nm["label"],"N":nm["n"],"Total N":nm["total_n"],
            "SW W":round(nm["sw_W"],3),"SW Sig.":_p(nm["sw_p"]),
            "KS D":round(nm["ks_D"],3) if not np.isnan(nm["ks_D"]) else "",
            "KS Sig.":_p(nm["ks_p"]),"Primary Criterion":nm["primary_label"],
            "Decision":"Normal" if nm["pass"] else "Non-Normal"})
    parts.append("\n=== NORMALITY TESTS ===\n" + pd.DataFrame(norm_rows).to_csv(index=False))

    # sphericity
    sph = R.get("sphericity")
    if sph and R.get("k",2) > 2:
        sph_rows = [{"Mauchly W":round(sph["W"],4),"chi2":round(sph["chi2"],3),
                     "df":sph["df"],"Sig.":_p(sph["p"]),
                     "eps_GG":round(sph["epsilon_gg"],4),"eps_HF":round(sph["epsilon_hf"],4),
                     "Sphericity Assumed":sph["sphericity_assumed"],"Correction":sph["correction"]}]
        parts.append("\n=== MAUCHLY\u2019S TEST OF SPHERICITY ===\n"
                     + pd.DataFrame(sph_rows).to_csv(index=False))

    # levene
    lev = R.get("levene")
    if lev is not None and isinstance(lev, pd.DataFrame) and not lev.empty:
        parts.append("\n=== LEVENE\u2019S TEST ===\n" + lev.to_csv(index=False))
    elif lev is not None and isinstance(lev, dict):
        parts.append("\n=== LEVENE\u2019S TEST ===\n"
                     + pd.DataFrame([{"F":round(lev["F"],3),"df1":lev["df1"],"df2":lev["df2"],
                                       "Sig.":_p(lev["Sig."]),"Equal Variances":lev["equal_var"]}])
                     .to_csv(index=False))

    # descriptives
    desc = R["desc"].copy()
    for c in desc.select_dtypes(include=float).columns:
        desc[c] = desc[c].apply(lambda v: round(v,3) if not np.isnan(v) else "")
    parts.append("\n=== DESCRIPTIVE STATISTICS ===\n" + desc.to_csv(index=False))

    # ANOVA table — format p correctly (not 0.0)
    if "anova_table" in R and not R["anova_table"].empty:
        at = R["anova_table"].copy()
        for c in ["p","p (GG)"]:
            if c in at.columns:
                at[c] = at[c].apply(lambda v: _p(v) if isinstance(v,float) and not np.isnan(v) else "")
        for c in ["SS","MS","F","Partial η²","ε (GG)"]:
            if c in at.columns:
                at[c] = at[c].apply(lambda v: round(v,3) if isinstance(v,float) and not np.isnan(v) else "")
        parts.append("\n=== ANOVA TABLE ===\n" + at.to_csv(index=False))

    # effect sizes
    if test_type == "One-Way ANOVA":
        pwr = R.get("power", float("nan"))
        es_rows = [{"Measure":"Partial η²","Value":round(R["partial_eta2"],4),"Interpretation":R["eta2_label"]},
                   {"Measure":"ω²","Value":round(R["omega2"],4),"Interpretation":R["omega2_label"]},
                   {"Measure":"Cohen's f","Value":round(R["cohens_f"],4),"Interpretation":""},
                   {"Measure":"Power","Value":f"{pwr*100:.1f}%" if not np.isnan(pwr) else "N/A","Interpretation":""}]
        parts.append("\n=== EFFECT SIZES & POWER ===\n" + pd.DataFrame(es_rows).to_csv(index=False))
    elif test_type in ["Two-Way Factorial ANOVA","Mixed ANOVA"]:
        srcs = ([(R["factor_a"],R["es_A"]),(R["factor_b"],R["es_B"]),(f"{R['factor_a']} × {R['factor_b']}",R["es_AB"])]
                if test_type=="Two-Way Factorial ANOVA" else
                [(R["between_col"],R["es_A"]),("Time",R["es_B"]),(f"{R['between_col']} × Time",R["es_AB"])])
        es_rows = [{"Source":lbl,"Partial η²":round(es["partial_eta2"],4),"Interpretation":es["label"],
                    "Power":f"{es['power']*100:.1f}%" if not np.isnan(es["power"]) else "N/A"}
                   for lbl,es in srcs]
        parts.append("\n=== EFFECT SIZES & POWER ===\n" + pd.DataFrame(es_rows).to_csv(index=False))

    # post-hoc
    if test_type == "One-Way ANOVA" and not R.get("posthoc",pd.DataFrame()).empty:
        ph = R["posthoc"].copy()
        for c in ph.select_dtypes(include=float).columns:
            ph[c] = ph[c].apply(lambda v: round(v,4) if not np.isnan(v) else "")
        parts.append("\n=== POST-HOC TESTS ===\n" + ph.to_csv(index=False))
    elif test_type == "Repeated Measures ANOVA" and not R.get("posthoc",pd.DataFrame()).empty:
        ph = R["posthoc"].copy()
        for c in ph.select_dtypes(include=float).columns:
            ph[c] = ph[c].apply(lambda v: round(v,4) if not np.isnan(v) else "")
        parts.append("\n=== POST-HOC PAIRWISE ===\n" + ph.to_csv(index=False))
    elif test_type == "Mixed ANOVA":
        ph_bt = R.get("posthoc_between", pd.DataFrame())
        ph_wt = R.get("posthoc_within",  pd.DataFrame())
        if not ph_bt.empty:
            for c in ph_bt.select_dtypes(include=float).columns:
                ph_bt[c] = ph_bt[c].apply(lambda v: round(v,4) if not np.isnan(v) else "")
            parts.append("\n=== POST-HOC: BETWEEN-GROUP ===\n" + ph_bt.to_csv(index=False))
        if not ph_wt.empty:
            for c in ph_wt.select_dtypes(include=float).columns:
                ph_wt[c] = ph_wt[c].apply(lambda v: round(v,4) if not np.isnan(v) else "")
            parts.append("\n=== POST-HOC: WITHIN-SUBJECT ===\n" + ph_wt.to_csv(index=False))

    # interpretation & APA
    clean_interps = [__import__("re").sub(r"<[^>]+>","",l) for l in interps]
    parts.append("\n=== INTERPRETATION ===\n"
                 + pd.DataFrame({"Line":range(1,len(clean_interps)+1),"Interpretation":clean_interps})
                 .to_csv(index=False))
    apa_clean = __import__("re").sub(r"<[^>]+>","",apa)
    parts.append(f"\n=== APA 7TH EDITION WRITE-UP ===\n{apa_clean}\n")
    return "\n".join(parts).encode("utf-8")


with dc1:
    with st.spinner("Generating HTML report\u2026"):
        html_data = _build_html_anova(R, meta, interps, apa, figs_b, alpha, test_type)
    st.download_button(
        "&#127760; HTML Report (Full)",
        html_data,
        f"ANOVA_{test_type.replace(' ','_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
        "text/html", use_container_width=True,
    )

with dc2:
    csv_data = _build_csv_anova(R, meta, interps, apa, alpha, test_type)
    st.download_button(
        "&#128221; CSV Tables",
        csv_data,
        f"ANOVA_{test_type.replace(' ','_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        "text/csv", use_container_width=True,
    )
